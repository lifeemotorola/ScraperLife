from setuptools import setup, find_packages

setup(
    name="homemaker",
    version="0.1.0",
    description="Homemaker add-on",
    author="Bruno Postle",
    author_email="bruno@postle.net",
    url="https://github.com/brunopostle/homemaker-addon",
    license="GPL-3.0-or-later",
    classifiers=[
        "License :: OSI Approved :: GNU General Public License v3 or later (GPLv3+)",
    ],
    packages=find_packages(
        include=["topologist", "topologist.*", "molior", "molior.*"]
    ),
    install_requires=["topologic_core", "pyaml", "numpy", "ifcopenshell", "shapely"],
)

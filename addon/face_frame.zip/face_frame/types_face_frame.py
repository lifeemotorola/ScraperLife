"""Face frame cabinet construction classes.

Phase 3a deliverable: class hierarchy and a minimal carcass build.
- FaceFrameCabinet: base class for all face frame cabinets. No drivers.
  All dimension propagation runs through cabinet.recalculate().
- BaseFaceFrameCabinet, UpperFaceFrameCabinet, TallFaceFrameCabinet,
  LapDrawerFaceFrameCabinet: subclasses with type-specific defaults.
- FaceFrameBay: bay cage object (Phase 3b will populate bay contents).

Carcass conventions match frameless (same CabinetPart GeoNode setup):
- Cabinet origin at back-left, floor level
- +X is right, -Y is forward (depth runs in -Y), +Z is up
- Back panel sits at y=0; front of cabinet is at y=-depth
- Mirror Y=True on a part means it extrudes in -Y from its origin
- Mirror Z=True means it extrudes in -Z from its origin
"""
import bpy
import bmesh
import math
import re
from types import SimpleNamespace
import os
from contextlib import contextmanager

from mathutils import Vector, Matrix, Euler

from ... import hb_utils
from ...hb_types import (CabinetPartModifier, GeoNodeCage, GeoNodeCutpart,
                        GeoNodeDrawerBox, GeoNodeRectangle)
from ...units import inch
from ...hb_details import apply_label_style
from ..common import types_appliances
from ..common import turned_leg
from ..frameless.types_frameless import CabinetPart
from ..frameless.types_products import HalfWall as _FramelessHalfWall
from ..frameless.types_products import SupportFrame as _FramelessSupportFrame
from . import solver_face_frame as solver
from . import island_pair
from . import shelf_nosing
from . import wood_top_edge
from . import decorative_corner
from . import cabinet_column
from . import bar_storage
from . import pulls


# ---------------------------------------------------------------------------
# Identity tags
# ---------------------------------------------------------------------------
TAG_CABINET_CAGE = 'IS_FACE_FRAME_CABINET_CAGE'
TAG_BAY_CAGE = 'IS_FACE_FRAME_BAY_CAGE'
TAG_OPENING_CAGE = 'IS_FACE_FRAME_OPENING_CAGE'
TAG_SPLIT_NODE = 'IS_FACE_FRAME_SPLIT_NODE'
# Non-cabinet face-frame PRODUCTS (e.g. the Half Wall) that should still
# behave like a cabinet for selection purposes: their cage shows + is the
# selection target in 'Cabinets' selection mode. They are NOT TAG_CABINET_CAGE
# (that would route them through the cabinet recalc / modify / carcass
# machinery, which would wreck their custom geometry) - the selection mode
# operator special-cases this tag the same way it does IS_APPLIANCE.
TAG_PRODUCT_CAGE = 'IS_FACE_FRAME_PRODUCT_CAGE'
# Interior tree tags. Internal nodes carry TAG_INTERIOR_SPLIT_NODE; leaves
# carry TAG_INTERIOR_REGION. Both live as cage children of an opening.
TAG_INTERIOR_SPLIT_NODE = 'IS_INTERIOR_SPLIT_NODE'
TAG_INTERIOR_REGION = 'IS_INTERIOR_REGION'

# Reentrance guards. Bay-level prop writes inside recalculate() (such as
# the width redistribution in _distribute_bay_widths) fire those props'
# update callbacks, which would normally call back into recalculate. The
# guards short-circuit that cycle.
#
# _RECALCULATING: cabinet root IDs currently inside recalculate(). Update
#     callbacks consult this and exit early if the cabinet is already in
#     the middle of a recalc.
# _DISTRIBUTING_WIDTHS: cabinet root IDs whose bay widths are currently
#     being written by _distribute_bay_widths. The bay width update callback
#     consults this to distinguish system writes (no auto-lock) from user
#     edits (auto-lock so the value holds during future redistributions).
# _RECALC_SUSPEND_DEPTH: refcounted suspend of recalculate_face_frame_cabinet.
#     While > 0, recalcs are coalesced by cabinet name into _PENDING_RECALC_NAMES
#     instead of executing. The outermost resume drains the pending set and
#     runs each cabinet's recalc exactly once. Use the suspend_recalc() context
#     manager - inner suspends stack and only the outermost exit drains.
_RECALCULATING = set()
_DISTRIBUTING_WIDTHS = set()
_RECALC_SUSPEND_DEPTH = 0
_PENDING_RECALC_NAMES = set()


@contextmanager
def suspend_recalc():
    """Suspend cabinet recalcs across a block of property writes.

    Pending recalcs (whether from update callbacks or explicit calls) are
    coalesced and run once when the outermost suspend exits. Use this
    around any operation that performs many property writes that would
    each trigger a full cabinet recalc - the actual layout work happens
    once at the end instead of N times during.
    """
    global _RECALC_SUSPEND_DEPTH
    _RECALC_SUSPEND_DEPTH += 1
    try:
        with hb_utils.children_index():
            yield
    finally:
        _RECALC_SUSPEND_DEPTH -= 1
        if _RECALC_SUSPEND_DEPTH == 0:
            pending = list(_PENDING_RECALC_NAMES)
            _PENDING_RECALC_NAMES.clear()
            for cab_name in pending:
                cab = bpy.data.objects.get(cab_name)
                if cab is None:
                    continue
                # Don't let one cabinet's recalc failure block the rest.
                try:
                    recalculate_face_frame_cabinet(cab)
                except Exception:
                    pass


# Single string-enum role for parts.
PART_ROLE_LEFT_SIDE = 'LEFT_SIDE'
PART_ROLE_RIGHT_SIDE = 'RIGHT_SIDE'
# Upper half of a side panel that has been seamed. A finished end past
# the length stock comes in has to be made from two boards; the user
# picks the joint height and the side builds as two parts, the base
# role carrying the piece below the seam and this one the piece above.
# Own roles rather than a second LEFT_SIDE so the many
# next(child with role == LEFT_SIDE) lookups keep finding the one part
# they mean; every pass that has to see both lists them together.
PART_ROLE_LEFT_SIDE_SEAM = 'LEFT_SIDE_SEAM'
PART_ROLE_RIGHT_SIDE_SEAM = 'RIGHT_SIDE_SEAM'
SIDE_SEAM_ROLE_FOR = {
    PART_ROLE_LEFT_SIDE: PART_ROLE_LEFT_SIDE_SEAM,
    PART_ROLE_RIGHT_SIDE: PART_ROLE_RIGHT_SIDE_SEAM,
}
# Shortest piece worth making on either side of a seam. A joint closer
# than this to an end is a sliver the shop would not cut, so the seam is
# ignored rather than built.
MIN_SEAM_PIECE = inch(3.0)
PART_ROLE_TOP = 'TOP'  # solid top panel for Upper / Tall (Base / Lap use stretchers)
PART_ROLE_FRONT_STRETCHER = 'FRONT_STRETCHER'
PART_ROLE_REAR_STRETCHER = 'REAR_STRETCHER'
# Workstation sink base: the aprons the sink hangs between, the
# partitions that carry it, and the cleats under them.
PART_ROLE_GALLEY_APRON = 'GALLEY_APRON'
PART_ROLE_GALLEY_PARTITION = 'GALLEY_PARTITION'
PART_ROLE_GALLEY_CLEAT = 'GALLEY_CLEAT'
PART_ROLE_BOTTOM = 'BOTTOM'
PART_ROLE_BACK = 'BACK'
# Finished bottom (uppers): an applied finish panel under the carcass
# bottom with an LED route cut near its front edge, plus an optional
# area light in the route for renders. Managed parts (built / cleaned
# by _apply_finished_bottom each recalc), not part of any wipe set.
PART_ROLE_FINISHED_BOTTOM = 'FINISHED_BOTTOM'
# finished_bottom_bays holds the carcass-bottom segments the condition
# reaches: a list of segment keys, EMPTY for all of them. A cabinet can
# also want the condition for a mid-rail shelf and for no bottom at all
# - a refrigerator surround finishing the shelf over the appliance -
# and empty cannot say that, so this sentinel does.
FINISHED_BOTTOM_BAYS_NONE = 'NONE'
PART_ROLE_FB_LED_CUTTER = 'FINISHED_BOTTOM_LED_CUTTER'
PART_ROLE_FB_LIGHT = 'FINISHED_BOTTOM_LIGHT'
# Visible LED diffuser: a thin emissive strip mesh up inside the route,
# so the glow has a visible source when looking up at the cabinet (the
# area light itself renders as nothing).
PART_ROLE_FB_LED_STRIP = 'FINISHED_BOTTOM_LED_STRIP'
PART_ROLE_TOE_KICK_SUBFRONT = 'TOE_KICK_SUBFRONT'
# Second beam of the sub-base, run near the back to carry the back
# edge of the carcass bottom (see solver.kick_subrear_segments).
PART_ROLE_TOE_KICK_SUBREAR = 'TOE_KICK_SUBREAR'
PART_ROLE_FINISH_TOE_KICK = 'FINISH_TOE_KICK'
PART_ROLE_LEFT_CORNER_FINISH_KICK = 'LEFT_CORNER_FINISH_KICK'
PART_ROLE_RIGHT_CORNER_FINISH_KICK = 'RIGHT_CORNER_FINISH_KICK'
PART_ROLE_MID_FINISH_KICK = 'MID_FINISH_KICK'
PART_ROLE_LEFT_KICK_RETURN = 'LEFT_KICK_RETURN'
PART_ROLE_RIGHT_KICK_RETURN = 'RIGHT_KICK_RETURN'
# Loose toe kick ladder sub-base (toe_kick_type == 'LOOSE'): a freestanding
# frame the floated carcass sits on - front + rear rail spanning between two
# front-to-back end boards. All four are finished-material parts.
PART_ROLE_LOOSE_KICK_FRONT = 'LOOSE_KICK_FRONT'
PART_ROLE_LOOSE_KICK_REAR = 'LOOSE_KICK_REAR'
PART_ROLE_LOOSE_KICK_END_LEFT = 'LOOSE_KICK_END_LEFT'
PART_ROLE_LOOSE_KICK_END_RIGHT = 'LOOSE_KICK_END_RIGHT'

# Leg product (slim face-frame post / filler). Built by a dedicated
# product class that bypasses the bay/solver pipeline; all parts are
# finished-material.
LEG_PRODUCT_TAG = 'IS_LEG_PRODUCT'
PART_ROLE_LEG_PANEL_LEFT = 'LEG_PANEL_LEFT'
PART_ROLE_LEG_PANEL_RIGHT = 'LEG_PANEL_RIGHT'
PART_ROLE_LEG_STILE = 'LEG_STILE'
PART_ROLE_LEG_TK_STILE = 'LEG_TK_STILE'
PART_ROLE_LEG_TK_FILLER = 'LEG_TK_FILLER'
PART_ROLE_LEG_FINISH_KICK = 'LEG_FINISH_KICK'
# Leg product v2: finished front bands + interior back / nailers.
PART_ROLE_LEG_FINISH_X_LEFT = 'LEG_FINISH_X_LEFT'
PART_ROLE_LEG_FINISH_X_RIGHT = 'LEG_FINISH_X_RIGHT'
PART_ROLE_LEG_BACK = 'LEG_BACK'
PART_ROLE_LEG_NAILER_LEFT = 'LEG_NAILER_LEFT'
PART_ROLE_LEG_NAILER_RIGHT = 'LEG_NAILER_RIGHT'
# Curved support leg: the whole leg as one profiled plywood panel.
PART_ROLE_LEG_CURVED_PANEL = 'LEG_CURVED_PANEL'

# Floating shelf (wall-mounted hollow slab). Built by a dedicated
# product class that bypasses the bay/solver pipeline; finished boards.
FLOATING_SHELF_TAG = 'IS_FLOATING_SHELF'
# Wood top (countertop part): a single finished slab product that snaps
# onto cabinet tops; see WoodTopFaceFrameCabinet.
WOOD_TOP_TAG = 'IS_WOOD_TOP'
PART_ROLE_WOOD_TOP = 'WOOD_TOP'
PART_ROLE_WOOD_TOP_EDGE = 'WOOD_TOP_EDGE'
PART_ROLE_SHELF_FRONT = 'SHELF_FRONT'
PART_ROLE_SHELF_TOP = 'SHELF_TOP'
PART_ROLE_SHELF_BOTTOM = 'SHELF_BOTTOM'
PART_ROLE_SHELF_PANEL_LEFT = 'SHELF_PANEL_LEFT'
PART_ROLE_SHELF_PANEL_RIGHT = 'SHELF_PANEL_RIGHT'

# Valance product (a decorative board spanning the gap between two
# upper cabinets). Same non-bay pattern as the floating shelf.
MANTLE_TAG = 'IS_MANTLE_PRODUCT'
PART_ROLE_MANTLE_FRONT = 'MANTLE_FRONT'
PART_ROLE_MANTLE_TOP = 'MANTLE_TOP'
PART_ROLE_MANTLE_BOTTOM = 'MANTLE_BOTTOM'
PART_ROLE_MANTLE_PANEL_LEFT = 'MANTLE_PANEL_LEFT'
PART_ROLE_MANTLE_PANEL_RIGHT = 'MANTLE_PANEL_RIGHT'
PART_ROLE_MANTLE_CROWN_FRONT = 'MANTLE_CROWN_FRONT'
PART_ROLE_MANTLE_CROWN_LEFT = 'MANTLE_CROWN_LEFT'
PART_ROLE_MANTLE_CROWN_RIGHT = 'MANTLE_CROWN_RIGHT'
PART_ROLE_MANTLE_CROWN_SWEEP = 'MANTLE_CROWN_SWEEP'
PART_ROLE_MANTLE_LEG_FRONT_L = 'MANTLE_LEG_FRONT_L'
PART_ROLE_MANTLE_LEG_FRONT_R = 'MANTLE_LEG_FRONT_R'
PART_ROLE_MANTLE_LEG_OUT_L = 'MANTLE_LEG_OUT_L'
PART_ROLE_MANTLE_LEG_OUT_R = 'MANTLE_LEG_OUT_R'
PART_ROLE_MANTLE_LEG_IN_L = 'MANTLE_LEG_IN_L'
PART_ROLE_MANTLE_LEG_IN_R = 'MANTLE_LEG_IN_R'
PART_ROLE_MANTLE_HEADER_FRONT = 'MANTLE_HEADER_FRONT'
PART_ROLE_MANTLE_HEADER_BOTTOM = 'MANTLE_HEADER_BOTTOM'
PART_ROLE_MANTLE_BASE_SWEEP = 'MANTLE_BASE_SWEEP'
# Tag key on PanelFaceFrameCabinet roots serving as a surround's paneled
# leg / header fronts (value = which front the panel is).
TAG_MANTLE_PANEL = 'hb_mantle_panel_role'
# Hidden prism cutters mitring a box product's front board into its
# finished end panels (floating shelf / contemporary mantle).
PART_ROLE_BOX_MITER_CUTTER = 'BOX_MITER_CUTTER'

VALANCE_TAG = 'IS_VALANCE_PRODUCT'
PART_ROLE_VALANCE_BOARD = 'VALANCE_BOARD'
PART_ROLE_VALANCE_COVER = 'VALANCE_COVER'
PART_ROLE_VALANCE_PANEL_LEFT = 'VALANCE_PANEL_LEFT'
PART_ROLE_VALANCE_PANEL_RIGHT = 'VALANCE_PANEL_RIGHT'
PART_ROLE_BLIND_PANEL_LEFT = 'BLIND_PANEL_LEFT'
PART_ROLE_BLIND_PANEL_RIGHT = 'BLIND_PANEL_RIGHT'

# 1/4" thick decorative panel that closes off the dead corner space when
# the cabinet sits next to a perpendicular cabinet on an adjacent wall.
BLIND_PANEL_THICKNESS = inch(0.25)

# Slat-stack tambour over the garage-level blind section (the straight
# sibling of the corner garage tambour). Plain purchased-stock mesh, not
# a CABINET_PART - the material walk's plain-mesh branch finishes it.
PART_ROLE_BLIND_SECTION_TAMBOUR = 'BLIND_SECTION_TAMBOUR'

# Garage-level dead-zone face frame (blind appliance garage): a stile at
# the cabinet end plus bottom / garage-top rail extensions across the
# dead zone, so the garage-level blind section is a real framed opening.
PART_ROLE_BLIND_GARAGE_STILE = 'BLIND_GARAGE_STILE'
PART_ROLE_BLIND_GARAGE_RAIL = 'BLIND_GARAGE_RAIL'

# Face frame member roles (rails and stiles). Phase 3a doesn't create any
# of these yet; defined here so the "Face Frame" selection mode has a known
# set of roles to filter on once Phase 3b builds them.
PART_ROLE_TOP_RAIL = 'TOP_RAIL'
PART_ROLE_BOTTOM_RAIL = 'BOTTOM_RAIL'
PART_ROLE_LEFT_STILE = 'LEFT_STILE'
PART_ROLE_RIGHT_STILE = 'RIGHT_STILE'
# Optional 'stile in lieu of leg' lower stiles on a refrigerator cabinet
# (floor -> top of fridge opening). Built only on RefrigeratorCabinet.
PART_ROLE_LEFT_REFRIG_STILE = 'LEFT_REFRIG_STILE'
PART_ROLE_RIGHT_REFRIG_STILE = 'RIGHT_REFRIG_STILE'
PART_ROLE_MID_STILE = 'MID_STILE'
# Companion RIGHT half of a mid stile sitting on an angled_multi bend:
# the stile splits lengthwise, each half lying in its side's front
# plane, mitered together at the bend (see solver.mid_stile_bend_
# halves). The original MID_STILE part becomes the LEFT half.
PART_ROLE_MID_STILE_HALF = 'MID_STILE_BEND_HALF'
PART_ROLE_MID_RAIL = 'MID_RAIL'
# Filler stiles in a front-dropped bay's open band (above the dropped
# top rail), fitting a farm sink / cooktop to the drop. Keyed per bay +
# side and reconciled from solver.front_drop_filler_segments.
PART_ROLE_FRONT_DROP_FILLER = 'FRONT_DROP_FILLER'

# Splitter members and backings created by H/V splits inside a single
# bay. Mid rail / mid stile sit in the face frame plane; division /
# shelf are carcass-deep panels behind them. Defined here (above the
# FACE_FRAME_PART_ROLES set) so they're in scope when the set is built.
PART_ROLE_BAY_MID_RAIL = 'BAY_MID_RAIL'
PART_ROLE_BAY_MID_STILE = 'BAY_MID_STILE'
PART_ROLE_BAY_DIVISION = 'BAY_DIVISION'
PART_ROLE_BAY_SHELF = 'BAY_SHELF'

FACE_FRAME_PART_ROLES = frozenset({
    PART_ROLE_TOP_RAIL, PART_ROLE_BOTTOM_RAIL,
    PART_ROLE_LEFT_STILE, PART_ROLE_RIGHT_STILE,
    PART_ROLE_MID_STILE, PART_ROLE_MID_STILE_HALF, PART_ROLE_MID_RAIL,
    PART_ROLE_BAY_MID_RAIL, PART_ROLE_BAY_MID_STILE,
    PART_ROLE_FRONT_DROP_FILLER,
    PART_ROLE_BLIND_GARAGE_STILE, PART_ROLE_BLIND_GARAGE_RAIL,
})

BAY_SPLITTER_ROLES = frozenset({
    PART_ROLE_BAY_MID_RAIL, PART_ROLE_BAY_MID_STILE,
})
BAY_BACKING_ROLES = frozenset({
    PART_ROLE_BAY_DIVISION, PART_ROLE_BAY_SHELF,
})


# Highlight colour for a face frame part the user has UNLOCKED (manually
# overridden). Shown in Face Frame selection mode -- amber, slightly
# transparent -- so changed-from-default parts stand out from the default
# light-blue highlight. Used by the toggle_mode operator AND the post-recalc
# highlight reapply below, so both colouring paths agree.
FACE_FRAME_UNLOCKED_COLOR = (0.95, 0.55, 0.10, 0.6)


def part_width_is_unlocked(obj):
    """True when this face frame part carries a manual width override (its
    unlock flag is set), so Face Frame selection mode can flag it as
    changed-from-default. Only the width-overridable roles can be unlocked;
    every other part returns False.
    """
    role = obj.get('hb_part_role')
    if role not in FACE_FRAME_PART_ROLES:
        return False
    root = find_cabinet_root(obj)
    if root is None:
        return False
    cab = root.face_frame_cabinet
    if role == PART_ROLE_LEFT_STILE:
        return bool(cab.unlock_left_stile)
    if role == PART_ROLE_RIGHT_STILE:
        return bool(cab.unlock_right_stile)
    if role == PART_ROLE_MID_STILE:
        msi = obj.get('hb_mid_stile_index', 0)
        if 0 <= msi < len(cab.mid_stile_widths):
            return bool(cab.mid_stile_widths[msi].unlock)
        return False
    if role in (PART_ROLE_TOP_RAIL, PART_ROLE_BOTTOM_RAIL):
        attr = ('unlock_top_rail' if role == PART_ROLE_TOP_RAIL
                else 'unlock_bottom_rail')
        # Cabinet-level rail unlock (the lock toggle in the cabinet prompts,
        # draw_face_frame_defaults) overrides every bay's rail, so flag the
        # part when it is set -- the same name lives on the bay, which the
        # right-click set_part_width path flips. Either one means overridden.
        if getattr(cab, attr):
            return True
        start = obj.get('hb_segment_start_bay', 0)
        bay = None
        for child in root.children:
            if child.get(TAG_BAY_CAGE) and child.get('hb_bay_index') == start:
                bay = child
                break
        if bay is None:
            return False
        return bool(getattr(bay.face_frame_bay, attr))
    if role in (PART_ROLE_BAY_MID_RAIL, PART_ROLE_BAY_MID_STILE):
        split_name = obj.get('hb_split_node_name')
        split = bpy.data.objects.get(split_name) if split_name else None
        if split is None:
            return False
        sp = split.face_frame_split
        if sp.unlock_splitter_width:
            return True
        idx = obj.get('hb_splitter_index', 0)
        coll = sp.splitter_widths
        return 0 <= idx < len(coll) and bool(coll[idx].active)
    return False

# Carcass interior partition behind each mid stile (one per gap).
PART_ROLE_MID_DIVISION = 'MID_DIVISION'

# Filler attached to a mid-div on the shallower bay's side, covering
# the mid-stile back-face overhang in the Z range between adjacent
# bays' floors when those floors differ.
PART_ROLE_PARTITION_SKIN = 'PARTITION_SKIN'

# Front parts (children of opening cages). Roles are reserved here so
# selection-mode filtering can pick them up; only DOOR is implemented in
# this pass. Drawer fronts and pullouts will use their own roles when
# they land.
PART_ROLE_DOOR = 'DOOR'
PART_ROLE_DRAWER_FRONT = 'DRAWER_FRONT'
PART_ROLE_PULLOUT_FRONT = 'PULLOUT_FRONT'
PART_ROLE_FALSE_FRONT = 'FALSE_FRONT'
PART_ROLE_INSET_PANEL = 'INSET_PANEL'
# Tilt-out: a drawer-styled front that tilts down on a BOTTOM hinge.
# Own role (not FALSE_FRONT) so it's drawer-styled but carries a pull and
# a swing; not in the drawer-box role set, so it gets no slide box.
PART_ROLE_TILT_OUT = 'TILT_OUT'
# ADA apron: the raked panel that closes a knee-clearance sink opening.
# Accessible sink: the cutter that rakes the carcass away underneath,
# and the tag on the product that carries it. Same lazy cutter +
# boolean pattern as the tip-up wedge.
PART_ROLE_ADA_CUTTER = 'ADA_CUTTER'
ADA_CUT_MOD_NAME = 'Knee Clearance'
ADA_SINK_TAG = 'IS_ADA_SINK'
PART_ROLE_APRON = 'APRON'
# Drawer-look door: a working DOOR leaf wearing N applied drawer-front
# panels (proud of the leaf, with reveal gaps that read as faux mid
# rails) so it looks like a drawer stack but opens as one door. Built in
# _update_fronts_in_opening as children of the door part (inherit swing);
# carry no DOOR_STYLE_NAME, so downstream consumers see one door.
PART_ROLE_DRAWER_LOOK_FRONT = 'DRAWER_LOOK_FRONT'
# Faux mid-rail strip between drawer-look fronts, added only for FULL
# INSET (proud of the inset fronts, like a real inset face frame).
PART_ROLE_DRAWER_LOOK_RAIL = 'DRAWER_LOOK_RAIL'
DRAWER_LOOK_REVEAL = inch(0.125)            # gap between applied fronts
DRAWER_LOOK_TALLER_TOP_FACTOR = 1.5         # top front height vs each other

# Applied finished-back part: a 3/4 panel layered on top of the carcass
# back when back_finished_end_condition is FINISHED. Carcass back stays
# at its normal back_thickness (1/4 typically); this part adds the
# visible finish surface behind it.
PART_ROLE_FINISHED_BACK = 'FINISHED_BACK'

# Finished-side return closeout. When a FINISHED side is extended back past
# a FINISHED back and the user sets a return width, the exposed back corner
# is wrapped by two 3/4 parts: a RETURN panel parallel to the side (its
# depth = the side's extend-back amount) that dies into the finished back,
# and a rear STILE (the outermost/rearmost member) whose width IS the return
# width, running full height to the floor. Managed by
# _reconcile_finished_side_returns; both roles are in _FINISH_EXTERIOR_ROLES.
PART_ROLE_LEFT_SIDE_RETURN = 'LEFT_SIDE_RETURN'
PART_ROLE_RIGHT_SIDE_RETURN = 'RIGHT_SIDE_RETURN'
PART_ROLE_LEFT_SIDE_RETURN_STILE = 'LEFT_SIDE_RETURN_STILE'
PART_ROLE_RIGHT_SIDE_RETURN_STILE = 'RIGHT_SIDE_RETURN_STILE'

# Tag carried by either kind of return member (the flat FINISHED cutpart or
# the PANELED applied-panel root) so the reconciler can find and kind-swap it
# regardless of type. `hb_return_member_kind` ('FINISHED'/'PANELED') records
# which kind is currently built.
TAG_RETURN_MEMBER = 'hb_return_member'

# Back conditions a side return can die into. Any back that presents a
# finished surface qualifies -- the return post simply closes the corner
# and the back field (flat, paneled or textured) butts into it. Shared by
# the geometry gate (_finished_side_return_width) and both UI surfaces
# that draw the return rows.
RETURN_BACK_CONDITIONS = ('FINISHED', 'PANELED', 'BEADBOARD', 'SHIPLAP',
                          'V_GROOVE')

# Side conditions that can carry a return closeout when extended back.
# Same surfaces as the back set: any side with a finished face -- flat,
# paneled or textured -- can wrap its exposed back corner.
RETURN_SIDE_CONDITIONS = ('FINISHED', 'PANELED', 'BEADBOARD', 'SHIPLAP',
                          'V_GROOVE')

# Applied flush-X strip: a 1/4 part covering the front portion of a
# cabinet side when LEFT/RIGHT_finished_end_condition is FLUSH_X. The
# strip's outer face is flush with the FF outer face; its width along
# the cabinet depth is the user's *_flush_x_amount value (typically
# 4"). Used for sides that abut a dishwasher / appliance where a full
# applied panel isn't wanted.
PART_ROLE_FLUSH_X = 'FLUSH_X'
TAG_FLUSH_X_SIDE = 'hb_flush_x_side'
# Strip stock thickness. Also the scribe band the carcass side recedes
# by so the strip's outer face lands on the cabinet's end plane (see
# solver.left_scribe_offset and the corner arm-end reserve).
FLUSH_X_THICKNESS = inch(0.25)
PART_ROLE_FULL_OVERLAY_STILE = 'FULL_OVERLAY_STILE'
TAG_FO_STILE_SIDE = 'hb_fo_stile_side'

# Per-bay finish liner: 1/4 finish-material panels added to the inner
# faces of a bay's opening (left / right / top) when the bay's
# finish_bay flag is set, so the exterior finish reads inside the
# opening. The back and bay floor get no liner - the carcass BACK /
# BOTTOM panels are cut from finish stock instead (TAG_SEGMENT_FINISHED).
# Keyed by bay index + face so they reuse-in-place / sweep cleanly
# across recalcs. See _reconcile_bay_finish_panels.
PART_ROLE_BAY_FINISH = 'BAY_FINISH'
TAG_BAY_FINISH_BAY = 'hb_bay_finish_bay'
TAG_BAY_FINISH_FACE = 'hb_bay_finish_face'
# Which opening within the bay a finish liner belongs to: an opening
# leaf index for a per-opening finish, or -1 for a whole-bay finish.
TAG_BAY_FINISH_OPENING = 'hb_bay_finish_opening'

# Stamped on a segmented carcass panel (BACK / BOTTOM) when the bays it
# spans are a finished region: the panel itself is the finish, so the
# material walk gives it the exterior finish instead of the interior.
# Segments break at finish boundaries so one flag covers the whole part.
TAG_SEGMENT_FINISHED = 'hb_segment_finished'

# Stamped on the part a finished OPENING sits on - the carcass bottom
# for a bottom-most leaf, otherwise the bay shelf / division under it.
# A finished region's floor is never lined; the panel already there is
# cut from finish stock. Re-stamped from scratch every recalc.
TAG_FINISH_FLOOR = 'hb_finish_floor'
FINISH_FLOOR_ROLES = (
    PART_ROLE_BOTTOM, PART_ROLE_BAY_SHELF, PART_ROLE_BAY_DIVISION,
)

# Textured-finish applied panels: 1/4 parts representing beadboard or
# shiplap finishes on a side (LEFT / RIGHT / BACK). The part keeps its
# driven GN cutpart (the L/W/T carrier downstream passes read) but the
# visible geometry is a static python mesh with the texture carved in -
# real quirk-bead grooves for BEADBOARD, nickel-gap plank reveals for
# SHIPLAP - written into the object's mesh data with the GN modifier
# display disabled (same pattern as HB_STATIC_SLAB fronts).
PART_ROLE_BEADBOARD = 'BEADBOARD'
PART_ROLE_SHIPLAP = 'SHIPLAP'
PART_ROLE_V_GROOVE = 'V_GROOVE'
TAG_TEXTURED_PANEL_SIDE = 'hb_textured_panel_side'
# Stamped on a textured panel whose mesh data carries the static carved
# geometry; the material walk assigns the finish to the mesh slot
# directly (cutpart surface inputs are inert while the GN is hidden).
TAG_STATIC_TEXTURED = 'HB_STATIC_TEXTURED'
TEXTURED_PANEL_ROLES = {
    'BEADBOARD': PART_ROLE_BEADBOARD,
    'SHIPLAP':   PART_ROLE_SHIPLAP,
    'V_GROOVE':  PART_ROLE_V_GROOVE,
}
# Beadboard plank spacing (matches the 'MDF Beadboard' door-panel kind);
# shiplap course pitch (matches the wood-hood default board width);
# v-groove plank spacing (the usual 4" sheet-goods layout).
TEXTURED_BEADBOARD_SPACING = 1.6 * 0.0254
TEXTURED_SHIPLAP_PITCH = 6.0 * 0.0254
TEXTURED_V_GROOVE_SPACING = 4.0 * 0.0254


def _v_groove_spacing(cab_props):
    """Groove spacing for this cabinet: its own where it carries one,
    else the standard layout. Files saved before the field existed, and
    a 0 left in it, both read as standard."""
    try:
        typed = float(getattr(cab_props, 'v_groove_spacing', 0.0) or 0.0)
    except (TypeError, ValueError):
        return TEXTURED_V_GROOVE_SPACING
    return typed if typed > 0.0 else TEXTURED_V_GROOVE_SPACING


def _shiplap_vertical(cab_props):
    """True when the cabinet runs its shiplap planks upright. Files
    saved before the direction existed read as horizontal."""
    return getattr(cab_props, 'shiplap_direction', 'HORIZONTAL') == 'VERTICAL'

# Applied panel side tag - written on a panel root that's been spawned
# by a cabinet to serve as its left/right/back finished end. Drives
# reconciliation (find / resize / remove on cabinet recalc).
TAG_APPLIED_PANEL_SIDE = 'hb_applied_to_cabinet_side'
# Which panel this is, where a side can carry more than one:
# 'LEFT', 'RIGHT', or 'BACK:<start bay>' for the per-segment
# applied backs.
TAG_APPLIED_PANEL_KEY = 'hb_applied_panel_key'

# Cabinet-side finished_end_condition values that spawn an applied panel
# child. All three spawn the same face-frame panel; they differ in the
# default front each opening carries (see applied_panel_sizing
# _CONDITION_FRONT_TYPE): PANELED -> inset panels, FALSE_FF ->
# fixed false fronts, WORKING_FF -> working doors. Per-opening
# overrides via the standard opening UI survive recalcs.
APPLIED_PANEL_END_TYPES = frozenset({'PANELED', 'FALSE_FF', 'WORKING_FF'})
# Stamped on the panel root so a condition flip re-defaults the
# openings' fronts while a same-condition recalc preserves overrides.
TAG_APPLIED_PANEL_CONDITION = 'hb_applied_panel_condition'


def front_reads_door_pool(part_obj):
    """True when a fixed front resolves its style in the DOOR pool even
    though its role is a drawer-ish one. A false face frame end stands in
    for a face frame full of door panels, so its fronts follow the Door
    Style exactly like a working face frame end's do. A FALSE_FRONT inside
    a real cabinet bay is a decorative drawer face and keeps the Drawer
    Front Style."""
    node = part_obj
    while node is not None:
        if node.get(TAG_APPLIED_PANEL_SIDE):
            return node.get(TAG_APPLIED_PANEL_CONDITION) == 'FALSE_FF'
        node = node.parent
    return False

# Stamped on a working face frame panel root: the depth its drawer and
# pullout boxes may run back into the host cabinet's cavity. The panel
# itself is only the 3/4 reserve deep, so without this the box depth
# solves nonpositive and the drawers come out empty - but a working
# frame is a real access side, so its boxes belong in the cabinet
# behind it. Paneled / false-front ends carry no boxes.
TAG_APPLIED_BOX_DEPTH = 'hb_applied_box_depth'
# Cap for that auto depth. The cavity behind a side working frame is
# the full interior width of the host, deeper than anything a slide
# runs; hold the auto size to a standard slide length and leave the
# rest to the per-opening Drawer Box Size override.
APPLIED_BOX_MAX_DEPTH = inch(21.0)

# Pivot empty parent of every front part. Holds the swing rotation
# (door / pullout) or the slide translation (drawer front) so the front
# part itself stays at a fixed local transform relative to the pivot.
PART_ROLE_FRONT_PIVOT = 'FRONT_PIVOT'

# Drawer box behind a drawer or pullout front. Parented to the front pivot
# (not the front part) so the box rides the slide animation but is sized
# from the opening cage's interior dimensions, independent of the front's
# overlay-inflated size. Not a member of FRONT_PART_ROLES; it's an interior
# part by structure even though it's spawned alongside the front.
PART_ROLE_DRAWER_BOX = 'DRAWER_BOX'
# Visual drawer-interior accessory geometry (dividers etc.), parented to
# the drawer box so it slides out with the front.
PART_ROLE_DRAWER_DIVIDER = 'DRAWER_DIVIDER'
# Every other rendered drawer accessory (trays, knife blocks, stepped
# spice shelves, organizers). Same wipe-and-rebuild lifecycle as the
# dividers; kept as its own role so reports can tell a loose partition
# from a dropped-in insert.
PART_ROLE_DRAWER_INSERT = 'DRAWER_INSERT'
# Hidden boolean cutter carving the U-notch of a sink duo drawer box.
# A wire child of the box, so it lives and dies with the box's own
# wipe-and-rebuild lifecycle.
PART_ROLE_DRAWER_BOX_CUTTER = 'DRAWER_BOX_CUTTER'

# Render hints an accessory can carry -> (builder method, default
# height in inches, whether the insert takes up drawer floor). Hints
# are matched case-insensitively; an accessory whose hint isn't listed
# here stays data-only (it is quoted and scheduled, just not modeled).
DRAWER_INSERT_BUILDERS = {
    'DIVIDER': ('_build_drawer_dividers', 0.0, False),
    'CUTLERY': ('_build_cutlery_insert', 2.375, True),
    'KNIFE_BLOCK': ('_build_knife_block_insert', 2.0, True),
    'SPICE': ('_build_spice_insert', 2.75, True),
    'PIGEON_HOLE': ('_build_pigeon_hole_insert', 6.0, True),
    'TRAY': ('_build_tray_insert', 2.0, True),
}


def parse_render_hint(hint):
    """Split an accessory render hint into ``(kind, params)``.

    A hint is a kind name, optionally followed by ``key=value`` pairs
    carrying the product spec's published sizes, e.g.
    ``"TRAY W=8.3125 D=16.6875 H=4.75 SLOTS=4"``. Values are inches.
    W / D / H are the size the product is made in; WMAX / DMAX are the
    largest it can be built, for the ones cut to fit the drawer.
    Unknown keys are ignored so the host application can extend a spec
    without breaking older builds, and an unparsable hint degrades to
    kind-only rather than failing the rebuild.
    """
    parts = (hint or '').split()
    if not parts:
        return '', {}
    params = {}
    for token in parts[1:]:
        key, sep, value = token.partition('=')
        if not sep:
            continue
        try:
            params[key.strip().upper()] = float(value)
        except ValueError:
            continue
    return parts[0].strip().upper(), params


def render_hint_kind(hint):
    """The insert kind a render hint resolves to, or '' when the hint
    is empty or names something this build can't model. UI uses this to
    decide which per-item settings are worth drawing."""
    kind = parse_render_hint(hint)[0]
    return kind if kind in DRAWER_INSERT_BUILDERS else ''


class DrawerInsertMesh:
    """Collects the prisms that make up one drawer insert so the whole
    insert ships as a single mesh object.

    Every insert part - tray walls and partitions, knife ribs, sloped
    spice shelves - is a (y, z) profile extruded along X, so one
    primitive covers the lot and a tray with a dozen partitions still
    costs one object per rebuild.
    """

    def __init__(self):
        self.verts = []
        self.faces = []

    def prism(self, x0, x1, profile):
        if x1 - x0 <= 1e-9 or len(profile) < 3:
            return
        base = len(self.verts)
        n = len(profile)
        self.verts.extend((x0, y, z) for y, z in profile)
        self.verts.extend((x1, y, z) for y, z in profile)
        self.faces.append([base + i for i in range(n)])
        self.faces.append([base + i for i in range(2 * n - 1, n - 1, -1)])
        for i in range(n):
            j = (i + 1) % n
            self.faces.append([base + i, base + j,
                               base + j + n, base + i + n])

    def box(self, x0, x1, y0, y1, z0, z1):
        if y1 - y0 <= 1e-9 or z1 - z0 <= 1e-9:
            return
        self.prism(x0, x1, [(y0, z0), (y1, z0), (y1, z1), (y0, z1)])

# Front roles that share the same panel geometry today. Keeping them
# grouped here so reconciliation can iterate the set instead of
# spelling each role out.
# Left/right filler stiles built inside an APPLIANCE opening (no door/drawer).
# Sits in the face-frame plane like a stile but is wiped + rebuilt per recalc
# like a front part, so it's grouped with FRONT_PART_ROLES rather than the
# cabinet-level FACE_FRAME_PART_ROLES (it has no per-part unlock width; its
# width comes from the opening's appliance/filler props).
PART_ROLE_APPLIANCE_FILLER = 'APPLIANCE_FILLER'

FRONT_PART_ROLES = frozenset({
    PART_ROLE_DOOR,
    PART_ROLE_DRAWER_FRONT,
    PART_ROLE_PULLOUT_FRONT,
    PART_ROLE_FALSE_FRONT,
    PART_ROLE_TILT_OUT,
    PART_ROLE_INSET_PANEL,
    PART_ROLE_APRON,
    PART_ROLE_APPLIANCE_FILLER,
})

FRONT_TYPE_TO_ROLE = {
    'DOOR':         PART_ROLE_DOOR,
    'DRAWER_FRONT': PART_ROLE_DRAWER_FRONT,
    'PULLOUT':      PART_ROLE_PULLOUT_FRONT,
    'FALSE_FRONT':  PART_ROLE_FALSE_FRONT,
    'TILT_OUT':     PART_ROLE_TILT_OUT,
}

# ---------------------------------------------------------------------------
# Interior parts (children of opening cages; sit behind the face frame).
# Orthogonal to front_type - any front_type can carry interior items, and
# 'open' openings (front_type = NONE) get all of their visual content from
# this list.
# ---------------------------------------------------------------------------
PART_ROLE_ADJUSTABLE_SHELF = 'ADJUSTABLE_SHELF'
# Finished-opening nosing profile on an adjustable shelf's front edge.
# One nosing part per shelf; profile outlines live in shelf_nosing.py.
PART_ROLE_SHELF_NOSING = 'SHELF_NOSING'
PART_ROLE_GLASS_SHELF = 'GLASS_SHELF'
PART_ROLE_PULLOUT_SHELF = 'PULLOUT_SHELF'
PART_ROLE_PULLOUT_SPACER = 'PULLOUT_SPACER'
PART_ROLE_ROLLOUT_BOX = 'ROLLOUT_BOX'
PART_ROLE_ROLLOUT_SPACER = 'ROLLOUT_SPACER'
# Which interior item + rollout_boxes entry built a rollout box. Stamped
# at create so a right-click command can find the per-box options for
# the object under the cursor (the boxes themselves are wiped and
# rebuilt every recalc, so the options can't live on them).
TAG_ROLLOUT_ITEM_INDEX = 'hb_rollout_item_index'
TAG_ROLLOUT_BOX_INDEX = 'hb_rollout_box_index'


# Finger scoop: the notch in the front of a rollout box. Traced from the
# shop's own part -- a 4" wide opening at the top edge narrowing to 3" at
# 1" deep, straight sides, with 3/8" breaks at all four corners. The
# breaks are true fillets tangent 3/8" back from each nominal corner,
# which reproduces the reference part to within 0.01".
_SCOOP_TOP_WIDTH = 4.0
_SCOOP_BOTTOM_WIDTH = 3.0
_SCOOP_DEPTH = 1.0
_SCOOP_CORNER = 0.375
_SCOOP_ARC_SEGMENTS = 8


def _finger_scoop_profile():
    """The scoop outline in INCHES as [(x, depth), ...], left to right.

    x runs from the scoop's centre, depth downward from the top edge of
    the box front. Fixed size -- the caller places it, nothing scales it,
    because the feature is sized to a hand rather than to the box.
    """
    th = _SCOOP_TOP_WIDTH / 2.0
    bh = _SCOOP_BOTTOM_WIDTH / 2.0
    c = _SCOOP_CORNER
    ang = math.atan((th - bh) / _SCOOP_DEPTH)      # side, off vertical
    ux, ud = math.sin(ang), math.cos(ang)          # unit down the side
    # A fillet tangent to both lines, c back from the corner along each:
    # the arcs meet the top edge and the flat bottom square on.
    r = c * math.tan((math.pi / 2.0 + ang) / 2.0)

    def arc(centre, start, end):
        cx, cd = centre
        a0 = math.atan2(start[1] - cd, start[0] - cx)
        a1 = math.atan2(end[1] - cd, end[0] - cx)
        # Both arcs turn through well under half a circle, so the short
        # way round is always the one wanted.
        while a1 - a0 > math.pi:
            a1 -= 2.0 * math.pi
        while a0 - a1 > math.pi:
            a1 += 2.0 * math.pi
        return [(cx + math.cos(a0 + (a1 - a0) * i / _SCOOP_ARC_SEGMENTS) * r,
                 cd + math.sin(a0 + (a1 - a0) * i / _SCOOP_ARC_SEGMENTS) * r)
                for i in range(1, _SCOOP_ARC_SEGMENTS)]

    top = (-(th + c), 0.0)                         # meets the top edge
    side_hi = (-th + c * ux, c * ud)               # onto the straight side
    side_lo = (-bh - c * ux, _SCOOP_DEPTH - c * ud)
    flat = (-(bh - c), _SCOOP_DEPTH)               # onto the flat bottom

    half = [top]
    half += arc((top[0], r), top, side_hi)
    half += [side_hi, side_lo]
    half += arc((flat[0], _SCOOP_DEPTH - r), side_lo, flat)
    half.append(flat)
    return half + [(-x, d) for x, d in reversed(half)]


def _seed_cutter_material(cutter, box_obj):
    """Put the box's own material on a drawer / rollout box cutter.

    The cut faces read the CUTTER's material, so a cutter with none
    leaves them on an empty slot -- unshaded white in material view. The
    cabinet material walk sets this properly from the style, but it only
    runs on a cabinet that has one; seeding from the box means an
    unstyled cabinet still cuts in the box's own material rather than in
    nothing.
    """
    try:
        from ... import hb_types
        mat = hb_types.GeoNodeObject(box_obj).get_input('Material')
    except Exception:
        mat = None
    if mat is None:
        return
    if cutter.data.materials:
        cutter.data.materials[0] = mat
    else:
        cutter.data.materials.append(mat)


def rollout_item_props(opening_obj, item_index):
    """The interior item behind a rollout box object, or None when the
    index no longer resolves. Same contract as rollout_box_props."""
    if opening_obj is None or item_index < 0:
        return None
    op_props = getattr(opening_obj, 'face_frame_opening', None)
    if op_props is None:
        return None
    items = getattr(op_props, 'interior_items', ())
    if item_index >= len(items):
        return None
    return items[item_index]


def rollout_box_props(opening_obj, item_index, box_index):
    """The Face_Frame_Rollout_Box entry behind a rollout box object, or
    None when the indices no longer resolve (item deleted, stack
    shortened, or a file saved before the per-box options existed)."""
    if opening_obj is None or item_index < 0 or box_index < 0:
        return None
    op_props = getattr(opening_obj, 'face_frame_opening', None)
    if op_props is None:
        return None
    items = getattr(op_props, 'interior_items', ())
    if item_index >= len(items):
        return None
    boxes = getattr(items[item_index], 'rollout_boxes', ())
    if box_index >= len(boxes):
        return None
    return boxes[box_index]


def rollout_box_props_for_object(obj):
    """(opening_obj, box_props) for a rollout box object, or (None, None).
    Walks up to the owning opening cage and reads the stamped indices."""
    if obj is None or obj.get('hb_part_role') != PART_ROLE_ROLLOUT_BOX:
        return None, None
    node = obj.parent
    while node is not None and not node.get(TAG_OPENING_CAGE):
        node = node.parent
    if node is None:
        return None, None
    return node, rollout_box_props(
        node,
        obj.get(TAG_ROLLOUT_ITEM_INDEX, -1),
        obj.get(TAG_ROLLOUT_BOX_INDEX, -1),
    )
PART_ROLE_TRAY_DIVIDER = 'TRAY_DIVIDER'
PART_ROLE_TRAY_LOCKED_SHELF = 'TRAY_LOCKED_SHELF'
PART_ROLE_VANITY_SHELF = 'VANITY_SHELF'
PART_ROLE_VANITY_SUPPORT = 'VANITY_SUPPORT'
PART_ROLE_ACCESSORY_LABEL = 'ACCESSORY_LABEL'
# Front types whose opening carries a drawer box. Accessories put in one
# of these are shown by the geometry built inside the box, so their name
# is not also printed into the opening - the item data is what feeds the
# schedules and legends downstream.
DRAWER_BOX_FRONT_TYPES = frozenset({'DRAWER_FRONT', 'PULLOUT'})
# Drawer boxes are bought / built in a fixed range of box heights and
# then set into whatever opening they land in - they are not cut to the
# opening. Rows are (minimum opening height, box height) in inches,
# read from the tallest row down; an opening under the first row's
# minimum is too short for a stock box. Sized to the opening rather
# than to the box's own clearances so a tall opening (a pullout behind
# a full-height door, say) still gets a real drawer instead of a box
# the height of the door.
STOCK_DRAWER_BOX_HEIGHTS = (
    (12.0, 11.125),
    (11.0, 10.125),
    (10.0,  9.125),
    ( 9.0,  8.125),
    ( 8.0,  7.125),
    ( 7.0,  6.125),
    ( 6.0,  5.125),
    ( 5.0,  4.125),
    ( 4.5,  3.625),
    ( 4.0,  3.125),
    ( 3.0,  2.125),
)


def stock_drawer_box_height(opening_height):
    """Box height for an opening of this height (scene units), or None
    when the opening is shorter than the smallest stock box."""
    opening_in = opening_height / inch(1.0)
    for min_opening_in, box_in in STOCK_DRAWER_BOX_HEIGHTS:
        if opening_in >= min_opening_in - 1.0e-4:
            return inch(box_in)
    return None
# Bar storage inserts (wine cubby / cellar / lattice / X / diagonal
# / half-circle, stemware, plate rack). One role for the whole family:
# each insert is a single derived mesh built in bar_storage.py; the
# specific product is read from the interior item's kind.
PART_ROLE_BAR_STORAGE = 'BAR_STORAGE'
# Hang rod across an opening (same role string the closets library uses,
# so downstream consumers treat both the same way).
PART_ROLE_CLOSET_ROD = 'CLOSET_ROD'
# Appliance-bay annotation: the square + word (SINK / COOKTOP) drawn on
# top of an appliance bay so plan views read like a dealer drawing.
# Wiped + recreated every recalc (sized from the live bay cage); the
# durable signal is the APPLIANCE_BAY custom prop on the bay cage.
PART_ROLE_APPLIANCE_ANNOTATION = 'APPLIANCE_ANNOTATION'
APPLIANCE_ANNO_SIDE_MARGIN = inch(2.0)     # square inset from each bay side
APPLIANCE_ANNO_Z_LIFT = inch(0.5)          # square sits this far above the bay top
APPLIANCE_ANNO_TEXT_SIZE = inch(2.0)
APPLIANCE_ANNO_LINE_THICKNESS = inch(0.05)
# Word pulled toward the bay FRONT (-Y) so it stays readable in
# elevations when an upper cabinet hangs over the sink / cooktop.
APPLIANCE_ANNO_TEXT_Y_OFFSET = inch(-4.0)
# Interior tree dividers: physical parts at split-node boundaries.
PART_ROLE_INTERIOR_DIVISION = 'INTERIOR_DIVISION'
PART_ROLE_INTERIOR_FIXED_SHELF = 'INTERIOR_FIXED_SHELF'
# Optional face frame member (rail / stile) inline with the
# cabinet face frame at an interior split node.
PART_ROLE_INTERIOR_FF_RAIL = 'INTERIOR_FF_RAIL'
PART_ROLE_INTERIOR_FF_STILE = 'INTERIOR_FF_STILE'

INTERIOR_PART_ROLES = frozenset({
    PART_ROLE_ADJUSTABLE_SHELF,
    PART_ROLE_SHELF_NOSING,
    PART_ROLE_GLASS_SHELF,
    PART_ROLE_PULLOUT_SHELF,
    PART_ROLE_PULLOUT_SPACER,
    PART_ROLE_ROLLOUT_BOX,
    PART_ROLE_ROLLOUT_SPACER,
    PART_ROLE_TRAY_DIVIDER,
    PART_ROLE_TRAY_LOCKED_SHELF,
    PART_ROLE_VANITY_SHELF,
    PART_ROLE_VANITY_SUPPORT,
    PART_ROLE_ACCESSORY_LABEL,
    PART_ROLE_BAR_STORAGE,
    PART_ROLE_CLOSET_ROD,
    PART_ROLE_INTERIOR_DIVISION,
    PART_ROLE_INTERIOR_FIXED_SHELF,
    PART_ROLE_INTERIOR_FF_RAIL,
    PART_ROLE_INTERIOR_FF_STILE,
})

# Maps a Face_Frame_Interior_Item.kind to the *primary* part role its
# descriptors carry. Multi-part assemblies (PULLOUT_SHELF, ROLLOUT,
# TRAY_DIVIDERS, VANITY_SHELVES) emit multiple part roles; this map
# only names the headline role used for tagging the wipe set.
INTERIOR_KIND_TO_ROLE = {
    'ADJUSTABLE_SHELF':      PART_ROLE_ADJUSTABLE_SHELF,
    'GLASS_SHELF':           PART_ROLE_GLASS_SHELF,
    'PULLOUT_SHELF':         PART_ROLE_PULLOUT_SHELF,
    'ROLLOUT':               PART_ROLE_ROLLOUT_BOX,
    'TRAY_DIVIDERS':         PART_ROLE_TRAY_DIVIDER,
    'VANITY_SHELVES':        PART_ROLE_VANITY_SHELF,
    'ACCESSORY':             PART_ROLE_ACCESSORY_LABEL,
    'INTERIOR_DIVISION':     PART_ROLE_INTERIOR_DIVISION,
    'INTERIOR_FIXED_SHELF':  PART_ROLE_INTERIOR_FIXED_SHELF,
    # Bar storage family: every kind materializes as one derived mesh
    # under the shared role.
    'WINE_CUBBY':            PART_ROLE_BAR_STORAGE,
    'WINE_CELLAR':           PART_ROLE_BAR_STORAGE,
    'WINE_LATTICE':          PART_ROLE_BAR_STORAGE,
    'WINE_X':                PART_ROLE_BAR_STORAGE,
    'WINE_DIAGONAL':         PART_ROLE_BAR_STORAGE,
    'WINE_HALF_CIRCLE':      PART_ROLE_BAR_STORAGE,
    'STEMWARE_RACK':         PART_ROLE_BAR_STORAGE,
    'PLATE_RACK':            PART_ROLE_BAR_STORAGE,
    'CLOSET_ROD':            PART_ROLE_CLOSET_ROD,
}

# Angled standard cabinet machinery. The cutter is a hidden GeoNodeCage
# whose cage volume covers everything forward of the angled face frame
# inner plane; carcass parts that need a trapezoidal silhouette carry a
# 'Angled Cut' boolean DIFFERENCE modifier referencing it. Defined down
# here so the role frozenset can reference PART_ROLE_ADJUSTABLE_SHELF
# (declared just above).
PART_ROLE_ANGLED_CUTTER = 'ANGLED_CUTTER'
ANGLED_CUT_MOD_NAME = 'Angled Cut'
ANGLED_CUT_PART_ROLES = frozenset({
    PART_ROLE_TOP, PART_ROLE_BOTTOM,
    PART_ROLE_BAY_SHELF,
    PART_ROLE_ADJUSTABLE_SHELF, PART_ROLE_GLASS_SHELF,
    PART_ROLE_TRAY_LOCKED_SHELF,
    PART_ROLE_INTERIOR_FIXED_SHELF,
})

# Tip-up wedge cutter (back-bottom chamfer). Same lazy-cutter + boolean
# pattern as the angled cutter, but the cutter is a triangular-prism MESH
# and it's driven by the wedge_* cabinet props (see solver.wedge_geometry).
PART_ROLE_WEDGE_CUTTER = 'WEDGE_CUTTER'
# The wedge itself: the corner that is cut off to tip the cabinet up and
# glued back on once it is standing. Built in place so the cabinet reads
# whole and the cut shows as a seam rather than a missing corner.
PART_ROLE_WEDGE = 'WEDGE'
WEDGE_CUT_MOD_NAME = 'Tip-Up Wedge'
WEDGE_CUT_PART_ROLES = frozenset({
    PART_ROLE_LEFT_SIDE, PART_ROLE_RIGHT_SIDE,
    PART_ROLE_BACK, PART_ROLE_FINISHED_BACK, PART_ROLE_BOTTOM,
    PART_ROLE_LEFT_KICK_RETURN, PART_ROLE_RIGHT_KICK_RETURN,
})

# Pipe chase: full-height notch at a back corner (or the back middle)
# for plumbing / vent runs. Same lazy box-cutter + boolean pattern as
# the tip-up wedge, driven by the chase_* cabinet props. Cover panels
# (real CabinetParts, PART_ROLE_PIPE_CHASE_PANEL) close the opening
# from the cabinet interior; managed by _apply_pipe_chase.
PART_ROLE_PIPE_CHASE_CUTTER = 'PIPE_CHASE_CUTTER'
PART_ROLE_PIPE_CHASE_PANEL = 'PIPE_CHASE_PANEL'
PIPE_CHASE_CUT_MOD_NAME = 'Pipe Chase'
# Chase covers are 1/2" stock, not the 3/4" the carcass runs at - the
# panels only close the void, nothing hangs off them.
PIPE_CHASE_PANEL_THICKNESS = inch(0.5)
PIPE_CHASE_CUT_PART_ROLES = frozenset({
    PART_ROLE_BACK, PART_ROLE_FINISHED_BACK,
    PART_ROLE_BOTTOM, PART_ROLE_TOP,
    PART_ROLE_REAR_STRETCHER, PART_ROLE_TOE_KICK_SUBREAR,
    PART_ROLE_LEFT_KICK_RETURN, PART_ROLE_RIGHT_KICK_RETURN,
    PART_ROLE_MID_DIVISION,
    PART_ROLE_BAY_SHELF,
    PART_ROLE_ADJUSTABLE_SHELF, PART_ROLE_GLASS_SHELF,
    PART_ROLE_TRAY_LOCKED_SHELF,
    PART_ROLE_INTERIOR_FIXED_SHELF,
})

# Angled back-extension trim cutter. The full-depth TOP / BOTTOM (and
# shelves) can't be a trapezoid natively (they are rectangular cutparts),
# so they are first extended rectangularly to reach the extended back
# corner, then a boolean DIFFERENCE trims the front overhang along the
# angled side line - leaving the trapezoid. Same lazy mesh-cutter pattern
# as the tip-up wedge; driven by extend_back_left / extend_back_right.
# Furniture / veneer wood top: an overhanging slab sitting proud on the
# carcass top, used by dresser products. Managed by _apply_furniture_top
# (ensure / position / cleanup), gated on the furniture_top cabinet prop;
# in _FINISH_EXTERIOR_ROLES so the material walk gives it the cabinet's
# exterior wood finish.
PART_ROLE_FURNITURE_TOP = 'FURNITURE_TOP'
# Furniture-top plan shapes (furniture_top_shape). BOW_BACK and RADIUS
# trim the rectangular top cutpart with a hidden boolean cutter (same
# lazy mesh-cutter pattern as the back-extension trim); WATERFALL adds a
# drop panel at each end of the top running from its underside to the
# floor (in _FINISH_EXTERIOR_ROLES like the top itself). All managed by
# _apply_furniture_top.
PART_ROLE_FURNITURE_TOP_CUTTER = 'FURNITURE_TOP_CUTTER'
PART_ROLE_FURNITURE_TOP_LEG = 'FURNITURE_TOP_LEG'
FURNITURE_TOP_CUT_MOD_NAME = 'Furniture Top Shape Cut'
# Arc tessellation for the bow-back / radius-corner cutter meshes.
FURNITURE_TOP_BOW_SEGMENTS = 48
FURNITURE_TOP_RADIUS_SEGMENTS = 16
# Finished back panel closing the open recess below an upper whose
# ends are extended down (hutch). Managed by _apply_hutch_back; in
# _FINISH_EXTERIOR_ROLES so it gets the cabinet's finish material.
PART_ROLE_HUTCH_BACK = 'HUTCH_BACK'
# Attached wing: an angled return panel on an end, built from that end's
# extend_back value when its "Attach as Wing" option is on (carcass stays
# square). Managed by _apply_wing; finished on its outer face only.
PART_ROLE_WING = 'WING'
PART_ROLE_BACK_EXT_CUTTER = 'BACK_EXT_CUTTER'
BACK_EXT_CUT_MOD_NAME = 'Back Extension Trim'
BACK_EXT_CUT_PART_ROLES = frozenset({
    PART_ROLE_TOP, PART_ROLE_BOTTOM,
    PART_ROLE_FRONT_STRETCHER, PART_ROLE_REAR_STRETCHER,
    PART_ROLE_FINISH_TOE_KICK, PART_ROLE_TOE_KICK_SUBFRONT,
    PART_ROLE_LOOSE_KICK_REAR,
    PART_ROLE_BAY_SHELF,
    PART_ROLE_ADJUSTABLE_SHELF, PART_ROLE_GLASS_SHELF,
})

# Over-stool side-front profile cut: a decorative silhouette (authored as a
# closed curve in face_frame_assets/profiles) boolean-subtracted from the
# bottom-front corner of each extended side panel. See _apply_overstool_profile.
PART_ROLE_SIDE_PROFILE_CUTTER = 'SIDE_PROFILE_CUTTER'
SIDE_PROFILE_CUT_MOD_NAME = 'Side Profile Cut'
PART_ROLE_OVERSTOOL_SHELF = 'OVERSTOOL_SHELF'
PART_ROLE_OVERSTOOL_TOWEL_BAR = 'OVERSTOOL_TOWEL_BAR'
# Leg-accessory sizing (effective real-world: 6" deep shelf with 6" clear
# opening height, 3/4" round towel bar). The shelf is back-aligned against
# the full-height back and hangs so the clear opening between the box
# bottom and the shelf top is exactly the spec opening.
OVERSTOOL_SHELF_FRONT_SETBACK = inch(2.75)  # leg front to shelf front (6" shelf at the default 9" depth)
OVERSTOOL_SHELF_MIN_DEPTH = inch(2.0)
OVERSTOOL_SHELF_THICKNESS = inch(0.75)
OVERSTOOL_CLEAR_OPENING = inch(6.0)  # box bottom down to shelf top
OVERSTOOL_TOWEL_BAR_DIAMETER = inch(0.75)
OVERSTOOL_TOWEL_BAR_Z_ABOVE_LEG_BOTTOM = inch(4.0)
OVERSTOOL_TOWEL_BAR_Y_FROM_FRONT = inch(1.0)
OVERSTOOL_TOWEL_BAR_SEGMENTS = 16
# The towel bar always sits low + back between the legs (the spot it takes
# in the shelf-and-towel-bar layout, where the legs drop 13").
OVERSTOOL_TOWEL_BAR_COMBO_Z_DROP = inch(3.5)
OVERSTOOL_TOWEL_BAR_COMBO_Y_BACK = inch(2.0)
_OVERSTOOL_PROFILE_BLEND = ('face_frame_assets', 'profiles', 'Over Stool Profile.blend')
_OVERSTOOL_PROFILE_CURVE_NAME = 'BézierCurve'
_OVERSTOOL_PROFILE_POLY_CACHE = None  # list[(x, y)] meters, ordered closed loop


def _overstool_profile_poly():
    """Return the over-stool profile outline as an ordered closed loop of
    (x, y) points in the profile's LOCAL XY (meters), sampled from the
    authored Bezier in the profile blend. Cached after the first load.

    Sampled with interpolate_bezier (no depsgraph / scene-link needed) so it
    is safe to call from a recalc. The loop is the profile silhouette; the
    cutter prism (in _position_side_profile_cutter) extrudes it through the
    panel thickness for a boolean DIFFERENCE.
    """
    global _OVERSTOOL_PROFILE_POLY_CACHE
    if _OVERSTOOL_PROFILE_POLY_CACHE is not None:
        return _OVERSTOOL_PROFILE_POLY_CACHE
    from mathutils.geometry import interpolate_bezier
    blend = os.path.join(os.path.dirname(__file__), *_OVERSTOOL_PROFILE_BLEND)
    before = set(bpy.data.objects)
    with bpy.data.libraries.load(blend, link=False) as (src, dst):
        dst.objects = [_OVERSTOOL_PROFILE_CURVE_NAME]
    obj = next((o for o in bpy.data.objects if o not in before), None)
    pts = []
    try:
        sp = obj.data.splines[0]
        bp = sp.bezier_points
        n = len(bp)
        res = max(8, obj.data.resolution_u)
        last = n if sp.use_cyclic_u else n - 1
        for i in range(last):
            a = bp[i]
            b = bp[(i + 1) % n]
            seg = interpolate_bezier(a.co, a.handle_right, b.handle_left, b.co, res)
            pts.extend((v.x, v.y) for v in seg[:-1])  # drop shared endpoint
    finally:
        cu = obj.data if obj else None
        if obj:
            bpy.data.objects.remove(obj, do_unlink=True)
        if cu and cu.users == 0:
            bpy.data.curves.remove(cu)
    _OVERSTOOL_PROFILE_POLY_CACHE = pts
    return pts


# ---------------------------------------------------------------------------
# Bottom-rail decorative profile cut (Beckony / Heritage / ... valance).
# A closed 2D Bezier authored with the decorative detail confined to the two
# ENDS and a flat horizontal middle. At apply time the ends stay FIXED and only
# the flat middle stretches to the rail length (3-slice), so the same profile
# fits any width with identical end details. Profiles are the '* Cutter.blend'
# curves in face_frame_assets/profiles. See _apply_bottom_rail_profile.
# ---------------------------------------------------------------------------
PART_ROLE_BOTTOM_RAIL_PROFILE_CUTTER = 'BOTTOM_RAIL_PROFILE_CUTTER'
BOTTOM_RAIL_PROFILE_CUT_MOD_NAME = 'Bottom Rail Profile Cut'
BOTTOM_RAIL_PROFILE_END_MARGIN = inch(2.0)  # flat, uncut rail left at each end
_BOTTOM_RAIL_PROFILE_ARCH = 'ARCH'          # procedural smooth-arch option (no blend)
BOTTOM_RAIL_PROFILE_ARCH_RISE = inch(2.0)   # arch height at the centre
# Procedural "traditional" valance: a straight ramp up from each end, a
# rounded shoulder, then a flat raised centre. Fixed end details, the
# plateau stretches with the rail (same as an authored profile).
_BOTTOM_RAIL_PROFILE_TRADITIONAL = 'TRADITIONAL'
BOTTOM_RAIL_PROFILE_TRADITIONAL_RISE = inch(2.0)       # plateau height
BOTTOM_RAIL_PROFILE_TRADITIONAL_RAMP_RUN = inch(4.0)   # straight ramp span
BOTTOM_RAIL_PROFILE_TRADITIONAL_RAMP_RISE = inch(1.6)  # ramp height at its top
BOTTOM_RAIL_PROFILE_TRADITIONAL_SHOULDER = inch(2.0)   # rounded run onto the plateau
_BOTTOM_RAIL_PROCEDURAL_PROFILES = frozenset((
    _BOTTOM_RAIL_PROFILE_ARCH, _BOTTOM_RAIL_PROFILE_TRADITIONAL))
_BOTTOM_RAIL_PROFILE_SUFFIX = ' Cutter.blend'
_BOTTOM_RAIL_PROFILE_POLY_CACHE = {}   # profile_id -> list[(x, y)] meters

# ---------------------------------------------------------------------------
# Corner treatment: the cabinet style's ss_corner_treatment (1/8-1/4-3/8
# radius, 1/4 cove, 1/4 x 1/4 chamfer) milled into the face frame's exposed
# front arrises -- the end stile's outer front edge where that side is a
# flush finished end, and the bottom front edge of an upper (bottom rail
# plus the stile bottoms). One boolean cutter prism per part per arris,
# built in the part's own frame so angled fronts come along for free.
# See _apply_corner_treatment.
# ---------------------------------------------------------------------------
PART_ROLE_CORNER_TREATMENT_CUTTER = 'CORNER_TREATMENT_CUTTER'
CORNER_TREATMENT_MOD_NAMES = {
    'LENGTH': 'Corner Treatment Edge',     # along the part's length
    'WIDTH': 'Corner Treatment Bottom',    # across a stile's bottom end
}
# Finished-end conditions whose outer face is flush with the end stile's
# edge (the stile arris IS the cabinet corner). Applied 3/4 panels /
# frames sit outboard of the stile and keep their own square corner.
CORNER_TREATMENT_FLUSH_ENDS = frozenset((
    'FINISHED', 'FLUSH_X', 'BEADBOARD', 'SHIPLAP', 'V_GROOVE'))

# ---------------------------------------------------------------------------
# Inset frame profile: the style overlay's face-frame edge detail (Beaded /
# Metro / Chamfer; Square = none) milled around every opening. One mitred
# ring cutter per opening cage, booleaned off every face-frame member whose
# box overlaps it, so stiles, rails and mid members all pick up the detail
# with real mitres at the opening corners. See _apply_frame_profile.
# ---------------------------------------------------------------------------
PART_ROLE_FRAME_PROFILE_CUTTER = 'FRAME_PROFILE_CUTTER'
FRAME_PROFILE_MOD_PREFIX = 'Frame Profile '
FRAME_PROFILE_PART_ROLES = FACE_FRAME_PART_ROLES | frozenset((
    PART_ROLE_LEFT_REFRIG_STILE, PART_ROLE_RIGHT_REFRIG_STILE))


def matrix_to_root(obj, root):
    """obj's transform relative to root, recomposed from each level's
    fresh loc/rot/scale (matrix_basis) so it is valid mid-recalc --
    matrix_local / matrix_world lag until the depsgraph refreshes.
    Identity when obj is root itself."""
    m = Matrix.Identity(4)
    cur = obj
    while cur is not None and cur is not root:
        m = cur.matrix_parent_inverse @ cur.matrix_basis @ m
        cur = cur.parent
    return m


def bottom_rail_profile_dir():
    return os.path.join(os.path.dirname(__file__), 'face_frame_assets', 'profiles')


def bay_cage_for_bottom_rail(rail):
    """The bay cage owning a bottom-rail part's segment (its
    hb_segment_start_bay index), or None. A ganged rail spanning several
    bays resolves to its START bay -- the same bay whose per-bay
    bottom_rail_profile override the cutter pass reads for the segment.
    Shared by the Set Bottom Rail Profile command and its menu."""
    seg = rail.get('hb_segment_start_bay')
    if not isinstance(seg, int):
        return None
    root = find_cabinet_root(rail)
    if root is None:
        return None
    for node in root.children:
        if node.get(TAG_BAY_CAGE) and node.get('hb_bay_index') == seg:
            return node
    return None


def _bottom_rail_profile_poly(profile_id):
    """Sampled closed-loop (x, y) outline (meters) for a profile id, cached.
    Same depsgraph-free Bezier sampling as _overstool_profile_poly."""
    if profile_id in _BOTTOM_RAIL_PROFILE_POLY_CACHE:
        return _BOTTOM_RAIL_PROFILE_POLY_CACHE[profile_id]
    from mathutils.geometry import interpolate_bezier
    blend = os.path.join(bottom_rail_profile_dir(), profile_id + '.blend')
    if not os.path.exists(blend):
        return []
    before = set(bpy.data.objects)
    with bpy.data.libraries.load(blend, link=False) as (src, dst):
        dst.objects = [profile_id] if profile_id in src.objects else list(src.objects)
    obj = next((o for o in bpy.data.objects if o not in before), None)
    pts = []
    try:
        sp = obj.data.splines[0]
        bp = sp.bezier_points
        n = len(bp)
        res = max(12, obj.data.resolution_u)
        last = n if sp.use_cyclic_u else n - 1
        for i in range(last):
            a = bp[i]
            b = bp[(i + 1) % n]
            seg = interpolate_bezier(a.co, a.handle_right, b.handle_left, b.co, res)
            pts.extend((v.x, v.y) for v in seg[:-1])
    finally:
        cu = obj.data if obj else None
        if obj:
            bpy.data.objects.remove(obj, do_unlink=True)
        if cu and cu.users == 0:
            bpy.data.curves.remove(cu)
    _BOTTOM_RAIL_PROFILE_POLY_CACHE[profile_id] = pts
    return pts


def _bottom_rail_profile_stretched(poly, target_len):
    """3-slice the profile to target_len. Seams are the x-range of the flat top
    edge (points at max Y): keep the LEFT detail (x <= left_seam) fixed,
    translate the RIGHT detail (x >= right_seam) by (target_len - ref_len), and
    stretch the flat middle between them. Returns the remapped [(x, y)], or None
    when the rail is too short to hold both end details."""
    if not poly:
        return None
    max_y = max(y for _, y in poly)
    ref_len = max(x for x, _ in poly)
    top_x = [x for x, y in poly if abs(y - max_y) < 1e-4]
    if not top_x:
        return None
    left_seam, right_seam = min(top_x), max(top_x)
    right_detail = ref_len - right_seam
    if target_len <= left_seam + right_detail:
        return None
    delta = target_len - ref_len
    mid_old = right_seam - left_seam
    mid_new = mid_old + delta
    out = []
    for x, y in poly:
        if x <= left_seam:
            nx = x
        elif x >= right_seam:
            nx = x + delta
        elif mid_old > 1e-9:
            nx = left_seam + (x - left_seam) * (mid_new / mid_old)
        else:
            nx = x
        out.append((nx, y))
    return out


def _bottom_rail_arch_poly(chord, rise=None, segments=48):
    """Closed (x, y) loop for a smooth arched bottom-rail cut spanning x in
    [0, chord]: the TOP edge is a circular arc rising `rise` at the centre from
    y=0 at both ends; the bottom edge is flat just below y=0 so the cut clears
    the rail's bottom edge. Chord = the arch's span; a wider rail flattens the
    arc (fixed rise, larger radius). Returns None for a non-positive span."""
    if rise is None:
        rise = BOTTOM_RAIL_PROFILE_ARCH_RISE
    if chord <= 0.0 or rise <= 0.0:
        return None
    half = chord / 2.0
    radius = (half * half + rise * rise) / (2.0 * rise)
    cx, cy = half, rise - radius
    below = -inch(0.25)
    top = []
    for i in range(segments + 1):
        x = chord * i / segments
        dx = x - cx
        top.append((x, cy + math.sqrt(max(0.0, radius * radius - dx * dx))))
    return top + [(chord, below), (0.0, below)]


def _bottom_rail_traditional_poly(chord, segments=16):
    """Closed (x, y) loop for the traditional valance cut spanning x in
    [0, chord]: from y=0 at each end a straight ramp rises RAMP_RISE over
    RAMP_RUN, a rounded shoulder (cubic, ramp-tangent in / level out) carries
    it up to RISE over SHOULDER, and the centre runs flat at RISE. End details
    are fixed size, so a wider rail only lengthens the plateau. Returns None
    when the span can't hold both end details plus a plateau."""
    rise = BOTTOM_RAIL_PROFILE_TRADITIONAL_RISE
    run = BOTTOM_RAIL_PROFILE_TRADITIONAL_RAMP_RUN
    ramp_rise = BOTTOM_RAIL_PROFILE_TRADITIONAL_RAMP_RISE
    shoulder = BOTTOM_RAIL_PROFILE_TRADITIONAL_SHOULDER
    end_detail = run + shoulder
    if chord <= 2.0 * end_detail + inch(1.0):
        return None
    # Left end detail: ramp then shoulder, sampled as a cubic bezier that
    # leaves along the ramp direction and arrives level on the plateau.
    p0 = (run, ramp_rise)
    p3 = (end_detail, rise)
    p1 = (run + shoulder * 0.5, ramp_rise + (ramp_rise / run) * shoulder * 0.5)
    p2 = (end_detail - shoulder * 0.35, rise)
    left = [(0.0, 0.0), p0]
    for i in range(1, segments + 1):
        t = i / segments
        mt = 1.0 - t
        x = (mt ** 3) * p0[0] + 3 * (mt ** 2) * t * p1[0] + 3 * mt * (t ** 2) * p2[0] + (t ** 3) * p3[0]
        y = (mt ** 3) * p0[1] + 3 * (mt ** 2) * t * p1[1] + 3 * mt * (t ** 2) * p2[1] + (t ** 3) * p3[1]
        left.append((x, min(y, rise)))
    right = [(chord - x, y) for (x, y) in reversed(left)]
    below = -inch(0.25)
    return left + right + [(chord, below), (0.0, below)]


# Baseline rotation_euler.z for parts that live in the face frame plane.
# Recalc adds face_frame_angle on top so they rotate with the angled
# FF plane in angled mode; with theta = 0 the values match the build-
# time rotations and there's no behavior change for square cabinets.
# Bay cages are handled separately in _update_bay_cage (no baseline; the
# FF angle IS the rotation).
FF_ROTATION_BASELINE_Z = {
    PART_ROLE_LEFT_STILE:        math.pi / 2,
    PART_ROLE_RIGHT_STILE:       math.pi / 2,
    PART_ROLE_LEFT_REFRIG_STILE:  math.pi / 2,
    PART_ROLE_RIGHT_REFRIG_STILE: math.pi / 2,
    PART_ROLE_FRONT_DROP_FILLER: math.pi / 2,
    PART_ROLE_TOP_RAIL:          0.0,
    PART_ROLE_BOTTOM_RAIL:       0.0,
    PART_ROLE_TOE_KICK_SUBFRONT: 0.0,
    PART_ROLE_FINISH_TOE_KICK:   0.0,
    PART_ROLE_BLIND_PANEL_LEFT:  math.pi / 2,
    PART_ROLE_BLIND_PANEL_RIGHT: math.pi / 2,
}


# ---------------------------------------------------------------------------
# Bay cage
# ---------------------------------------------------------------------------
class FaceFrameBay(GeoNodeCage):
    """Bay cage: a child of a FaceFrameCabinet that defines one bay's volume.
    Phase 3b populates bay contents (face frame members, openings)."""

    def create(self, name="Bay"):
        super().create(name)
        self.obj[TAG_BAY_CAGE] = True
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_bay_commands'
        self.obj.display_type = 'WIRE'


# ---------------------------------------------------------------------------
# Opening cage
# ---------------------------------------------------------------------------
class FaceFrameOpening(GeoNodeCage):
    """Opening cage: a child of a FaceFrameBay that defines one face frame
    opening's volume. Each bay starts with a single opening filling its
    face frame opening; splitter operations subdivide a bay by adding
    more openings.

    The cage is positioned in the face frame plane (Y depth = fft) and
    spans the opening width / height between the bay's bounding stiles
    and rails. Doors, drawer fronts, and pullouts attach to the opening
    and overlay it by the opening's per-side overlay values (or the
    cabinet defaults when an overlay side is locked).
    """

    def create(self, name="Opening"):
        super().create(name)
        self.obj[TAG_OPENING_CAGE] = True
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_opening_commands'
        self.obj.display_type = 'WIRE'


class FaceFrameInteriorRegion(GeoNodeCage):
    """Interior tree leaf cage. A wireframe box inside an opening that
    represents one region of the interior split tree. Selectable in the
    viewport; the panel uses the active region to drive which leaf's
    interior_items are shown / edited.
    """

    def create(self, name="Region"):
        super().create(name)
        self.obj[TAG_INTERIOR_REGION] = True
        self.obj.display_type = 'WIRE'


# ---------------------------------------------------------------------------
# Tree cloning (used by insert_bay to copy a bay's contents)
# ---------------------------------------------------------------------------
def _copy_property_group(src, dst, skip=()):
    """Copy every writable, non-pointer field from one PropertyGroup to
    another, recursing into nested CollectionProperty members. `skip` is
    a set of identifiers to leave untouched on dst. Pointer props are
    skipped (none of the face frame PGs carry them today; the guard is
    defensive against future additions)."""
    for prop in src.bl_rna.properties:
        ident = prop.identifier
        if ident == 'rna_type' or ident in skip or prop.is_readonly:
            continue
        if prop.type == 'POINTER':
            continue
        if prop.type == 'COLLECTION':
            dst_coll = getattr(dst, ident)
            dst_coll.clear()
            for src_item in getattr(src, ident):
                _copy_property_group(src_item, dst_coll.add())
            continue
        try:
            setattr(dst, ident, getattr(src, ident))
        except (AttributeError, TypeError):
            pass


def _clone_interior_tree_node(src_node, new_parent):
    """Recursively clone an opening's interior tree node - a region leaf
    cage or an interior-split Empty - under new_parent. Carcass interior
    parts are not cloned; the recalc rebuilds those from the copied
    PropertyGroups."""
    if src_node.get(TAG_INTERIOR_REGION):
        new_leaf = FaceFrameInteriorRegion()
        new_leaf.create('Region')
        new_leaf.obj.parent = new_parent
        ici = src_node.get('hb_interior_child_index')
        if ici is not None:
            new_leaf.obj['hb_interior_child_index'] = ici
        _copy_property_group(
            src_node.face_frame_interior_region,
            new_leaf.obj.face_frame_interior_region,
        )
        return new_leaf.obj

    if src_node.get(TAG_INTERIOR_SPLIT_NODE):
        split_obj = hb_utils.new_object('Interior Split', None)
        bpy.context.scene.collection.objects.link(split_obj)
        split_obj.empty_display_type = 'PLAIN_AXES'
        split_obj.empty_display_size = 0.001
        split_obj[TAG_INTERIOR_SPLIT_NODE] = True
        split_obj.parent = new_parent
        ici = src_node.get('hb_interior_child_index')
        if ici is not None:
            split_obj['hb_interior_child_index'] = ici
        _copy_property_group(
            src_node.face_frame_interior_split,
            split_obj.face_frame_interior_split,
        )
        children = sorted(
            [c for c in src_node.children
             if c.get(TAG_INTERIOR_REGION)
             or c.get(TAG_INTERIOR_SPLIT_NODE)],
            key=lambda c: c.get('hb_interior_child_index', 0),
        )
        for c in children:
            _clone_interior_tree_node(c, split_obj)
        return split_obj
    return None


def _clone_bay_tree_node(src_node, new_parent, opening_counter):
    """Recursively clone a bay's interior tree node - an opening cage or
    a split-node Empty - under new_parent. opening_counter is a one-item
    list used as a mutable per-bay counter so cloned openings get fresh
    sequential opening_index values. Fronts, pulls, and carcass parts
    are not cloned: the recalc rebuilds those from the copied front_type
    plus the cabinet style."""
    if src_node.get(TAG_OPENING_CAGE):
        new_op = FaceFrameOpening()
        new_op.create('Opening')
        new_op.obj.parent = new_parent
        idx = opening_counter[0]
        opening_counter[0] += 1
        new_op.obj['hb_opening_index'] = idx
        # opening_index is the within-bay counter, reassigned here; every
        # other opening field (front_type, overlays, interior_items, ...)
        # is copied verbatim so the new bay matches the anchor.
        _copy_property_group(
            src_node.face_frame_opening,
            new_op.obj.face_frame_opening,
            skip=('opening_index',),
        )
        new_op.obj.face_frame_opening.opening_index = idx
        sci = src_node.get('hb_split_child_index')
        if sci is not None:
            new_op.obj['hb_split_child_index'] = sci
        interior_root = solver._interior_tree_root(src_node)
        if interior_root is not None:
            _clone_interior_tree_node(interior_root, new_op.obj)
        return new_op.obj

    if src_node.get(TAG_SPLIT_NODE):
        split_obj = hb_utils.new_object('Split Node', None)
        bpy.context.scene.collection.objects.link(split_obj)
        split_obj.empty_display_type = 'PLAIN_AXES'
        split_obj.empty_display_size = 0.001
        split_obj[TAG_SPLIT_NODE] = True
        split_obj.parent = new_parent
        sci = src_node.get('hb_split_child_index')
        if sci is not None:
            split_obj['hb_split_child_index'] = sci
        _copy_property_group(
            src_node.face_frame_split, split_obj.face_frame_split)
        children = sorted(
            [c for c in src_node.children
             if c.get(TAG_OPENING_CAGE) or c.get(TAG_SPLIT_NODE)],
            key=lambda c: c.get('hb_split_child_index', 0),
        )
        for c in children:
            _clone_bay_tree_node(c, split_obj, opening_counter)
        return split_obj
    return None


# ---------------------------------------------------------------------------
# Bay width budget
# ---------------------------------------------------------------------------
def bay_width_budget(cabinet_obj):
    """(bays, consumed, available) for one cabinet's row of bays.

    `bays` are its bay cages in index order, `consumed` is the width the
    stiles take out of the face frame, and `available` is the face-frame
    length the stiles and bays divide up between them. Those are the
    three numbers a bay width has to agree with, so they live in one
    place: _distribute_bay_widths divides them, locked_bay_slack checks
    them, and anything wanting to report on a cabinet can ask.
    """
    cab_props = cabinet_obj.face_frame_cabinet
    bays = sorted(
        [c for c in cabinet_obj.children if c.get(TAG_BAY_CAGE)],
        key=lambda c: c.get('hb_bay_index', 0),
    )
    if not bays:
        return [], 0.0, 0.0

    # Space taken by stiles
    consumed = cab_props.left_stile_width + cab_props.right_stile_width
    for i in range(min(len(bays) - 1, len(cab_props.mid_stile_widths))):
        consumed += cab_props.mid_stile_widths[i].width

    # In angled mode the face frame becomes the hypotenuse, so rails
    # and openings need to size against that length, not the cabinet's
    # world X width. Layout's face_frame_length helper would do this
    # but isn't built yet at this point in recalc, so reproduce the
    # same condition + math directly from cab_props.
    is_angled_single_bay = (
        cab_props.corner_type == 'NONE'
        and len(bays) == 1
        and (cab_props.unlock_left_depth or cab_props.unlock_right_depth)
    )
    if is_angled_single_bay:
        ld = (cab_props.left_depth if cab_props.unlock_left_depth
              else cab_props.depth)
        rd = (cab_props.right_depth if cab_props.unlock_right_depth
              else cab_props.depth)
        available_width = math.hypot(cab_props.width, ld - rd)
    else:
        # Same FF-plane insets FaceFrameLayout uses (blind offset +
        # decorative corner post) so the bay share matches the FF
        # area the solver will actually build.
        inset_left, inset_right = solver.face_frame_insets(cab_props)
        available_width = cab_props.width - inset_left - inset_right

    return bays, consumed, available_width


def locked_bay_slack(cabinet_obj):
    """Width left over when EVERY bay in the cabinet has had its width
    set by hand: the available face frame, less the stiles, less the set
    bay widths. Positive means the bays fall short of the cabinet,
    negative means they overrun it, zero means they add up.

    None when at least one bay is still calculated -- that bay takes
    whatever is left over, so there is nothing there to be wrong. This
    is the one arrangement the distributor cannot fix for you, which is
    why it is worth asking about.
    """
    bays, consumed, available = bay_width_budget(cabinet_obj)
    if not bays:
        return None
    if any(not b.face_frame_bay.unlock_width for b in bays):
        return None
    return available - consumed - sum(b.face_frame_bay.width for b in bays)


# ---------------------------------------------------------------------------
# Base cabinet class
# ---------------------------------------------------------------------------
class FaceFrameCabinet(GeoNodeCage):
    # When True, the place_cabinet modal pins bay_qty=1 and disables
    # fill-to-gap behavior. Used for single-unit products like sinks
    # where tiling across a wall doesn't make sense.
    single_placement = False

    """Base class for all face frame cabinets.

    No drivers. All dimensions flow through the recalculate() method which
    reads from the cabinet's face_frame_cabinet PropertyGroup and writes
    dimensions/positions to all child parts.
    """

    default_width = inch(36)
    default_height = inch(34.5)
    default_depth = inch(24)
    default_cabinet_type = 'BASE'
    # Optional floor->bottom mount height for uppers at placement. None =
    # use the scene wall-cabinet location; a subclass may pin a value
    # (read by ops_placement._upper_mount_z).
    default_z_location = None

    # =====================================================================
    # Construction
    # =====================================================================
    def create_cabinet_root(self, name):
        """Create the cabinet's top-level cage object."""
        super().create(name)

        self.obj[TAG_CABINET_CAGE] = True
        self.obj['CABINET_TYPE'] = self.default_cabinet_type
        self.obj['CLASS_NAME'] = self.__class__.__name__
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_cabinet_commands'
        self.obj.display_type = 'WIRE'

        # Mirror Y on the cabinet cage so the wireframe extrudes in -Y from
        # origin, matching the convention used by all child parts.
        self.set_input('Mirror Y', True)

        # Initialize the object-level PropertyGroup. Every size write
        # below fires an update callback that would run a full
        # recalculate() on a root with no parts yet - a dozen no-op
        # layouts per cabinet, each walking the whole scene. The
        # reentrance guard sends those callbacks straight back out
        # (the width callback still records its anchor stash); the cage
        # dims are synced by hand after, and create_carcass() runs the
        # real layout once the parts exist.
        scene = bpy.context.scene
        cab_props = self.obj.face_frame_cabinet
        cabinet_id = id(self.obj)
        _RECALCULATING.add(cabinet_id)
        try:
            cab_props.cabinet_type = self.default_cabinet_type

            # Type-specific top scribe defaults: amount the carcass top
            # is held down from bay_top_z. Uppers and talls both reserve
            # a 1/2 band for scribing to the ceiling; bases get none.
            # Sides drop with the carcass top unless flagged finished.
            cab_props.top_scribe = {
                'UPPER': inch(0.5),
                'TALL':  inch(0.5),
            }.get(self.default_cabinet_type, 0.0)

            # Uppers sit at the back of a corner with shallower
            # carcasses, so the blind amount default tracks Upper depth
            # conventions (12") vs the standard 24" Base/Tall default
            # seeded by the property declaration.
            if self.default_cabinet_type == 'UPPER':
                cab_props.blind_amount_left = inch(12.0)
                cab_props.blind_amount_right = inch(12.0)

            if hasattr(scene, 'hb_face_frame'):
                ff_scene = scene.hb_face_frame
                cab_props.left_stile_width = ff_scene.ff_end_stile_width
                cab_props.right_stile_width = ff_scene.ff_end_stile_width
                cab_props.top_rail_width = ff_scene.ff_top_rail_width
                cab_props.bottom_rail_width = ff_scene.ff_bottom_rail_width
                cab_props.face_frame_thickness = ff_scene.ff_face_frame_thickness
                # Project toe kick defaults (product classes that need a
                # fixed kick -- refrigerator 0, lap drawer float --
                # override after this in their own create()).
                tk_h = getattr(ff_scene, 'default_toe_kick_height', None)
                if tk_h is not None:
                    cab_props.toe_kick_height = tk_h
                    cab_props.toe_kick_setback = ff_scene.default_toe_kick_setback

            cab_props.width = self.default_width
            cab_props.height = self.default_height
            cab_props.depth = self.default_depth
        finally:
            _RECALCULATING.discard(cabinet_id)

        # What the skipped recalcs would have done on a bare root.
        self.set_input('Dim X', cab_props.width)
        self.set_input('Dim Y', cab_props.depth)
        self.set_input('Dim Z', cab_props.height)

    def create_carcass(self, has_toe_kick, bay_qty=1):
        """Create the 5-part carcass + face frame end stiles + N bay cages
        + N-1 mid stiles. Initial rail segments are computed and created
        in the trailing recalculate() call.

        The whole body runs under _RECALCULATING + _DISTRIBUTING_WIDTHS so
        that prop assignments during initialization don't trigger nested
        recalcs or auto-lock the bay widths. The single recalculate() after
        the guard release does the layout once with all props in place.
        """
        cabinet_id = id(self.obj)
        _RECALCULATING.add(cabinet_id)
        _DISTRIBUTING_WIDTHS.add(cabinet_id)
        try:
            self._build_carcass_parts(bay_qty)
        finally:
            _RECALCULATING.discard(cabinet_id)
            _DISTRIBUTING_WIDTHS.discard(cabinet_id)

        # All parts and props in place - run the layout once.
        self.recalculate()

    # =====================================================================
    # Insert / Delete bay (structural mutation)
    # =====================================================================
    def insert_bay(self, anchor_index, direction):
        """Insert a new bay relative to an existing one.

        anchor_index: index of the existing bay we're inserting next to.
        direction: 'BEFORE' (new bay takes anchor's slot, anchor shifts
        right) or 'AFTER' (new bay goes one past anchor, everything
        beyond shifts right).

        Adds one bay object (with a single fresh opening), one
        mid_stile_widths entry, one mid stile part, and a slot-0 / slot-1
        mid div pair. Existing bay / mid stile / mid div parts whose
        index sits at or past the insertion point have their hb_*_index
        bumped by one. width=0 + unlock_width=False on the new bay so
        the redistributor immediately gives it an equal share.
        """
        bays = self._sorted_bays()
        if not bays:
            return
        anchor_index = max(0, min(anchor_index, len(bays) - 1))
        # Hold the anchor bay's object ref before the reindex pass. The
        # ref is stable across reindexing (only its hb_bay_index prop
        # changes), so the new bay can clone its tree afterwards.
        anchor_bay = bays[anchor_index]
        new_bay_index = anchor_index if direction == 'BEFORE' else anchor_index + 1
        # Inserting AT new_bay_index means existing bays at new_bay_index
        # and beyond shift up by one. The new mid-stile sits at gap
        # new_bay_index - 1 if inserting at position > 0, else at gap 0.
        # Concretely: if new_bay_index < new_bay_count - 1 there's a gap
        # to the right of the new bay; else gap to the left.
        new_gap_index = new_bay_index - 1 if new_bay_index > 0 else 0
        # When inserting at position > 0 the new gap sits BETWEEN the
        # bay-to-the-left and the new bay. When inserting at position 0
        # (BEFORE bay 0) the new gap sits between the new bay and old
        # bay 0, which is gap 0 in the new numbering. Either way, gap
        # ranges shift up by one for any old gap whose index >= new_gap_index.

        cab_props = self.obj.face_frame_cabinet
        cabinet_id = id(self.obj)
        _RECALCULATING.add(cabinet_id)
        _DISTRIBUTING_WIDTHS.add(cabinet_id)
        try:
            # 1) Reindex existing bays at/after new_bay_index.
            for bay_obj in self._sorted_bays():
                idx = bay_obj.get('hb_bay_index', 0)
                if idx >= new_bay_index:
                    bay_obj['hb_bay_index'] = idx + 1
                    bay_obj.face_frame_bay.bay_index = idx + 1

            # 2) Reindex existing mid-stile / mid-div parts at/after new_gap_index.
            for child in self._sorted_mid_parts():
                idx = child.get('hb_mid_stile_index', 0)
                if idx >= new_gap_index:
                    child['hb_mid_stile_index'] = idx + 1

            # 3) Insert mid_stile_widths entry at new_gap_index by
            #    add()-then-shuffle, since CollectionProperty has no
            #    insert(at). Shift values from new_gap_index forward.
            #    Seed from the cabinet's default (style-synced) rather
            #    than a constant: a hardcoded seed left inserted gaps at
            #    2" on styled cabinets whose stiles are 1.5", with no
            #    override flag to explain it.
            self._insert_mid_stile_width_entry(
                new_gap_index, cab_props.bay_mid_stile_width)

            # 4) Build the new bay object + opening.
            new_bay = self._create_bay_at(new_bay_index)

            # 4b) Replace the new bay's placeholder opening with a deep
            #     copy of the anchor bay's tree (openings, splits, front
            #     types, overlays, interior items / interior tree). Bay-
            #     level physical props stay at _create_bay_at defaults so
            #     the redistributor still gives the new bay an equal
            #     width share. Fronts / pulls are rebuilt by the recalc.
            anchor_roots = [c for c in anchor_bay.children
                            if c.get(TAG_OPENING_CAGE)
                            or c.get(TAG_SPLIT_NODE)]
            if anchor_roots:
                for placeholder in [c for c in new_bay.children
                                    if c.get(TAG_OPENING_CAGE)
                                    or c.get(TAG_SPLIT_NODE)]:
                    for d in list(placeholder.children_recursive):
                        bpy.data.objects.remove(d, do_unlink=True)
                    bpy.data.objects.remove(placeholder, do_unlink=True)
                _clone_bay_tree_node(anchor_roots[0], new_bay, [0])

            # 5) Build the new mid-stile + mid-div pair at new_gap_index.
            self._create_mid_parts_at(new_gap_index)
        finally:
            _RECALCULATING.discard(cabinet_id)
            _DISTRIBUTING_WIDTHS.discard(cabinet_id)

        # Route through the module-level wrapper, not the bare
        # recalculate(): the wrapper also runs _reapply_cabinet_style,
        # which re-adds the per-front door-style modifier the wipe-and-
        # rebuild recalc strips. Calling self.recalculate() directly
        # would leave every front rendering as a slab.
        recalculate_face_frame_cabinet(self.obj)
        return new_bay

    def delete_bay(self, bay_index):
        """Delete the bay at bay_index. Refuses if it would leave zero
        bays. Cleans up the bay's subtree (openings, fronts, pulls,
        interior items), removes one gap (mid_stile_widths entry plus
        the matching mid-stile and mid-div pair), and reindexes the
        rest. When deleting bay i:
          - if i < n_bays - 1: gap i is removed (right-of-bay)
          - else (last bay): gap n_gaps - 1 is removed (left-of-bay)
        """
        bays = self._sorted_bays()
        if len(bays) <= 1:
            return False
        bay_index = max(0, min(bay_index, len(bays) - 1))
        target_bay = bays[bay_index]

        n_bays_before = len(bays)
        n_gaps_before = max(0, n_bays_before - 1)
        if bay_index < n_bays_before - 1:
            removed_gap_index = bay_index
        else:
            removed_gap_index = n_gaps_before - 1

        cabinet_id = id(self.obj)
        _RECALCULATING.add(cabinet_id)
        _DISTRIBUTING_WIDTHS.add(cabinet_id)
        try:
            # 1) Wipe the bay's entire subtree (openings -> fronts ->
            #    pulls -> interior items, plus the bay cage itself).
            for descendant in list(target_bay.children_recursive):
                bpy.data.objects.remove(descendant, do_unlink=True)
            bpy.data.objects.remove(target_bay, do_unlink=True)

            # 2) Remove mid-stile + mid-div pair at removed_gap_index.
            for child in list(self._sorted_mid_parts()):
                if child.get('hb_mid_stile_index', 0) == removed_gap_index:
                    bpy.data.objects.remove(child, do_unlink=True)

            # 3) Remove the mid_stile_widths entry at removed_gap_index.
            self._remove_mid_stile_width_entry(removed_gap_index)

            # 4) Reindex remaining bays past bay_index down by one.
            for bay_obj in self._sorted_bays():
                idx = bay_obj.get('hb_bay_index', 0)
                if idx > bay_index:
                    bay_obj['hb_bay_index'] = idx - 1
                    bay_obj.face_frame_bay.bay_index = idx - 1

            # 5) Reindex remaining mid parts past removed_gap_index down
            #    by one.
            for child in self._sorted_mid_parts():
                idx = child.get('hb_mid_stile_index', 0)
                if idx > removed_gap_index:
                    child['hb_mid_stile_index'] = idx - 1
        finally:
            _RECALCULATING.discard(cabinet_id)
            _DISTRIBUTING_WIDTHS.discard(cabinet_id)

        # Route through the wrapper so _reapply_cabinet_style re-adds
        # the per-front door-style modifiers the rebuild strips.
        recalculate_face_frame_cabinet(self.obj)
        return True

    # ----- Helpers used by insert_bay / delete_bay -----------------------
    def _sorted_bays(self):
        return sorted(
            [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )

    def _sorted_mid_parts(self):
        """Cabinet children that participate in gap indexing: mid-stile
        plus the slot-0 / slot-1 mid-div pair per gap."""
        roles = (PART_ROLE_MID_STILE, PART_ROLE_MID_DIVISION)
        return sorted(
            [c for c in self.obj.children if c.get('hb_part_role') in roles],
            key=lambda c: (c.get('hb_mid_stile_index', 0),
                           0 if c.get('hb_part_role') == PART_ROLE_MID_STILE else 1,
                           c.get('hb_mid_div_slot', 0)),
        )

    def _insert_mid_stile_width_entry(self, index, width_value):
        """Insert a mid_stile_widths entry by add()+ripple-shift, since
        CollectionProperty doesn't expose insert-at. After this the
        entry at `index` carries width_value (and zeroed extends)."""
        coll = self.obj.face_frame_cabinet.mid_stile_widths
        coll.add()
        n = len(coll)
        for i in range(n - 2, index - 1, -1):
            coll[i + 1].width = coll[i].width
            coll[i + 1].extend_up_amount = coll[i].extend_up_amount
            coll[i + 1].extend_down_amount = coll[i].extend_down_amount
        coll[index].width = width_value
        coll[index].extend_up_amount = 0.0
        coll[index].extend_down_amount = 0.0

    def _remove_mid_stile_width_entry(self, index):
        coll = self.obj.face_frame_cabinet.mid_stile_widths
        n = len(coll)
        for i in range(index, n - 1):
            coll[i].width = coll[i + 1].width
            coll[i].extend_up_amount = coll[i + 1].extend_up_amount
            coll[i].extend_down_amount = coll[i + 1].extend_down_amount
        coll.remove(n - 1)

    def _create_bay_at(self, bay_index):
        """Build a fresh bay + single opening with hb_bay_index set.
        Width=0 + unlock_width=False -> recalc redistributor gives it an
        equal share among unlocked bays. Other defaults pulled from
        cabinet props (matching the initial _build_carcass_parts path).
        """
        cab_props = self.obj.face_frame_cabinet
        bay = FaceFrameBay()
        bay.create(f'Bay {bay_index + 1}')
        bay.obj.parent = self.obj
        bay.obj['hb_bay_index'] = bay_index
        bp = bay.obj.face_frame_bay
        bp.bay_index = bay_index
        bp.width = 0.0   # redistributor fills it
        # See _build_carcass_parts for bay.height / kick_height semantics.
        bp.height = cab_props.height
        bp.depth = cab_props.depth
        bp.kick_height = (cab_props.toe_kick_height
                          if self._has_toe_kick() else 0.0)
        bp.top_offset = 0.0
        bp.top_rail_width = cab_props.top_rail_width
        bp.bottom_rail_width = cab_props.bottom_rail_width

        opening = FaceFrameOpening()
        opening.create('Opening 1')
        opening.obj.parent = bay.obj
        opening.obj['hb_opening_index'] = 0
        opening.obj.face_frame_opening.opening_index = 0
        opening.obj.face_frame_opening.front_type = (
            default_front_type_for_root(self.obj)
        )
        return bay.obj

    def _create_mid_parts_at(self, gap_index):
        """Build a mid stile and a slot-0 / slot-1 mid div pair at
        gap_index. Mirrors the initial loop in _build_carcass_parts."""
        mid_stile = CabinetPart()
        mid_stile.create(f'Mid Stile {gap_index + 1}')
        mid_stile.obj.parent = self.obj
        mid_stile.obj['hb_part_role'] = PART_ROLE_MID_STILE
        mid_stile.obj['CABINET_PART'] = True
        mid_stile.obj['hb_mid_stile_index'] = gap_index
        mid_stile.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        mid_stile.obj.rotation_euler.y = math.radians(-90)
        mid_stile.obj.rotation_euler.z = math.radians(90)
        mid_stile.set_input('Mirror Y', True)
        mid_stile.set_input('Mirror Z', True)

        # Face-frame-only roots (panels / applied panels) have no carcass,
        # so they get the mid stile but never mid-division partitions or
        # partition skins. Mirrors the guard in _build_carcass_parts;
        # without it insert_bay (used by the applied-panel split) seeds
        # carcass parts onto panels that shouldn't have them.
        if not self._has_carcass():
            return

        for slot in (0, 1):
            mid_div = CabinetPart()
            mid_div.create(f'Mid Division {gap_index + 1}.{slot}')
            mid_div.obj.parent = self.obj
            mid_div.obj['hb_part_role'] = PART_ROLE_MID_DIVISION
            mid_div.obj['CABINET_PART'] = True
            mid_div.obj['hb_mid_stile_index'] = gap_index
            mid_div.obj['hb_mid_div_slot'] = slot
            mid_div.obj.rotation_euler.y = math.radians(-90)
            mid_div.set_input('Mirror Y', True)
            mid_div.set_input('Mirror Z', True)
            if slot == 1:
                mid_div.obj.hide_viewport = True
                mid_div.obj.hide_render = True
            else:
                notch_front = mid_div.add_part_modifier(
                    'CPM_CORNERNOTCH', 'Notch Top Front')
                notch_front.set_input('Flip X', True)
                notch_front.set_input('Flip Y', True)
                notch_front.mod.show_viewport = False
                notch_front.mod.show_render = False
                notch_back = mid_div.add_part_modifier(
                    'CPM_CORNERNOTCH', 'Notch Top Back')
                notch_back.set_input('Flip X', True)
                notch_back.set_input('Flip Y', False)
                notch_back.mod.show_viewport = False
                notch_back.mod.show_render = False

        # Partition skins: two slots per gap (slot 0 = bottom step,
        # slot 1 = top step, Upper/Tall only). Both start hidden;
        # recalc reveals + sizes them based on partition_skin_panels.
        for slot in (0, 1):
            skin = CabinetPart()
            skin.create(f'Partition Skin {gap_index + 1}.{slot}')
            skin.obj.parent = self.obj
            skin.obj['hb_part_role'] = PART_ROLE_PARTITION_SKIN
            skin.obj['CABINET_PART'] = True
            skin.obj['hb_mid_stile_index'] = gap_index
            skin.obj['hb_partition_skin_slot'] = slot
            skin.obj.rotation_euler.y = math.radians(-90)
            skin.set_input('Mirror Y', True)
            skin.set_input('Mirror Z', True)
            skin.obj.hide_viewport = True
            skin.obj.hide_render = True

    def _build_carcass_parts(self, bay_qty):
        """Body of create_carcass, factored out so the guard wrapping above
        is easy to read. Creates carcass parts, end stiles, bay cages, and
        mid stile parts. Initializes per-bay PropertyGroups.
        """
        # ----- Carcass -----
        # Skipped for face-frame-only roots (panels). Bottom / top / back
        # are already segment-keyed and lazy; only the side panels are
        # created up-front and need the explicit gate.
        if self._has_carcass():
            left = CabinetPart()
            left.create('Left Side')
            left.obj.parent = self.obj
            left.obj['hb_part_role'] = PART_ROLE_LEFT_SIDE
            left.obj['CABINET_PART'] = True
            left.obj.rotation_euler.y = math.radians(-90)
            left.set_input('Mirror Y', True)
            left.set_input('Mirror Z', True)
            # Front-bottom corner notch for NOTCH toe kick type. Both
            # sides have Mirror Y = True so Flip Y = True targets the
            # front face. Flip X = False targets the bottom (origin end
            # of Length axis). Driven and toggled per recalc; defaults
            # off so FLUSH / FLOATING / uppers see no cut.
            l_notch = left.add_part_modifier('CPM_CORNERNOTCH', 'Notch Front Bottom')
            l_notch.set_input('Flip X', False)
            l_notch.set_input('Flip Y', True)
            l_notch.mod.show_viewport = False
            l_notch.mod.show_render = False

            right = CabinetPart()
            right.create('Right Side')
            right.obj.parent = self.obj
            right.obj['hb_part_role'] = PART_ROLE_RIGHT_SIDE
            right.obj['CABINET_PART'] = True
            right.obj.rotation_euler.y = math.radians(-90)
            right.set_input('Mirror Y', True)
            right.set_input('Mirror Z', False)
            r_notch = right.add_part_modifier('CPM_CORNERNOTCH', 'Notch Front Bottom')
            r_notch.set_input('Flip X', False)
            r_notch.set_input('Flip Y', True)
            r_notch.mod.show_viewport = False
            r_notch.mod.show_render = False

            # Seam pieces: the top half of a side panel that has been
            # split at a joint height. Hidden until a seam is set.
            for seam_role in (PART_ROLE_LEFT_SIDE_SEAM,
                              PART_ROLE_RIGHT_SIDE_SEAM):
                self._ensure_side_seam_part(seam_role)

        # Bottom is segment-keyed; created lazily by _reconcile_carcass_bottoms.

        # Top is segment-keyed; created lazily by _reconcile_carcass_tops.

        # Back is segment-keyed; created lazily by _reconcile_carcass_backs.

        # ----- End stiles -----
        left_stile = CabinetPart()
        left_stile.create('Left End Stile')
        left_stile.obj.parent = self.obj
        left_stile.obj['hb_part_role'] = PART_ROLE_LEFT_STILE
        left_stile.obj['CABINET_PART'] = True
        left_stile.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        left_stile.obj.rotation_euler.y = math.radians(-90)
        left_stile.obj.rotation_euler.z = math.radians(90)
        left_stile.set_input('Mirror Y', True)
        left_stile.set_input('Mirror Z', True)

        right_stile = CabinetPart()
        right_stile.create('Right End Stile')
        right_stile.obj.parent = self.obj
        right_stile.obj['hb_part_role'] = PART_ROLE_RIGHT_STILE
        right_stile.obj['CABINET_PART'] = True
        right_stile.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        right_stile.obj.rotation_euler.y = math.radians(-90)
        right_stile.obj.rotation_euler.z = math.radians(90)
        right_stile.set_input('Mirror Y', False)
        right_stile.set_input('Mirror Z', True)

        # ----- Bay cages + bay-level prop initialization -----
        cab_props = self.obj.face_frame_cabinet
        bay_qty = max(1, int(bay_qty))
        equal_bay_width = (
            cab_props.width
            - cab_props.left_stile_width
            - cab_props.right_stile_width
            - (bay_qty - 1) * cab_props.bay_mid_stile_width
        ) / bay_qty

        for i in range(bay_qty):
            bay = FaceFrameBay()
            bay.create(f'Bay {i + 1}')
            bay.obj.parent = self.obj
            bay.obj['hb_bay_index'] = i
            bp = bay.obj.face_frame_bay
            bp.bay_index = i
            bp.width = equal_bay_width
            # bay.height runs floor to top of top rail. For base / tall
            # the kick lives inside this envelope at bay-local
            # [0, kick_height]; bay.kick_height is the floor-to-bottom-
            # rail distance, seeded from the cabinet default and held in
            # sync by _distribute_bay_kick_heights when locked.
            bp.height = cab_props.height
            bp.depth = cab_props.depth
            bp.kick_height = (cab_props.toe_kick_height
                              if self._has_toe_kick() else 0.0)
            bp.top_offset = 0.0
            bp.top_rail_width = cab_props.top_rail_width
            bp.bottom_rail_width = cab_props.bottom_rail_width

            # One opening per bay at create time - fills the bay's face
            # frame opening. Splitter operations subdivide a bay later by
            # adding more opening children.
            opening = FaceFrameOpening()
            opening.create('Opening 1')
            opening.obj.parent = bay.obj
            opening.obj['hb_opening_index'] = 0
            opening.obj.face_frame_opening.opening_index = 0
            opening.obj.face_frame_opening.front_type = (
                default_front_type_for_root(self.obj)
            )

        # ----- Mid stile parts + width collection (one per gap) -----
        cab_props.mid_stile_widths.clear()
        for i in range(bay_qty - 1):
            ms_entry = cab_props.mid_stile_widths.add()
            ms_entry.width = cab_props.bay_mid_stile_width

            mid_stile = CabinetPart()
            mid_stile.create(f'Mid Stile {i + 1}')
            mid_stile.obj.parent = self.obj
            mid_stile.obj['hb_part_role'] = PART_ROLE_MID_STILE
            mid_stile.obj['CABINET_PART'] = True
            mid_stile.obj['hb_mid_stile_index'] = i
            mid_stile.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
            mid_stile.obj.rotation_euler.y = math.radians(-90)
            mid_stile.obj.rotation_euler.z = math.radians(90)
            mid_stile.set_input('Mirror Y', True)
            mid_stile.set_input('Mirror Z', True)

            # Mid Division panels: carcass partition behind this mid
            # stile. Skipped for face-frame-only roots (panels). Two
            # slots per gap so we can show one centered panel for
            # matching bay depths or two face-to-face panels for
            # differing depths without create/delete during recalc. Slot
            # 1 starts hidden; recalc toggles it based on the panel list
            # returned by solver.mid_division_panels.
            if not self._has_carcass():
                continue
            for slot in (0, 1):
                mid_div = CabinetPart()
                mid_div.create(f'Mid Division {i + 1}.{slot}')
                mid_div.obj.parent = self.obj
                mid_div.obj['hb_part_role'] = PART_ROLE_MID_DIVISION
                mid_div.obj['CABINET_PART'] = True
                mid_div.obj['hb_mid_stile_index'] = i
                mid_div.obj['hb_mid_div_slot'] = slot
                mid_div.obj.rotation_euler.y = math.radians(-90)
                mid_div.set_input('Mirror Y', True)
                mid_div.set_input('Mirror Z', True)
                if slot == 1:
                    mid_div.obj.hide_viewport = True
                    mid_div.obj.hide_render = True
                else:
                    # Slot 0 may need stretcher notches at top-front and
                    # top-back when this gap has a single shared panel
                    # AND the stretcher segment passes through. Two
                    # CPM_CORNERNOTCH modifiers are added once at build
                    # time; recalc drives their X / Y / Route Depth and
                    # toggles show_viewport based on solver flags.
                    #
                    # Local-axis mapping after rot Y=-90, Mirror Y=True,
                    # Mirror Z=True:
                    #   local +X (Length) -> world +Z  (panel vertical)
                    #   local +Y (Width)  -> world +Y  (back is local +Y end)
                    #   local +Z (Thick)  -> world +X
                    # CPM_CORNERNOTCH operates in local space with X
                    # cutting along Length (vertical depth from one X
                    # end), Y cutting along Width (horizontal depth from
                    # one Y end), Route Depth cutting along Thickness.
                    # Top corner -> Flip X = True (X-far end = top).
                    # Front corner (world -Y) -> Flip Y = True (the
                    # Mirror-Y-driven far end = front face).
                    # Back corner (world +Y, the local-Y origin face)
                    # -> Flip Y = False (default end).
                    notch_front = mid_div.add_part_modifier(
                        'CPM_CORNERNOTCH', 'Notch Top Front')
                    notch_front.set_input('Flip X', True)
                    notch_front.set_input('Flip Y', True)
                    notch_front.mod.show_viewport = False
                    notch_front.mod.show_render = False
                    notch_back = mid_div.add_part_modifier(
                        'CPM_CORNERNOTCH', 'Notch Top Back')
                    notch_back.set_input('Flip X', True)
                    notch_back.set_input('Flip Y', False)
                    notch_back.mod.show_viewport = False
                    notch_back.mod.show_render = False

            # Partition skins: two slots per gap (slot 0 = bottom step,
            # slot 1 = top step, Upper/Tall only). Both start hidden;
            # recalc reveals + sizes them based on partition_skin_panels.
            for slot in (0, 1):
                skin = CabinetPart()
                skin.create(f'Partition Skin {i + 1}.{slot}')
                skin.obj.parent = self.obj
                skin.obj['hb_part_role'] = PART_ROLE_PARTITION_SKIN
                skin.obj['CABINET_PART'] = True
                skin.obj['hb_mid_stile_index'] = i
                skin.obj['hb_partition_skin_slot'] = slot
                skin.obj.rotation_euler.y = math.radians(-90)
                skin.set_input('Mirror Y', True)
                skin.set_input('Mirror Z', True)
                skin.obj.hide_viewport = True
                skin.obj.hide_render = True

        # Rails and per-bay carcass bottoms get created lazily by the segment reconciliation step inside
        # recalculate(). No initial rail objects needed here.

    # =====================================================================
    # Calculators - dimension distribution among peers (bay widths)
    # =====================================================================
    def _distribute_bay_depths(self):
        """For each bay where unlock_depth is False, sync the bay's
        depth to the cabinet depth. Bays with unlock_depth=True keep
        their stored value, allowing per-bay overrides.
        """
        cab_props = self.obj.face_frame_cabinet
        bays = sorted(
            [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )
        for bay_obj in bays:
            bp = bay_obj.face_frame_bay
            if bp.unlock_depth:
                continue
            if abs(bp.depth - cab_props.depth) > 1e-6:
                bp.depth = cab_props.depth

    def _distribute_bay_heights(self):
        """Sync each bay's height to cabinet height when unlock_height
        is False. bay.height is the full vertical extent floor to top of
        top rail; the toe kick lives inside it for base / tall bays via
        bay.kick_height (handled by _distribute_bay_kick_heights).
        """
        cab_props = self.obj.face_frame_cabinet
        bays = sorted(
            [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )
        if not bays:
            return
        target = cab_props.height
        for bay_obj in bays:
            bp = bay_obj.face_frame_bay
            if bp.unlock_height:
                continue
            if abs(bp.height - target) > 1e-6:
                bp.height = target

    def _distribute_bay_kick_heights(self):
        """Sync each bay's kick_height to cabinet toe_kick_height when
        unlock_kick_height is False. Mirrors _distribute_bay_widths.
        Uppers (no toe kick) get 0.

        System writes are bracketed by _DISTRIBUTING_WIDTHS so the bay's
        kick_height update callback knows not to treat them as user edits
        and auto-lock the bay.
        """
        cab_props = self.obj.face_frame_cabinet
        bays = sorted(
            [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )
        if not bays:
            return
        target = (cab_props.toe_kick_height
                  if self._has_toe_kick() else 0.0)
        _DISTRIBUTING_WIDTHS.add(id(self.obj))
        try:
            for bay_obj in bays:
                bp = bay_obj.face_frame_bay
                if bp.unlock_kick_height:
                    continue
                if abs(bp.kick_height - target) > 1e-6:
                    bp.kick_height = target
        finally:
            _DISTRIBUTING_WIDTHS.discard(id(self.obj))

    def _distribute_bay_rails(self):
        """Sync each bay's top / bottom rail width to the cabinet defaults
        unless the bay has the matching unlock_*_rail flag set. Mirrors
        _distribute_bay_depths: a locked bay follows the cabinet default,
        an unlocked bay holds its own per-bay rail override.
        """
        cab_props = self.obj.face_frame_cabinet
        bays = sorted(
            [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )
        for bay_obj in bays:
            bp = bay_obj.face_frame_bay
            if not bp.unlock_top_rail:
                if abs(bp.top_rail_width - cab_props.top_rail_width) > 1e-6:
                    bp.top_rail_width = cab_props.top_rail_width
            if not bp.unlock_bottom_rail:
                if abs(bp.bottom_rail_width - cab_props.bottom_rail_width) > 1e-6:
                    bp.bottom_rail_width = cab_props.bottom_rail_width

    def _distribute_bay_widths(self):
        """Redistribute available width among bays whose unlock_width is False.

        Runs at the top of recalculate() so that bay-width fields are up to
        date before the layout solver reads them. Bays with unlock_width=True
        hold their current width; bays with unlock_width=False each get an
        equal share of whatever width is left.

        System writes during this method are bracketed by _DISTRIBUTING_WIDTHS
        so the bay-width update callback knows not to auto-lock.
        """
        bays, consumed, available_width = bay_width_budget(self.obj)
        if not bays:
            return

        # Sum of locked bay widths
        locked_total = 0.0
        unlocked_bays = []
        for bay_obj in bays:
            bp = bay_obj.face_frame_bay
            if bp.unlock_width:
                locked_total += bp.width
            else:
                unlocked_bays.append(bay_obj)

        if not unlocked_bays:
            return  # all bays locked, nothing to redistribute

        remainder = available_width - consumed - locked_total
        share = remainder / len(unlocked_bays)

        # Write shares to unlocked bays under the distribution guard so
        # callbacks from these writes don't trigger auto-lock.
        _DISTRIBUTING_WIDTHS.add(id(self.obj))
        try:
            for bay_obj in unlocked_bays:
                bp = bay_obj.face_frame_bay
                if abs(bp.width - share) > 1e-6:
                    bp.width = share
        finally:
            _DISTRIBUTING_WIDTHS.discard(id(self.obj))

    # =====================================================================
    # Layout / dimension propagation - source of truth is the prop group.
    # No drivers; the solver writes resolved values directly to parts.
    # =====================================================================
    def _distribute_split_sizes(self):
        """Redistribute sizes among siblings inside every split node in
        every bay's tree. Walks the tree top-down: at each split node,
        the parent FF opening dim along the split's axis is divided
        into (n - 1) splitter widths plus n child sizes; locked
        children hold their stored value, unlocked share the rest.

        Mirrors _distribute_bay_widths but operates per-bay-tree
        instead of per-cabinet. System writes go through the
        _DISTRIBUTING_WIDTHS guard so update callbacks know not to
        auto-lock.
        """
        cab_props = self.obj.face_frame_cabinet
        for bay_obj in [c for c in self.obj.children
                        if c.get(TAG_BAY_CAGE)]:
            bp = bay_obj.face_frame_bay
            roots = [c for c in bay_obj.children
                     if c.get(TAG_OPENING_CAGE)
                     or c.get(TAG_SPLIT_NODE)]
            if not roots:
                continue
            root = roots[0]
            # Bay's tree root has no size of its own; it fills the bay's
            # face frame opening rect. bp.height spans floor to top of
            # top rail, so subtract both rails AND kick_height to leave
            # the FF opening only (uppers carry kick_height = 0 so this
            # is a no-op there). Same correction applied in
            # _bay_root_reveals; without it the children sum to a total
            # that's too large by kick_height and the bottom child
            # overflows when laid out against cage_dim_z.
            # remove_bottom mirrors solver.effective_bottom_rail_width:
            # with the rail removed the opening grows down into its
            # band, so no rail width is reserved -- otherwise stored
            # sizes run one rail short of the built openings (seen as
            # wrong opening heights on refrigerator cabinets, whose
            # bays all carry remove_bottom).
            eff_bottom = (0.0 if getattr(bp, 'remove_bottom', False)
                          else bp.bottom_rail_width)
            ff_height = (bp.height - bp.top_rail_width
                         - eff_bottom - bp.kick_height)
            ff_width = bp.width
            self._redistribute_split_node(root, ff_width, ff_height, cab_props,
                                          bay_props=bp, is_bay_root=True)

    def _splitter_widths_for(self, sp, children, n_splitters,
                             bay_props, is_bay_root):
        """Per-member splitter widths for the size math, matching what
        the solver actually builds.

        The node's scalar splitter_width is only the default: a member
        with an active per-index entry holds its own width, and the
        member capping a bay that dropped its bottom rail, whose lowest
        child is a frontless opening, is built as that bay's BOTTOM RAIL
        rather than a mid rail (see solver._walk_tree). Distributing on
        the scalar alone left the stored opening sizes disagreeing with
        the built daylight wherever either rule applies -- an appliance
        cabinet whose lowest zone runs open to the floor reported its
        door opening one rail-difference short.
        """
        ov = sp.splitter_widths
        widths = [
            (ov[i].width if i < len(ov) and ov[i].active
             else sp.splitter_width)
            for i in range(n_splitters)
        ]
        if not (n_splitters and sp.axis == 'H' and is_bay_root
                and bay_props is not None
                and getattr(bay_props, 'remove_bottom', False)):
            return widths
        last = children[-1]
        if not last.get(TAG_OPENING_CAGE):
            return widths
        if (last.face_frame_opening.front_type
                not in solver._FRONTLESS_FRONT_TYPES):
            return widths
        i = n_splitters - 1
        if i < len(ov) and ov[i].remove_member:
            return widths
        bottom_rail = bay_props.bottom_rail_width or 0.0
        if bottom_rail > 0.0:
            widths[i] = bottom_rail
        return widths

    def _redistribute_split_node(self, node, parent_ff_width,
                                 parent_ff_height, cab_props,
                                 bay_props=None, is_bay_root=False):
        """If `node` is a split, redistribute among its children and
        recurse into each child. The parent_ff_* args describe the FF
        opening dim of the rect this node occupies (which is what its
        children share). Leaves end the recursion.

        `bay_props` / `is_bay_root` describe where this node sits so the
        splitter widths can follow the same rules the solver builds by
        (see _splitter_widths_for); only the bay's own root node can
        carry the bottom-rail member.
        """
        if not node.get(TAG_SPLIT_NODE):
            return
        sp = node.face_frame_split
        children = sorted(
            [c for c in node.children
             if c.get(TAG_OPENING_CAGE) or c.get(TAG_SPLIT_NODE)],
            key=lambda c: c.get('hb_split_child_index', 0),
        )
        if not children:
            return

        is_h = (sp.axis == 'H')
        parent_dim = parent_ff_height if is_h else parent_ff_width
        n_splitters = len(children) - 1
        splitter_total = sum(self._splitter_widths_for(
            sp, children, n_splitters, bay_props, is_bay_root))

        locked_total = 0.0
        unlocked = []
        for c in children:
            size_val, unlock = self._read_node_size(c)
            if unlock:
                locked_total += size_val
            else:
                unlocked.append(c)

        # Vanity door rule: an unlocked child stamped SIZE_ROLE
        # 'VANITY_DOOR' takes its share plus VANITY_DOOR_EXTRA_WIDTH,
        # deducted from the pool first. Mirrors the geometry rule in
        # solver_face_frame._redistribute_sizes; both must agree or the
        # stored sizes drift from the built fronts.
        extra_total = sum(
            solver.VANITY_DOOR_EXTRA_WIDTH for c in unlocked
            if c.get('SIZE_ROLE') == 'VANITY_DOOR'
        )
        remainder = parent_dim - splitter_total - locked_total
        share = ((remainder - extra_total) / len(unlocked)) if unlocked else 0.0

        _DISTRIBUTING_WIDTHS.add(id(self.obj))
        try:
            for c in unlocked:
                extra = (solver.VANITY_DOOR_EXTRA_WIDTH
                         if c.get('SIZE_ROLE') == 'VANITY_DOOR' else 0.0)
                self._write_node_size(c, share + extra)
        finally:
            _DISTRIBUTING_WIDTHS.discard(id(self.obj))

        for c in children:
            size_val, _ = self._read_node_size(c)
            if is_h:
                child_w, child_h = parent_ff_width, size_val
            else:
                child_w, child_h = size_val, parent_ff_height
            self._redistribute_split_node(c, child_w, child_h, cab_props,
                                          bay_props=bay_props)

    def _read_node_size(self, obj):
        """Return (size, unlock_size) for any tree node (leaf opening
        or internal split node)."""
        if obj.get(TAG_OPENING_CAGE):
            op = obj.face_frame_opening
            return op.size, op.unlock_size
        if obj.get(TAG_SPLIT_NODE):
            sp = obj.face_frame_split
            return sp.size, sp.unlock_size
        return 0.0, False

    def _write_node_size(self, obj, value):
        """Write redistributed size to a tree node."""
        if obj.get(TAG_OPENING_CAGE):
            obj.face_frame_opening.size = value
        elif obj.get(TAG_SPLIT_NODE):
            obj.face_frame_split.size = value

    @hb_utils.with_children_index
    def recalculate(self):
        """Recompute all part dimensions and positions from props.

        Order:
        1. Sync cage Dim X/Y/Z (so the wireframe matches even if no parts)
        2. Build a FaceFrameLayout snapshot
        3. Compute top/bottom rail segments
        4. Reconcile rail objects against segments (create missing, delete obsolete)
        5. Walk all children and dispatch by role - write resolved geometry
        """
        cab_props = self.obj.face_frame_cabinet
        self.set_input('Dim X', cab_props.width)
        self.set_input('Dim Y', cab_props.depth)
        self.set_input('Dim Z', cab_props.height)

        # Depths and heights first - each bay's tree redistribution
        # reads bp.height to compute the available FF rect, and the
        # solver reads bp.depth for carcass parts.
        self._distribute_bay_depths()
        self._distribute_bay_heights()
        self._distribute_bay_kick_heights()
        # Rail widths follow the cabinet default unless a bay is unlocked.
        self._distribute_bay_rails()
        # Then the width calculator before the solver reads bay widths.
        self._distribute_bay_widths()
        # Then redistribute sizes inside each bay's tree of openings /
        # splits. Order matters: bay widths need to be settled first
        # because each bay's tree's available width comes from bp.width.
        self._distribute_split_sizes()

        layout = solver.FaceFrameLayout(self.obj)
        carcass_depth = solver.carcass_inner_depth(layout)

        # Compute and reconcile rail segments before the dispatch loop
        top_segments = solver.top_rail_segments(layout)
        bottom_segments = solver.bottom_rail_segments(layout)
        self._reconcile_rails(PART_ROLE_TOP_RAIL, top_segments)
        self._reconcile_rails(PART_ROLE_BOTTOM_RAIL, bottom_segments)
        # Drop fillers: filler stiles in each front-dropped bay's open
        # band, fitting a farm sink / cooktop (keyed per bay + side).
        drop_filler_segs = solver.front_drop_filler_segments(layout)
        self._reconcile_front_drop_fillers(drop_filler_segs)
        # Mitered mid stile halves at angled_multi bends (companion
        # right-half parts + their miter cutters).
        self._reconcile_mid_stile_bend_halves(layout)

        # Carcass branch - skipped for face-frame-only roots (panels).
        # Empty segment lists make the dispatch loop's carcass branches
        # no-ops, since _build_carcass_parts also skipped creating those
        # children.
        if self._has_carcass():
            carcass_bottom_segs = solver.carcass_bottom_segments(layout)
            carcass_back_segs = solver.carcass_back_segments(layout)
            self._reconcile_carcass_bottoms(carcass_bottom_segs)
            self._reconcile_carcass_backs(carcass_back_segs)
            if self._has_toe_kick():
                kick_subfront_segs = solver.kick_subfront_segments(layout)
                self._reconcile_kick_subfronts(kick_subfront_segs)
                kick_subrear_segs = solver.kick_subrear_segments(layout)
                self._reconcile_kick_subrears(kick_subrear_segs)
                finish_kick_segs = solver.finish_kick_segments(layout)
                self._reconcile_finish_kicks(finish_kick_segs)
                self._ensure_corner_finish_kick(
                    PART_ROLE_LEFT_CORNER_FINISH_KICK, 'Finish Toe Kick Left')
                self._ensure_corner_finish_kick(
                    PART_ROLE_RIGHT_CORNER_FINISH_KICK, 'Finish Toe Kick Right')
                self._reconcile_mid_finish_kicks(layout)
                self._ensure_partition_skin_slot2(layout)
                self._ensure_kick_return(
                    PART_ROLE_LEFT_KICK_RETURN, 'Toe Kick Return Left',
                    mirror_z=True)
                self._ensure_kick_return(
                    PART_ROLE_RIGHT_KICK_RETURN, 'Toe Kick Return Right',
                    mirror_z=False)
                # Loose ladder sub-base. Always ensured (hidden in the
                # dispatch loop unless toe_kick_type == 'LOOSE'), so a
                # toe-kick-type change toggles visibility without
                # creating / destroying parts.
                self._ensure_loose_kick_part(
                    PART_ROLE_LOOSE_KICK_FRONT, 'Loose Kick Front',
                    kind='RAIL', mirror_z=True)
                self._ensure_loose_kick_part(
                    PART_ROLE_LOOSE_KICK_REAR, 'Loose Kick Rear',
                    kind='RAIL', mirror_z=True)
                self._ensure_loose_kick_part(
                    PART_ROLE_LOOSE_KICK_END_LEFT, 'Loose Kick End Left',
                    kind='END', mirror_z=True)
                self._ensure_loose_kick_part(
                    PART_ROLE_LOOSE_KICK_END_RIGHT, 'Loose Kick End Right',
                    kind='END', mirror_z=False)
            else:
                kick_subfront_segs = []
                kick_subrear_segs = []
                finish_kick_segs = []
                self._reconcile_kick_subfronts([])
                self._reconcile_kick_subrears([])
                self._reconcile_finish_kicks([])

            # Blind panels exist on every carcass-bearing cabinet (Base /
            # Tall / Upper / Lap Drawer). Hidden when stile type isn't
            # BLIND or the side's blind flag is False - the dispatch loop
            # toggles visibility per side.
            self._ensure_blind_panel(
                PART_ROLE_BLIND_PANEL_LEFT, 'Blind Panel Left', mirror_y=True)
            self._ensure_blind_panel(
                PART_ROLE_BLIND_PANEL_RIGHT, 'Blind Panel Right', mirror_y=False)

            # Top construction branches on cabinet type:
            #   BASE / LAP_DRAWER -> Front + Rear stretchers
            #   UPPER / TALL      -> Solid top panel
            # Cleanup the other style's parts in case of cabinet-type
            # change or migration from a previous architecture.
            if layout.uses_stretchers:
                front_stretcher_segs = solver.front_stretcher_segments(layout)
                rear_stretcher_segs = solver.rear_stretcher_segments(layout)
                self._cleanup_role(PART_ROLE_TOP)
                self._reconcile_stretchers(PART_ROLE_FRONT_STRETCHER, front_stretcher_segs)
                self._reconcile_stretchers(PART_ROLE_REAR_STRETCHER, rear_stretcher_segs)
                carcass_top_segs = []
            else:
                carcass_top_segs = solver.carcass_top_segments(layout)
                self._cleanup_role(PART_ROLE_FRONT_STRETCHER)
                self._cleanup_role(PART_ROLE_REAR_STRETCHER)
                self._reconcile_carcass_tops(carcass_top_segs)
                front_stretcher_segs = []
                rear_stretcher_segs = []
        else:
            carcass_bottom_segs = []
            carcass_back_segs = []
            carcass_top_segs = []
            front_stretcher_segs = []
            rear_stretcher_segs = []
            kick_subfront_segs = []
            kick_subrear_segs = []
            finish_kick_segs = []

        top_seg_by_start = {s['start_bay']: s for s in top_segments}
        bot_seg_by_start = {s['start_bay']: s for s in bottom_segments}
        drop_filler_by_key = {(s['bay'], s['side']): s for s in drop_filler_segs}
        kick_seg_by_start = {s['start_bay']: s for s in kick_subfront_segs}
        rear_seg_by_start = {s['start_bay']: s for s in kick_subrear_segs}
        finish_kick_seg_by_start = {s['start_bay']: s for s in finish_kick_segs}
        carc_bot_by_start = {s['start_bay']: s for s in carcass_bottom_segs}
        carc_back_by_start = {s['start_bay']: s for s in carcass_back_segs}
        front_str_by_start = {s['start_bay']: s for s in front_stretcher_segs}
        rear_str_by_start = {s['start_bay']: s for s in rear_stretcher_segs}
        carc_top_by_start = {s['start_bay']: s for s in carcass_top_segs}

        # Ensure every part in this cabinet carries a right-click menu.
        # Fronts (nested under openings, not direct children) and parts
        # built before the part menu existed get the shared part-commands
        # menu - without clobbering parts that already have a more
        # specific one (interior parts, etc.).
        for _part_obj in self.obj.children_recursive:
            if _part_obj.get('hb_part_role') and not _part_obj.get('MENU_ID'):
                _part_obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'

        for child in self.obj.children:
            role = child.get('hb_part_role')
            bay_index = child.get('hb_bay_index', 0)

            # Bay cage handling (no hb_part_role; identified by tag)
            if child.get(TAG_BAY_CAGE):
                self._update_bay_cage(child, layout, bay_index)
                continue

            if not role:
                continue

            # Manual / frozen parts opt out of the parametric rewrite.
            # IS_MANUAL_PART is set by hb_face_frame.make_part_editable
            # once the cutpart GN has been applied to real mesh: the user
            # has hand-edited this board, so its location / dims / rotation
            # / visibility are left exactly as they are. Skipped BEFORE the
            # FF rotation block so a frozen stile / rail isn't re-rotated.
            #
            # Self-heal: a part whose cutpart GN modifier is gone has been
            # applied (by make_part_editable, or by hand in the modifier
            # stack) and has no inputs to push - set_input would raise. It
            # is manual by construction, so stamp the flag and skip. This
            # keeps recalc crash-proof regardless of how a part was applied.
            if child.type == 'MESH':
                _mn = child.home_builder.mod_name
                if _mn and _mn not in child.modifiers:
                    child['IS_MANUAL_PART'] = True
            if child.get('IS_MANUAL_PART'):
                continue

            # FF plane rotation. Hits stiles, rails, and kick subfronts;
            # leaves other parts (sides, back, panels) at their built-in
            # rotation_euler. Idempotent in square mode (theta = 0).
            # angled_multi: each part takes ITS bay's front angle (end
            # stiles from their end bay, segment-keyed members from
            # their start bay) instead of the one whole-cabinet theta.
            ff_baseline = FF_ROTATION_BASELINE_Z.get(role)
            if ff_baseline is not None:
                child.rotation_euler.z = (
                    ff_baseline + self._part_ff_theta(layout, role, child))

            part = GeoNodeCutpart(child)

            # ---- Carcass (sides shrink to leave room for the face frame at front) ----
            # End-side suppression: when the adjacent end bay has
            # remove_carcass set, the side panel becomes an orphan
            # (no back / bottom / top to attach to at that bay), so
            # hide it. The neighbouring bay's enclosure is provided by
            # the gap mid-division. remove_bottom is not enough to
            # warrant suppression - the carcass shell remains.
            if role == PART_ROLE_LEFT_SIDE:
                # FALSE_FF / WORKING_FF: the applied face frame IS the
                # side - no carcass side panel behind it.
                # An end combined with the run behind is the same
                # story, when the far run lays a BOARD across it: that
                # board is this end's side, and both would otherwise
                # sit in the same plane. An applied panel goes over a
                # side rather than replacing one, so a paneled
                # combined end keeps its board (island_pair returns
                # None there) and is just held back for the panel.
                visible = (not layout.bays[0].get('remove_carcass')
                           and layout.l_fin_end not in ('FALSE_FF',
                                                        'WORKING_FF')
                           and island_pair.covered_end_side_thickness(
                               self.obj, 'LEFT') is None)
                child.hide_viewport = not visible
                child.hide_render = not visible
                # Refresh the square baseline even when HIDDEN: the back
                # extension (_apply_back_extension / _angle_side_panel)
                # derives the splay line, hypotenuse width, and trim-
                # cutter placement from this part's live location.x and
                # Width every recalc. A hidden side left stale (values
                # still splayed from its last visible recalc) feeds the
                # splay math garbage - Width compounds by 1/cos each
                # pass and the cutter line drifts, misshaping the
                # stretchers / kick fronts / bottom whenever the end is
                # an applied-FF condition instead of FINISHED.
                pos = solver.left_side_position(layout)
                length, width, thickness = solver.left_side_dims(layout)
                # FINISHED side on an angled corner: run to the FF
                # FRONT plane; the bisector miter cut trims it against
                # the end stile (_apply_panel_front_miter).
                if (layout.l_fin_end == 'FINISHED'
                        and self._panel_miter_angles(layout, 'LEFT')[0]):
                    width += layout.fft
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)
                self._update_side_corner_notch(child, layout, 0)
                self._update_side_far_notch(child, layout)
                self._update_side_back_notch(child, layout, 0)

            elif role == PART_ROLE_RIGHT_SIDE:
                last = layout.bay_count - 1
                visible = (not layout.bays[last].get('remove_carcass')
                           and layout.r_fin_end not in ('FALSE_FF',
                                                        'WORKING_FF')
                           and island_pair.covered_end_side_thickness(
                               self.obj, 'RIGHT') is None)
                child.hide_viewport = not visible
                child.hide_render = not visible
                # Refresh the square baseline even when hidden - see the
                # LEFT_SIDE branch for why the back extension needs it.
                pos = solver.right_side_position(layout)
                length, width, thickness = solver.right_side_dims(layout)
                if (layout.r_fin_end == 'FINISHED'
                        and self._panel_miter_angles(layout, 'RIGHT')[0]):
                    width += layout.fft
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)
                self._update_side_corner_notch(child, layout, last)
                self._update_side_far_notch(child, layout)
                self._update_side_back_notch(child, layout, last)

            elif role == PART_ROLE_BOTTOM:
                seg = carc_bot_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['panel_dim_y'])
                part.set_input('Thickness', seg['thickness'])
                child[TAG_SEGMENT_FINISHED] = seg['finished']

            elif role == PART_ROLE_FRONT_STRETCHER:
                seg = front_str_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_REAR_STRETCHER:
                seg = rear_str_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_TOP:
                seg = carc_top_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['panel_dim_y'])
                part.set_input('Thickness', seg['thickness'])
                self._apply_top_sink_cutout(child, seg)

            elif role == PART_ROLE_BACK:
                # WORKING_FF back: the applied face frame is a real
                # access side - the 1/4 carcass back comes out (the
                # frame's working fronts open into the cavity). A
                # FALSE_FF back is decorative only and keeps the back.
                visible = layout.b_fin_end != 'WORKING_FF'
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                seg = carc_back_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['vertical_length'])
                part.set_input('Width', seg['horizontal_length'])
                part.set_input('Thickness', seg['thickness'])
                child[TAG_SEGMENT_FINISHED] = seg['finished']

            # ---- End stiles ----
            elif role == PART_ROLE_LEFT_STILE:
                length, width, thickness = solver.left_end_stile_dims(layout)
                # A stile with no width is not a part: some products
                # collapse the face frame to a single member, and a
                # zero-width board should not read on the drawings or
                # the cutlist. Same hide-and-skip the refrigerator
                # stile below uses.
                visible = width > 1e-6
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.left_end_stile_position(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            elif role == PART_ROLE_RIGHT_STILE:
                length, width, thickness = solver.right_end_stile_dims(layout)
                visible = width > 1e-6
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.right_end_stile_position(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            # ---- Refrigerator 'stile in lieu of leg' (floor -> opening top) ----
            elif role == PART_ROLE_LEFT_REFRIG_STILE:
                visible = solver.has_refrig_stile(layout, 'LEFT')
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.left_refrig_stile_position(layout)
                length, width, thickness = solver.left_refrig_stile_dims(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            elif role == PART_ROLE_RIGHT_REFRIG_STILE:
                visible = solver.has_refrig_stile(layout, 'RIGHT')
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.right_refrig_stile_position(layout)
                length, width, thickness = solver.right_refrig_stile_dims(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            # ---- Rails (segment-keyed) ----
            elif role == PART_ROLE_TOP_RAIL:
                seg = top_seg_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_BOTTOM_RAIL:
                seg = bot_seg_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            # ---- Drop fillers (front-dropped sink / cooktop band) ----
            elif role == PART_ROLE_FRONT_DROP_FILLER:
                seg = drop_filler_by_key.get(
                    (child.get('hb_segment_start_bay'),
                     child.get('hb_drop_filler_side')))
                if seg is None:
                    continue
                child.location = seg['pos']
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_TOE_KICK_SUBFRONT:
                seg = kick_seg_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_TOE_KICK_SUBREAR:
                seg = rear_seg_by_start.get(child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_FINISH_TOE_KICK:
                seg = finish_kick_seg_by_start.get(
                    child.get('hb_segment_start_bay'))
                if seg is None:
                    continue
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_LEFT_CORNER_FINISH_KICK:
                visible = solver.has_left_corner_finish_kick(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.left_corner_finish_kick_position(layout)
                length, width, thickness = solver.left_corner_finish_kick_dims(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            elif role == PART_ROLE_RIGHT_CORNER_FINISH_KICK:
                visible = solver.has_right_corner_finish_kick(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.right_corner_finish_kick_position(layout)
                length, width, thickness = solver.right_corner_finish_kick_dims(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            elif role == PART_ROLE_MID_FINISH_KICK:
                gi = child.get('hb_mid_stile_index', 0)
                side = child.get('hb_mid_kick_side', 'LEFT')
                pos = solver.mid_finish_kick_position(layout, gi, side)
                dims = solver.mid_finish_kick_dims(layout, gi, side)
                if pos is None or dims is None:
                    child.hide_viewport = True
                    child.hide_render = True
                    continue
                child.hide_viewport = False
                child.hide_render = False
                child.location = pos
                length, width, thickness = dims
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            elif role == PART_ROLE_LEFT_KICK_RETURN:
                visible = solver.has_left_kick_return(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.left_kick_return_position(layout)
                length, width, thickness = solver.left_kick_return_dims(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            elif role == PART_ROLE_RIGHT_KICK_RETURN:
                visible = solver.has_right_kick_return(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                pos = solver.right_kick_return_position(layout)
                length, width, thickness = solver.right_kick_return_dims(layout)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)

            # ---- Loose toe kick ladder (visible only for LOOSE) ----
            elif role == PART_ROLE_LOOSE_KICK_FRONT:
                visible = solver.has_loose_kick(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                seg = solver.loose_kick_front_rail(layout)
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_LOOSE_KICK_REAR:
                visible = solver.has_loose_kick(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                seg = solver.loose_kick_rear_rail(layout)
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_LOOSE_KICK_END_LEFT:
                visible = solver.has_loose_kick(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                seg = solver.loose_kick_end(layout, 'LEFT')
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_LOOSE_KICK_END_RIGHT:
                visible = solver.has_loose_kick(layout)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                seg = solver.loose_kick_end(layout, 'RIGHT')
                child.location = (seg['x'], seg['y'], seg['z'])
                part.set_input('Length', seg['length'])
                part.set_input('Width', seg['width'])
                part.set_input('Thickness', seg['thickness'])

            elif role == PART_ROLE_BLIND_PANEL_LEFT:
                # Visible when the left end is a blind corner stile AND
                # the side's blind flag is on (an adjacent cabinet is
                # actually butted against this stile). Either condition
                # off and the panel hides without being deleted.
                visible = (cab_props.left_stile_type == 'BLIND'
                           and cab_props.blind_left
                           and cab_props.blind_amount_left > 0)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                z_origin, z_height = self._blind_panel_z_range('LEFT')
                # Anchored at the LEFT endpoint of the FF outer plane,
                # offset back by face_frame_thickness so the panel sits
                # just behind the face frame. Length runs vertically
                # (cabinet interior height); Width runs +X by
                # blind_amount via Mirror Y=True (matches left stile);
                # Thickness extends +Y deeper into the cabinet body.
                child.location = (0.0,
                                  -cab_props.depth + cab_props.face_frame_thickness,
                                  z_origin)
                part.set_input('Length', z_height)
                part.set_input('Width', cab_props.blind_amount_left)
                part.set_input('Thickness', BLIND_PANEL_THICKNESS)

            elif role == PART_ROLE_BLIND_PANEL_RIGHT:
                visible = (cab_props.right_stile_type == 'BLIND'
                           and cab_props.blind_right
                           and cab_props.blind_amount_right > 0)
                child.hide_viewport = not visible
                child.hide_render = not visible
                if not visible:
                    continue
                z_origin, z_height = self._blind_panel_z_range('RIGHT')
                # Anchored at the RIGHT endpoint of the FF outer plane.
                # Mirror Y=False makes Width grow -X from this anchor
                # (matches right stile), so the panel reaches inboard
                # by blind_amount.
                child.location = (cab_props.width,
                                  -cab_props.depth + cab_props.face_frame_thickness,
                                  z_origin)
                part.set_input('Length', z_height)
                part.set_input('Width', cab_props.blind_amount_right)
                part.set_input('Thickness', BLIND_PANEL_THICKNESS)

            # ---- Mid stiles (gap-keyed) ----
            elif role == PART_ROLE_MID_STILE:
                # Backfill MENU_ID for cabinets created before right-click was added
                if not child.get('MENU_ID'):
                    child['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
                msi = child.get('hb_mid_stile_index', 0)
                if msi >= len(layout.mid_stiles):
                    child.hide_viewport = True
                    continue
                child.hide_viewport = False
                halves = solver.mid_stile_bend_halves(layout, msi)
                if halves is not None:
                    # This stile sits on a bend: it becomes the LEFT
                    # half, lying in the left region's front plane and
                    # mitered against the companion right half at the
                    # bend line.
                    h = halves['left']
                    child.location = h['pos']
                    child.rotation_euler.z = math.pi / 2 + h['theta']
                    part.set_input('Length', halves['length'])
                    part.set_input('Width', h['width'])
                    part.set_input('Thickness', halves['thickness'])
                    self._apply_mid_stile_miter(child, layout, msi,
                                                'LEFT', halves)
                    continue
                self._clear_mid_stile_miter(child)
                child.rotation_euler.z = math.pi / 2
                pos = solver.mid_stile_position(layout, msi)
                length, width, thickness = solver.mid_stile_dims(layout, msi)
                child.location = pos
                part.set_input('Length', length)
                part.set_input('Width', width)
                part.set_input('Thickness', thickness)
                self._apply_mid_stile_step_notches(child, part, layout, msi)

            elif role == PART_ROLE_MID_STILE_HALF:
                msi = child.get('hb_mid_stile_index', 0)
                halves = (solver.mid_stile_bend_halves(layout, msi)
                          if msi < len(layout.mid_stiles) else None)
                if halves is None:
                    # Reconcile pre-pass deletes stale companions; this
                    # is just a same-recalc safety net.
                    child.hide_viewport = True
                    child.hide_render = True
                    continue
                child.hide_viewport = False
                child.hide_render = False
                h = halves['right']
                child.location = h['pos']
                child.rotation_euler.z = math.pi / 2 + h['theta']
                part.set_input('Length', halves['length'])
                part.set_input('Width', h['width'])
                part.set_input('Thickness', halves['thickness'])
                self._apply_mid_stile_miter(child, layout, msi,
                                            'RIGHT', halves)

            elif role == PART_ROLE_MID_DIVISION:
                msi = child.get('hb_mid_stile_index', 0)
                slot = child.get('hb_mid_div_slot', 0)
                panels = solver.mid_division_panels(layout, msi)
                # Pick the panel whose slot matches this child. Slot 0
                # is always present when the gap exists; slot 1 only
                # when bay depths differ (2-panel diff-depth case).
                panel = next((p for p in panels if p['slot'] == slot), None)
                if panel is None:
                    child.hide_viewport = True
                    child.hide_render = True
                    continue
                child.hide_viewport = False
                child.hide_render = False
                child.location = (panel['x'], panel['y'], panel['z'])
                part.set_input('Length',    panel['length'])
                part.set_input('Width',     panel['width'])
                part.set_input('Thickness', panel['thickness'])
                # Bay-height step: this division is the void's finished
                # surface (flush with the stile's notch plane); the
                # material walk reads the stamp and finishes the
                # void-side face.
                side = panel.get('step_flush')
                if side:
                    child['HB_STEP_FINISHED_SIDE'] = side
                elif 'HB_STEP_FINISHED_SIDE' in child:
                    del child['HB_STEP_FINISHED_SIDE']
                # Drive top stretcher notches (slot 0 only - slot 1 has
                # no notch modifiers and panel['notch_active'] is False
                # there anyway).
                self._update_mid_div_notches(child, panel)
                # Toe-kick notch for a division that finishes a void
                # down to the floor.
                self._drive_mid_div_floor_notch(child, layout, msi, panel)

            elif role == PART_ROLE_PARTITION_SKIN:
                msi = child.get('hb_mid_stile_index', 0)
                slot = child.get('hb_partition_skin_slot', 0)
                skins = solver.partition_skin_panels(layout, msi)
                skin = next((s for s in skins if s['slot'] == slot), None)
                if slot == 2:
                    # Slot 2 (floating finish) drops to the floor; notch its
                    # front-bottom to clear the toe-kick recess (off when the
                    # gap's mid stile is itself stile-to-floor).
                    self._drive_partition_skin_floor_notch(
                        child, layout, msi, skin)
                if skin is None:
                    child.hide_viewport = True
                    child.hide_render = True
                    continue
                child.hide_viewport = False
                child.hide_render = False
                child.location = (skin['x'], skin['y'], skin['z'])
                part.set_input('Length',    skin['length'])
                part.set_input('Width',     skin['width'])
                part.set_input('Thickness', skin['thickness'])

        # Spawn / resize / remove applied finished-end panels last so
        # they pick up the most recent cabinet dimensions. Skipped for
        # panel roots (a panel never carries another panel as its end).
        if self._has_carcass():
            self._reconcile_applied_panels(layout)
            self._reconcile_finished_back(layout)
            self._reconcile_flush_x_strips(layout)
            self._reconcile_full_overlay_stiles(layout)
            self._update_blind_section_parts(layout)
            self._reconcile_textured_panels(layout)
            self._reconcile_bay_finish_panels(layout)
            # Run a FINISHED carcass side past the cabinet back by its
            # per-side extend. The applied / textured side families carry
            # their own overhang above; the FINISHED side has no applied
            # part, so the carcass side itself is grown here.
            self._extend_finished_side_panels(layout)
            # Close the exposed corner of an extended finished side with a
            # return panel + rear stile when a return width is set (needs a
            # FINISHED back to return into). Runs after the extend so it can
            # read the grown side's rear edge.
            self._reconcile_finished_side_returns(layout)

        # Angled cabinet cutter: drives the trapezoidal silhouette on
        # the root cage, top, bottom, and any shelves. Lazy: created
        # on transition into angled mode, removed on transition out.
        # Single-bay keeps the one rotated cage cutter; angled_multi
        # uses per-end triangular wedge cutters instead (only the end
        # bays angle - the middle stays square and must not be cut).
        if layout.is_angled and self._has_carcass():
            if layout.angled_multi:
                self._cleanup_single_angled_cutter_and_cuts()
                self._apply_multi_angled_wedges(layout)
            else:
                self._cleanup_multi_angled_wedges()
                cutter_obj = self._ensure_angled_cutter()
                self._position_angled_cutter(cutter_obj, layout)
                self._apply_angled_cuts(cutter_obj)
        else:
            self._cleanup_angled_cutter_and_cuts()

        # Angled back extension: splay one/both side panels outward at the
        # back and widen the carcass panels, so the back is wider than the
        # square front (access into an angled wall corner). Runs after the
        # part loop so it reshapes the already-positioned sides / back /
        # top / bottom in place; a no-op when both extends are 0.
        if self._has_carcass():
            self._apply_back_extension(layout)

        # Extend Bottom / Top (uppers): overhang the carcass bottom or top
        # past a side to cover the corner void where two uppers meet. Runs
        # after the part loop / back extension so it reshapes the positioned
        # deck parts in place.
        if self._has_carcass() and layout.cabinet_type == 'UPPER':
            self._apply_bottom_extension(layout)
            self._apply_top_extension(layout)

        # Finished bottom (uppers): applied finish panel + LED route +
        # optional render light. Unconditional so a cleared condition
        # cleans up its parts.
        self._apply_finished_bottom(layout)

        # Under-cabinet appliances (uppers): microwave / short vent hood
        # blocks hanging under a bay. Unconditional so clearing a bay's
        # selection removes its block.
        self._apply_under_cabinet_appliances(layout)

        # Galley workstation construction: aprons, partitions, cleats
        # and the sink. Unconditional so another cabinet sheds them.
        self._apply_galley_parts(layout)

        # Appliance bay annotation (square + SINK / COOKTOP word) on top
        # of stamped bays and the dedicated sink cabinet's basin bay.
        # Unconditional so stale annotations are wiped even when the
        # trigger goes away.
        self._apply_appliance_annotations(layout)

        # Furniture / veneer wood top: an overhanging slab sitting proud
        # on the carcass top (dresser / furniture products). Managed like
        # the cutters so it tracks width / depth / height; a no-op when
        # furniture_top is off.
        self._apply_furniture_top(layout)

        # Hutch finished back: close the open recess below an upper
        # whose ends are extended down. No-op when off / no drop.
        self._apply_hutch_back(layout)

        # Over-stool side-front profile: cut the decorative leg profile into
        # the bottom-front of each extended side. No-op + cleanup when off.
        self._apply_overstool_profile(layout)

        # Seamed side panels: split a finished end into two boards at
        # the height the user picked. After every pass that sizes or
        # moves a side (back extension, extend-back, overstool profile)
        # so the piece above the joint inherits the finished panel, and
        # before the notch / boolean passes below so a full-height cut
        # reaches both pieces.
        self._reconcile_side_seams(layout)

        # Bottom-rail decorative profile (valance): cut the chosen profile
        # into the bottom rail(s). No-op + cleanup when off.
        self._apply_bottom_rail_profile(layout)

        # Corner treatment: the style's edge detail on the exposed face
        # frame arrises. No-op + cleanup when Square / unset.
        self._apply_corner_treatment(layout)

        # Inset frame profile: the overlay's edge detail around every
        # opening. No-op + cleanup for square-edged overlays.
        self._apply_frame_profile(layout)

        # Over-stool leg accessories: shelf and/or towel bar between the legs
        # per the overstool_accessory dropdown. No-op + cleanup when off.
        self._apply_overstool_accessories(layout)

        # Tip-up wedge: chamfer the back-bottom corner when enabled and the
        # cabinet's tip-up diagonal exceeds the ceiling. Re-applied here so
        # it survives part reconciliation, exactly like the angled cutter.
        self._reconcile_ada_side_shape(layout)

        wedge = solver.wedge_geometry(layout) if self._has_carcass() else None
        if wedge is not None:
            length, height, _clamped = wedge
            cutter_obj = self._ensure_wedge_cutter()
            self._position_wedge_cutter(cutter_obj, length, height)
            self._apply_wedge_cuts(cutter_obj)
            self._position_wedge_piece(layout, length, height)
            # Publish the computed dims on the cabinet root (meters) as
            # id props so downstream consumers (e.g. drawing / annotation
            # layers) can read them without recomputing. Cleared when the
            # wedge is removed.
            self.obj['WEDGE_LENGTH'] = length
            self.obj['WEDGE_HEIGHT'] = height
        else:
            self._cleanup_wedge_cutter_and_cuts()
            for _k in ('WEDGE_LENGTH', 'WEDGE_HEIGHT'):
                if _k in self.obj:
                    del self.obj[_k]

        # Pipe chase: full-height back-corner / back-middle notch with
        # cover panels. Re-applied here so it survives part
        # reconciliation, exactly like the tip-up wedge. No-op + cleanup
        # when chase_enabled is off.
        self._apply_pipe_chase(layout)

        # Decorative corners: square notch in a vertical corner filled
        # by a milled post. Last, so the notch cuts parts the passes
        # above have already reshaped (back extension, extended bottom,
        # finished bottom). No-op + cleanup when no corner is on.
        self._apply_decorative_corners(layout)

        # Cabinet columns: split turnings applied over stiles, proud of
        # the frame face. Nothing to cut, so ordering only needs the
        # frame's final geometry. No-op + cleanup when none assigned.
        self._apply_cabinet_columns(layout)


    # ------------------------------------------------------------------
    # Round-top doors: the face frame follows the arc
    # ------------------------------------------------------------------
    # A quarter / half circle door cuts its own top corner away, which
    # would leave the square frame opening showing daylight above the
    # curve. The member above the door has to carry the same curve: it
    # grows down to the door's springline and its bottom edge becomes an
    # arc concentric with the door's, sitting the overlay inside it. One
    # wide curved rail, the way it is cut from a blank.
    #
    # The member keeps its cutpart Length / Width (the rail width the
    # user set, and everything that reads it) and renders a static mesh
    # instead, the same trade the python-built doors make.

    _ARCH_RAIL_TAG = 'HB_ARCH_FRAME_RAIL'
    _ARCH_RAIL_SEGS = 24

    def _part_local_matrix(self, obj, closed_front=False):
        """obj's transform in this cabinet's space, composed from the
        stored transform channels rather than matrix_world, which is a
        depsgraph result and is stale mid-recalc.

        With closed_front, a front pivot contributes its position but
        not its swing, giving the transform the part would have with
        the door shut. Anything derived from a front's OUTLINE has to
        read it that way: the pivot carries swing_percent, so a door
        standing open would otherwise report its arc swung out of the
        opening, and the member above it would find no curve to follow.
        """
        m = Matrix.Identity(4)
        node = obj
        while node is not None and node is not self.obj:
            basis = node.matrix_basis
            is_pivot = node.get('hb_part_role') == PART_ROLE_FRONT_PIVOT
            if closed_front and is_pivot:
                basis = (Matrix.Translation(node.location)
                         @ Matrix.Diagonal(node.scale.to_4d()))
            m = (node.matrix_parent_inverse @ basis) @ m
            node = node.parent
        return m

    def _cutpart_box_local(self, obj):
        """(x0, x1, y0, y1, z0, z1) of a cutpart's box in this cabinet's
        space, from its Length / Width / Thickness and mirror flags -
        analytic, so it holds before the depsgraph has evaluated the
        modifier. None when obj isn't a cutpart."""
        try:
            part = GeoNodeCutpart(obj)
            length = part.get_input('Length')
            width = part.get_input('Width')
            thickness = part.get_input('Thickness')
            mx = bool(part.get_input('Mirror X'))
            my = bool(part.get_input('Mirror Y'))
            mz = bool(part.get_input('Mirror Z'))
        except Exception:
            return None
        spans = ((-length, 0.0) if mx else (0.0, length),
                 (-width, 0.0) if my else (0.0, width),
                 (-thickness, 0.0) if mz else (0.0, thickness))
        m = self._part_local_matrix(obj)
        pts = [m @ Vector((x, y, z))
               for x in spans[0] for y in spans[1] for z in spans[2]]
        return (min(p.x for p in pts), max(p.x for p in pts),
                min(p.y for p in pts), max(p.y for p in pts),
                min(p.z for p in pts), max(p.z for p in pts))

    def _round_top_door_arcs(self):
        """The outline arcs of this cabinet's round-top doors, in cabinet
        space: dicts of centre (cx, cz), radius, the x span the arc
        covers and the door's top edge. Empty when no door is round."""
        from . import props_hb_face_frame as ff_props
        arcs = []
        for obj in self.obj.children_recursive:
            if obj.get('hb_part_role') != PART_ROLE_DOOR:
                continue
            geom, _reason = ff_props.front_round_top_geometry(obj)
            if geom is None:
                continue
            # The door mesh runs its height along +X and its width along
            # -Y (or +Y unmirrored, see _mirror_front_mesh_y_if_unmirrored),
            # so door-local (x across, z up) maps in as (z, -x) / (z, x).
            sign = -1.0
            try:
                if not GeoNodeCutpart(obj).get_input('Mirror Y'):
                    sign = 1.0
            except Exception:
                pass
            # Closed: the curve belongs to the opening, not to wherever
            # the door happens to be swung to right now.
            mat = self._part_local_matrix(obj, closed_front=True)

            def to_cab(dx, dz):
                return mat @ Vector((dz, sign * dx, 0.0))

            centre = to_cab(geom['centre_x'], geom['z_spring'])
            ends = [to_cab(*geom['outline'][0]), to_cab(*geom['outline'][-1])]
            radius = geom['radius']
            arcs.append(dict(cx=centre.x, cz=centre.z, radius=radius,
                             x_lo=min(e.x for e in ends),
                             x_hi=max(e.x for e in ends),
                             door_top=centre.z + radius,
                             door=obj))
        return arcs

    # How far a member's bottom may sit clear of the door's top and
    # still count as the member above it. An overlay door reaches into
    # the member's band (negative clearance) and an inset one stops a
    # reveal short, so the gate only has to be wider than a reveal --
    # wide enough and a door with nothing over it would reach up and
    # grab a rail two openings away.
    _ARCH_MEMBER_GAP = inch(1.0)

    def _arch_frame_member(self, arc, members):
        """The frame member sitting above a door arc: the lowest one
        spanning the door that reaches above the door's top. Inset doors
        sit a reveal BELOW the member, overlay doors lap up into it, so
        this takes the nearest member above rather than the one the
        door's top lands inside. None when the door has nothing over it
        (a door running to the top of a frameless opening)."""
        x_mid = (arc['x_lo'] + arc['x_hi']) / 2.0
        best = None
        for obj, box in members:
            x0, x1, _y0, _y1, z0, z1 = box
            if x_mid < x0 - 1e-6 or x_mid > x1 + 1e-6:
                continue
            if z1 < arc['door_top'] - 1e-6:
                continue
            if z0 - arc['door_top'] > self._ARCH_MEMBER_GAP:
                continue
            if best is None or z0 < best[1][4]:
                best = (obj, box)
        return best

    def _arch_bottom_profile(self, box, arcs):
        """Bottom edge of an arched member, left to right, as absolute
        (x, z) points in cabinet space: the member's own bottom line,
        dipping under each door's arc. The frame arc is concentric with
        the door's, one overlay in, so it meets the door's straight
        edges tangentially and peaks exactly on the member's bottom."""
        x0, x1, _y0, _y1, z0, _z1 = box
        stations = {x0, x1}
        curves = []
        for arc in arcs:
            radius = arc['radius'] - (arc['door_top'] - z0)
            if radius <= 0.0:
                continue
            lo = max(x0, max(arc['x_lo'], arc['cx'] - radius))
            hi = min(x1, min(arc['x_hi'], arc['cx'] + radius))
            if hi - lo <= 1e-9:
                continue
            curves.append((arc['cx'], arc['cz'], radius, lo, hi))
            for i in range(self._ARCH_RAIL_SEGS + 1):
                stations.add(lo + (hi - lo) * i / self._ARCH_RAIL_SEGS)
        if not curves:
            return None

        def bottom_at(x):
            z = z0
            for cx, cz, radius, lo, hi in curves:
                if x < lo - 1e-9 or x > hi + 1e-9:
                    continue
                dx = min(abs(x - cx), radius)
                z = min(z, cz + math.sqrt(max(radius * radius - dx * dx, 0.0)))
            return z

        return [(x, bottom_at(x)) for x in sorted(stations)]

    def _build_arch_member_mesh(self, obj, box, bottom):
        """Replace a frame member's box with a static mesh whose bottom
        edge follows ``bottom``, and mute its cutpart so the box stops
        drawing. Materials come off the cutpart's own sockets so the
        member keeps its finish."""
        x0, x1, y0, y1, _z0, z1 = box
        poly = [(x0, z1), (x1, z1)]
        poly += [(x, z) for (x, z) in reversed(bottom)]
        # Drop repeats so the cap ngons stay clean.
        loop = []
        for pt in poly:
            if (not loop or abs(pt[0] - loop[-1][0]) > 1e-9
                    or abs(pt[1] - loop[-1][1]) > 1e-9):
                loop.append(pt)
        if len(loop) < 3:
            return False
        inv = self._part_local_matrix(obj).inverted()
        verts = []
        for y in (y0, y1):
            for (x, z) in loop:
                verts.append(inv @ Vector((x, y, z)))
        n = len(loop)
        faces = [tuple(range(n)), tuple(reversed(range(n, 2 * n)))]
        slots = [0, 0]
        for i in range(n):
            j = (i + 1) % n
            faces.append((i, n + i, n + j, j))
            slots.append(1)
        mats = self._cutpart_materials(obj)
        me = obj.data
        me.clear_geometry()
        me.from_pydata([tuple(v) for v in verts], [], faces)
        if mats:
            me.materials.clear()
            for mat in mats:
                me.materials.append(mat)
            attr = (me.attributes.get('material_index')
                    or me.attributes.new('material_index', 'INT', 'FACE'))
            attr.data.foreach_set('value', slots)
        me.update()
        # The member's local axes differ by role, so let bmesh settle
        # the winding rather than assuming one: the prism is closed,
        # so recalculated normals all face out.
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
        me.update()
        for mod in obj.modifiers:
            if mod.type == 'NODES' and mod.node_group \
                    and mod.node_group.name == 'GeoNodeCutpart':
                mod.show_viewport = False
                mod.show_render = False
        obj[self._ARCH_RAIL_TAG] = True
        return True

    def _cutpart_materials(self, obj):
        """(face, edge) materials a cutpart is carrying, for a static
        mesh that replaces its box. Socket values go through hb_utils:
        modifier inputs stopped being ID properties in 5.2, and reading
        them directly raises there instead of coming back empty - which
        took the whole arch pass down with it."""
        for mod in obj.modifiers:
            if mod.type != 'NODES' or not mod.node_group:
                continue
            if mod.node_group.name != 'GeoNodeCutpart':
                continue
            face = edge = None
            for item in mod.node_group.interface.items_tree:
                if getattr(item, 'item_type', '') != 'SOCKET':
                    continue
                if item.name == 'Top Surface':
                    face = hb_utils.try_get_gn_input(mod, item.identifier)
                elif item.name == 'Edge L1':
                    edge = hb_utils.try_get_gn_input(mod, item.identifier)
            if face is not None or edge is not None:
                return [face, edge if edge is not None else face]
        return []

    def _restore_arch_member(self, obj):
        """Put a member that no longer carries an arch back on its box."""
        obj.data.clear_geometry()
        # The box takes its materials from the cutpart's sockets; the
        # slots the static mesh added would shadow them.
        obj.data.materials.clear()
        obj.data.update()
        for mod in obj.modifiers:
            if mod.type == 'NODES' and mod.node_group \
                    and mod.node_group.name == 'GeoNodeCutpart':
                mod.show_viewport = True
                mod.show_render = True
        if self._ARCH_RAIL_TAG in obj:
            del obj[self._ARCH_RAIL_TAG]

    def _apply_round_top_frames(self):
        """Carry each round-top door's curve into the frame member above
        it. Reads the built doors and members rather than the layout
        snapshot, so it can also be re-run on its own when a door's
        shape changes without a full recalc (see
        refresh_round_top_frames). No-op + cleanup when no door in the
        cabinet is round."""
        was_arched = [o for o in self.obj.children_recursive
                      if o.get(self._ARCH_RAIL_TAG)]
        arcs = self._round_top_door_arcs()
        arched = []
        if arcs:
            members = []
            for obj in self.obj.children_recursive:
                role = obj.get('hb_part_role') or ''
                if not role.endswith('_RAIL'):
                    continue
                box = self._cutpart_box_local(obj)
                if box is not None:
                    members.append((obj, box))
            by_member = {}
            for arc in arcs:
                found = self._arch_frame_member(arc, members)
                if found is None:
                    continue
                obj, box = found
                by_member.setdefault(obj.name, (obj, box, []))[2].append(arc)
            for obj, box, member_arcs in by_member.values():
                bottom = self._arch_bottom_profile(box, member_arcs)
                if bottom is None:
                    continue
                if self._build_arch_member_mesh(obj, box, bottom):
                    arched.append(obj)
        for obj in was_arched:
            if obj not in arched:
                self._restore_arch_member(obj)

    def _part_ff_theta(self, layout, role, child):
        """Z rotation added to a FF part's baseline. Single-plane cabinets
        (square or single-bay angled) share one face_frame_angle.
        angled_multi resolves per part: LEFT-anchored roles take bay 0's
        front angle, RIGHT-anchored roles the last bay's, and
        segment-keyed members (rails, kicks, drop fillers - split at the
        bend points by the solver) their start bay's. Mid stiles aren't
        in FF_ROTATION_BASELINE_Z and stay square at the bends."""
        if not layout.angled_multi:
            return solver.face_frame_angle(layout)
        if role in (PART_ROLE_LEFT_STILE, PART_ROLE_LEFT_REFRIG_STILE,
                    PART_ROLE_BLIND_PANEL_LEFT):
            return solver.bay_front_angle(layout, 0)
        if role in (PART_ROLE_RIGHT_STILE, PART_ROLE_RIGHT_REFRIG_STILE,
                    PART_ROLE_BLIND_PANEL_RIGHT):
            return solver.bay_front_angle(layout, layout.bay_count - 1)
        return solver.bay_front_angle(
            layout, child.get('hb_segment_start_bay', 0))

    # =====================================================================
    # Angled cabinet cutter (unlock_left/right_depth on)
    # =====================================================================
    def _ensure_angled_cutter(self):
        """Find the cabinet's angled cutter or build it. Lazy: only
        called when entering angled mode, so non-angled cabinets carry
        no extra child. Skips the per-end wedge cutters of the
        angled_multi path (tagged hb_angled_side)."""
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_ANGLED_CUTTER
                    and not child.get('hb_angled_side')):
                return child
        cutter = GeoNodeCage()
        cutter.create('Angled Cutter')
        cutter.obj.parent = self.obj
        cutter.obj['hb_part_role'] = PART_ROLE_ANGLED_CUTTER
        # Show Cage emits the cage geometry the boolean reads from;
        # hide_viewport keeps the wireframe out of the artist's way.
        cutter.set_input('Show Cage', True)
        cutter.obj.hide_viewport = True
        return cutter.obj

    def _position_angled_cutter(self, cutter_obj, layout):
        """Place / size the cutter so its cage covers the wedge of
        space forward of the angled FF inner plane.

        Origin sits at the LEFT endpoint of the FF inner plane shifted
        backward along the FF direction by `margin`, with rotation_
        euler.z = face_frame_angle so cutter-local +X runs from left
        to right along the FF line. Cage extends in cutter-local +X
        for ff_length + 2 * margin (past both endpoints), in cutter-
        local -Y for dim_y + margin (toward the cabinet front, far
        enough to clear it from any point on the FF inner plane), and
        in +Z for dim_z + 2 * margin (covering top and bottom panels
        plus margin in either direction).
        """
        margin = inch(2.0)
        fft = layout.fft
        ld = solver.effective_left_depth(layout)
        theta = solver.face_frame_angle(layout)
        ff_len = solver.face_frame_length(layout)
        cos_t = math.cos(theta)
        sin_t = math.sin(theta)

        cutter_obj.location = (
            -margin * cos_t,
            -ld + fft - margin * sin_t,
            -margin,
        )
        cutter_obj.rotation_euler = (0.0, 0.0, theta)

        cage = GeoNodeCage(cutter_obj)
        cage.set_input('Dim X', ff_len + 2.0 * margin)
        cage.set_input('Dim Y', layout.dim_y + margin)
        cage.set_input('Dim Z', layout.dim_z + 2.0 * margin)
        cage.set_input('Mirror X', False)
        cage.set_input('Mirror Y', True)
        cage.set_input('Mirror Z', False)
        cage.set_input('Show Cage', True)

    def _iter_angled_cut_targets(self):
        """Yield every object that should carry the 'Angled Cut'
        modifier: cabinet root cage (so its silhouette matches the
        carved carcass), cabinet-level top / bottom panels, and any
        bay shelf / adjustable shelf living deeper in the bay tree.
        """
        yield self.obj
        stack = list(self.obj.children)
        while stack:
            obj = stack.pop()
            role = obj.get('hb_part_role')
            if role == PART_ROLE_ANGLED_CUTTER:
                continue
            if role in ANGLED_CUT_PART_ROLES:
                yield obj
            stack.extend(obj.children)

    def _apply_angled_cuts(self, cutter_obj):
        """Ensure every cuttable target carries a boolean DIFFERENCE
        modifier named ANGLED_CUT_MOD_NAME pointing at the cutter.
        Idempotent; safe to call every recalc."""
        for part in self._iter_angled_cut_targets():
            mod = part.modifiers.get(ANGLED_CUT_MOD_NAME)
            if mod is None:
                mod = part.modifiers.new(name=ANGLED_CUT_MOD_NAME, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
            if mod.object is not cutter_obj:
                mod.object = cutter_obj

    def _cleanup_single_angled_cutter_and_cuts(self):
        """Reverse of _apply_angled_cuts + _ensure_angled_cutter for the
        SINGLE-plane cutter only: pulls the 'Angled Cut' modifier off
        every target and removes the un-sided cutter child. Leaves the
        angled_multi wedge cutters alone (single<->multi transitions
        call the other side's cleanup). No-op when nothing to undo."""
        for part in self._iter_angled_cut_targets():
            mod = part.modifiers.get(ANGLED_CUT_MOD_NAME)
            if mod is not None:
                part.modifiers.remove(mod)
        for child in list(self.obj.children):
            if (child.get('hb_part_role') == PART_ROLE_ANGLED_CUTTER
                    and not child.get('hb_angled_side')):
                bpy.data.objects.remove(child, do_unlink=True)

    def _cleanup_angled_cutter_and_cuts(self):
        """Full reverse of angled mode: single-plane cutter + per-end
        wedge cutters and all their modifiers. No-op when there's
        nothing to undo."""
        self._cleanup_single_angled_cutter_and_cuts()
        self._cleanup_multi_angled_wedges()

    # ---- angled_multi: per-end triangular wedge cutters ----
    # Only the first / last bay of a multi-bay cabinet angles; the
    # middle bays stay square. One vertical prism per unlocked end
    # covers the plan-view triangle between that end's angled FF inner
    # plane and the square FF inner plane (y = -dim_y + fft), so the
    # full-depth tops / bottoms / shelves get their corner carved while
    # square-region material is untouched. Mesh-prism pattern mirrors
    # _miter_wedge_mesh / the back-ext cutter.
    def _multi_wedge_mod_name(self, side):
        return f'{ANGLED_CUT_MOD_NAME} {side[0]}'

    def _ensure_angled_wedge_cutter(self, side):
        """Find or build the mesh wedge cutter for one end. Tagged with
        hb_angled_side so the single-plane cutter lookup skips it."""
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_ANGLED_CUTTER
                    and child.get('hb_angled_side') == side):
                return child
        name = f'Angled Wedge Cutter {side.title()}'
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = PART_ROLE_ANGLED_CUTTER
        cutter['hb_angled_side'] = side
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _multi_wedge_plan(self, layout, side):
        """Plan-view quad (4 (x, y) tuples, cabinet-local) of one end's
        wedge, or None when that end doesn't angle. The quad runs along
        the end bay's FF INNER plane from just outside the cabinet to
        the exact X where that plane crosses the square inner plane
        (y = -dim_y + fft), then squares off toward the front."""
        margin = inch(2.0)
        fft = layout.fft
        last = layout.bay_count - 1
        bay_index = 0 if side == 'LEFT' else last
        theta = solver.bay_front_angle(layout, bay_index)
        if abs(theta) < 1e-9:
            return None
        t = math.tan(theta)
        inner_lift = fft / math.cos(theta)
        y_square = -layout.dim_y + fft
        y_front = -(max(layout.dim_y,
                        solver.effective_left_depth(layout),
                        solver.effective_right_depth(layout)) + margin)
        if side == 'LEFT':
            ld = solver.effective_left_depth(layout)
            # Inner plane: y = -ld + tan * x + fft / cos
            def y_in(x):
                return -ld + t * x + inner_lift
            x_i = (y_square + ld - inner_lift) / t
            x_out = -margin
        else:
            rd = solver.effective_right_depth(layout)
            # Inner plane: y = -rd - tan * (dim_x - x) + fft / cos
            def y_in(x):
                return -rd - t * (layout.dim_x - x) + inner_lift
            x_i = layout.dim_x + (y_square + rd - inner_lift) / t
            x_out = layout.dim_x + margin
        return (
            (x_out, y_in(x_out)),
            (x_i,   y_square),
            (x_i,   y_front),
            (x_out, y_front),
        )

    @staticmethod
    def _wedge_prism_mesh(cutter, pts, z0, z1):
        """Rebuild the cutter as a vertical prism over the plan quad
        `pts` (cabinet-local XY), spanning z0..z1. Same construction as
        _miter_wedge_mesh but with explicit corner points."""
        bm = bmesh.new()
        lo = [bm.verts.new((x, y, z0)) for (x, y) in pts]
        hi = [bm.verts.new((x, y, z1)) for (x, y) in pts]
        bm.faces.new(lo)
        bm.faces.new(list(reversed(hi)))
        for i in range(len(pts)):
            j = (i + 1) % len(pts)
            bm.faces.new((lo[i], lo[j], hi[j], hi[i]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter.data)
        bm.free()
        cutter.location = (0.0, 0.0, 0.0)
        cutter.rotation_euler = (0.0, 0.0, 0.0)

    def _apply_multi_angled_wedges(self, layout):
        """Ensure each unlocked end carries its wedge cutter + boolean
        modifiers on every cuttable target; clean up an end whose angle
        collapsed to zero (depth typed back to the cabinet depth)."""
        margin = inch(2.0)
        for side in ('LEFT', 'RIGHT'):
            pts = self._multi_wedge_plan(layout, side)
            if pts is None:
                self._cleanup_multi_angled_wedge_side(side)
                continue
            cutter = self._ensure_angled_wedge_cutter(side)
            self._wedge_prism_mesh(cutter, pts,
                                   -margin, layout.dim_z + margin)
            mod_name = self._multi_wedge_mod_name(side)
            for part in self._iter_angled_cut_targets():
                mod = part.modifiers.get(mod_name)
                if mod is None:
                    mod = part.modifiers.new(name=mod_name, type='BOOLEAN')
                    mod.operation = 'DIFFERENCE'
                if mod.object is not cutter:
                    mod.object = cutter

    def _cleanup_multi_angled_wedge_side(self, side):
        mod_name = self._multi_wedge_mod_name(side)
        for part in self._iter_angled_cut_targets():
            mod = part.modifiers.get(mod_name)
            if mod is not None:
                part.modifiers.remove(mod)
        for child in list(self.obj.children):
            if (child.get('hb_part_role') == PART_ROLE_ANGLED_CUTTER
                    and child.get('hb_angled_side') == side):
                bpy.data.objects.remove(child, do_unlink=True)

    def _cleanup_multi_angled_wedges(self):
        """Reverse of _apply_multi_angled_wedges for both ends."""
        for side in ('LEFT', 'RIGHT'):
            self._cleanup_multi_angled_wedge_side(side)

    # ---- mitered finished ends on the plain box products ----
    # On the floating shelf and the contemporary (no-crown) mantle the
    # shop miters the front board into a finished end panel at 45
    # through the front corner instead of butting the panel behind the
    # front. Two hidden prism cutters per finished end (one trims the
    # front board's end, the complement trims the panel's front tip);
    # the caller extends the panel to the full depth first so the two
    # cut faces meet on the diagonal.
    def _ensure_box_miter_cutter(self, side, which):
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_BOX_MITER_CUTTER
                    and child.get('hb_miter_side') == side
                    and child.get('hb_miter_part') == which):
                return child
        name = f'End Miter Cutter {side.title()} {which.title()}'
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = PART_ROLE_BOX_MITER_CUTTER
        cutter['hb_miter_side'] = side
        cutter['hb_miter_part'] = which
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _apply_box_end_miter(self, side, active, front, panel,
                             width, depth, mt, z1):
        """Build / drop one end's miter: cutters + booleans on the
        front board and end panel. `z1` is the top of the parts (the
        prisms overshoot both ends). Manual parts are left alone."""
        mod_name = f'End Miter {side[0]}'
        pairs = (('FRONT', front), ('PANEL', panel))
        if not active:
            for _which, part in pairs:
                mod = part.modifiers.get(mod_name)
                if mod is not None:
                    part.modifiers.remove(mod)
            for child in list(self.obj.children):
                if (child.get('hb_part_role') == PART_ROLE_BOX_MITER_CUTTER
                        and child.get('hb_miter_side') == side):
                    bpy.data.objects.remove(child, do_unlink=True)
            return
        m = inch(2.0)
        # The miter runs from the front outer corner to the inner
        # corner one material thickness back; each triangle covers one
        # side of that diagonal (extended past both ends so the
        # boolean never grazes a coplanar face).
        if side == 'LEFT':
            a = (-m, -depth - m)
            b = (mt + m, -depth + mt + m)
            close = {'FRONT': (-m, -depth + mt + m),
                     'PANEL': (mt + m, -depth - m)}
        else:
            a = (width + m, -depth - m)
            b = (width - mt - m, -depth + mt + m)
            close = {'FRONT': (width + m, -depth + mt + m),
                     'PANEL': (width - mt - m, -depth - m)}
        for which, part in pairs:
            cutter = self._ensure_box_miter_cutter(side, which)
            self._wedge_prism_mesh(cutter, (a, b, close[which]),
                                   -m, z1 + m)
            if part.get('IS_MANUAL_PART'):
                continue
            mod = part.modifiers.get(mod_name)
            if mod is None:
                mod = part.modifiers.new(name=mod_name, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
            if mod.object is not cutter:
                mod.object = cutter

    # ---- angled_multi: mitered mid stile halves at the bends ----
    # A mid stile sitting ON a bend splits lengthwise: the original
    # MID_STILE part becomes the left half (in the left region's front
    # plane) and a MID_STILE_HALF companion carries the right half; the
    # two miter together on the bisector plane through the bend line
    # via per-half prism cutters (same wedge pattern as the panel
    # miters). Geometry comes from solver.mid_stile_bend_halves.
    MID_STILE_MITER_MOD_NAME = 'Mid Stile Miter'
    MID_STILE_MITER_CUTTER_ROLE = 'MID_STILE_MITER_CUTTER'

    def _reconcile_mid_stile_bend_halves(self, layout):
        """Ensure each bend gap has its right-half companion; drop
        companions and miter cutters whose gap went flat (or whose
        cabinet left angled mode entirely)."""
        wanted = {gi for gi in range(len(layout.mid_stiles))
                  if solver.mid_stile_bend_thetas(layout, gi) is not None}
        for child in list(self.obj.children):
            r = child.get('hb_part_role')
            if r == PART_ROLE_MID_STILE_HALF:
                if child.get('hb_mid_stile_index') not in wanted:
                    bpy.data.objects.remove(child, do_unlink=True)
            elif r == self.MID_STILE_MITER_CUTTER_ROLE:
                if child.get('hb_ms_miter_gap') not in wanted:
                    bpy.data.objects.remove(child, do_unlink=True)
        existing = {child.get('hb_mid_stile_index')
                    for child in self.obj.children
                    if child.get('hb_part_role') == PART_ROLE_MID_STILE_HALF}
        for gi in sorted(wanted - existing):
            self._create_mid_stile_half(gi)

    # Step-notch modifiers on a mid stile whose adjacent bays differ in
    # vertical extent (see solver.mid_stile_notches). Which Flip picks
    # which stile end / side is fixed by the stile's part config
    # (rot Y=-90 Z=90, Mirror Y + Z).
    _MID_STILE_NOTCH_MODS = (('BOTTOM', 'Step Notch Bottom'),
                             ('TOP', 'Step Notch Top'))
    _MID_STILE_NOTCH_FLIP_X = {'BOTTOM': False, 'TOP': True}
    _MID_STILE_NOTCH_FLIP_Y = {'LEFT': False, 'RIGHT': True}

    def _apply_mid_stile_step_notches(self, child, part, layout, msi):
        """Drive the step-notch corner cutouts on a flat mid stile.
        Where only one adjacent bay runs beside the stile (bay heights
        differ), the absent bay's half of the width is notched away
        (solver.mid_stile_notches). Modifiers are added lazily so
        stiles from older files pick them up on their next recalc.
        """
        notches = {n['end']: n
                   for n in solver.mid_stile_notches(layout, msi)}
        for end, mod_name in self._MID_STILE_NOTCH_MODS:
            n = notches.get(end)
            mod = child.modifiers.get(mod_name)
            if n is None:
                if mod is not None:
                    mod.show_viewport = False
                    mod.show_render = False
                continue
            if mod is None:
                part.add_part_modifier('CPM_CORNERNOTCH', mod_name)
                mod = child.modifiers.get(mod_name)
                if mod is None:      # unexpected node-group failure
                    continue
            ng = mod.node_group
            if ng is None:
                continue
            for iname, val in (
                    ('X', n['span']),
                    ('Y', n['width']),
                    ('Route Depth', layout.fft + inch(0.1)),
                    ('Flip X', self._MID_STILE_NOTCH_FLIP_X[end]),
                    ('Flip Y', self._MID_STILE_NOTCH_FLIP_Y[n['side']])):
                ni = ng.interface.items_tree.get(iname)
                if ni is not None:
                    hb_utils.set_gn_input(mod, ni.identifier, val)
            mod.show_viewport = True
            mod.show_render = True

    def _create_mid_stile_half(self, gap_index):
        """Right-half companion board; same part config as the mid
        stile it splits from (see _create_mid_parts_at)."""
        half = CabinetPart()
        half.create(f'Mid Stile {gap_index + 1} R')
        half.obj.parent = self.obj
        half.obj['hb_part_role'] = PART_ROLE_MID_STILE_HALF
        half.obj['CABINET_PART'] = True
        half.obj['hb_mid_stile_index'] = gap_index
        half.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        half.obj.rotation_euler.y = math.radians(-90)
        half.obj.rotation_euler.z = math.radians(90)
        half.set_input('Mirror Y', True)
        half.set_input('Mirror Z', True)
        return half

    def _ensure_mid_stile_miter_cutter(self, gap_index, half):
        for child in self.obj.children:
            if (child.get('hb_part_role') == self.MID_STILE_MITER_CUTTER_ROLE
                    and child.get('hb_ms_miter_gap') == gap_index
                    and child.get('hb_ms_miter_half') == half):
                return child
        name = f'Mid Stile Miter Cutter {gap_index + 1} {half.title()}'
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = self.MID_STILE_MITER_CUTTER_ROLE
        cutter['hb_ms_miter_gap'] = gap_index
        cutter['hb_ms_miter_half'] = half
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _apply_mid_stile_miter(self, part_obj, layout, gap_index, half,
                               halves):
        """Rebuild this half's miter cutter prism and ensure the boolean
        on the half board. `half` is 'LEFT' (the MID_STILE part) or
        'RIGHT' (the companion)."""
        from mathutils import Vector
        cutter = self._ensure_mid_stile_miter_cutter(gap_index, half)
        corner = Vector(halves['bend'])
        miter_dir = Vector(halves['miter_dir'])
        open_dir = Vector(halves[half.lower()]['open_dir'])
        self._miter_wedge_mesh(cutter, corner, miter_dir, open_dir,
                               -0.05, layout.dim_z + 0.05)
        mod = part_obj.modifiers.get(self.MID_STILE_MITER_MOD_NAME)
        if mod is None:
            mod = part_obj.modifiers.new(
                name=self.MID_STILE_MITER_MOD_NAME, type='BOOLEAN')
            mod.operation = 'DIFFERENCE'
            mod.solver = 'EXACT'
        if mod.object is not cutter:
            mod.object = cutter

    def _clear_mid_stile_miter(self, part_obj):
        mod = part_obj.modifiers.get(self.MID_STILE_MITER_MOD_NAME)
        if mod is not None:
            part_obj.modifiers.remove(mod)

    # =====================================================================
    # Angled back extension (trapezoidal back; extend_back_left / _right)
    # =====================================================================
    def _part_input(self, child, name):
        for m in child.modifiers:
            if m.type == 'NODES' and m.node_group:
                for it in m.node_group.interface.items_tree:
                    if getattr(it, 'in_out', '') == 'INPUT' and it.name == name:
                        try:
                            return hb_utils.get_gn_input(m, it.identifier)
                        except Exception:
                            return None
        return None

    def _set_part_input(self, child, name, value):
        for m in child.modifiers:
            if m.type == 'NODES' and m.node_group:
                for it in m.node_group.interface.items_tree:
                    if getattr(it, 'in_out', '') == 'INPUT' and it.name == name:
                        hb_utils.set_gn_input(m, it.identifier, value)
                        return

    def _back_ext_line(self, side, extend, depth):
        """The outer line of a back-extended / wing end, in cabinet-local XY.

        Returns (front_target, back_target, phi, w_new): front_target is the
        fixed front-outer corner; back_target is the back-outer corner moved
        out (signed) by `extend`; phi orients a part's local -Y axis from the
        new back toward the fixed front; w_new is the hypotenuse length.
        Shared by _angle_side_panel (carcass splay) and the attached wing so
        both sit on the exact same edge.
        """
        from mathutils import Vector
        dim_x = self.obj.face_frame_cabinet.width
        if side == 'RIGHT':
            outer_x = dim_x
            back_target = Vector((outer_x + extend, 0.0))
        else:  # LEFT
            outer_x = 0.0
            back_target = Vector((outer_x - extend, 0.0))
        front_target = Vector((outer_x, -depth))
        d = front_target - back_target
        w_new = d.length
        dn = d.normalized()
        # part-local front offset is (0, -W): R(phi)*(0,-1) must equal dn.
        # R(phi)*(0,-1) = (sin phi, -cos phi)  =>  phi = atan2(dn.x, -dn.y)
        phi = math.atan2(dn.x, -dn.y)
        return front_target, back_target, phi, w_new

    # =====================================================================
    # Applied-panel front miter (angled side <-> face frame joint)
    # =====================================================================
    # When an applied panel's side is angled - a splayed back extension
    # or an angled-front cabinet (rotated FF plane) - the panel meets
    # the face frame at a non-90 corner. The panel is extended to the
    # FF FRONT plane and both members are cut on the bisector plane
    # through the front-outer corner: a true outside miter. One hidden
    # prism cutter per member (stile side / panel side of the plane),
    # boolean DIFFERENCE, same lazy pattern as the overstool profile.
    PANEL_MITER_CUT_MOD_NAME = 'Front Miter Cut'

    def _panel_miter_angles(self, layout, side):
        """(active, corner C, ff_dir_in, panel_dir_in) for the side's
        front-outer corner, in cabinet-local plan XY. ff_dir_in runs
        from the corner along the FF front line toward the other side;
        panel_dir_in runs from the corner along the panel's outer line
        toward the back. active is False when the corner is square
        (no splay, no angled front)."""
        from mathutils import Vector
        ext_l, ext_r = self._back_ext_effective()
        ext = ext_l if side == 'LEFT' else ext_r
        # Per-side front angle: angled_multi only bends at the ends, so
        # this side's miter keys off ITS end bay's angle; single-plane
        # cabinets keep the whole-cabinet theta.
        if not layout.is_angled:
            theta = 0.0
        elif layout.angled_multi:
            bay_index = 0 if side == 'LEFT' else layout.bay_count - 1
            theta = solver.bay_front_angle(layout, bay_index)
        else:
            theta = solver.face_frame_angle(layout)
        if ext == 0.0 and theta == 0.0:
            return False, None, None, None
        depth_l = (solver.effective_left_depth(layout)
                   if layout.is_angled else layout.dim_y)
        depth_r = (solver.effective_right_depth(layout)
                   if layout.is_angled else layout.dim_y)
        cl = Vector((0.0, -depth_l))
        cr = Vector((layout.dim_x, -depth_r))
        if layout.angled_multi:
            # The FF front line leaving each corner runs to that end's
            # BEND point, not to the far corner (piecewise front).
            bend_l, bend_r = solver.multi_bend_points(layout)
            other_l = Vector((bend_l, -layout.dim_y))
            other_r = Vector((bend_r, -layout.dim_y))
        else:
            other_l, other_r = cr, cl
        if side == 'LEFT':
            corner, other, depth = cl, other_l, depth_l
            back = Vector((0.0 - ext, 0.0))
        else:
            corner, other, depth = cr, other_r, depth_r
            back = Vector((layout.dim_x + ext, 0.0))
        ff_dir = (other - corner).normalized()
        panel_dir = (back - corner).normalized()
        return True, corner, ff_dir, panel_dir

    def _ensure_panel_miter_cutter(self, side, which):
        role = 'PANEL_MITER_CUTTER'
        for child in self.obj.children:
            if (child.get('hb_part_role') == role
                    and child.get('hb_miter_side') == side
                    and child.get('hb_miter_which') == which):
                return child
        name = f'Panel Miter Cutter {side.title()} {which.title()}'
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = role
        cutter['hb_miter_side'] = side
        cutter['hb_miter_which'] = which
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    @staticmethod
    def _miter_wedge_mesh(cutter, corner, miter_dir, open_dir, z0, z1):
        """Rebuild the cutter as a vertical prism over the quadrant
        bounded by the miter line (corner + t*miter_dir) and opened
        toward open_dir (a direction on the side of the plane whose
        material should be removed). Cabinet-local coords."""
        big = 2.0
        p0 = corner
        p1 = corner + miter_dir * big
        p2 = p1 + open_dir * big
        p3 = corner + open_dir * big
        bm = bmesh.new()
        lo = [bm.verts.new((p.x, p.y, z0)) for p in (p0, p1, p2, p3)]
        hi = [bm.verts.new((p.x, p.y, z1)) for p in (p0, p1, p2, p3)]
        bm.faces.new(lo)
        bm.faces.new(list(reversed(hi)))
        for i in range(4):
            j = (i + 1) % 4
            bm.faces.new((lo[i], lo[j], hi[j], hi[i]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter.data)
        bm.free()
        cutter.location = (0.0, 0.0, 0.0)
        cutter.rotation_euler = (0.0, 0.0, 0.0)

    def _miter_boolean(self, part_obj, cutter, active):
        mod = part_obj.modifiers.get(self.PANEL_MITER_CUT_MOD_NAME)
        if not active:
            if mod is not None:
                part_obj.modifiers.remove(mod)
            return
        if mod is None:
            mod = part_obj.modifiers.new(
                name=self.PANEL_MITER_CUT_MOD_NAME, type='BOOLEAN')
            mod.operation = 'DIFFERENCE'
            mod.solver = 'EXACT'
        if mod.object is not cutter:
            mod.object = cutter

    def _miter_covered_members(self, side, panel_obj):
        """Every part that could carry the covering-side miter cut on
        this side: the applied panel's facing stile (when a panel
        exists) and the carcass side panel (the member for a FINISHED
        end). Both are returned so apply/cleanup can clear stale cuts
        when the condition flips between FINISHED and an applied type.
        Each entry is (part, is_active_for) where is_active_for is
        'PANEL' or 'SIDE'."""
        members = []
        if panel_obj is not None:
            facing_role = ('RIGHT_STILE' if side == 'LEFT' else 'LEFT_STILE')
            for c in panel_obj.children_recursive:
                if c.get('hb_part_role') == facing_role:
                    members.append((c, 'PANEL'))
        side_role = ('LEFT_SIDE' if side == 'LEFT' else 'RIGHT_SIDE')
        side_part = next(
            (c for c in self.obj.children
             if c.get('hb_part_role') == side_role), None)
        if side_part is not None:
            members.append((side_part, 'SIDE'))
        return members

    def _cleanup_panel_miter(self, side, stile_part, panel_obj):
        if stile_part is not None:
            self._miter_boolean(stile_part, None, False)
        for part, _kind in self._miter_covered_members(side, panel_obj):
            self._miter_boolean(part, None, False)
        for child in list(self.obj.children):
            if (child.get('hb_part_role') == 'PANEL_MITER_CUTTER'
                    and child.get('hb_miter_side') == side):
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    def _apply_panel_front_miter(self, layout, side, panel_obj):
        """Miter the cabinet end stile and the covering member - the
        applied panel's facing stile, or the FINISHED carcass side -
        into each other at an angled side's front corner. No-op (with
        cleanup) on square corners or when the side carries neither an
        applied panel nor a FINISHED end."""
        cab = self.obj.face_frame_cabinet
        condition = (cab.left_finished_end_condition if side == 'LEFT'
                     else cab.right_finished_end_condition)
        target_kind = ('PANEL' if panel_obj is not None
                       else 'SIDE' if condition == 'FINISHED' else None)
        stile_role = ('LEFT_STILE' if side == 'LEFT' else 'RIGHT_STILE')
        stile_part = next(
            (c for c in self.obj.children
             if c.get('hb_part_role') == stile_role), None)
        active, corner, ff_dir, panel_dir = self._panel_miter_angles(
            layout, side)
        if not active or target_kind is None or stile_part is None:
            self._cleanup_panel_miter(side, stile_part, panel_obj)
            return
        miter_dir = (ff_dir + panel_dir).normalized()
        z0, z1 = -0.05, layout.dim_z + 0.05
        # Stile cutter: removes stile material past the miter plane on
        # the covering side; the covering cutter mirrors on the FF side.
        stile_cut = self._ensure_panel_miter_cutter(side, 'STILE')
        self._miter_wedge_mesh(stile_cut, corner, miter_dir, panel_dir,
                               z0, z1)
        self._miter_boolean(stile_part, stile_cut, True)
        panel_cut = self._ensure_panel_miter_cutter(side, 'PANEL')
        self._miter_wedge_mesh(panel_cut, corner, miter_dir, ff_dir,
                               z0, z1)
        for part, kind in self._miter_covered_members(side, panel_obj):
            self._miter_boolean(part, panel_cut, kind == target_kind)

    def _back_ext_canonical_depth(self, layout, side):
        """Front-plane depth defining THE canonical splay line for one
        side: from the FF front-outer corner to the extended back
        corner. Every splayed member on the side (carcass side, applied
        panel, textured skin, loose-kick end board) derives its
        rotation from this ONE line and scales its own span by
        1/cos(phi), so all the planes stay parallel. Per-side effective
        depth on angled-front cabinets."""
        if layout.is_angled:
            return (solver.effective_left_depth(layout) if side == 'LEFT'
                    else solver.effective_right_depth(layout))
        return layout.dim_y

    def _back_ext_effective(self):
        """(ext_left, ext_right) the CARCASS actually splays by. A side
        whose extension is carried by an attached wing keeps a square
        carcass, so it reads 0 here - mirrors _apply_back_extension's
        wing gating. Used by the finished-end covering reconcilers so
        applied panels / textured skins follow the same splayed line
        the carcass side does."""
        cab = self.obj.face_frame_cabinet
        raw_l = cab.extend_back_left
        raw_r = cab.extend_back_right
        ext_l = 0.0 if (cab.wing_attached_left and raw_l != 0.0) else raw_l
        ext_r = 0.0 if (cab.wing_attached_right and raw_r != 0.0) else raw_r
        return ext_l, ext_r

    def _splay_covering(self, side, extend, location, rotation_z, width,
                        depth_line, front_anchored=False):
        """Apply the back-extension splay to a side COVERING (applied
        panel root or textured skin): rotate it onto the CANONICAL
        splay line (see _back_ext_canonical_depth) and scale its span
        by 1/cos(phi), keeping its inboard offset. Every member on the
        side shares the canonical angle so the planes stay parallel.

        A covering whose width spans AWAY from its origin toward the
        front (LEFT applied panel, LEFT / RIGHT skins) is back-anchored:
        its origin rides the back-outer corner, which MOVES to the splay
        target. The RIGHT applied panel spans from the front toward the
        back, so it is front-anchored: its origin keeps its offset from
        the FIXED front-outer corner and only rotates.

        Returns (location, rotation_z, width). No-op for extend == 0.
        """
        if extend == 0.0:
            return location, rotation_z, width
        ft, bt, phi, _hyp = self._back_ext_line(side, extend, depth_line)
        c, s = math.cos(phi), math.sin(phi)
        w_new = width / c if c > 1e-6 else width
        if front_anchored:
            px, py = ft.x, ft.y          # fixed front-outer corner
        else:
            px = 0.0 if side == 'LEFT' else self.obj.face_frame_cabinet.width
            py = 0.0                      # old back-outer corner
        offx = location[0] - px
        offy = location[1] - py
        if not front_anchored:
            px, py = bt.x, bt.y          # back corner moves to target
        return ((px + offx * c - offy * s,
                 py + offx * s + offy * c,
                 location[2]),
                rotation_z + phi, w_new)

    def _angle_side_panel(self, child, side, extend, depth_line,
                          front_trim=False):
        """Splay one carcass side panel outward at the back by `extend`
        (meters), pivoting about its FRONT-OUTER corner so the front edge
        stays put. Analytic transform (no bound-box sampling):

        The side part's origin is its BACK-OUTER corner; its outer edge
        runs along part-local -Y by Width (= depth). For a RIGHT side the
        outer x is dim_x; the back-outer corner moves dim_x -> dim_x +
        extend, the front-outer corner stays at (dim_x, -depth). LEFT
        mirrors (outer x = 0, back moves to -extend).

        Sets: location = back-corner target, rotation_euler.z = phi so the
        part-local -Y axis points from the new back toward the fixed
        front, and Width = the new (hypotenuse) depth.
        """
        import math
        from mathutils import Vector
        # `extend` may be NEGATIVE: positive splays the back corner outward
        # (back wider than front), negative pulls it inward (back narrower).
        # The analytic transform below handles either sign -- back_target moves
        # the corner the signed amount and w_new / phi follow. Only exactly 0
        # is a no-op (the caller resets rotation in that case).
        width = self._part_input(child, 'Width')
        if width is None or extend == 0.0:
            return None
        # CANONICAL splay line for the side (front-plane depth): the
        # side's rotation comes from this line so it stays PARALLEL to
        # the applied panel / skin / miter geometry, which all use the
        # same line. Its own span just scales by 1/cos(phi).
        front_target, back_target, phi, _hyp = self._back_ext_line(
            side, extend, depth_line)
        cphi = math.cos(phi)
        if cphi <= 1e-6:
            return None
        # Scribe-aware: a PANELED / UNFINISHED-scribed side sits INBOARD
        # of the cabinet's outer plane. The side's own outer line is the
        # canonical line shifted HORIZONTALLY by s / cos(phi) (parallel
        # offset s measured perpendicular), which keeps its back corner
        # ON the back plane (y = 0) instead of poking behind it. The
        # dispatch reset location this recalc, so location.x still holds
        # the square scribe position.
        from mathutils import Vector
        dim_x = self.obj.face_frame_cabinet.width
        if side == 'RIGHT':
            s = dim_x - child.location.x
            shift = Vector((-s / cphi, 0.0))
        else:
            s = child.location.x
            shift = Vector((s / cphi, 0.0))
        child.rotation_euler.z = phi
        child.location.x = back_target.x + shift.x
        child.location.y = 0.0
        w_new = width / cphi
        if front_trim:
            # The front end gets beveled flush against the FF back
            # plane (Side Front End Trim): overshoot the plane so the
            # boolean has material to cut on both faces.
            t = self._part_input(child, 'Thickness') or inch(0.75)
            w_new += t * abs(math.tan(phi)) + inch(0.5)
        self._set_part_input(child, 'Width', w_new)
        # Return the side's OWN outer line (scribe-offset from the
        # canonical line) so the trapezoid trim cutter's side-thickness
        # inset lands on the side's true INNER face.
        return (front_target + shift, back_target + shift)

    # =====================================================================
    # Furniture / veneer wood top (dresser products)
    # =====================================================================
    def _ensure_furniture_top(self):
        """Find or lazily create the furniture-top CabinetPart - a flat
        slab parented to the cabinet root, tagged PART_ROLE_FURNITURE_TOP
        and CABINET_PART so the material walk picks it up. Reused across
        recalcs; sizing / placement is done by _position_furniture_top."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_FURNITURE_TOP:
                return child
        top = CabinetPart()
        top.create('Wood Top')
        top.obj.parent = self.obj
        top.obj['hb_part_role'] = PART_ROLE_FURNITURE_TOP
        top.obj['CABINET_PART'] = True
        # Flat slab orientation: Length -> +X, Width -> -Y (Mirror Y),
        # Thickness -> +Z (Mirror Z False) so it sits proud ON the carcass
        # top rather than extending down into the case.
        top.set_input('Mirror Y', True)
        top.set_input('Mirror Z', False)
        return top.obj

    def _position_furniture_top(self, top_obj):
        """Size + place the furniture top from the cabinet width / depth /
        height and the per-side furniture_top_overhang_* / _thickness props.
        Each edge (front / back / left / right) overhangs the carcass
        independently. Falls back to the legacy uniform furniture_top_overhang
        (and a flush back) for data saved before the per-side props.

        BOW_BACK shape: the slab is first extended straight back by the
        bow altitude so it covers the arc's bulge; the shape cutter then
        trims it back to the arc (the arc's corners stay on the straight
        back-overhang line)."""
        cab = self.obj.face_frame_cabinet
        dim_x = cab.width
        dim_y = cab.depth
        dim_z = cab.height
        legacy = cab.furniture_top_overhang
        ohl = getattr(cab, 'furniture_top_overhang_left', legacy)
        ohr = getattr(cab, 'furniture_top_overhang_right', legacy)
        ohf = getattr(cab, 'furniture_top_overhang_front', legacy)
        ohb = getattr(cab, 'furniture_top_overhang_back', 0.0)
        th = cab.furniture_top_thickness
        bow = 0.0
        if getattr(cab, 'furniture_top_shape', 'RECTANGLE') == 'BOW_BACK':
            bow = max(getattr(cab, 'furniture_top_bow_altitude', 0.0), 0.0)
        part = GeoNodeCutpart(top_obj)
        part.set_input('Length', dim_x + ohl + ohr)   # left + right overhang
        part.set_input('Width', dim_y + ohf + ohb + bow)  # front/back + bow
        part.set_input('Thickness', th)
        # Origin at the case top back-left corner, shifted -X by the left
        # overhang and +Y by the back overhang (plus the bow bulge). Width
        # runs -Y from the back edge past the front (y = -(dim_y + ohf)).
        # Thickness +Z.
        top_obj.location = Vector((-ohl, ohb + bow, dim_z))
        top_obj.rotation_euler = (0.0, 0.0, 0.0)

    def _cleanup_furniture_top(self):
        """Remove the furniture-top part (furniture_top toggled off, or a
        non-carcass / non-furniture cabinet) plus its shape cutter and
        any waterfall drop panels."""
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_FURNITURE_TOP:
                bpy.data.objects.remove(child, do_unlink=True)
        self._cleanup_furniture_top_cutter()
        self._cleanup_furniture_top_legs()

    # ---- Furniture top shape (bow back / radius corners / waterfall) ----
    def _furniture_top_extents(self):
        """Plan-space extents of the furniture top in cabinet-local XY:
        (x_left, x_right, y_front, y_back) EXCLUDING any bow bulge - the
        bow arc's corners sit on y_back. Mirrors the sizing math in
        _position_furniture_top."""
        cab = self.obj.face_frame_cabinet
        legacy = cab.furniture_top_overhang
        ohl = getattr(cab, 'furniture_top_overhang_left', legacy)
        ohr = getattr(cab, 'furniture_top_overhang_right', legacy)
        ohf = getattr(cab, 'furniture_top_overhang_front', legacy)
        ohb = getattr(cab, 'furniture_top_overhang_back', 0.0)
        return (-ohl, cab.width + ohr, -(cab.depth + ohf), ohb)

    def _ensure_furniture_top_cutter(self):
        """Find or lazily create the furniture-top shape cutter MESH.
        Hidden in the viewport; the boolean reads its mesh regardless.
        Mirrors _ensure_back_ext_cutter."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_FURNITURE_TOP_CUTTER:
                return child
        mesh = bpy.data.meshes.new('Wood Top Shape Cutter')
        cutter = hb_utils.new_object('Wood Top Shape Cutter', mesh)
        cutter['hb_part_role'] = PART_ROLE_FURNITURE_TOP_CUTTER
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_furniture_top_cutter(self, cutter_obj):
        """Rebuild the shape-cutter mesh for the current shape props.

        BOW_BACK: one prism removing everything behind the circular arc
        through the two back corners and the apex (bow altitude past the
        straight back edge). The slab was pre-extended by the altitude in
        _position_furniture_top, so the DIFFERENCE leaves the bowed edge.

        RADIUS: one prism per corner with a non-zero radius, removing the
        corner material outside a quarter-circle of that radius. Radii are
        clamped so opposite corners cannot overlap.

        Prisms span only the top's Z range (plus a margin) so nothing else
        is affected, and their outer walls sit a margin outside the slab so
        no cutter face is coplanar with a slab face."""
        cab = self.obj.face_frame_cabinet
        shape = getattr(cab, 'furniture_top_shape', 'RECTANGLE')
        x_l, x_r, y_f, y_b = self._furniture_top_extents()
        th = cab.furniture_top_thickness
        margin = inch(1.0)
        z0 = cab.height - margin
        z1 = cab.height + th + margin

        def prism(bm, pts):
            # Extrude a closed plan polygon from z0 to z1; winding is
            # unified by the recalc_face_normals below.
            bot = [bm.verts.new((p[0], p[1], z0)) for p in pts]
            top = [bm.verts.new((p[0], p[1], z1)) for p in pts]
            bm.faces.new(bot)
            bm.faces.new(list(reversed(top)))
            n = len(pts)
            for i in range(n):
                j = (i + 1) % n
                bm.faces.new((bot[i], bot[j], top[j], top[i]))

        bm = bmesh.new()
        if shape == 'BOW_BACK':
            alt = max(getattr(cab, 'furniture_top_bow_altitude', 0.0), 0.0)
            if alt > 1e-6:
                # Circle through (x_l, y_b), (x_r, y_b) and the apex
                # ((x_l + x_r) / 2, y_b + alt): R = (c^2 + a^2) / 2a with
                # c the half-chord, centered a - R below the apex.
                half = (x_r - x_l) * 0.5
                rad = (half * half + alt * alt) / (2.0 * alt)
                cx = (x_l + x_r) * 0.5
                cy = y_b + alt - rad
                a0 = math.atan2(y_b - cy, x_l - cx)
                a1 = math.atan2(y_b - cy, x_r - cx)
                y_out = y_b + alt + margin
                segs = FURNITURE_TOP_BOW_SEGMENTS
                pts = []
                for i in range(segs + 1):
                    ang = a0 + (a1 - a0) * i / segs
                    pts.append((cx + rad * math.cos(ang),
                                cy + rad * math.sin(ang)))
                # Close around the outside: past the right corner, back
                # behind the extended slab, past the left corner. The end
                # walls sit outside the slab ends so the only cut faces
                # are along the arc itself.
                pts.extend([(x_r + margin, y_b), (x_r + margin, y_out),
                            (x_l - margin, y_out), (x_l - margin, y_b)])
                prism(bm, pts)
        elif shape == 'RADIUS':
            segs = FURNITURE_TOP_RADIUS_SEGMENTS
            rmax = max(min(x_r - x_l, y_b - y_f) * 0.5 - inch(0.01), 0.0)
            corners = (
                # (corner, x/y direction into the slab, radius prop)
                (x_l, y_f, 1.0, 1.0,
                 getattr(cab, 'furniture_top_radius_front_left', 0.0)),
                (x_r, y_f, -1.0, 1.0,
                 getattr(cab, 'furniture_top_radius_front_right', 0.0)),
                (x_l, y_b, 1.0, -1.0,
                 getattr(cab, 'furniture_top_radius_back_left', 0.0)),
                (x_r, y_b, -1.0, -1.0,
                 getattr(cab, 'furniture_top_radius_back_right', 0.0)),
            )
            for px, py, sx, sy, r in corners:
                r = min(max(r, 0.0), rmax)
                if r <= 1e-6:
                    continue
                # Quarter-circle centered r in from both edges; removal
                # region = the corner block outside the arc, extended a
                # margin past both slab edges.
                ccx, ccy = px + sx * r, py + sy * r
                pts = [(px + sx * r, py)]      # tangent point on the X edge
                for i in range(1, segs):
                    ang = (math.pi * 0.5) * i / segs
                    pts.append((ccx - sx * r * math.sin(ang),
                                ccy - sy * r * math.cos(ang)))
                pts.append((px, py + sy * r))  # tangent point on the Y edge
                pts.extend([(px - sx * margin, py + sy * r),
                            (px - sx * margin, py - sy * margin),
                            (px + sx * r, py - sy * margin)])
                prism(bm, pts)
        if bm.faces:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter_obj.data)
        bm.free()
        cutter_obj.location = (0.0, 0.0, 0.0)
        cutter_obj.rotation_euler = (0.0, 0.0, 0.0)

    def _cleanup_furniture_top_cutter(self):
        """Remove the shape cutter and its boolean modifier on the top.
        No-op when there is nothing to undo."""
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_FURNITURE_TOP:
                mod = child.modifiers.get(FURNITURE_TOP_CUT_MOD_NAME)
                if mod is not None:
                    child.modifiers.remove(mod)
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_FURNITURE_TOP_CUTTER:
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    def _ensure_furniture_top_leg(self, side):
        """Find or lazily create one waterfall drop panel ('LEFT' /
        'RIGHT'), tagged like the top so the material walk finishes it.
        Same vertical-panel orientation as the carcass sides: Length up,
        Width along -Y, thickness across X - mirrored so each leg's
        origin X is its OUTER face."""
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_FURNITURE_TOP_LEG
                    and child.get('hb_leg_side') == side):
                return child
        leg = CabinetPart()
        leg.create(f'Wood Top Waterfall {side.title()}')
        leg.obj.parent = self.obj
        leg.obj['hb_part_role'] = PART_ROLE_FURNITURE_TOP_LEG
        leg.obj['hb_leg_side'] = side
        leg.obj['CABINET_PART'] = True
        leg.obj.rotation_euler.y = math.radians(-90)
        leg.set_input('Mirror Y', True)
        # LEFT grows thickness +X (inward from the outer face at the
        # top's left edge); RIGHT grows -X from the top's right edge.
        leg.set_input('Mirror Z', side == 'LEFT')
        return leg.obj

    def _position_furniture_top_legs(self):
        """Size + place both waterfall drop panels: outer face flush with
        the top's end, running from the floor to the underside of the top,
        spanning the top's full plan depth, same thickness as the top."""
        cab = self.obj.face_frame_cabinet
        x_l, x_r, y_f, y_b = self._furniture_top_extents()
        th = cab.furniture_top_thickness
        dim_z = cab.height
        for side, outer_x in (('LEFT', x_l), ('RIGHT', x_r)):
            leg_obj = self._ensure_furniture_top_leg(side)
            if leg_obj.get('IS_MANUAL_PART'):
                continue
            part = GeoNodeCutpart(leg_obj)
            part.set_input('Length', dim_z)      # floor -> underside of top
            part.set_input('Width', y_b - y_f)   # full top plan depth
            part.set_input('Thickness', th)
            leg_obj.location = Vector((outer_x, y_b, 0.0))
            leg_obj.rotation_euler = (0.0, math.radians(-90), 0.0)

    def _cleanup_furniture_top_legs(self):
        """Remove the waterfall drop panels (shape changed / top gone)."""
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_FURNITURE_TOP_LEG:
                bpy.data.objects.remove(child, do_unlink=True)

    def _apply_furniture_top(self, layout):
        """Build / position the veneer wood top when furniture_top is on and
        the cabinet has a carcass; otherwise ensure it is gone. Called once
        per recalc (after _apply_back_extension) so it tracks width / depth /
        height changes - the managed-part lifecycle mirrors the cutters.
        Also manages the shape extras from furniture_top_shape: the
        bow-back / radius-corner boolean cutter and the waterfall drop
        panels."""
        cab = self.obj.face_frame_cabinet
        if getattr(cab, 'furniture_top', False) and self._has_carcass():
            top_obj = self._ensure_furniture_top()
            # A made-editable (manual) top is hand-controlled: its cutpart
            # GeoNode has been applied off, so re-driving it would raise
            # (no modifier to set inputs on). Leave it exactly as the user
            # edited it - including any shape cutter / waterfall panels.
            if top_obj.get('IS_MANUAL_PART'):
                return
            self._position_furniture_top(top_obj)
            shape = getattr(cab, 'furniture_top_shape', 'RECTANGLE')
            wants_cut = (
                (shape == 'BOW_BACK'
                 and getattr(cab, 'furniture_top_bow_altitude', 0.0) > 1e-6)
                or (shape == 'RADIUS' and any(
                    getattr(cab, f'furniture_top_radius_{c}', 0.0) > 1e-6
                    for c in ('front_left', 'front_right',
                              'back_left', 'back_right'))))
            if wants_cut:
                cutter = self._ensure_furniture_top_cutter()
                self._position_furniture_top_cutter(cutter)
                mod = top_obj.modifiers.get(FURNITURE_TOP_CUT_MOD_NAME)
                if mod is None:
                    mod = top_obj.modifiers.new(
                        name=FURNITURE_TOP_CUT_MOD_NAME, type='BOOLEAN')
                    mod.operation = 'DIFFERENCE'
                    mod.solver = 'EXACT'
                if mod.object is not cutter:
                    mod.object = cutter
            else:
                self._cleanup_furniture_top_cutter()
            if shape == 'WATERFALL':
                self._position_furniture_top_legs()
            else:
                self._cleanup_furniture_top_legs()
        else:
            self._cleanup_furniture_top()

    # =====================================================================
    # Finished bottom (uppers)
    # =====================================================================
    # (thickness, flush) per finished_bottom_type. Non-flush panels hang
    # with their top against the carcass bottom's underside; flush panels
    # sit with their underside at the bottom-rail bottom (cabinet z=0) -
    # the same placement rule the upper-bottom detail card draws.
    _FINISHED_BOTTOM_SPECS = {
        'QUARTER': (inch(0.25), False),
        'THREE_QUARTER': (inch(0.75), False),
        'QUARTER_FLUSH': (inch(0.25), True),
        'THREE_QUARTER_FLUSH': (inch(0.75), True),
    }
    _FB_ROUTE_WIDTH = inch(0.875)
    _FB_ROUTE_FRONT_INSET = inch(1.5)
    _FB_CUT_MOD_NAME = 'FB LED Route'

    _FB_ROLES = (PART_ROLE_FB_LED_CUTTER, PART_ROLE_FINISHED_BOTTOM,
                 PART_ROLE_FB_LIGHT, PART_ROLE_FB_LED_STRIP)

    @staticmethod
    def _led_strip_material():
        """Shared emissive LED-strip material, created on first use.
        The viewport display color makes the strip read as a light
        band in Solid shading too."""
        mat = bpy.data.materials.get('HB LED Strip')
        if mat is not None:
            return mat
        mat = bpy.data.materials.new('HB LED Strip')
        mat.use_nodes = True
        nt = mat.node_tree
        nt.nodes.clear()
        out = nt.nodes.new('ShaderNodeOutputMaterial')
        em = nt.nodes.new('ShaderNodeEmission')
        em.inputs['Color'].default_value = (1.0, 0.956, 0.839, 1.0)
        em.inputs['Strength'].default_value = 5.0
        nt.links.new(em.outputs['Emission'], out.inputs['Surface'])
        mat.diffuse_color = (1.0, 0.956, 0.839, 1.0)
        return mat

    # Recursive: a carcass-bottom panel hangs off the cabinet root, but a
    # mid-rail shelf's panel is parented to that shelf's split node so it
    # rides the bay's own transform. Keys are unique across both (segment
    # keys are bay numbers, shelf keys carry a 'shelf:' prefix).
    def _fb_children(self, role):
        return [c for c in self.obj.children_recursive
                if c.get('hb_part_role') == role]

    def _fb_child_for_key(self, role, key):
        for child in self.obj.children_recursive:
            if (child.get('hb_part_role') == role
                    and child.get('hb_fb_key') == key):
                return child
        return None

    def _cleanup_finished_bottom(self, keep_keys=None, roles=None):
        """Remove finished-bottom objects. With keep_keys, only stale
        segment keys go; with roles, only those roles are touched."""
        for role in (roles or self._FB_ROLES):
            for child in self._fb_children(role):
                if keep_keys is not None and (
                        child.get('hb_fb_key') in keep_keys):
                    continue
                bpy.data.objects.remove(child, do_unlink=True)

    @staticmethod
    def _rebuild_box_mesh(obj, x0, x1, y0, y1, z0, z1):
        """Regenerate obj's mesh as an axis-aligned box (boolean cutter)."""
        import bmesh
        verts = [
            (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
            (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
        ]
        faces = [
            (0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
            (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7),
        ]
        mesh = obj.data
        mesh.clear_geometry()
        mesh.from_pydata(verts, [], faces)
        mesh.validate()
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        bm.free()
        mesh.update()

    def _fb_target_from_part(self, src, key, parent, rail_w, thickness,
                             mirror_y=True):
        """One finish target, read off the part being finished: where the
        panel goes, how big it is, and what the flush rule measures
        against (the face-frame member in front of it, and the finished
        part's own thickness).

        The finish panel takes the finished part's own Y mirroring so the
        two share a footprint; `mirror_y` is the fallback for a part whose
        flag cannot be read (the carcass bottom mirrors, a bay shelf does
        not).
        """
        try:
            length = self._part_input(src, 'Length')
            width = self._part_input(src, 'Width')
        except Exception:
            return None
        if not length or not width:
            return None
        src_mirror = self._part_input(src, 'Mirror Y')
        mirror_y = mirror_y if src_mirror is None else bool(src_mirror)
        y0 = src.location.y
        return {
            'key': key,
            'parent': parent,
            'mirror_y': mirror_y,
            'x': src.location.x,
            'y': y0,
            # -Y is forward, so the front edge is whichever end of the
            # part's own Y span sits furthest that way.
            'front_y': y0 - width if mirror_y else y0,
            'length': length,
            'width': width,
            'underside': src.location.z,
            'rail_width': rail_w,
            'thickness': thickness,
        }

    def _fb_bottom_targets(self, cab):
        """One target per live carcass-bottom segment, filtered by the
        cabinet's per-bay scope (empty scope = every segment,
        FINISHED_BOTTOM_BAYS_NONE = none of them)."""
        scope = {s.strip() for s in
                 getattr(cab, 'finished_bottom_bays', '').split(',')
                 if s.strip()}
        if FINISHED_BOTTOM_BAYS_NONE in scope:
            return []
        targets = []
        for src in self.obj.children:
            if (src.get('hb_part_role') != PART_ROLE_BOTTOM
                    or src.hide_viewport
                    or src.get('IS_MANUAL_PART')):
                continue
            key = str(src.get('hb_segment_start_bay', 0))
            if scope and key not in scope:
                continue
            tgt = self._fb_target_from_part(
                src, key, self.obj, cab.bottom_rail_width,
                cab.material_thickness)
            if tgt is not None:
                targets.append(tgt)
        return targets

    @staticmethod
    def _fb_rail_for_shelf(split, idx):
        """The face-frame member standing in front of a shelf. A bay whose
        bottom is removed tags its lowest splitter BOTTOM_RAIL rather than
        BAY_MID_RAIL - which is exactly the rail over a refrigerator
        opening - so match on IS_BAY_SPLITTER_RAIL, the flag both carry."""
        for child in split.children:
            if (child.get('IS_BAY_SPLITTER_RAIL')
                    and child.get('hb_splitter_index', 0) == idx):
                return child
        return None

    def _fb_shelf_targets(self):
        """One target per opted-in mid-rail shelf.

        The shelf behind a mid rail is the bottom of everything above it,
        and when the opening below holds an appliance that underside is
        the one on show - a refrigerator surround, where the cabinet's own
        bottom is nowhere near it. Opt-in per shelf (the splitter entry the
        right-click dialog writes), so a cabinet's other shelves are left
        alone, and not upper-only: these cabinets are tall.
        """
        targets = []
        for shelf in self.obj.children_recursive:
            if (shelf.get('hb_part_role') != PART_ROLE_BAY_SHELF
                    or shelf.hide_viewport
                    or shelf.get('IS_MANUAL_PART')):
                continue
            split = shelf.parent
            if split is None or not split.get(TAG_SPLIT_NODE):
                continue
            idx = shelf.get('hb_splitter_index', 0)
            coll = split.face_frame_split.splitter_widths
            if idx >= len(coll) or not coll[idx].finished_bottom:
                continue
            # No rail, no finished bottom: the flush rule is measured off
            # the rail's bottom edge, and a shelf whose member was removed
            # has nothing to measure against.
            rail = self._fb_rail_for_shelf(split, idx)
            if rail is None:
                continue
            rail_w = self._part_input(rail, 'Width')
            t_shelf = self._part_input(shelf, 'Thickness')
            if not rail_w or not t_shelf:
                continue
            tgt = self._fb_target_from_part(
                shelf, 'shelf:%s:%d' % (split.name, idx), split,
                rail_w, t_shelf, mirror_y=False)
            if tgt is not None:
                targets.append(tgt)
        return targets

    def _apply_finished_bottom(self, layout):
        """Build / position the finished bottom assembly per the
        cabinet's finished_bottom_type; ensure it's gone when NONE.

        Targets are the live carcass-bottom segments of an upper (one
        panel each, mirroring that segment's span and height - so the
        finish stops inside finished ends exactly like the carcass bottom
        does, follows a raised / dropped bay's own bottom, and skips bays
        whose bottom is removed) plus any mid-rail shelf switched on for
        it. Each panel gets an LED route cut into its underside near the
        front edge and an optional area light in the route.
        """
        cab = self.obj.face_frame_cabinet
        spec = self._FINISHED_BOTTOM_SPECS.get(
            getattr(cab, 'finished_bottom_type', 'NONE'))
        if spec is None or not self._has_carcass():
            self._cleanup_finished_bottom()
            return
        targets = []
        if layout.cabinet_type == 'UPPER':
            targets.extend(self._fb_bottom_targets(cab))
        targets.extend(self._fb_shelf_targets())
        if not targets:
            self._cleanup_finished_bottom()
            return

        t_fin, flush = spec
        want_route = getattr(cab, 'finished_bottom_led_route', False)
        want_light = want_route and getattr(
            cab, 'finished_bottom_light', False)
        route_width = getattr(cab, 'finished_bottom_route_width',
                              self._FB_ROUTE_WIDTH)
        route_inset = getattr(cab, 'finished_bottom_route_inset',
                              self._FB_ROUTE_FRONT_INSET)
        # Clamp the cut so at least 1/16" of material stays above it.
        route_depth = min(
            getattr(cab, 'finished_bottom_route_depth', inch(0.375)),
            max(t_fin - inch(0.0625), inch(0.03125)))

        live_keys = set()
        for tgt in targets:
            live_keys.add(tgt['key'])
            self._build_fb_target(tgt, t_fin, flush, want_route,
                                  want_light, route_width, route_inset,
                                  route_depth)

        # Stale targets (bay merged away, bottom newly removed, shelf
        # switched back off); with the route off every cutter goes, and
        # with the light off (or the route off) every light.
        self._cleanup_finished_bottom(keep_keys=live_keys)
        if not want_route:
            self._cleanup_finished_bottom(roles=(PART_ROLE_FB_LED_CUTTER,))
        if not want_light:
            self._cleanup_finished_bottom(
                roles=(PART_ROLE_FB_LIGHT, PART_ROLE_FB_LED_STRIP))

    def _build_fb_target(self, tgt, t_fin, flush, want_route, want_light,
                         route_width, route_inset, route_depth):
        """Panel + LED route + optional light for one finish target."""
        key = tgt['key']
        parent = tgt['parent']
        x0 = tgt['x']
        y0 = tgt['y']
        seg_len = tgt['length']
        seg_w = tgt['width']
        underside_z = tgt['underside']
        # Non-flush: panel top against the finished part's underside.
        # Flush: panel underside at the bottom edge of the face-frame
        # member in front of it (the part's top sits at the member's top,
        # so the member's bottom is underside - (member - part thickness)).
        z_fin = (underside_z - (tgt['rail_width'] - tgt['thickness'])
                 if flush else underside_z - t_fin)

        panel = self._fb_child_for_key(PART_ROLE_FINISHED_BOTTOM, key)
        if panel is None:
            part = CabinetPart()
            part.create('Finished Bottom')
            part.obj.parent = parent
            part.obj['hb_part_role'] = PART_ROLE_FINISHED_BOTTOM
            part.obj['hb_fb_key'] = key
            part.obj['CABINET_PART'] = True
            part.set_input('Mirror Y', tgt['mirror_y'])
            panel = part.obj
        if not panel.get('IS_MANUAL_PART'):
            panel.location = (x0, y0, z_fin)
            gn = GeoNodeCutpart(panel)
            gn.set_input('Length', seg_len)
            gn.set_input('Width', seg_w)
            gn.set_input('Thickness', t_fin)

        # LED route across this target's width, behind the panel's front
        # edge by the route inset. Opt-in; size and location come from the
        # cabinet props.
        route_y0 = tgt['front_y'] + route_inset
        if want_route:
            cutter = self._fb_child_for_key(PART_ROLE_FB_LED_CUTTER, key)
            if cutter is None:
                mesh = bpy.data.meshes.new('FB LED Route Cutter')
                cutter = hb_utils.new_object('FB LED Route Cutter', mesh)
                for coll in self.obj.users_collection:
                    coll.objects.link(cutter)
                cutter.parent = parent
                cutter['hb_part_role'] = PART_ROLE_FB_LED_CUTTER
                cutter['hb_fb_key'] = key
                cutter['IS_CUTTING_OBJ'] = True
                cutter.hide_viewport = True
                cutter.hide_render = True
            self._rebuild_box_mesh(
                cutter,
                x0 - 0.005, x0 + seg_len + 0.005,
                route_y0, route_y0 + route_width,
                z_fin - 0.003, z_fin + route_depth)
            mod = panel.modifiers.get(self._FB_CUT_MOD_NAME)
            if mod is None and not panel.get('IS_MANUAL_PART'):
                mod = panel.modifiers.new(
                    name=self._FB_CUT_MOD_NAME, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            if mod is not None:
                # Route walls show the finish carried on the cutter.
                mod.material_mode = 'TRANSFER'
                if mod.object is not cutter:
                    mod.object = cutter
        else:
            mod = panel.modifiers.get(self._FB_CUT_MOD_NAME)
            if mod is not None:
                panel.modifiers.remove(mod)

        # Optional area light in this target's route for renders.
        if want_light:
            light_obj = self._fb_child_for_key(PART_ROLE_FB_LIGHT, key)
            if light_obj is None or light_obj.type != 'LIGHT':
                light_data = bpy.data.lights.new('FB LED Light', 'AREA')
                light_obj = hb_utils.new_object('FB LED Light', light_data)
                for coll in self.obj.users_collection:
                    coll.objects.link(light_obj)
                light_obj.parent = parent
                light_obj['hb_part_role'] = PART_ROLE_FB_LIGHT
                light_obj['hb_fb_key'] = key
                light_obj['IS_2D_ANNOTATION'] = True
                light_obj.data.energy = 10.0
            light = light_obj.data
            light.shape = 'RECTANGLE'
            light.size = max(seg_len - inch(2.0), inch(1.0))
            light.size_y = route_width * 0.8
            light_obj.location = (
                x0 + seg_len / 2.0,
                route_y0 + route_width / 2.0,
                z_fin - 0.002)

            # Visible diffuser: a thin emissive strip up inside the
            # route (the area light renders as nothing, so this is
            # what reads as the light source from below). Sits in
            # the top half of the groove, held a hair off the route
            # ceiling and side walls.
            strip = self._fb_child_for_key(PART_ROLE_FB_LED_STRIP, key)
            if strip is None:
                mesh = bpy.data.meshes.new('FB LED Strip')
                strip = hb_utils.new_object('FB LED Strip', mesh)
                for coll in self.obj.users_collection:
                    coll.objects.link(strip)
                strip.parent = parent
                strip['hb_part_role'] = PART_ROLE_FB_LED_STRIP
                strip['hb_fb_key'] = key
                strip['IS_2D_ANNOTATION'] = True
            end_margin = (inch(1.0) if seg_len > inch(3.0)
                          else seg_len * 0.1)
            strip_top = z_fin + route_depth - 0.0005
            strip_bottom = max(strip_top - inch(0.0625),
                               z_fin + 0.001)
            self._rebuild_box_mesh(
                strip,
                x0 + end_margin, x0 + seg_len - end_margin,
                route_y0 + route_width * 0.1,
                route_y0 + route_width * 0.9,
                strip_bottom, strip_top)
            mat = self._led_strip_material()
            if strip.data.materials:
                strip.data.materials[0] = mat
            else:
                strip.data.materials.append(mat)

    # =====================================================================
    # Under-cabinet appliances (uppers)
    # =====================================================================
    # Block stand-ins for a microwave or a short vent hood hanging under
    # an upper bay. Overall sizes are real, the geometry is a plain box:
    # enough to read in 3D and to land on the elevations. Detailed models
    # ship in a separate optional library and are swapped in over the
    # block. Not cabinet parts - no CABINET_PART / hb_part_role tag - so
    # they stay out of part lists; tagged IS_APPLIANCE so downstream
    # consumers treat them like any other appliance.
    UCA_TAG = 'HB_UNDER_CABINET_APPLIANCE'
    # kind -> (object name, APPLIANCE_TYPE)
    _UCA_SPECS = {
        'MICROWAVE': ("Microwave", 'MICROWAVE'),
        'HOOD': ("Under Cabinet Hood", 'UNDER_CABINET_HOOD'),
    }

    @staticmethod
    def _stainless_material():
        """Shared brushed-stainless material for appliance blocks,
        created on first use. The viewport display color keeps them
        reading as metal in Solid shading too."""
        mat = bpy.data.materials.get('HB Stainless Steel')
        if mat is not None:
            return mat
        mat = bpy.data.materials.new('HB Stainless Steel')
        mat.use_nodes = True
        bsdf = mat.node_tree.nodes.get('Principled BSDF')
        if bsdf is not None:
            bsdf.inputs['Base Color'].default_value = (0.55, 0.56, 0.58, 1.0)
            if 'Metallic' in bsdf.inputs:
                bsdf.inputs['Metallic'].default_value = 1.0
            if 'Roughness' in bsdf.inputs:
                bsdf.inputs['Roughness'].default_value = 0.35
        mat.diffuse_color = (0.55, 0.56, 0.58, 1.0)
        return mat

    @classmethod
    def _uca_material(cls, finish):
        """Material for an appliance block. Stainless is generated in
        code; every other finish is an accessory-finish material (the
        same metals the pulls offer), falling back to stainless when the
        finish library has no such name."""
        if finish and finish != 'STAINLESS':
            mat = pulls.load_finish_material(finish)
            if mat is not None:
                return mat
        return cls._stainless_material()

    # ---- Galley workstation parts ----------------------------------
    GALLEY_KEY = 'hb_galley_key'

    def _is_galley(self):
        return str(self.obj.get('CLASS_NAME', '')).startswith('Galley')

    def _galley_children(self):
        return [c for c in self.obj.children if c.get(self.GALLEY_KEY)]

    def _cleanup_galley_parts(self, keep_keys=None):
        for child in self._galley_children():
            if keep_keys is not None and child.get(self.GALLEY_KEY) in keep_keys:
                continue
            bpy.data.objects.remove(child, do_unlink=True)

    def _ensure_galley_part(self, key, name, role, kind):
        """Find or make one workstation part. ``kind`` sets the
        orientation: an APRON stands across the width like the back, a
        PARTITION runs front to back like a side, a CLEAT lies flat."""
        for child in self._galley_children():
            if child.get(self.GALLEY_KEY) == key:
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj[self.GALLEY_KEY] = key
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        if kind == 'APRON':
            part.obj.rotation_euler.x = math.radians(90)
            part.obj.rotation_euler.y = math.radians(-90)
            part.set_input('Mirror Y', True)
        elif kind == 'PARTITION':
            part.obj.rotation_euler.y = math.radians(-90)
            part.set_input('Mirror Y', True)
            part.set_input('Mirror Z', True)
        else:
            part.set_input('Mirror Y', True)
        return part.obj

    def _apply_galley_parts(self, layout):
        """The workstation construction, placed every recalc: aprons hung
        from under the stretchers at the front setback and against the
        back, partitions from the cabinet floor up to the aprons under
        every mid stile and against each side, cleats beneath them in
        the kick, and the sink spanning the end partitions."""
        if not self._is_galley():
            self._cleanup_galley_parts()
            return
        cab = self.obj.face_frame_cabinet
        setback = max(float(getattr(cab, 'galley_front_apron_setback',
                                    GALLEY_FRONT_SETBACK)), 0.0)
        mt, dim_x, dim_y, dim_z = layout.mt, layout.dim_x, layout.dim_y, layout.dim_z
        stretcher_t = float(getattr(cab, 'stretcher_thickness', mt))
        apron_h = max(GALLEY_APRON_H - stretcher_t, mt)
        apron_z = dim_z - GALLEY_APRON_H
        inner_w = max(dim_x - 2.0 * mt, mt)
        gm = GALLEY_MATERIAL
        live = set()

        def place(key, name, role, kind, loc, length, width, thickness):
            obj = self._ensure_galley_part(key, name, role, kind)
            obj.location = loc
            part = GeoNodeCutpart(obj)
            part.set_input('Length', length)
            part.set_input('Width', width)
            part.set_input('Thickness', thickness)
            live.add(key)

        # Aprons: the location is the panel's back face; it builds
        # toward the front.
        place('front_apron', 'Galley Front Apron', PART_ROLE_GALLEY_APRON,
              'APRON', (mt, -dim_y + setback + gm, apron_z), apron_h, inner_w,
              gm)
        place('back_apron', 'Galley Back Apron', PART_ROLE_GALLEY_APRON,
              'APRON', (mt, -mt, apron_z), apron_h, inner_w, gm)

        # Partitions and their cleats.
        z0 = layout.tkh + mt
        p_h = max(apron_z - z0, gm)
        p_depth = max(dim_y - setback - mt - gm, gm)
        columns = [('end_left', mt, gm), ('end_right', dim_x - mt - gm, gm)]
        for i in range(layout.bay_count - 1):
            stile_x0 = solver.bay_x_position(layout, i) + layout.bays[i]['width']
            stile_w = (layout.mid_stiles[i]['width']
                       if i < len(layout.mid_stiles) else 0.0)
            columns.append(('mid_%d' % i,
                            stile_x0 + stile_w / 2.0 - GALLEY_PARTITION_T / 2.0,
                            GALLEY_PARTITION_T))
        for key, x, t in columns:
            place('part_' + key, 'Galley Partition', PART_ROLE_GALLEY_PARTITION,
                  'PARTITION', (x, -mt, z0), p_h, p_depth, t)
            if layout.tkh > 0.0:
                place('cleat_' + key, 'Galley Cleat', PART_ROLE_GALLEY_CLEAT,
                      'CLEAT', (x, -mt, 0.0), t, p_depth, layout.tkh)
        self._cleanup_galley_parts(keep_keys=live)

        # The sink, between the end partitions, from the back panel to
        # the front apron's face.
        from ..common import appliance_geo
        appliance_geo.sync_galley_sink(
            self.obj, mt + gm, max(dim_x - 2.0 * (mt + gm), gm), -mt,
            max(dim_y - setback - mt, gm), dim_z)
        # The storage openings' kit goes in on a deferred pass: seeding
        # writes interior items, which is a recalc of its own.
        if self._galley_storage_unseeded(layout):
            _schedule_galley_seed(self.obj.name)

    def _galley_storage_bays(self, layout):
        """(bay, kind) for every bay: the last is the sink base and gets
        no kit (kind None), the bay beside it takes the two culinary-kit
        roll-outs, and the rest take tray dividers."""
        bays = sorted([c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
                      key=lambda c: c.get('hb_bay_index', 0))[:layout.bay_count]
        out = []
        for i, bay in enumerate(bays):
            if i == len(bays) - 1:
                kind = None
            elif i == len(bays) - 2:
                kind = 'ROLLOUT'
            else:
                kind = 'TRAY_DIVIDERS'
            out.append((bay, kind))
        return out

    def _galley_storage_unseeded(self, layout):
        for bay, _kind in self._galley_storage_bays(layout):
            for cage in bay.children_recursive:
                if cage.get(TAG_OPENING_CAGE) and not cage.get('hb_galley_seeded'):
                    return True
        return False

    def seed_galley_storage(self, layout):
        """Put the kit into the storage openings once: the roll-outs are
        the two culinary-kit boxes, a 14 in bowl below a 10 1/2 in one,
        and the default shelves come out of any opening that gets kit.
        Everything keeps under the sink: the roll-outs go without their
        full-height spacers and the tray dividers' locked shelf sits
        just below the bowl."""
        from ..common import appliance_geo
        inv = self.obj.matrix_world.inverted()
        sink_bottom = layout.dim_z - appliance_geo.SINK_H
        for bay, kind in self._galley_storage_bays(layout):
            for cage in bay.children_recursive:
                if not cage.get(TAG_OPENING_CAGE) or cage.get('hb_galley_seeded'):
                    continue
                cage['hb_galley_seeded'] = True
                op = cage.face_frame_opening
                if op.front_type not in ('DOOR', 'NONE'):
                    continue
                for j in reversed(range(len(op.interior_items))):
                    if op.interior_items[j].kind == 'ADJUSTABLE_SHELF':
                        op.interior_items.remove(j)
                if kind is None:
                    continue    # the sink base stays open for the plumbing
                item = op.interior_items.add()
                item.kind = kind
                opening_z = (inv @ cage.matrix_world.translation).z
                if kind == 'TRAY_DIVIDERS':
                    item.tray_opening_height = max(
                        sink_bottom - opening_z - inch(0.25), inch(6.0))
                if kind == 'ROLLOUT':
                    item.hide_rollout_spacers = True
                    for height, top in ((inch(6.125), 'BOWL_14'),
                                        (inch(4.625), 'BOWL_10')):
                        box = item.rollout_boxes.add()
                        try:
                            box.height_preset = 'CUSTOM'
                        except TypeError:
                            pass
                        box.height = height
                        box.galley_top = top

    def _uca_children(self):
        return [c for c in self.obj.children if c.get(self.UCA_TAG)]

    def _cleanup_under_cabinet_appliances(self, keep_keys=None):
        """Remove appliance blocks; with keep_keys only stale bays go."""
        for child in self._uca_children():
            if keep_keys is not None and child.get('hb_uca_key') in keep_keys:
                continue
            bpy.data.objects.remove(child, do_unlink=True)

    def _apply_under_cabinet_appliances(self, layout):
        """Build / position one appliance block per upper bay that asks
        for one. Width follows the bay opening unless the bay carries an
        explicit width; the block hangs from the underside of the bay
        (or of its finished bottom panel, when one covers it) and runs
        forward from the back of the cabinet, so a unit deeper than the
        cabinet sticks out the front the way it does in the field.

        The bay's opening has already been raised by the appliance
        height (see props._sync_under_cabinet_opening), so the block
        drops into the space the shortened box left below it."""
        if layout.cabinet_type != 'UPPER':
            self._cleanup_under_cabinet_appliances()
            return

        fb_panels = [c for c in self.obj.children
                     if c.get('hb_part_role') == PART_ROLE_FINISHED_BOTTOM]
        live_keys = set()
        for bay_obj in [c for c in self.obj.children if c.get(TAG_BAY_CAGE)]:
            bay_index = bay_obj.get('hb_bay_index', 0)
            if bay_obj.hide_viewport or bay_index >= layout.bay_count:
                continue
            props = bay_obj.face_frame_bay
            kind = getattr(props, 'under_cabinet_appliance', 'NONE')
            spec = self._UCA_SPECS.get(kind)
            if spec is None:
                continue
            name, appliance_type = spec
            height = props.under_cabinet_appliance_height
            depth = props.under_cabinet_appliance_depth
            bay_width = layout.bays[bay_index]['width']
            width = props.under_cabinet_appliance_width or bay_width
            if not width or not height or not depth:
                continue

            # Centered on the bay opening, back against the cabinet back.
            bay_left = solver.bay_x_position(layout, bay_index)
            x0 = bay_left + (bay_width - width) / 2.0
            z_top = solver.bay_bottom_z(layout, bay_index)
            for panel in fb_panels:
                try:
                    p_len = self._part_input(panel, 'Length')
                except Exception:
                    continue
                p_x0 = panel.location.x
                if (p_x0 < x0 + width and p_x0 + (p_len or 0.0) > x0
                        and panel.location.z < z_top):
                    z_top = panel.location.z

            key = str(bay_index)
            live_keys.add(key)
            block = None
            for child in self._uca_children():
                if child.get('hb_uca_key') == key:
                    block = child
                    break
            if block is None:
                mesh = bpy.data.meshes.new(name)
                block = hb_utils.new_object(name, mesh)
                for coll in self.obj.users_collection:
                    coll.objects.link(block)
                block.parent = self.obj
                block[self.UCA_TAG] = kind
                block['hb_uca_key'] = key
                block['IS_APPLIANCE'] = True
            # Finish: applied when the bay's pick changes, so a designer
            # who assigns their own material to the block keeps it.
            finish = getattr(props, 'under_cabinet_appliance_finish',
                             'STAINLESS')
            if block.get('hb_uca_finish') != finish:
                mat = self._uca_material(finish)
                if mat is not None:
                    block.data.materials.clear()
                    block.data.materials.append(mat)
                    block['hb_uca_finish'] = finish
            if block.get(self.UCA_TAG) != kind:
                # Switched kind on an existing bay - rename so the
                # outliner matches what is now hanging there.
                block.name = name
            block[self.UCA_TAG] = kind
            block['APPLIANCE_TYPE'] = appliance_type
            block['APPLIANCE_LABEL'] = name
            block.location = (x0, 0.0, z_top - height)
            self._rebuild_box_mesh(block, 0.0, width, -depth, 0.0,
                                   0.0, height)

        self._cleanup_under_cabinet_appliances(keep_keys=live_keys)

    # =====================================================================
    # Hutch finished back (uppers with ends extended down)
    # =====================================================================
    def _ensure_hutch_back(self):
        """Find or lazily create the hutch recess back CabinetPart - a
        panel mirroring the carcass back's orientation, tagged
        PART_ROLE_HUTCH_BACK (+ CABINET_PART so the material walk gives it
        the finish material). Sized / placed by _position_hutch_back."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_HUTCH_BACK:
                return child
        back = CabinetPart()
        back.create('Hutch Back')
        back.obj.parent = self.obj
        back.obj['hb_part_role'] = PART_ROLE_HUTCH_BACK
        back.obj['CABINET_PART'] = True
        # Same orientation as the carcass back (Length up, Width across X).
        back.obj.rotation_euler.x = math.radians(90)
        back.obj.rotation_euler.y = math.radians(-90)
        back.set_input('Mirror Y', True)
        return back.obj

    def _position_hutch_back(self, back_obj, layout):
        """Span the back of the dropped-end recess: same X / Y / thickness
        as the carcass back, from the box bottom DOWN by the drop (the
        deeper of the two ends when they differ)."""
        segs = solver.carcass_back_segments(layout)
        if not segs:
            self._cleanup_hutch_back()
            return
        left_x = min(s['x'] for s in segs)
        right_x = max(s['x'] + s['horizontal_length'] for s in segs)
        drop = max(solver.ends_down_drop(layout, 'LEFT'),
                   solver.ends_down_drop(layout, 'RIGHT'))
        box_bottom = solver.bay_bottom_z(layout, 0)
        bottom_z = box_bottom - drop
        # Top out at the carcass back's bottom edge (seg z) so the recess
        # back is continuous with it and reaches the actual underside of
        # the upper box - bay_bottom_z is only the bottom-rail line, which
        # sits ~a rail below the bottom panel, leaving a gap.
        top_z = segs[0]['z']
        part = GeoNodeCutpart(back_obj)
        part.set_input('Length', top_z - bottom_z)
        part.set_input('Width', right_x - left_x)
        part.set_input('Thickness', segs[0]['thickness'])
        back_obj.location = (left_x, segs[0]['y'], bottom_z)

    def _cleanup_hutch_back(self):
        """Remove the hutch recess back (option off / no end dropped)."""
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_HUTCH_BACK:
                bpy.data.objects.remove(child, do_unlink=True)

    def _apply_hutch_back(self, layout):
        """Close the open recess below an upper whose ends are extended
        down with a finished back, when hutch_finished_back is on and at
        least one end is dropped. Called once per recalc; managed like the
        other extras."""
        cab = self.obj.face_frame_cabinet
        drop = max(solver.ends_down_drop(layout, 'LEFT'),
                   solver.ends_down_drop(layout, 'RIGHT'))
        if getattr(cab, 'hutch_finished_back', False) and drop > 0:
            back_obj = self._ensure_hutch_back()
            self._position_hutch_back(back_obj, layout)
        else:
            self._cleanup_hutch_back()

    def _apply_back_extension(self, layout):
        """Reshape the carcass into a trapezoid wider at the back when
        extend_back_left / extend_back_right are set. v1 step 1: angle the
        side panel(s). Back / top / bottom widening follows. No-op (and
        resets any prior angle) when an end's extend is 0.
        """
        cab = self.obj.face_frame_cabinet
        raw_l = getattr(cab, 'extend_back_left', 0.0) or 0.0
        raw_r = getattr(cab, 'extend_back_right', 0.0) or 0.0
        # "Attach as Wing" converts an end's back extension into a separate
        # angled return panel: the carcass stays SQUARE for that end and the
        # extension is built as a wing below instead. Only active when the
        # end's extend is non-zero.
        wing_l = bool(getattr(cab, 'wing_attached_left', False)) and raw_l != 0.0
        wing_r = bool(getattr(cab, 'wing_attached_right', False)) and raw_r != 0.0
        # Carcass-effective extends: zero on a wing end so the splay / widen /
        # trim below leave it square; the raw value drives the wing instead.
        ext_l = 0.0 if wing_l else raw_l
        ext_r = 0.0 if wing_r else raw_r
        # Either end may be POSITIVE (outward, back wider) or NEGATIVE
        # (inward, back narrower); only exactly 0 is a no-op for that end.
        active = ext_l != 0.0 or ext_r != 0.0
        line_l = None   # (front_outer, back_outer) of the angled left side
        line_r = None   # ... right side; feed the trim cutter
        # Per-side thickness for the trim cutter's inner-face inset,
        # from the solver so it's right even when the side part is
        # HIDDEN (FALSE_FF / WORKING_FF: thickness 0 - the side's own
        # line already carries the scribe shift, so line + thickness
        # lands on the cavity bound for EVERY end condition and the
        # carve matches the FINISHED case exactly). Previously one
        # shared variable was overwritten by whichever side was read
        # last, so the cut plane used the wrong side's thickness.
        thick_l = solver.left_side_thickness(layout)
        thick_r = solver.right_side_thickness(layout)
        for child in self.obj.children:
            role = child.get('hb_part_role')
            if role == PART_ROLE_LEFT_SIDE:
                if ext_l != 0.0:
                    line_l = self._angle_side_panel(
                        child, 'LEFT', ext_l,
                        self._back_ext_canonical_depth(layout, 'LEFT'),
                        front_trim=(layout.l_fin_end != 'FINISHED'))
                else:
                    child.rotation_euler.z = 0.0
            elif role == PART_ROLE_RIGHT_SIDE:
                if ext_r != 0.0:
                    line_r = self._angle_side_panel(
                        child, 'RIGHT', ext_r,
                        self._back_ext_canonical_depth(layout, 'RIGHT'),
                        front_trim=(layout.r_fin_end != 'FINISHED'))
                else:
                    child.rotation_euler.z = 0.0
            elif role in (PART_ROLE_BACK, PART_ROLE_FINISHED_BACK):
                # Back panel: X-span is the 'Width' input. Not a trim-cutter
                # target, so it follows the corner directly in BOTH directions
                # (grows outward / shrinks inward).
                self._widen_back_panel(child, ext_l, ext_r, 'Width',
                                       layout=layout)
            elif role in (PART_ROLE_REAR_STRETCHER, PART_ROLE_FRONT_STRETCHER,
                          PART_ROLE_FINISH_TOE_KICK,
                          PART_ROLE_TOE_KICK_SUBFRONT):
                # Stretchers AND the toe-kick front members (finish kick + sub
                # kick) all span left-right (X-span is 'Length') and have depth
                # in Y, so the angled side crosses them. Treated like top/bottom:
                # outward grows rectangularly then the cutter trims the overhang;
                # inward stays square and the cutter trims the corner
                # (allow_shrink=False). The toe-kick fronts are RECESSED in Y, so
                # at their setback the angled side has already moved off the
                # square width -- widening + the cutter lands their end on the
                # side line at that depth, closing the gap the recess opened.
                # Front-most edges trim back to the square front-outer corner, so
                # the square front face is unaffected.
                self._widen_back_panel(child, ext_l, ext_r, 'Length',
                                       allow_shrink=False, layout=layout)
            elif role in (PART_ROLE_TOP, PART_ROLE_BOTTOM):
                # Full-depth panels ARE trim-cutter targets. Outward: extend
                # rectangularly to the corner, the cutter trims the FRONT
                # overhang -> trapezoid. Inward: leave the panel SQUARE
                # (allow_shrink=False ignores a negative end) and let the cutter
                # remove the BACK corner instead. The cutter's cut line is the
                # angled side either way, so a square panel trims correctly.
                self._widen_back_panel(child, ext_l, ext_r, 'Length',
                                       allow_shrink=False, layout=layout)
            elif role == PART_ROLE_LOOSE_KICK_REAR:
                # Loose-ladder rear rail spans X at the cabinet back:
                # widen to the splayed corners, the cutter trims its
                # ends to the angled side line (buried joint inside the
                # splayed end boards).
                self._widen_back_panel(child, ext_l, ext_r, 'Length',
                                       allow_shrink=False, layout=layout)
            elif role == PART_ROLE_LOOSE_KICK_END_LEFT:
                self._splay_loose_kick_end(
                    child, 'LEFT', ext_l,
                    self._back_ext_canonical_depth(layout, 'LEFT'))
            elif role == PART_ROLE_LOOSE_KICK_END_RIGHT:
                self._splay_loose_kick_end(
                    child, 'RIGHT', ext_r,
                    self._back_ext_canonical_depth(layout, 'RIGHT'))

        # Trapezoid trim for the full-depth panels (top / bottom / shelves):
        # boolean-difference the front overhang along the angled side
        # line(s). Built only when an end is extended; removed otherwise.
        if active and (line_l is not None or line_r is not None):
            cutter = self._ensure_back_ext_cutter()
            self._position_back_ext_cutter(cutter, line_l, line_r,
                                           thick_l, thick_r)
            self._apply_back_ext_cuts(cutter)
        else:
            self._cleanup_back_ext_cutter_and_cuts()

        # Splayed side front-end bevel against the FF back (FINISHED
        # sides run to the front plane and take the corner miter
        # instead - see _apply_side_front_trim).
        self._apply_side_front_trim(
            layout, 'LEFT',
            ext_l != 0.0 and layout.l_fin_end != 'FINISHED')
        self._apply_side_front_trim(
            layout, 'RIGHT',
            ext_r != 0.0 and layout.r_fin_end != 'FINISHED')

        # Wing attached: for an end whose "Attach as Wing" is on (and its
        # extend is non-zero), the carcass above stayed square (wing ends were
        # zeroed out of ext_l / ext_r); add the angled return panel along the
        # line the raw extend defines. Off / 0 -> removed.
        self._apply_wing(layout, 'LEFT', raw_l if wing_l else 0.0)
        self._apply_wing(layout, 'RIGHT', raw_r if wing_r else 0.0)

    SIDE_FRONT_TRIM_MOD_NAME = 'Side Front End Trim'

    def _apply_side_front_trim(self, layout, side, active):
        """Bevel a splayed side panel's FRONT end flush against the
        BACK of the face frame: the splayed side meets the flat FF
        back at the splay angle, so a square end cut leaves a wedge
        gap. _angle_side_panel overshoots the plane; this boolean cuts
        the overshoot on the plane y = -(depth - fft), leaving the end
        face seated against the FF back. Skipped for FINISHED sides
        (they run to the FRONT plane and take the corner miter
        instead). Cutter + modifier removed when inactive."""
        side_role = ('LEFT_SIDE' if side == 'LEFT' else 'RIGHT_SIDE')
        side_part = next(
            (c for c in self.obj.children
             if c.get('hb_part_role') == side_role), None)
        cutter_role = 'SIDE_FRONT_TRIM_CUTTER'
        cutter = next(
            (c for c in self.obj.children
             if c.get('hb_part_role') == cutter_role
             and c.get('hb_trim_side') == side), None)
        if not active or side_part is None:
            if side_part is not None:
                mod = side_part.modifiers.get(self.SIDE_FRONT_TRIM_MOD_NAME)
                if mod is not None:
                    side_part.modifiers.remove(mod)
            if cutter is not None:
                mesh = cutter.data
                bpy.data.objects.remove(cutter, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
            return
        if cutter is None:
            name = f'Side Front Trim Cutter {side.title()}'
            mesh = bpy.data.meshes.new(name)
            cutter = hb_utils.new_object(name, mesh)
            cutter['hb_part_role'] = cutter_role
            cutter['hb_trim_side'] = side
            cutter.parent = self.obj
            cutter.display_type = 'WIRE'
            cutter.hide_render = True
            cutter.hide_viewport = True
            for coll in self.obj.users_collection:
                coll.objects.link(cutter)
                break
        # Box removing everything FORWARD of the FF back plane.
        depth_line = self._back_ext_canonical_depth(layout, side)
        plane_y = -(depth_line - layout.fft)
        big = 1.0
        x0, x1 = -big, self.obj.face_frame_cabinet.width + big
        y0, y1 = plane_y - big, plane_y
        z0, z1 = -big, layout.dim_z + big
        bm = bmesh.new()
        v = [bm.verts.new(p) for p in (
            (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
            (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1))]
        for f in ((0, 1, 2, 3), (7, 6, 5, 4), (0, 4, 5, 1),
                  (1, 5, 6, 2), (2, 6, 7, 3), (3, 7, 4, 0)):
            bm.faces.new([v[i] for i in f])
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter.data)
        bm.free()
        cutter.location = (0.0, 0.0, 0.0)
        cutter.rotation_euler = (0.0, 0.0, 0.0)
        mod = side_part.modifiers.get(self.SIDE_FRONT_TRIM_MOD_NAME)
        if mod is None:
            mod = side_part.modifiers.new(
                name=self.SIDE_FRONT_TRIM_MOD_NAME, type='BOOLEAN')
            mod.operation = 'DIFFERENCE'
            mod.solver = 'EXACT'
        if mod.object is not cutter:
            mod.object = cutter

    def _splay_loose_kick_end(self, child, side, extend, depth_line):
        """Splay a loose-ladder end board along the CANONICAL side
        line. Back-anchored like the side (origin at the back-outer
        corner, board spans -Y by its Length input) but with a -pi/2
        base Z rotation (kick-return orientation), so the splay adds
        phi on top of the base and the span scales by 1/cos(phi).
        Reset to square on extend == 0 (the main dispatch already
        restored location + Length from the solver this recalc)."""
        base_z = -math.pi / 2.0
        if extend == 0.0:
            child.rotation_euler.z = base_z
            return
        length = self._part_input(child, 'Length')
        if length is None:
            return
        front_target, back_target, phi, _hyp = self._back_ext_line(
            side, extend, depth_line)
        cphi = math.cos(phi)
        if cphi <= 1e-6:
            return
        child.rotation_euler.z = base_z + phi
        child.location.x = back_target.x
        child.location.y = back_target.y
        self._set_part_input(child, 'Length', length / cphi)

    def _apply_wing(self, layout, side, extend):
        """Build / remove the attached wing on one end. `extend` is the raw
        extend_back value (already gated on the wing checkbox by the caller);
        0 removes the wing. The wing is a flat angled return panel standing on
        the same (front-outer, back-outer) line the back extension would have
        used, with the carcass kept square."""
        if extend != 0.0 and self._has_carcass():
            wing_obj = self._ensure_wing(side)
            self._position_wing(wing_obj, layout, side, extend)
        else:
            self._cleanup_wing(side)

    def _ensure_wing(self, side):
        """Find or lazily create one end's wing CabinetPart - a bare finished
        panel tagged PART_ROLE_WING (+ CABINET_PART so the material walk
        finishes its outer face) and WING_SIDE so the two ends stay distinct.
        Same base orientation as a carcass side (Length up, Width across);
        Mirror Z matches the side so the finished outer face is Bottom."""
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_WING
                    and child.get('WING_SIDE') == side):
                return child
        wing = CabinetPart()
        wing.create('Wing')
        wing.obj.parent = self.obj
        wing.obj['hb_part_role'] = PART_ROLE_WING
        wing.obj['CABINET_PART'] = True
        wing.obj['WING_SIDE'] = side
        wing.obj.rotation_euler.y = math.radians(-90)
        wing.set_input('Mirror Y', True)
        wing.set_input('Mirror Z', side == 'LEFT')
        return wing.obj

    def _position_wing(self, wing_obj, layout, side, extend):
        """Stand the wing on the angled end line: full side height, the
        hypotenuse as its Width, pivoted to phi. Reuses _back_ext_line
        (shared with the carcass splay) and the solver's square side
        position / dims, so the wing tracks height / depth and sits at the
        side's base Z.

        The front end of the line is carried to the FACE FRAME front plane
        (side width + fft), not the carcass front, so the wing's front edge
        lands flush with the front of the cabinet. A non-zero per-end wing
        width overrides the automatic run: the panel keeps the same line
        but stops that far from the front corner - the front edge stays
        anchored on the cabinet, the back end pulls in (for wings that
        would otherwise run past the end of a wall)."""
        if side == 'LEFT':
            pos = solver.left_side_position(layout)
            length, width, thickness = solver.left_side_dims(layout)
        else:
            pos = solver.right_side_position(layout)
            length, width, thickness = solver.right_side_dims(layout)
        # The wing reads as the cabinet's finished return, so it runs
        # the full face height. An UNFINISHED upper side is captured by
        # the bottom panel (its bottom edge rises by the bottom rail
        # width), which would leave the wing short of the frame bottom -
        # carry it down to where a finished side would end.
        if not layout.has_toe_kick:
            bay_index = 0 if side == 'LEFT' else layout.bay_count - 1
            finished_bottom = (solver.bay_bottom_z(layout, bay_index)
                               - solver.ends_down_drop(layout, side)
                               - solver.side_extend_down(layout, side))
            if pos[2] > finished_bottom + 1e-6:
                length += pos[2] - finished_bottom
                pos = (pos[0], pos[1], finished_bottom)
        front_target, back_target, phi, w_new = self._back_ext_line(
            side, extend, width + layout.fft)
        cab = self.obj.face_frame_cabinet
        override = (cab.wing_width_left if side == 'LEFT'
                    else cab.wing_width_right)
        if override > 0.0:
            w_eff = min(override, w_new)
            # Origin sits w_eff along the line from the front corner, so
            # the panel (which runs from its origin toward the front)
            # always ends exactly on the front corner.
            origin = front_target + (back_target - front_target).normalized() * w_eff
        else:
            w_eff = w_new
            origin = back_target
        part = GeoNodeCutpart(wing_obj)
        part.set_input('Length', length)       # full cabinet (side) height
        part.set_input('Width', w_eff)         # run along the end line
        part.set_input('Thickness', thickness)
        wing_obj.rotation_euler.z = phi
        wing_obj.location = (origin.x, origin.y, pos[2])

    def _cleanup_wing(self, side):
        """Remove one end's wing (checkbox off or extend back to 0)."""
        for child in list(self.obj.children):
            if (child.get('hb_part_role') == PART_ROLE_WING
                    and child.get('WING_SIDE') == side):
                bpy.data.objects.remove(child, do_unlink=True)

    def _apply_bottom_extension(self, layout):
        """Overhang the carcass bottom panel(s) laterally past the side(s) to
        cover the void where two upper cabinets meet in a corner. Uppers only.

        Outward only (extend_bottom_left / _right are min 0). Reuses
        _widen_back_panel on the BOTTOM children with the 'Length' span input:
        that helper already grows only the end(s) that reach a cabinet end
        (so on a multi-bay upper just the outermost bottom segment overhangs,
        interior bay divisions are left alone) and derives the span
        analytically (recalc-stale-safe). Nothing else moves - the face frame,
        sides, and doors stay square, so only the bottom sticks out under the
        void. No-op (square) when both extends are 0; the part loop has already
        reset each bottom to its square span this recalc, so this is applied on
        top each time and self-corrects when the values drop back to 0.
        """
        cab = self.obj.face_frame_cabinet
        ext_l = getattr(cab, 'extend_bottom_left', 0.0) or 0.0
        ext_r = getattr(cab, 'extend_bottom_right', 0.0) or 0.0
        self._extend_deck_part(PART_ROLE_BOTTOM, ext_l, ext_r, layout)

    def _apply_top_extension(self, layout):
        """Top-panel twin of _apply_bottom_extension: overhang the carcass
        top past a side to cover the void ABOVE where two uppers meet in a
        corner (a stacked / bulkhead condition). Same mechanics -- only the
        top part grows, faces stay square, self-corrects at 0."""
        cab = self.obj.face_frame_cabinet
        ext_l = getattr(cab, 'extend_top_left', 0.0) or 0.0
        ext_r = getattr(cab, 'extend_top_right', 0.0) or 0.0
        self._extend_deck_part(PART_ROLE_TOP, ext_l, ext_r, layout)

    def _extend_deck_part(self, role, ext_l, ext_r, layout):
        """Grow the outermost TOP / BOTTOM segment(s) of `role` past the
        cabinet end(s) by ext_l / ext_r (outward only)."""
        if ext_l == 0.0 and ext_r == 0.0:
            return
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                self._widen_back_panel(child, ext_l, ext_r, 'Length',
                                       allow_shrink=True, layout=layout)

    def _widen_back_panel(self, child, ext_l, ext_r, span_input,
                          allow_shrink=True, layout=None):
        """Move a back-row panel's X-span end(s) to follow the angled back
        corner(s). Signed: a POSITIVE end extends the span outward, a NEGATIVE
        end shrinks it inward. Only the end(s) reaching a cabinet end move; a
        segment ending at an interior bay division is left alone. The right
        end moves by ext_r; the left end by ext_l (and the origin follows so
        the right end stays put). `span_input` is the X-span geometry-node
        input ('Width' for the back panel, 'Length' for stretchers / top /
        bottom).

        `allow_shrink`: False for full-depth TOP / BOTTOM, which the trim
        cutter re-shapes -- a NEGATIVE (inward) end is ignored here so the
        panel stays SQUARE and the cutter removes the back corner instead.
        True (back panel / rear stretcher, not cutter targets) follows the
        corner directly in both directions.

        The part loop has just reset this panel's square span/location, so the
        deltas are applied on top each recalc (self-correcting).
        """
        if not allow_shrink:
            # Trim-cutter targets: ignore inward (negative) ends -- the cutter
            # trims the back corner off the square panel.
            ext_l = max(ext_l, 0.0)
            ext_r = max(ext_r, 0.0)
        if ext_l == 0.0 and ext_r == 0.0:
            return
        width = self._part_input(child, span_input)
        if width is None:
            return
        dim_x = self.obj.face_frame_cabinet.width
        # X extent of this panel in cabinet-local, derived ANALYTICALLY from the
        # part's fresh origin + span -- NOT from bound_box. The part loop just
        # set this panel's location + span this recalc, but bound_box is the
        # depsgraph-EVALUATED extent and can still report the PREVIOUS extend
        # within the same pass (stale). Reading it made the "reaches the end"
        # test flip between recalcs, so the part length flickered as the extend
        # value changed. The part's origin is its left (-X) edge and the span
        # runs +X by `width` (the same convention the grow/origin math below
        # relies on), so the extent is [location.x, location.x + width]. The
        # back is inset from each cabinet end by the side thickness, so "reaches
        # the end" uses a 1" tolerance rather than touching 0 / dim_x exactly.
        x_lo = child.location.x
        x_hi = child.location.x + width
        # "Reaches the end" is measured against the CARCASS INNER bound,
        # not the cabinet face: a PANELED / scribed side pushes the
        # carcass inboard (scribe + side thickness can exceed the old
        # fixed 1" tolerance), and a part ending at that inner face must
        # still follow the extension. layout carries the per-side
        # scribe-aware bounds.
        end_tol = inch(0.5)
        if layout is not None:
            inner_l = solver.carcass_inner_left_x(layout)
            inner_r = solver.carcass_inner_right_x(layout)
        else:
            inner_l, inner_r = inch(1.0), dim_x - inch(1.0)
        grow_left = ext_l if x_lo <= inner_l + end_tol else 0.0
        grow_right = ext_r if x_hi >= inner_r - end_tol else 0.0
        if grow_left == 0.0 and grow_right == 0.0:
            return
        # Floor the result so a large inward value can't invert the panel.
        new_width = max(width + grow_left + grow_right, inch(0.125))
        self._set_part_input(child, span_input, new_width)
        # The right end moves with the span from the fixed left origin (no
        # origin move). Moving the left end shifts the origin by -grow_left:
        # +grow_left (outward) moves the origin -X; a negative grow_left
        # (inward) moves it +X. Right end stays put either way.
        if grow_left != 0.0:
            child.location.x -= grow_left

    # =====================================================================
    # Tip-up wedge cutter (back-bottom chamfer; driven by wedge_* props)
    # =====================================================================
    def _ensure_back_ext_cutter(self):
        """Find or lazily create the back-extension trim cutter MESH.
        Hidden in the viewport; the boolean reads its mesh regardless.
        Mirrors _ensure_wedge_cutter."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_BACK_EXT_CUTTER:
                return child
        mesh = bpy.data.meshes.new('Back Extension Cutter')
        cutter = hb_utils.new_object('Back Extension Cutter', mesh)
        cutter['hb_part_role'] = PART_ROLE_BACK_EXT_CUTTER
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_back_ext_cutter(self, cutter_obj, line_l, line_r,
                                  thick_l, thick_r):
        """Rebuild the cutter mesh as one half-space box per angled side,
        each removing the front overhang outside that side's INNER face -
        so the rectangularly-extended top / bottom become trapezoids that
        match the angled sides.

        Each `line` is (front_outer, back_outer) Vector2 in cabinet-local
        X-Y, as used to place the angled side (scribe shift included).
        The inner face is that line offset toward the cabinet body by
        that side's OWN thickness (thick_l / thick_r); the box keeps the
        body side and removes the rest. line + thickness = the splayed
        cavity bound, identical across end conditions (FINISHED: 3/4
        panel on the outer line; WORKING_FF / FALSE_FF: 3/4 scribe-
        shifted line + zero side).
        """
        import math
        from mathutils import Vector
        margin = inch(2.0)
        dim_x = self.obj.face_frame_cabinet.width
        dim_y = self.obj.face_frame_cabinet.depth
        dim_z = self.obj.face_frame_cabinet.height
        big = (dim_x + dim_y) * 2.0 + inch(12.0)
        body_center = Vector((dim_x * 0.5, -dim_y * 0.5))
        z0, z1 = -margin, dim_z + margin

        bm = bmesh.new()

        def add_box(front_outer, back_outer, side_thickness):
            d = (back_outer - front_outer)
            if d.length < 1e-6:
                return
            dirn = d.normalized()
            # inward normal candidates; pick the one pointing toward the
            # body center (that side is kept).
            n = Vector((-dirn.y, dirn.x))
            if n.dot(body_center - front_outer) < 0:
                n = -n
            # inner face line, offset toward the body by the side thickness
            f_in = front_outer + n * side_thickness
            # remove side is away from the body: -n
            rem = -n
            # box: u along dirn (both ways), v along rem (0..big = remove),
            # extruded in z.
            def P(u, v, z):
                p = f_in + dirn * u + rem * v
                return (p.x, p.y, z)
            us = (-big, big)
            vs = (-inch(0.005), big)  # tiny bite into the body to avoid a sliver
            verts = {}
            for iu, u in enumerate(us):
                for iv, v in enumerate(vs):
                    for iz, z in enumerate((z0, z1)):
                        verts[(iu, iv, iz)] = bm.verts.new(P(u, v, z))
            bm.verts.ensure_lookup_table()

            def face(a, bb, c, dd):
                bm.faces.new((verts[a], verts[bb], verts[c], verts[dd]))
            face((0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1))
            face((0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0))
            face((0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0))
            face((1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1))
            face((0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0))
            face((0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1))

        if line_l is not None:
            add_box(line_l[0], line_l[1], thick_l)
        if line_r is not None:
            add_box(line_r[0], line_r[1], thick_r)
        if bm.faces:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter_obj.data)
        bm.free()
        cutter_obj.location = (0.0, 0.0, 0.0)
        cutter_obj.rotation_euler = (0.0, 0.0, 0.0)

    def _iter_back_ext_cut_targets(self):
        """Full-depth panels the trapezoid trim applies to. Mirrors
        _iter_wedge_cut_targets."""
        stack = list(self.obj.children)
        while stack:
            obj = stack.pop()
            role = obj.get('hb_part_role')
            if role == PART_ROLE_BACK_EXT_CUTTER:
                continue
            if role in BACK_EXT_CUT_PART_ROLES:
                yield obj
            stack.extend(obj.children)

    def _apply_back_ext_cuts(self, cutter_obj):
        """Ensure every target carries a boolean DIFFERENCE modifier named
        BACK_EXT_CUT_MOD_NAME pointing at the cutter. Idempotent."""
        for part in self._iter_back_ext_cut_targets():
            mod = part.modifiers.get(BACK_EXT_CUT_MOD_NAME)
            if mod is None:
                mod = part.modifiers.new(
                    name=BACK_EXT_CUT_MOD_NAME, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            if mod.object is not cutter_obj:
                mod.object = cutter_obj

    def _cleanup_back_ext_cutter_and_cuts(self):
        """Reverse of _apply_back_ext_cuts + _ensure_back_ext_cutter.
        No-op when there's nothing to undo."""
        for part in self._iter_back_ext_cut_targets():
            mod = part.modifiers.get(BACK_EXT_CUT_MOD_NAME)
            if mod is not None:
                part.modifiers.remove(mod)
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_BACK_EXT_CUTTER:
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    # ------------------------------------------------------------------
    # Seamed side panels
    # ------------------------------------------------------------------

    def _side_seam_height(self, cab, side):
        """The joint height the user set for `side`, measured from the
        cabinet bottom. 0 means the panel builds whole -- either because
        nobody has placed a seam yet, or because the No Seam flag says
        the end is one piece however long it is."""
        if self._side_no_seam(cab, side):
            return 0.0
        key = 'left_side_seam_height' if side == 'LEFT' else 'right_side_seam_height'
        return max(getattr(cab, key, 0.0) or 0.0, 0.0)

    def _side_no_seam(self, cab, side):
        """True when this end is deliberately built in one piece."""
        key = 'left_side_no_seam' if side == 'LEFT' else 'right_side_no_seam'
        return bool(getattr(cab, key, False))

    def _side_seam_blocked(self, cab, layout, side):
        """Why this side cannot carry a seam, or None when it can.

        The seam only makes sense where the carcass side panel IS the
        finished face -- a paneled / applied-frame end gets its finish
        from a separate part, and those are built from members that are
        never one oversize board. Angled and back-extended sides are out
        because the panel there is a splayed trapezoid reshaped by later
        passes, not the square board this pass cuts in two.
        """
        condition = layout.l_fin_end if side == 'LEFT' else layout.r_fin_end
        if condition != 'FINISHED':
            return 'condition'
        if layout.is_angled:
            return 'angled'
        extend = (getattr(cab, 'extend_back_left', 0.0) if side == 'LEFT'
                  else getattr(cab, 'extend_back_right', 0.0))
        if extend:
            return 'extended'
        return None

    def side_seam_available(self, side):
        """True when `side` ('LEFT' / 'RIGHT') could take a panel seam.
        Public so the menu / operator can ask without rebuilding a
        layout."""
        try:
            cab = self.obj.face_frame_cabinet
            layout = solver.FaceFrameLayout(self.obj)
        except Exception:
            return False
        return self._side_seam_blocked(cab, layout, side) is None

    _SIDE_SEAM_SPEC = {
        PART_ROLE_LEFT_SIDE_SEAM: ('Left Side Seam', True),
        PART_ROLE_RIGHT_SIDE_SEAM: ('Right Side Seam', False),
    }

    def _ensure_side_seam_part(self, seam_role):
        """The seam piece for a side, created if this cabinet predates
        seams. Same rotation and mirror flags as the side it belongs to,
        so the piece reads as the same board carried on. No front-bottom
        notch: the kick cut belongs to the piece that reaches the floor.
        """
        existing = self._side_part_by_role(seam_role)
        if existing is not None:
            return existing
        name, mirror_z = self._SIDE_SEAM_SPEC[seam_role]
        seam = CabinetPart()
        seam.create(name)
        seam.obj.parent = self.obj
        seam.obj['hb_part_role'] = seam_role
        seam.obj['CABINET_PART'] = True
        seam.obj.rotation_euler.y = math.radians(-90)
        seam.set_input('Mirror Y', True)
        seam.set_input('Mirror Z', mirror_z)
        seam.obj.hide_viewport = True
        seam.obj.hide_render = True
        return seam.obj

    def _reconcile_side_seams(self, layout):
        """Split a finished side panel into two boards at the user's seam
        height, or put it back together when there is no seam.

        Runs late, after every pass that resizes or moves a side panel
        (back extension, finished extend-back, the overstool profile),
        so the piece above the seam can simply inherit the side's final
        depth and Y and take the length left over. The base role keeps
        the piece BELOW the joint -- it owns the origin, the kick notch,
        and every lookup that means "the side" -- and the seam role
        carries the piece above it, one board length higher.

        The back rabbet is re-driven on both pieces: it spans whatever
        length its part ends up with, so the piece below has to be told
        it is shorter now and the piece above needs its own.
        """
        if not self._has_carcass():
            return
        cab = self.obj.face_frame_cabinet
        for side, base_role in (('LEFT', PART_ROLE_LEFT_SIDE),
                                ('RIGHT', PART_ROLE_RIGHT_SIDE)):
            seam_role = SIDE_SEAM_ROLE_FOR[base_role]
            base_obj = self._side_part_by_role(base_role)
            seam_obj = self._side_part_by_role(seam_role)
            if seam_obj is None:
                # Built before seams existed. Only pay for the part when
                # a seam is actually wanted, so an untouched old cabinet
                # recalcs exactly as it did.
                if self._side_seam_height(cab, side) <= 0.0:
                    continue
                seam_obj = self._ensure_side_seam_part(seam_role)
            bay_index = 0 if side == 'LEFT' else layout.bay_count - 1

            blocked = self._side_seam_blocked(cab, layout, side)
            base_part = GeoNodeCutpart(base_obj) if base_obj is not None else None
            full = None
            if base_part is not None:
                # The part loop has already written the square length for
                # this recalc, so this is the whole board every time --
                # the split never compounds.
                full = base_part.get_input('Length')
            cut = self._side_seam_height(cab, side) - solver.side_bottom_z(
                layout, bay_index, side)

            active = (blocked is None
                      and base_obj is not None
                      and not base_obj.hide_viewport
                      and full is not None
                      and MIN_SEAM_PIECE <= cut <= full - MIN_SEAM_PIECE)
            if not active:
                seam_obj.hide_viewport = True
                seam_obj.hide_render = True
                continue

            base_part.set_input('Length', cut)
            self._update_side_back_notch(base_obj, layout, bay_index)

            seam_part = GeoNodeCutpart(seam_obj)
            seam_part.set_input('Length', full - cut)
            seam_part.set_input('Width', base_part.get_input('Width'))
            seam_part.set_input('Thickness', base_part.get_input('Thickness'))
            seam_obj.location = (base_obj.location.x,
                                 base_obj.location.y,
                                 base_obj.location.z + cut)
            seam_obj.rotation_euler = base_obj.rotation_euler.copy()
            seam_obj.hide_viewport = False
            seam_obj.hide_render = False
            self._update_side_back_notch(seam_obj, layout, bay_index)

    # =====================================================================
    # Over-stool side-front profile cut (decorative leg foot)
    # =====================================================================
    def _side_part_by_role(self, role):
        """The carcass side panel (LEFT_SIDE / RIGHT_SIDE) - a direct child
        of the cabinet root. None if absent (panels / suppressed bays)."""
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                return child
        return None

    def _ensure_side_profile_cutter(self, side):
        """Find or lazily create the per-side profile cutter MESH (one per
        side, distinguished by hb_profile_side). Hidden; the boolean reads
        its mesh regardless. Mirrors _ensure_back_ext_cutter."""
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_SIDE_PROFILE_CUTTER
                    and child.get('hb_profile_side') == side):
                return child
        name = 'Side Profile Cutter ' + side.title()
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = PART_ROLE_SIDE_PROFILE_CUTTER
        cutter['hb_profile_side'] = side
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_side_profile_cutter(self, cutter, side, layout):
        """Rebuild the cutter mesh as a prism: the profile silhouette placed
        with its LOCAL ORIGIN at the side's bottom-front corner (profile X ->
        cabinet depth/Y, profile Y -> vertical/Z), extruded through the full
        panel thickness in X. Built in CABINET-LOCAL coords (cutter at
        identity), the same frame the side position is expressed in.

        Orientation knobs (eyeball / flip if the cut faces the wrong way):
          DEPTH_SIGN  profile +X -> +Y (toward the back) when +1.
          UP_SIGN     profile +Y -> +Z (upward) when +1.
        """
        poly = _overstool_profile_poly()
        if not poly:
            return
        if side == 'RIGHT':
            pos = solver.right_side_position(layout)
            dims = solver.right_side_dims(layout)
        else:
            pos = solver.left_side_position(layout)
            dims = solver.left_side_dims(layout)
        depth, thickness = dims[1], dims[2]
        corner_y = pos[1] - depth          # front edge (front = -Y)
        corner_z = pos[2]                  # dropped side bottom
        margin = inch(2.0)
        x0 = pos[0] - thickness - margin   # span the full panel thickness
        x1 = pos[0] + thickness + margin   # (both directions; panel is thin)
        DEPTH_SIGN, UP_SIGN = 1.0, 1.0
        bm = bmesh.new()
        loop0, loop1 = [], []
        for (px, py) in poly:
            y = corner_y + DEPTH_SIGN * px
            z = corner_z + UP_SIGN * py
            loop0.append(bm.verts.new((x0, y, z)))
            loop1.append(bm.verts.new((x1, y, z)))
        bm.faces.new(loop0)
        bm.faces.new(list(reversed(loop1)))
        n = len(poly)
        for i in range(n):
            j = (i + 1) % n
            bm.faces.new((loop0[i], loop0[j], loop1[j], loop1[i]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter.data)
        bm.free()
        cutter.location = (0.0, 0.0, 0.0)
        cutter.rotation_euler = (0.0, 0.0, 0.0)

    def _cleanup_side_profile_cutters(self):
        """Reverse of _apply_overstool_profile. No-op when nothing to undo."""
        for role in (PART_ROLE_LEFT_SIDE, PART_ROLE_RIGHT_SIDE):
            part = self._side_part_by_role(role)
            if part is None:
                continue
            mod = part.modifiers.get(SIDE_PROFILE_CUT_MOD_NAME)
            if mod is not None:
                part.modifiers.remove(mod)
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_SIDE_PROFILE_CUTTER:
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    def _apply_overstool_profile(self, layout):
        """Cut the over-stool decorative profile into the bottom-front corner
        of each extended side panel. Gated on an UPPER with side_front_profile
        on AND the sides actually dropped (extend_sides_down > 0). A no-op +
        full cleanup otherwise, so toggling off restores the square legs."""
        on = (layout.cabinet_type == 'UPPER'
              and getattr(layout, 'side_front_profile', False)
              and getattr(layout, 'extend_sides_down', False)
              and getattr(layout, 'extend_sides_down_amount', 0.0) > 0.0)
        if not on:
            self._cleanup_side_profile_cutters()
            return
        for side, role in (('LEFT', PART_ROLE_LEFT_SIDE),
                           ('RIGHT', PART_ROLE_RIGHT_SIDE)):
            part = self._side_part_by_role(role)
            if part is None:
                continue
            cutter = self._ensure_side_profile_cutter(side)
            self._position_side_profile_cutter(cutter, side, layout)
            mod = part.modifiers.get(SIDE_PROFILE_CUT_MOD_NAME)
            if mod is None:
                mod = part.modifiers.new(
                    name=SIDE_PROFILE_CUT_MOD_NAME, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            if mod.object is not cutter:
                mod.object = cutter

    # =====================================================================
    # Bottom-rail decorative profile cut (valance)
    # =====================================================================
    def _bottom_rail_parts(self):
        return [c for c in self.obj.children_recursive
                if c.get('hb_part_role') == PART_ROLE_BOTTOM_RAIL]

    def _ensure_bottom_rail_profile_cutter(self, seg_key):
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_BOTTOM_RAIL_PROFILE_CUTTER
                    and child.get('hb_profile_seg') == seg_key):
                return child
        name = 'Bottom Rail Profile Cutter ' + str(seg_key)
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = PART_ROLE_BOTTOM_RAIL_PROFILE_CUTTER
        cutter['hb_profile_seg'] = seg_key
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_bottom_rail_profile_cutter(self, cutter, rail, profile_id, poly):
        """Rebuild the cutter prism aligned to the rail: profile X -> rail
        Length, profile Y -> up from the rail's bottom edge (rail local Y=0),
        extruded through the rail Thickness. Built in cabinet-local coords via
        the rail's matrix_local (rails are direct children of the root). ARCH
        generates a smooth circular arc; every other profile 3-slices its
        authored curve. Returns False (and clears the mesh) when too short."""
        part = GeoNodeCutpart(rail)
        try:
            length = part.get_input('Length')
            thickness = part.get_input('Thickness')
        except Exception:
            return False
        # Inset the cut from each rail end by a flat margin: it spans
        # [margin, length - margin], leaving uncut rail at each end.
        margin = BOTTOM_RAIL_PROFILE_END_MARGIN
        inner_len = length - 2.0 * margin
        if profile_id == _BOTTOM_RAIL_PROFILE_ARCH:
            rpoly = _bottom_rail_arch_poly(inner_len)
        elif profile_id == _BOTTOM_RAIL_PROFILE_TRADITIONAL:
            rpoly = _bottom_rail_traditional_poly(inner_len)
        else:
            rpoly = _bottom_rail_profile_stretched(poly, inner_len)
        if not rpoly:
            cutter.data.clear_geometry()
            return False
        rpoly = [(px + margin, py) for (px, py) in rpoly]
        # Extrude symmetrically past BOTH faces so the cut passes fully through
        # the rail regardless of which way its local thickness axis points (the
        # rail mesh runs 0..-Thickness in local Z, not 0..+Thickness).
        eps = inch(0.1)
        zt = thickness + eps
        ml = rail.matrix_local
        bm = bmesh.new()
        loop0, loop1 = [], []
        for (px, py) in rpoly:
            loop0.append(bm.verts.new(ml @ Vector((px, py, -zt))))
            loop1.append(bm.verts.new(ml @ Vector((px, py, zt))))
        bm.faces.new(loop0)
        bm.faces.new(list(reversed(loop1)))
        n = len(rpoly)
        for i in range(n):
            j = (i + 1) % n
            bm.faces.new((loop0[i], loop0[j], loop1[j], loop1[i]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter.data)
        bm.free()
        cutter.location = (0.0, 0.0, 0.0)
        cutter.rotation_euler = (0.0, 0.0, 0.0)
        return True

    def _cleanup_bottom_rail_profile_cutters(self):
        """Reverse of _apply_bottom_rail_profile. No-op when nothing to undo."""
        for rail in self._bottom_rail_parts():
            mod = rail.modifiers.get(BOTTOM_RAIL_PROFILE_CUT_MOD_NAME)
            if mod is not None:
                rail.modifiers.remove(mod)
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_BOTTOM_RAIL_PROFILE_CUTTER:
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    def _segment_bottom_rail_profile(self, cab_default, seg_key):
        """Profile id for one bottom-rail segment: the segment's start
        bay's override when set (bay props bottom_rail_profile, CABINET
        = inherit), else the cabinet-level default. Lets split rails cut
        independently -- one arched valance bay between plain ones."""
        if isinstance(seg_key, int):
            for node in self.obj.children:
                if (node.get(TAG_BAY_CAGE)
                        and node.get('hb_bay_index') == seg_key):
                    ov = getattr(node.face_frame_bay,
                                 'bottom_rail_profile', 'CABINET')
                    if ov and ov != 'CABINET':
                        return ov
                    break
        return cab_default

    def _apply_bottom_rail_profile(self, layout):
        """Cut the chosen decorative profile into the bottom rail(s). Gated on
        BASE / UPPER; a no-op + full cleanup otherwise. One cutter per
        bottom-rail segment; each segment resolves its own profile (per-bay
        override, else the cabinet-level pick); the profile's end details
        stay fixed while its flat middle stretches to each rail's length."""
        cab_props = self.obj.face_frame_cabinet
        cab_default = getattr(cab_props, 'bottom_rail_profile', 'NONE')
        if layout.cabinet_type not in ('BASE', 'UPPER'):
            self._cleanup_bottom_rail_profile_cutters()
            return
        poly_cache = {}
        live_keys = set()
        for rail in self._bottom_rail_parts():
            seg_key = rail.get('hb_segment_start_bay')
            if seg_key is None:
                seg_key = rail.name
            profile_id = self._segment_bottom_rail_profile(cab_default, seg_key)
            mod = rail.modifiers.get(BOTTOM_RAIL_PROFILE_CUT_MOD_NAME)
            is_arch = profile_id in _BOTTOM_RAIL_PROCEDURAL_PROFILES
            if profile_id not in ('NONE', '') and not is_arch:
                if profile_id not in poly_cache:
                    poly_cache[profile_id] = _bottom_rail_profile_poly(profile_id)
                poly = poly_cache[profile_id]
            else:
                poly = None
            if profile_id in ('NONE', '') or (not is_arch and not poly):
                # This segment stays plain; its cutter (if any) is
                # dropped by the stale-key sweep below.
                if mod is not None:
                    rail.modifiers.remove(mod)
                continue
            live_keys.add(seg_key)
            cutter = self._ensure_bottom_rail_profile_cutter(seg_key)
            ok = self._position_bottom_rail_profile_cutter(cutter, rail, profile_id, poly)
            if not ok:
                if mod is not None:
                    rail.modifiers.remove(mod)
                continue
            if mod is None:
                mod = rail.modifiers.new(
                    name=BOTTOM_RAIL_PROFILE_CUT_MOD_NAME, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            # Cut faces read the cutter's material (the material walk
            # keeps the cutter on the finish), not a target index.
            mod.material_mode = 'TRANSFER'
            if mod.object is not cutter:
                mod.object = cutter
        # Drop cutters whose rail segment no longer exists.
        for child in list(self.obj.children):
            if (child.get('hb_part_role') == PART_ROLE_BOTTOM_RAIL_PROFILE_CUTTER
                    and child.get('hb_profile_seg') not in live_keys):
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    # =====================================================================
    # Corner treatment (face-frame arris detail)
    # =====================================================================
    def _corner_treatment_run(self):
        """Shaped run [(u, v), ...] for the assigned cabinet style's corner
        treatment, or None (no style / Square / unknown name)."""
        style_name = self.obj.get('STYLE_NAME')
        if not style_name:
            return None
        try:
            from .props_hb_face_frame import get_style_props
            ff = get_style_props()
            cs = next((c for c in ff.cabinet_styles if c.name == style_name), None)
            if cs is None:
                return None
            from ..common import door_profiles
            return door_profiles.named_edge_run(cs.corner_treatment_name())
        except Exception:
            return None

    def _corner_treatment_cutters(self):
        return [c for c in self.obj.children
                if c.get('hb_part_role') == PART_ROLE_CORNER_TREATMENT_CUTTER]

    def _ensure_corner_treatment_cutter(self, key):
        for child in self._corner_treatment_cutters():
            if child.get('hb_ct_key') == key:
                return child
        name = 'Corner Treatment Cutter ' + key
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = PART_ROLE_CORNER_TREATMENT_CUTTER
        cutter['hb_ct_key'] = key
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_corner_treatment_cutter(self, cutter, part_obj, run, axis,
                                          far_trim=0.0):
        """Rebuild the cutter as a prism of the removed-corner outline swept
        along one arris of a cutpart. Cutpart mesh-local convention: x is
        the Length axis, the front-outer arris lies on (y = 0, z = 0), the
        Width runs in +/-y per 'Mirror Y' and the Thickness in +/-z per
        'Mirror Z'. axis 'LENGTH' sweeps that arris end to end (stile
        outer edge / rail bottom edge); 'WIDTH' sweeps across the x = 0
        end (a stile's bottom) so the bottom detail wraps the corner.
        ``far_trim`` pulls the sweep back from the far (x = Length) end:
        an end stile's milled arris dies into the top rail instead of
        running out at the top of the frame.
        Built in cabinet-local coords via matrix_to_root. Returns False
        (mesh cleared) when the part can't be read."""
        part = GeoNodeCutpart(part_obj)
        try:
            length = part.get_input('Length')
            width = part.get_input('Width')
            mirror_y = bool(part.get_input('Mirror Y'))
            mirror_z = bool(part.get_input('Mirror Z'))
        except Exception:
            cutter.data.clear_geometry()
            return False
        umax = max(u for u, v in run)
        vmax = max(v for u, v in run)
        if umax <= 0.0 or vmax <= 0.0 or length <= 0.0 or width <= 0.0:
            cutter.data.clear_geometry()
            return False
        ys = -1.0 if mirror_y else 1.0
        zs = -1.0 if mirror_z else 1.0
        eps = inch(0.05)
        # Removed corner in (u across the face from the arris, v into the
        # thickness from the front face), padded outside the part so the
        # boolean never sits on a coplanar face.
        outline = [(-eps, -eps), (umax, -eps)] + list(run) + [(-eps, vmax)]
        if axis == 'LENGTH':
            # A trimmed run stops ON the trim plane (no eps overshoot):
            # that face is where the milled detail ends, not a boolean
            # face that needs clearing off the part.
            far = length - far_trim if far_trim > 0.0 else length + eps
            if far <= 0.0:
                cutter.data.clear_geometry()
                return False
            span = (-eps, far)

            def pt(u, v, s):
                return Vector((s, ys * u, zs * v))
        else:
            span = (-eps, width + eps)

            def pt(u, v, s):
                return Vector((u, ys * s, zs * v))
        ml = matrix_to_root(part_obj, self.obj)
        bm = bmesh.new()
        loop0 = [bm.verts.new(ml @ pt(u, v, span[0])) for (u, v) in outline]
        loop1 = [bm.verts.new(ml @ pt(u, v, span[1])) for (u, v) in outline]
        bm.faces.new(loop0)
        bm.faces.new(list(reversed(loop1)))
        n = len(outline)
        for i in range(n):
            j = (i + 1) % n
            bm.faces.new((loop0[i], loop0[j], loop1[j], loop1[i]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter.data)
        bm.free()
        cutter.location = (0.0, 0.0, 0.0)
        cutter.rotation_euler = (0.0, 0.0, 0.0)
        return True

    def _cleanup_corner_treatment(self, keep_keys=()):
        """Drop corner-treatment booleans + cutters not in keep_keys."""
        keep = set(keep_keys)
        for child in self.obj.children:
            for axis, mod_name in CORNER_TREATMENT_MOD_NAMES.items():
                if f"{child.name}|{axis}" in keep:
                    continue
                mod = child.modifiers.get(mod_name)
                if mod is not None:
                    child.modifiers.remove(mod)
        for cutter in list(self._corner_treatment_cutters()):
            if cutter.get('hb_ct_key') in keep:
                continue
            mesh = cutter.data
            bpy.data.objects.remove(cutter, do_unlink=True)
            if mesh is not None and mesh.users == 0:
                bpy.data.meshes.remove(mesh)

    @staticmethod
    def _corner_treatment_top_trim(layout, role):
        """How far short of the top of an end stile the milled arris
        stops: the treatment dies into the top rail rather than running
        out at the top of the frame, so the rail's band of the stile
        stays square. A dropped front (sink / cooktop bay) carries the
        rail down with it, and the stile above it stays square too.
        0 for the refrigerator stiles-in-lieu-of-leg (they meet the
        raised end stile, not a rail) and for a bay with no top rail.
        """
        if role == PART_ROLE_LEFT_STILE:
            bay_index = 0
        elif role == PART_ROLE_RIGHT_STILE:
            bay_index = layout.bay_count - 1
        else:
            return 0.0
        if not (0 <= bay_index < len(layout.bays)):
            return 0.0
        rail = layout.bays[bay_index].get('top_rail_width', 0.0) or 0.0
        if rail <= 0.0:
            return 0.0
        return rail + solver.front_drop(layout, bay_index)

    def _apply_corner_treatment(self, layout):
        """Cut the style's corner treatment into the exposed face frame
        arrises: the end stile's outer front edge (plus the refrigerator
        stile-in-lieu-of-leg below it) on each flush finished end, and on
        uppers the bottom front edge -- bottom rail(s) along their length
        and the end stiles across their bottoms. Square / no style / no
        flush ends = full cleanup."""
        run = self._corner_treatment_run()
        wanted = []   # (part_obj, axis, far_trim)
        if run is not None:
            sides = set()
            if layout.l_fin_end in CORNER_TREATMENT_FLUSH_ENDS:
                sides.add('LEFT')
            if layout.r_fin_end in CORNER_TREATMENT_FLUSH_ENDS:
                sides.add('RIGHT')
            bottom = layout.cabinet_type == 'UPPER'
            for child in self.obj.children:
                if child.hide_viewport:
                    continue
                role = child.get('hb_part_role')
                if role in (PART_ROLE_LEFT_STILE, PART_ROLE_LEFT_REFRIG_STILE):
                    side = 'LEFT'
                elif role in (PART_ROLE_RIGHT_STILE, PART_ROLE_RIGHT_REFRIG_STILE):
                    side = 'RIGHT'
                elif role == PART_ROLE_BOTTOM_RAIL:
                    side = None
                else:
                    continue
                if side is not None and side in sides:
                    wanted.append((child, 'LENGTH',
                                   self._corner_treatment_top_trim(layout, role)))
                if bottom:
                    if role == PART_ROLE_BOTTOM_RAIL:
                        wanted.append((child, 'LENGTH', 0.0))
                    elif role in (PART_ROLE_LEFT_STILE, PART_ROLE_RIGHT_STILE):
                        wanted.append((child, 'WIDTH', 0.0))
        live_keys = set()
        for part_obj, axis, far_trim in wanted:
            key = f"{part_obj.name}|{axis}"
            cutter = self._ensure_corner_treatment_cutter(key)
            if not self._position_corner_treatment_cutter(
                    cutter, part_obj, run, axis, far_trim):
                continue
            live_keys.add(key)
            mod_name = CORNER_TREATMENT_MOD_NAMES[axis]
            mod = part_obj.modifiers.get(mod_name)
            if mod is None:
                mod = part_obj.modifiers.new(name=mod_name, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            # Cut faces read the cutter's material (the material walk
            # keeps the cutter on the finish).
            mod.material_mode = 'TRANSFER'
            if mod.object is not cutter:
                mod.object = cutter
        self._cleanup_corner_treatment(live_keys)

    # =====================================================================
    # Inset frame profile (Beaded / Metro / Chamfer around every opening)
    # =====================================================================
    def _frame_profile_run(self):
        """Shaped run for the assigned style's inset frame profile, or
        None (no style / square-edged overlay)."""
        style_name = self.obj.get('STYLE_NAME')
        if not style_name:
            return None
        try:
            from .props_hb_face_frame import get_style_props
            ff = get_style_props()
            cs = next((c for c in ff.cabinet_styles if c.name == style_name), None)
            if cs is None:
                return None
            from ..common import door_profiles
            return door_profiles.inset_frame_run(cs.frame_profile_kind())
        except Exception:
            return None

    def _frame_profile_cutters(self):
        return [c for c in self.obj.children
                if c.get('hb_part_role') == PART_ROLE_FRAME_PROFILE_CUTTER]

    def _ensure_frame_profile_cutter(self, key):
        for child in self._frame_profile_cutters():
            if child.get('hb_fp_key') == key:
                return child
        name = 'Frame Profile Cutter ' + key
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = PART_ROLE_FRAME_PROFILE_CUTTER
        cutter['hb_fp_key'] = key
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    @staticmethod
    def _frame_profile_outline(run):
        """Removed-material outline around one opening arris: the run plus
        a padding corner just inside the opening / in front of the face
        so the boolean never sits on a coplanar face."""
        eps = inch(0.05)
        umax = max(u for u, v in run)
        vmax = max(v for u, v in run)
        return [(-eps, -eps), (umax, -eps)] + list(run) + [(-eps, vmax)], umax, vmax, eps

    def _position_frame_profile_cutter(self, cutter, bay_obj, rect, run, fft):
        """Rebuild the cutter as the outline swept around one face-frame
        opening rectangle with mitred corners, in cabinet-local coords.
        ``rect`` = (x0, z0, w, h) in BAY-local coords (the bay cage sits
        on the face frame's BACK plane at local y = 0, so the front face
        is y = -fft; angled bays carry their rotation in the cage
        transform). Returns the cutter's cabinet-local bounds (min, max)
        or None."""
        x0, z0, w, h = rect
        if w <= 0.0 or h <= 0.0:
            cutter.data.clear_geometry()
            return None
        outline, umax, vmax, eps = self._frame_profile_outline(run)
        if umax <= 0.0 or vmax <= 0.0:
            cutter.data.clear_geometry()
            return None
        m = matrix_to_root(bay_obj, self.obj)
        corners = [(x0, z0), (x0 + w, z0), (x0 + w, z0 + h), (x0, z0 + h)]
        dirs = [(-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0)]
        bm = bmesh.new()
        rings = []
        lo = [float('inf')] * 3
        hi = [float('-inf')] * 3
        for (cx, cz), (dx, dz) in zip(corners, dirs):
            ring = []
            for (u, v) in outline:
                p = m @ Vector((cx + dx * u, -fft + v, cz + dz * u))
                for i in range(3):
                    lo[i] = min(lo[i], p[i])
                    hi[i] = max(hi[i], p[i])
                ring.append(bm.verts.new(p))
            rings.append(ring)
        n = len(outline)
        for c in range(4):
            a = rings[c]
            b = rings[(c + 1) % 4]
            for k in range(n):
                j = (k + 1) % n
                bm.faces.new((a[k], a[j], b[j], b[k]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter.data)
        bm.free()
        cutter.location = (0.0, 0.0, 0.0)
        cutter.rotation_euler = (0.0, 0.0, 0.0)
        return (Vector(lo), Vector(hi))

    def _part_root_bounds(self, part_obj):
        """Cabinet-local AABB of a cutpart from its fresh transform and
        Length / Width / Thickness (mesh-local box x [0, L], y signed by
        Mirror Y, z signed by Mirror Z), or None."""
        part = GeoNodeCutpart(part_obj)
        try:
            length = part.get_input('Length')
            width = part.get_input('Width')
            thickness = part.get_input('Thickness')
            ys = -1.0 if part.get_input('Mirror Y') else 1.0
            zs = -1.0 if part.get_input('Mirror Z') else 1.0
        except Exception:
            return None
        m = matrix_to_root(part_obj, self.obj)
        lo = [float('inf')] * 3
        hi = [float('-inf')] * 3
        for x in (0.0, length):
            for y in (0.0, ys * width):
                for z in (0.0, zs * thickness):
                    p = m @ Vector((x, y, z))
                    for i in range(3):
                        lo[i] = min(lo[i], p[i])
                        hi[i] = max(hi[i], p[i])
        return (Vector(lo), Vector(hi))

    def _cleanup_frame_profile(self, keep_pairs=(), keep_keys=()):
        """Drop frame-profile booleans not in keep_pairs {(part name,
        opening key)} and cutters not in keep_keys."""
        keep_pairs = set(keep_pairs)
        keep_keys = set(keep_keys)
        for child in self.obj.children_recursive:
            for mod in list(child.modifiers):
                if not mod.name.startswith(FRAME_PROFILE_MOD_PREFIX):
                    continue
                key = mod.name[len(FRAME_PROFILE_MOD_PREFIX):]
                if (child.name, key) in keep_pairs:
                    continue
                child.modifiers.remove(mod)
        for cutter in list(self._frame_profile_cutters()):
            if cutter.get('hb_fp_key') in keep_keys:
                continue
            mesh = cutter.data
            bpy.data.objects.remove(cutter, do_unlink=True)
            if mesh is not None and mesh.users == 0:
                bpy.data.meshes.remove(mesh)

    def _apply_frame_profile(self, layout):
        """Mill the overlay's frame profile around every opening: one
        mitred ring cutter per opening leaf (its cage rect minus the
        reveals = the face frame opening), booleaned off each visible
        face-frame member whose box overlaps the ring. Square overlays /
        no style = full cleanup."""
        run = self._frame_profile_run()
        if run is None:
            self._cleanup_frame_profile()
            return
        fft = layout.fft
        members = []
        for child in self.obj.children_recursive:
            if child.hide_viewport:
                continue
            if child.get('hb_part_role') not in FRAME_PROFILE_PART_ROLES:
                continue
            bounds = self._part_root_bounds(child)
            if bounds is not None:
                members.append((child, bounds))
        tol = 1e-4
        live_pairs = set()
        live_keys = set()
        bay_objs = {}
        for node in self.obj.children:
            if node.get(TAG_BAY_CAGE):
                bay_objs[node.get('hb_bay_index')] = node
        for bi in range(layout.bay_count):
            bay_obj = bay_objs.get(bi)
            if bay_obj is None:
                continue
            for leaf in solver.bay_openings(layout, bi)['leaves']:
                op_obj = bpy.data.objects.get(leaf.get('obj_name') or '')
                if op_obj is None or op_obj.hide_viewport:
                    continue
                # Leaf cage rect minus its reveals = the face frame opening.
                rl = leaf['reveal_left']
                rr = leaf['reveal_right']
                rt = leaf['reveal_top']
                rb = leaf['reveal_bottom']
                rect = (leaf['cage_x'] + rl, leaf['cage_z'] + rb,
                        leaf['cage_dim_x'] - rl - rr,
                        leaf['cage_dim_z'] - rt - rb)
                key = op_obj.name
                cutter = self._ensure_frame_profile_cutter(key)
                bounds = self._position_frame_profile_cutter(
                    cutter, bay_obj, rect, run, fft)
                if bounds is None:
                    continue
                clo, chi = bounds
                hit = False
                for part_obj, (plo, phi) in members:
                    if any(plo[i] >= chi[i] - tol or phi[i] <= clo[i] + tol
                           for i in range(3)):
                        continue
                    hit = True
                    mod_name = FRAME_PROFILE_MOD_PREFIX + key
                    mod = part_obj.modifiers.get(mod_name)
                    if mod is None:
                        mod = part_obj.modifiers.new(name=mod_name, type='BOOLEAN')
                        mod.operation = 'DIFFERENCE'
                        mod.solver = 'EXACT'
                    mod.material_mode = 'TRANSFER'
                    if mod.object is not cutter:
                        mod.object = cutter
                    live_pairs.add((part_obj.name, key))
                if hit:
                    live_keys.add(key)
        self._cleanup_frame_profile(live_pairs, live_keys)

    # =====================================================================
    # Over-stool leg accessories (shelf / towel bar between the legs)
    # =====================================================================
    def _overstool_interior(self, layout):
        """(left_inner_x, right_inner_x, front_y, leg_bottom_z) for the gap
        between the two extended legs - shared by the shelf and towel bar.
        left/right inner = side outer x +/- its thickness; front = leg front
        edge (y = -depth); leg_bottom = the dropped side bottom z."""
        lp = solver.left_side_position(layout); ld = solver.left_side_dims(layout)
        rp = solver.right_side_position(layout); rd = solver.right_side_dims(layout)
        left_inner = lp[0] + ld[2]
        right_inner = rp[0] - rd[2]
        front_y = lp[1] - ld[1]
        return left_inner, right_inner, front_y, lp[2]

    def _ensure_overstool_shelf(self):
        """Find or lazily create the leg shelf CabinetPart - a flat slab
        tagged PART_ROLE_OVERSTOOL_SHELF + CABINET_PART so the material walk
        gives it the exterior finish. Reused across recalcs."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_OVERSTOOL_SHELF:
                return child
        shelf = CabinetPart()
        shelf.create('Leg Shelf')
        shelf.obj.parent = self.obj
        shelf.obj['hb_part_role'] = PART_ROLE_OVERSTOOL_SHELF
        shelf.obj['CABINET_PART'] = True
        # Length -> +X (between legs), Width -> -Y (Mirror Y) so the shelf
        # runs from the back (y=0) forward, Thickness -> +Z (up).
        shelf.set_input('Mirror Y', True)
        shelf.set_input('Mirror Z', False)
        return shelf.obj

    def _position_overstool_shelf(self, shelf_obj, layout):
        """Span the shelf between the leg inner faces, seated against the
        full-height back (Mirror Y runs its 6" depth forward), hung so the
        clear opening from the box bottom down to the shelf top is exactly
        OVERSTOOL_CLEAR_OPENING (6"). Clamped to the leg bottom if the
        drop is too small to fit opening + shelf."""
        left_inner, right_inner, _front_y, leg_bottom = self._overstool_interior(layout)
        part = GeoNodeCutpart(shelf_obj)
        # Shelf depth follows the cabinet depth: from the full-height back
        # forward to a fixed setback behind the leg fronts.
        shelf_depth = max(layout.dim_y - solver.back_thickness(layout)
                          - OVERSTOOL_SHELF_FRONT_SETBACK,
                          OVERSTOOL_SHELF_MIN_DEPTH)
        part.set_input('Length', right_inner - left_inner)
        part.set_input('Width', shelf_depth)
        part.set_input('Thickness', OVERSTOOL_SHELF_THICKNESS)
        drop = solver.side_extend_down(layout)
        z = max(leg_bottom + drop - OVERSTOOL_CLEAR_OPENING
                - OVERSTOOL_SHELF_THICKNESS, leg_bottom)
        back_y = (solver.left_side_position(layout)[1]
                  - solver.back_thickness(layout))
        shelf_obj.location = Vector((left_inner, back_y, z))
        shelf_obj.rotation_euler = (0.0, 0.0, 0.0)

    def _ensure_overstool_towel_bar(self):
        """Find or lazily create the towel-bar MESH object (a round rod).
        Rebuilt each recalc by _position_overstool_towel_bar."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_OVERSTOOL_TOWEL_BAR:
                return child
        mesh = bpy.data.meshes.new('Towel Bar')
        bar = hb_utils.new_object('Towel Bar', mesh)
        bar['hb_part_role'] = PART_ROLE_OVERSTOOL_TOWEL_BAR
        bar['CABINET_PART'] = True
        bar.parent = self.obj
        for coll in self.obj.users_collection:
            coll.objects.link(bar)
            break
        return bar

    def _position_overstool_towel_bar(self, bar_obj, layout):
        """Rebuild the towel bar as a cylinder spanning the leg inner faces,
        axis along X, OVERSTOOL_TOWEL_BAR_Y_FROM_FRONT back from the leg front
        and OVERSTOOL_TOWEL_BAR_Z_ABOVE_LEG_BOTTOM up from the leg bottom."""
        from mathutils import Matrix
        left_inner, right_inner, front_y, leg_bottom = self._overstool_interior(layout)
        length = right_inner - left_inner
        r = OVERSTOOL_TOWEL_BAR_DIAMETER * 0.5
        bm = bmesh.new()
        # create_cone builds along local Z; rotate 90 about Y so the axis is X.
        bmesh.ops.create_cone(
            bm, cap_ends=True, cap_tris=False,
            segments=OVERSTOOL_TOWEL_BAR_SEGMENTS,
            radius1=r, radius2=r, depth=length,
            matrix=Matrix.Rotation(math.radians(90.0), 4, 'Y'))
        bm.to_mesh(bar_obj.data)
        bm.free()
        # The towel bar always sits low + back (the same spot it takes in the
        # combo layout), whether or not a shelf is also present.
        z_above = OVERSTOOL_TOWEL_BAR_Z_ABOVE_LEG_BOTTOM - OVERSTOOL_TOWEL_BAR_COMBO_Z_DROP
        y_back = OVERSTOOL_TOWEL_BAR_Y_FROM_FRONT + OVERSTOOL_TOWEL_BAR_COMBO_Y_BACK
        bar_obj.location = Vector(((left_inner + right_inner) * 0.5,
                                   front_y + y_back,
                                   leg_bottom + z_above))
        bar_obj.rotation_euler = (0.0, 0.0, 0.0)

    def _cleanup_overstool_part(self, role):
        """Remove the shelf or towel bar (accessory not wanted / no legs)."""
        for child in list(self.obj.children):
            if child.get('hb_part_role') == role:
                mesh = child.data if child.type == 'MESH' else None
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    def _apply_overstool_accessories(self, layout):
        """Build / remove the leg shelf and towel bar per overstool_accessory.
        Only when the cabinet is an upper with the sides actually extended
        (the accessories hang between the legs). Idempotent + self-cleaning so
        switching the dropdown adds / removes the right parts."""
        legs = (layout.cabinet_type == 'UPPER'
                and getattr(layout, 'extend_sides_down', False)
                and getattr(layout, 'extend_sides_down_amount', 0.0) > 0.0
                and self._has_carcass())
        acc = getattr(layout, 'overstool_accessory', 'SHELF') if legs else None
        if legs and acc in ('SHELF', 'SHELF_AND_TOWEL_BAR'):
            self._position_overstool_shelf(self._ensure_overstool_shelf(), layout)
        else:
            self._cleanup_overstool_part(PART_ROLE_OVERSTOOL_SHELF)
        if legs and acc in ('TOWEL_BAR', 'SHELF_AND_TOWEL_BAR'):
            self._position_overstool_towel_bar(self._ensure_overstool_towel_bar(), layout)
        else:
            self._cleanup_overstool_part(PART_ROLE_OVERSTOOL_TOWEL_BAR)

    def _ensure_wedge_cutter(self):
        """Find or lazily create the wedge cutter MESH object. Hidden in
        the viewport; a boolean still reads its mesh regardless."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_WEDGE_CUTTER:
                return child
        mesh = bpy.data.meshes.new('Wedge Cutter')
        cutter = hb_utils.new_object('Wedge Cutter', mesh)
        cutter['hb_part_role'] = PART_ROLE_WEDGE_CUTTER
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_wedge_cutter(self, cutter_obj, length, height):
        """Rebuild the cutter's triangular-prism mesh from the live wedge
        dims. Cross-section in the Y-Z plane (cabinet back at y=0, front
        at y=-dim_y, floor z=0):
          P1 = (-length, 0)       forward point where the cut meets the bottom
          P2 = (0, height)        upper point where the cut meets the back
          P3 = (+margin, -margin) back-bottom corner pushed past the faces
        Extruded along X from -margin to dim_x + margin so it spans both
        side panels. Differencing the prism chamfers the back-bottom corner.
        """
        margin = inch(0.5)
        dim_x = self.obj.face_frame_cabinet.width
        p1 = (-length, 0.0)
        p2 = (0.0, height)
        p3 = (margin, -margin)
        x_min, x_max = -margin, dim_x + margin
        bm = bmesh.new()
        v1L = bm.verts.new((x_min, p1[0], p1[1]))
        v2L = bm.verts.new((x_min, p2[0], p2[1]))
        v3L = bm.verts.new((x_min, p3[0], p3[1]))
        v1R = bm.verts.new((x_max, p1[0], p1[1]))
        v2R = bm.verts.new((x_max, p2[0], p2[1]))
        v3R = bm.verts.new((x_max, p3[0], p3[1]))
        bm.verts.ensure_lookup_table()
        bm.faces.new((v1L, v2L, v3L))
        bm.faces.new((v1R, v3R, v2R))
        bm.faces.new((v1L, v1R, v2R, v2L))
        bm.faces.new((v2L, v2R, v3R, v3L))
        bm.faces.new((v3L, v3R, v1R, v1L))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter_obj.data)
        bm.free()
        cutter_obj.location = (0.0, 0.0, 0.0)

    def _ensure_wedge_piece(self):
        """Find or lazily create the wedge MESH object - the corner that
        comes off to tip the cabinet up and goes back on afterwards."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_WEDGE:
                return child
        mesh = bpy.data.meshes.new('Wedge')
        piece = hb_utils.new_object('Wedge', mesh)
        piece['hb_part_role'] = PART_ROLE_WEDGE
        # Not a CABINET_PART: it is the offcut of the sides, back and
        # bottom rather than a board of its own, so it takes its finish
        # through the plain-mesh path the way a shelf nosing does and
        # stays out of the cutlist.
        piece['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        piece.parent = self.obj
        for coll in self.obj.users_collection:
            coll.objects.link(piece)
            break
        return piece

    def _position_wedge_piece(self, layout, length, height):
        """Rebuild the wedge piece from the live dims.

        The same triangle the cutter takes out of the body, built to the
        line rather than past it: from the point where the cut meets the
        bottom, up the back to where it leaves it, and back around the
        corner. With the body chamfered underneath it the cabinet reads
        whole and the cut reads as a seam - which is the cabinet as it
        ends up on site, wedge glued back on.

        Only where there is board to cut, though. Run across the whole
        width it filled the open bottom of a bay - an appliance opening
        has no floor and often no back - with a solid ramp that is no
        part of the cabinet.
        """
        piece = self._ensure_wedge_piece()
        # Cross-section in Y-Z: the cut line, then the back-bottom corner.
        section = ((-length, 0.0), (0.0, height), (0.0, 0.0))
        bm = bmesh.new()
        if length > 0.0 and height > 0.0:
            for box in self._wedge_piece_spans(layout, height):
                x0, x1, y0, y1, z0, z1 = box
                clipped = self._clip_section(section, y0, y1, z0, z1)
                if clipped:
                    self._add_section_prism(bm, clipped, x0, x1)
        if bm.faces:
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(piece.data)
        bm.free()
        piece.location = (0.0, 0.0, 0.0)
        return piece

    def _wedge_piece_spans(self, layout, height):
        """Where the cabinet has material in the wedge corner.

        Yields (x0, x1, y0, y1, z0, z1) boxes - the ends taken whole, then
        each back and bay floor across its own span only. The wedge is the
        offcut of those boards, so this is what the cut actually removes.
        """
        dim_x = self.obj.face_frame_cabinet.width
        dim_y = layout.dim_y
        inner_l = solver.carcass_inner_left_x(layout)
        inner_r = solver.carcass_inner_right_x(layout)
        bays = layout.bays or []
        # The two ends: side panel plus any kick return under it, taken as
        # one so the cut reads as a single seam down the end.
        if bays:
            yield (solver.left_scribe_offset(layout), inner_l,
                   -dim_y, -dim_y + bays[0]['depth'], 0.0, height)
            yield (inner_r, dim_x - solver.right_scribe_offset(layout),
                   -dim_y, -dim_y + bays[-1]['depth'], 0.0, height)
        # Backs and bay floors, clipped to the inside of the sides so a
        # notched back does not double up on the end columns.
        for seg in solver.carcass_back_segments(layout):
            x0 = max(seg['x'], inner_l)
            x1 = min(seg['x'] + seg['horizontal_length'], inner_r)
            if x1 > x0:
                yield (x0, x1, seg['y'] - seg['thickness'], seg['y'],
                       seg['z'], seg['z'] + seg['vertical_length'])
        for seg in solver.carcass_bottom_segments(layout):
            x0 = max(seg['x'], inner_l)
            x1 = min(seg['x'] + seg['length'], inner_r)
            if x1 > x0:
                yield (x0, x1, seg['y'] - seg['panel_dim_y'], seg['y'],
                       seg['z'], seg['z'] + seg['thickness'])

    @staticmethod
    def _clip_section(section, y0, y1, z0, z1):
        """Clip a convex Y-Z polygon to an axis-aligned box.

        Sutherland-Hodgman against the four sides. Returns [] when the
        box misses the polygon or leaves only a sliver.
        """
        pts = list(section)
        for axis, bound, keep_above in ((0, y0, True), (0, y1, False),
                                        (1, z0, True), (1, z1, False)):
            if len(pts) < 3:
                return []
            out = []
            count = len(pts)
            for i in range(count):
                cur = pts[i]
                nxt = pts[(i + 1) % count]
                if keep_above:
                    cur_in, nxt_in = cur[axis] >= bound, nxt[axis] >= bound
                else:
                    cur_in, nxt_in = cur[axis] <= bound, nxt[axis] <= bound
                if cur_in:
                    out.append(cur)
                if cur_in != nxt_in:
                    da = cur[axis] - bound
                    db = nxt[axis] - bound
                    if abs(da - db) < 1e-12:
                        continue
                    t = da / (da - db)
                    out.append((cur[0] + (nxt[0] - cur[0]) * t,
                                cur[1] + (nxt[1] - cur[1]) * t))
            pts = out
        if len(pts) < 3:
            return []
        area = 0.0
        for i in range(len(pts)):
            a = pts[i]
            b = pts[(i + 1) % len(pts)]
            area += a[0] * b[1] - b[0] * a[1]
        if abs(area) * 0.5 < 1e-10:
            return []
        return pts

    @staticmethod
    def _add_section_prism(bm, section, x0, x1):
        """Extrude a Y-Z polygon between two X planes into ``bm``."""
        if x1 - x0 < 1e-9:
            return
        left = [bm.verts.new((x0, y, z)) for y, z in section]
        right = [bm.verts.new((x1, y, z)) for y, z in section]
        bm.verts.ensure_lookup_table()
        bm.faces.new(left)
        bm.faces.new(tuple(reversed(right)))
        count = len(section)
        for i in range(count):
            j = (i + 1) % count
            bm.faces.new((left[i], right[i], right[j], left[j]))

    # =====================================================================
    # Accessible sink: knee clearance raked out of the carcass underside
    # =====================================================================
    def _ada_shape(self, layout):
        """The rake, as (wall_run, rake_run, rise, floor_z) in cabinet
        units, or None when this cabinet is not raked.

        A wheelchair comes at the cabinet from the room, so the FRONT is
        the end that is cut away: the box keeps its full height for
        ``wall_run`` forward of the wall, rakes down over the next
        stretch, and is left as a band at the front where the knees go
        under. The rake's run is what is left between the two, so a box
        too shallow for both stretches gets no rake.

        Everything is measured inside the BOX, not off the room floor.
        On a floating kick the box starts at the kick height - that gap
        is what the cabinet hangs above the floor - so the band height
        is taken off the box's own height, and the cut starts at its
        underside.
        """
        cab = self.obj.face_frame_cabinet
        if not getattr(cab, 'ada_side_shape', False):
            return None
        floor_z = solver.bay_bottom_z(layout, 0) if layout.bays else 0.0
        box_height = layout.dim_z - floor_z
        wall_run = cab.ada_side_wall_run
        front_run = cab.ada_side_front_run
        rake_run = layout.dim_y - wall_run - front_run
        rise = box_height - cab.ada_side_front_height
        if rake_run <= 0.0 or rise <= 0.0:
            return None
        return wall_run, rake_run, rise, floor_z

    def _ensure_ada_cutter(self):
        """Find or lazily create the knee-clearance cutter MESH object."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_ADA_CUTTER:
                return child
        mesh = bpy.data.meshes.new('Knee Clearance Cutter')
        cutter = hb_utils.new_object('Knee Clearance Cutter', mesh)
        cutter['hb_part_role'] = PART_ROLE_ADA_CUTTER
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_ada_cutter(self, cutter_obj, layout, shape):
        """Rebuild the cutter from the live shape.

        Cross-section in Y-Z, cabinet back at y=0 and front at
        y=-dim_y: everything below the rake line, from the wall end of
        the rake forward past the front face, and all the way down past
        the cabinet floor.

        Down to the floor rather than just through the box: the cage
        runs the cabinet's whole height, so stopping at the box floor
        left a block of it hanging under the raked front - and on a
        cabinet that keeps a toe kick, the kick under the rake is in the
        knee space too.
        """
        wall_run, rake_run, rise, floor_z = shape
        margin = inch(1.0)
        # The rake runs from the wall end (still at the box floor) down
        # to the front band's underside.
        y_wall = -wall_run
        y_rake_end = y_wall - rake_run
        y_front = -layout.dim_y - margin
        z0 = floor_z
        z_bottom = -margin
        section = ((y_wall, z0), (y_rake_end, z0 + rise),
                   (y_front, z0 + rise), (y_front, z_bottom),
                   (y_wall, z_bottom))
        x_min, x_max = -margin, layout.dim_x + margin
        bm = bmesh.new()
        left = [bm.verts.new((x_min, y, z)) for y, z in section]
        right = [bm.verts.new((x_max, y, z)) for y, z in section]
        bm.verts.ensure_lookup_table()
        bm.faces.new(left)
        bm.faces.new(tuple(reversed(right)))
        n = len(section)
        for i in range(n):
            j = (i + 1) % n
            bm.faces.new((left[i], right[i], right[j], left[j]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(cutter_obj.data)
        bm.free()
        cutter_obj.location = (0.0, 0.0, 0.0)

    def _apply_ada_cuts(self, cutter_obj):
        """Point every carcass part the rake meets at the cutter."""
        for part in self._iter_wedge_cut_targets():
            mod = part.modifiers.get(ADA_CUT_MOD_NAME)
            if mod is None:
                mod = part.modifiers.new(name=ADA_CUT_MOD_NAME,
                                         type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            if mod.object is not cutter_obj:
                mod.object = cutter_obj

    def _cleanup_ada_cutter_and_cuts(self):
        """Reverse of the two above. No-op with nothing to undo."""
        for part in self._iter_wedge_cut_targets():
            mod = part.modifiers.get(ADA_CUT_MOD_NAME)
            if mod is not None:
                part.modifiers.remove(mod)
        for child in list(self.obj.children):
            if child.get('hb_part_role') == PART_ROLE_ADA_CUTTER:
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    def _reconcile_ada_side_shape(self, layout):
        """Rake the carcass underside, or take the rake away again.

        Published on the root so a drawing can call the shape out
        without redoing the trigonometry: the two runs, the rise, and
        the raked edge's own length - the dimension the shop reads off
        the side view.
        """
        shape = self._ada_shape(layout) if self._has_carcass() else None
        if shape is None:
            self._cleanup_ada_cutter_and_cuts()
            for key in ('ADA_WALL_RUN', 'ADA_RAKE_RUN', 'ADA_RISE',
                        'ADA_RAKE_LENGTH'):
                if key in self.obj:
                    del self.obj[key]
            return
        wall_run, rake_run, rise, _floor_z = shape
        cutter = self._ensure_ada_cutter()
        self._position_ada_cutter(cutter, layout, shape)
        self._apply_ada_cuts(cutter)
        one_inch = inch(1.0)
        self.obj['ADA_WALL_RUN'] = round(wall_run / one_inch, 3)
        self.obj['ADA_RAKE_RUN'] = round(rake_run / one_inch, 3)
        self.obj['ADA_RISE'] = round(rise / one_inch, 3)
        self.obj['ADA_RAKE_LENGTH'] = round(
            math.hypot(rake_run, rise) / one_inch, 3)

    def _iter_wedge_cut_targets(self):
        """Root cage + carcass parts whose back-bottom corner the wedge
        chamfers. Mirrors _iter_angled_cut_targets."""
        yield self.obj
        stack = list(self.obj.children)
        while stack:
            obj = stack.pop()
            role = obj.get('hb_part_role')
            # Neither the cutter nor the wedge itself: cutting the wedge
            # with its own cutter would take away the very piece this is
            # meant to leave standing.
            if role in (PART_ROLE_WEDGE_CUTTER, PART_ROLE_WEDGE):
                continue
            if role in WEDGE_CUT_PART_ROLES:
                yield obj
            stack.extend(obj.children)

    def _apply_wedge_cuts(self, cutter_obj):
        """Ensure every target carries a boolean DIFFERENCE modifier named
        WEDGE_CUT_MOD_NAME pointing at the cutter. Idempotent; safe every
        recalc."""
        for part in self._iter_wedge_cut_targets():
            mod = part.modifiers.get(WEDGE_CUT_MOD_NAME)
            if mod is None:
                mod = part.modifiers.new(name=WEDGE_CUT_MOD_NAME, type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            if mod.object is not cutter_obj:
                mod.object = cutter_obj

    def _cleanup_wedge_cutter_and_cuts(self):
        """Reverse of _apply_wedge_cuts + _ensure_wedge_cutter. No-op when
        there's nothing to undo."""
        for part in self._iter_wedge_cut_targets():
            mod = part.modifiers.get(WEDGE_CUT_MOD_NAME)
            if mod is not None:
                part.modifiers.remove(mod)
        for child in list(self.obj.children):
            if child.get('hb_part_role') in (PART_ROLE_WEDGE_CUTTER,
                                             PART_ROLE_WEDGE):
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

    # =====================================================================
    # Pipe chase (back corner / back middle notch + cover panels)
    # =====================================================================
    def _chase_extents(self, cab):
        """(x_lo, x_hi) of the chase cut in cabinet-local X, clamped to
        the cabinet. None when disabled-degenerate (zero size)."""
        w = min(cab.chase_width, cab.width)
        if w <= 0.0 or cab.chase_depth <= 0.0:
            return None
        if cab.chase_location == 'LEFT_BACK':
            return 0.0, w
        if cab.chase_location == 'RIGHT_BACK':
            return cab.width - w, cab.width
        off = max(0.0, min(cab.chase_offset, cab.width - w))
        if getattr(cab, 'chase_offset_from', 'LEFT') == 'RIGHT':
            return cab.width - w - off, cab.width - off
        return off, off + w

    def _chase_z_span(self, cab):
        """(z_lo, z_hi) of the chase cut in cabinet-local Z, clamped to
        the cabinet. chase_height 0 (or a span that covers everything)
        runs the historic full-height chase."""
        h = getattr(cab, 'chase_height', 0.0)
        if h <= 0.0:
            return 0.0, cab.height
        z_lo = max(0.0, min(getattr(cab, 'chase_z_offset', 0.0),
                            cab.height))
        z_hi = min(z_lo + h, cab.height)
        if z_hi <= z_lo:
            return 0.0, cab.height
        return z_lo, z_hi

    def _chase_fit_box(self, parent_obj, op_props, op_x, op_y,
                       box_dx, box_dy, rear_clr):
        """Resolve a box (drawer or rollout) against the cabinet's pipe
        chase. Returns ``(box_dy, notch_width)``: the depth to build at
        and, for the NOTCH fit, the overlap width to boolean out
        (None when the box doesn't meet the chase).

        The opening's ``chase_fit`` decides: SHORTEN (default) clamps the
        depth so the box and its slide clear the chase covers by the
        normal rear clearance; NOTCH keeps full depth and reports the
        overlap so the caller can mark the box for the boolean; FULL
        leaves it alone. Coordinates: ``op_x`` / ``op_y`` are relative to
        ``parent_obj``, whose chain up to the root is unrotated, so
        parent-local + accumulated chain offsets = cabinet-local.
        """
        cab = self.obj.face_frame_cabinet
        if not (getattr(cab, 'chase_enabled', False) and self._has_carcass()):
            return box_dy, None
        span = self._chase_extents(cab)
        if span is None:
            return box_dy, None
        px, py, _pz = self._cabinet_local_offset(parent_obj)
        bx0 = px + op_x
        bx1 = bx0 + box_dx
        x_lo, x_hi = span
        if bx1 <= x_lo or bx0 >= x_hi:
            return box_dy, None
        fit = (getattr(op_props, 'chase_fit', 'SHORTEN')
               if op_props is not None else 'SHORTEN')
        chase_depth = min(cab.chase_depth, cab.depth)
        # Cabinet-local Y of the box rear; the chase covers' interior
        # face sits at -chase_depth (back plane = 0).
        intrusion = py + op_y + box_dy + chase_depth
        if intrusion <= 0.0:
            return box_dy, None
        if fit == 'SHORTEN':
            return box_dy - (intrusion + rear_clr), None
        if fit == 'NOTCH':
            return box_dy, min(bx1, x_hi) - max(bx0, x_lo)
        return box_dy, None

    def _apply_pipe_chase(self, layout):
        """Notch the chosen back corner (or the back middle) full height
        for a pipe chase and close the opening with cover panels. Managed
        like the wedge: ensure / position / cleanup, safe every recalc."""
        cab = self.obj.face_frame_cabinet
        span = (self._chase_extents(cab)
                if getattr(cab, 'chase_enabled', False) and self._has_carcass()
                else None)
        if span is None:
            self._cleanup_pipe_chase()
            return
        x_lo, x_hi = span
        depth = min(cab.chase_depth, cab.depth)
        z_lo, z_hi = self._chase_z_span(cab)
        cutter = self._ensure_pipe_chase_cutter()
        self._position_pipe_chase_cutter(
            cutter, cab, x_lo, x_hi, depth, z_lo, z_hi)
        self._apply_pipe_chase_cuts(cutter, cab)
        self._build_pipe_chase_panels(
            layout, cab, x_lo, x_hi, depth, z_lo, z_hi)
        # Publish the applied spec on the root (meters) so downstream
        # consumers (drawings / reports) can read it without recomputing.
        # Cleared when the chase is removed.
        self.obj['PIPE_CHASE_LOCATION'] = cab.chase_location
        self.obj['PIPE_CHASE_WIDTH'] = x_hi - x_lo
        self.obj['PIPE_CHASE_DEPTH'] = depth
        self.obj['PIPE_CHASE_HEIGHT'] = z_hi - z_lo
        self.obj['PIPE_CHASE_Z'] = z_lo

    def _ensure_pipe_chase_cutter(self):
        """Find or lazily create the chase cutter MESH object. Hidden in
        the viewport; a boolean still reads its mesh regardless."""
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_PIPE_CHASE_CUTTER:
                return child
        mesh = bpy.data.meshes.new('Pipe Chase Cutter')
        cutter = hb_utils.new_object('Pipe Chase Cutter', mesh)
        cutter['hb_part_role'] = PART_ROLE_PIPE_CHASE_CUTTER
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _position_pipe_chase_cutter(self, cutter_obj, cab, x_lo, x_hi,
                                    depth, z_lo, z_hi):
        """Rebuild the cutter's box mesh from the live chase dims. The box
        spans the chase footprint (back at y=0), pushed past the back /
        floor / top faces by a margin so the boolean cuts cleanly through;
        corner chases also push past the cabinet's outer edge so the
        optional side notch opens through the side's outside face. An
        applied finished back sits OUTSIDE the cage (Y in [0, thickness],
        optionally extended past the cabinet ends), so the rear face and
        the corner overshoot grow to punch all the way through it.
        Partial-height chases stop the cut at the typed z span; the
        margin overshoot applies only at ends coinciding with the
        cabinet bottom / top so those faces are punched through."""
        margin = inch(0.5)
        rear = 0.0
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_FINISHED_BACK:
                rear = max(rear, child.location.y)
        x0, x1 = x_lo, x_hi
        if cab.chase_location == 'LEFT_BACK':
            x0 -= margin + max(0.0, getattr(cab, 'back_finished_extend_left', 0.0))
        elif cab.chase_location == 'RIGHT_BACK':
            x1 += margin + max(0.0, getattr(cab, 'back_finished_extend_right', 0.0))
        y0, y1 = -depth, rear + margin
        z0 = z_lo - margin if z_lo <= 1e-6 else z_lo
        z1 = z_hi + margin if z_hi >= cab.height - 1e-6 else z_hi
        bm = bmesh.new()
        bmesh.ops.create_cube(bm, size=1.0)
        for v in bm.verts:
            v.co.x = x0 if v.co.x < 0.0 else x1
            v.co.y = y0 if v.co.y < 0.0 else y1
            v.co.z = z0 if v.co.z < 0.0 else z1
        bm.to_mesh(cutter_obj.data)
        bm.free()
        cutter_obj.location = (0.0, 0.0, 0.0)

    def _iter_pipe_chase_cut_targets(self, cab):
        """Root cage + carcass / interior parts the chase notch passes
        through. The adjacent side panel is included only for a corner
        chase with the optional side notch on. Parts outside the chase
        footprint are unaffected by the boolean, so over-targeting is
        harmless. Mirrors _iter_wedge_cut_targets."""
        side_roles = ()
        if getattr(cab, 'chase_notch_side', False):
            if cab.chase_location == 'LEFT_BACK':
                side_roles = (PART_ROLE_LEFT_SIDE, PART_ROLE_LEFT_SIDE_SEAM)
            elif cab.chase_location == 'RIGHT_BACK':
                side_roles = (PART_ROLE_RIGHT_SIDE, PART_ROLE_RIGHT_SIDE_SEAM)
        yield self.obj
        stack = list(self.obj.children)
        while stack:
            obj = stack.pop()
            role = obj.get('hb_part_role')
            if role in (PART_ROLE_PIPE_CHASE_CUTTER,
                        PART_ROLE_PIPE_CHASE_PANEL):
                continue
            # side_roles is empty when no side notch applies, so
            # roleless objects (split nodes, cages - role None) never
            # match. A None target crashes modifiers.new on an EMPTY. A
            # seamed side is two parts and the chase runs full height,
            # so both pieces are named.
            # Drawer and rollout boxes join only when their opening opted
            # into NOTCH (stamped by _create_drawer_box_for_front /
            # _create_rollout_box) -- that's the U-shaped box around a
            # sink chase.
            if (role in PIPE_CHASE_CUT_PART_ROLES
                    or (role is not None and role in side_roles)
                    or (role in (PART_ROLE_DRAWER_BOX, PART_ROLE_ROLLOUT_BOX)
                        and obj.get('HB_CHASE_FIT') == 'NOTCH')):
                yield obj
            stack.extend(obj.children)

    def _apply_pipe_chase_cuts(self, cutter_obj, cab):
        """Ensure every target carries a boolean DIFFERENCE modifier named
        PIPE_CHASE_CUT_MOD_NAME pointing at the cutter, and strip it from
        anything no longer targeted (side notch toggled off, location
        flipped). Idempotent; safe every recalc."""
        targets = set()
        for part in self._iter_pipe_chase_cut_targets(cab):
            targets.add(part)
            if part.type != 'MESH':
                continue
            mod = part.modifiers.get(PIPE_CHASE_CUT_MOD_NAME)
            if mod is None:
                mod = part.modifiers.new(name=PIPE_CHASE_CUT_MOD_NAME,
                                         type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
                mod.solver = 'EXACT'
            if mod.object is not cutter_obj:
                mod.object = cutter_obj
        stack = list(self.obj.children)
        while stack:
            obj = stack.pop()
            if obj not in targets:
                mod = obj.modifiers.get(PIPE_CHASE_CUT_MOD_NAME)
                if mod is not None:
                    obj.modifiers.remove(mod)
            stack.extend(obj.children)

    def _ensure_chase_panel(self, slot, name):
        """Find or create the cover panel for a chase slot ('FACE',
        'RETURN_L', 'RETURN_R'). Reconciled in place so user material /
        naming edits survive resizes."""
        for child in self.obj.children:
            if (child.get('hb_part_role') == PART_ROLE_PIPE_CHASE_PANEL
                    and child.get('hb_chase_slot') == slot):
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj['hb_part_role'] = PART_ROLE_PIPE_CHASE_PANEL
        part.obj['CABINET_PART'] = True
        part.obj['hb_chase_slot'] = slot
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        return part.obj

    def _build_pipe_chase_panels(self, layout, cab, x_lo, x_hi, depth,
                                 z_lo, z_hi):
        """Cover panels closing the chase opening from the cabinet
        interior, flush with the cut faces: a face panel parallel to the
        back at the chase depth, plus a return parallel to the side at
        each open chase edge (one for a corner chase, two for a middle
        chase). Panels span the chase's z range (the full cabinet height
        for a historic full-height chase); a partial-height chase also
        gets a horizontal cap closing the notch at its top -- and at its
        bottom when the notch is lifted off the cabinet bottom."""
        t = PIPE_CHASE_PANEL_THICKNESS
        loc = cab.chase_location
        # Face panel X span: butt against the intact side panel's inner
        # face on a corner chase (unless the side itself is notched away).
        face_lo, face_hi = x_lo, x_hi
        notch_side = getattr(cab, 'chase_notch_side', False)
        if loc == 'LEFT_BACK' and not notch_side:
            face_lo = min(x_hi, x_lo + solver.left_side_thickness(layout))
        elif loc == 'RIGHT_BACK' and not notch_side:
            face_hi = max(x_lo, x_hi - solver.right_side_thickness(layout))

        wanted = {}
        if face_hi - face_lo > 0.0:
            wanted['FACE'] = ('Chase Face',
                              (face_lo, -depth + t, z_lo),
                              face_hi - face_lo)
        if depth - t > 0.0:
            if loc in ('RIGHT_BACK', 'BACK_MIDDLE'):
                wanted['RETURN_L'] = ('Chase Return',
                                      (x_lo, 0.0, z_lo), depth - t)
            if loc in ('LEFT_BACK', 'BACK_MIDDLE'):
                wanted['RETURN_R'] = ('Chase Return',
                                      (x_hi - t, 0.0, z_lo), depth - t)

        # Horizontal caps closing a partial-height notch, inset between
        # the returns and stopping at the face panel's plane.
        cap_lo = face_lo + (t if 'RETURN_L' in wanted else 0.0)
        cap_hi = face_hi - (t if 'RETURN_R' in wanted else 0.0)
        if cap_hi - cap_lo > 0.0 and depth - t > 0.0:
            if z_hi < cab.height - 1e-6:
                wanted['TOP'] = ('Chase Top',
                                 (cap_lo, 0.0, z_hi - t), cap_hi - cap_lo)
            if z_lo > 1e-6:
                wanted['BOTTOM'] = ('Chase Bottom',
                                    (cap_lo, 0.0, z_lo), cap_hi - cap_lo)

        # Drop panels whose slot is no longer wanted (location changed).
        for child in list(self.obj.children):
            if (child.get('hb_part_role') == PART_ROLE_PIPE_CHASE_PANEL
                    and child.get('hb_chase_slot') not in wanted):
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)

        for slot, (name, position, width) in wanted.items():
            obj = self._ensure_chase_panel(slot, name)
            if slot == 'FACE':
                # Back-panel orientation: Length up, Width along +X,
                # Thickness toward the cabinet front (-Y).
                obj.rotation_euler = (math.radians(90), math.radians(-90), 0.0)
                part = GeoNodeCutpart(obj)
                part.set_input('Mirror Y', True)
                part.set_input('Mirror Z', False)
                length = z_hi - z_lo
            elif slot in ('TOP', 'BOTTOM'):
                # Flat cap: Length along +X, Width toward the front (-Y),
                # Thickness up from the origin z.
                obj.rotation_euler = (0.0, 0.0, 0.0)
                part = GeoNodeCutpart(obj)
                part.set_input('Mirror Y', True)
                part.set_input('Mirror Z', False)
                length = width
                width = depth - t
            else:
                # Mid-division orientation: Length up, Width toward the
                # front (-Y), Thickness along +X.
                obj.rotation_euler = (0.0, math.radians(-90), 0.0)
                part = GeoNodeCutpart(obj)
                part.set_input('Mirror Y', True)
                part.set_input('Mirror Z', True)
                length = z_hi - z_lo
            obj.location = position
            part.set_input('Length', length)
            part.set_input('Width', width)
            part.set_input('Thickness', t)

    def _cleanup_pipe_chase(self):
        """Reverse of _apply_pipe_chase: strip the boolean cuts, remove
        the cutter and cover panels, clear the published spec. No-op when
        there's nothing to undo."""
        objs = [self.obj]
        stack = list(self.obj.children)
        while stack:
            obj = stack.pop()
            objs.append(obj)
            stack.extend(obj.children)
        for obj in objs:
            mod = obj.modifiers.get(PIPE_CHASE_CUT_MOD_NAME)
            if mod is not None:
                obj.modifiers.remove(mod)
        for child in list(self.obj.children):
            if child.get('hb_part_role') in (PART_ROLE_PIPE_CHASE_CUTTER,
                                             PART_ROLE_PIPE_CHASE_PANEL):
                mesh = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
        for _k in ('PIPE_CHASE_LOCATION', 'PIPE_CHASE_WIDTH',
                   'PIPE_CHASE_DEPTH'):
            if _k in self.obj:
                del self.obj[_k]

    # =====================================================================
    # Decorative corners (notched corner posts)
    # =====================================================================
    def _apply_decorative_corners(self, layout):
        """Build / position / remove the milled posts let into the
        cabinet's vertical corners, and the notch cutters that make
        room for them. Managed like the pipe chase - ensure, position,
        cut, clean up - so it is safe every recalc and survives part
        reconciliation. Face-frame-only roots (panels) have no corner
        to notch, so they only ever clean up.

        Section profiles, the band stack and the notch box all live in
        decorative_corner.py; this is the recalc-side wiring.
        """
        cab = self.obj.face_frame_cabinet
        if not self._has_carcass():
            decorative_corner.apply_corners(
                self.obj, cab.width, cab.depth, cab.height,
                {'style': 'NONE'})
            return
        spec = decorative_corner.spec_from_props(cab, self._has_toe_kick())
        decorative_corner.apply_corners(
            self.obj, cab.width, cab.depth, cab.height, spec)

    # =====================================================================
    # Cabinet columns (split turnings over stiles)
    # =====================================================================
    def _apply_cabinet_columns(self, layout):
        """Build / position / remove the split-turned columns applied
        over this cabinet's stiles. Placement math (which stile, frame
        extent, plane angle) is resolved here from the solver layout;
        the geometry, stacking, and object management live in
        cabinet_column.py.

        v1 covers straight and single-angled fronts on standard
        cabinets. Corner types and piecewise (multi-bay angled) fronts
        only clean up - the FF-plane parameterization of a column
        centered on a bend isn't defined yet.
        """
        cab = self.obj.face_frame_cabinet
        entries = list(getattr(cab, 'cabinet_columns', ()))
        if (not entries or cab.corner_type != 'NONE'
                or layout.angled_multi):
            cabinet_column.apply_columns(self.obj, [])
            return

        flush_floor = (layout.has_toe_kick
                       and layout.toe_kick_type == 'FLUSH')
        theta = solver.face_frame_angle(layout)

        placements = []
        for entry in entries:
            key = entry.stile_key
            # End columns sit flush with the cabinet end (block face in
            # line with the frame's outer edge), the rest of the widened
            # stile reading as a reveal beside them; mid columns are
            # centered on their stile.
            end_off = cabinet_column.end_axis_offset(entry.size)
            if key == 'LEFT':
                ffx = min(end_off, layout.lsw / 2.0)
                bay_lo = bay_hi = 0
                label = "Left"
            elif key == 'RIGHT':
                ffx = (solver.face_frame_length(layout)
                       - min(end_off, layout.rsw / 2.0))
                bay_lo = bay_hi = layout.bay_count - 1
                label = "Right"
            elif key.startswith('MID_'):
                try:
                    gap = int(key[4:])
                except ValueError:
                    continue
                if gap >= len(layout.mid_stiles):
                    # Bay layout changed under the assignment; keep the
                    # entry (it revives if the gap returns) but build
                    # nothing.
                    continue
                ms_width = layout.mid_stiles[gap]['width']
                ffx = (solver.bay_x_position(layout, gap)
                       + layout.bays[gap]['width'] + ms_width / 2.0)
                bay_lo, bay_hi = gap, gap + 1
                label = "Mid %d" % (gap + 1)
            else:
                continue

            z_bottom = min(solver.bay_bottom_z(layout, bay_lo),
                           solver.bay_bottom_z(layout, bay_hi))
            z_top = max(solver.bay_top_z(layout, bay_lo),
                        solver.bay_top_z(layout, bay_hi))
            bay = layout.bays[bay_lo]
            # Both end blocks default to 1" over the TOP rail; the
            # bottom one on a flush kick also drops over the kick.
            bottom_rail = bay['top_rail_width']
            if flush_floor:
                # Flush kick: the frame runs to the floor and the wide
                # rail is kick + rail, so the column and its default
                # bottom block follow it down.
                bottom_rail += bay['kick_height']
                z_bottom = 0.0

            x, y, _z = solver.ff_outer_world_pos(layout, ffx, 0.0)
            placements.append({
                'key': key,
                'label': label,
                'x': x, 'y': y, 'theta': theta,
                'z_bottom': z_bottom, 'z_top': z_top,
                'style': entry.style,
                'size': entry.size,
                'top_block': entry.top_block,
                'top_block_height': entry.top_block_height,
                'bottom_block': entry.bottom_block,
                'bottom_block_height': entry.bottom_block_height,
                'floor_block': entry.floor_block,
                'floor_block_height': entry.floor_block_height,
                'top_rail_width': bay['top_rail_width'],
                'bottom_rail_width': bottom_rail,
            })
        cabinet_column.apply_columns(self.obj, placements)

    # =====================================================================
    # Applied finished-end panels (parented panel roots covering a side)
    # =====================================================================
    def _reconcile_applied_panels(self, layout):
        """Sync applied panel children to the cabinet's three side
        finished-end conditions. For each side whose condition is in
        APPLIED_PANEL_END_TYPES, ensure a panel root exists, parented
        and tagged with the side. Resize / reposition existing panels
        without rebuilding their bay/opening structure - so user edits
        (splits, front-type changes, mid-stile widths) survive.
        """
        cab = self.obj.face_frame_cabinet
        side_conditions = {
            'LEFT':  cab.left_finished_end_condition,
            'RIGHT': cab.right_finished_end_condition,
            'BACK':  cab.back_finished_end_condition,
        }

        # What to build, as (key, side, condition, segment). A side
        # makes one panel; the BACK makes one per stretch of bays that
        # share a back type and a depth, so a bay carrying its own back
        # gets its own panel at its own depth.
        back_segments = solver.applied_back_segments(layout)
        targets = []
        for side in ('LEFT', 'RIGHT'):
            targets.append((side, side, side_conditions[side], None))
        for seg in back_segments:
            targets.append(('BACK:%d' % seg['start_bay'], 'BACK',
                            seg['condition'], seg))

        # Index existing panels by that same key. Multiple per key
        # shouldn't happen, but if it does we keep the first and remove
        # extras to converge on a clean state. Panels whose key is gone
        # (a segment that merged away, or a back type turned off) go
        # with them.
        wanted_keys = {key for key, _s, _c, _seg in targets
                       if _c in APPLIED_PANEL_END_TYPES}
        existing = {}
        extras = []
        for child in self.obj.children:
            side = child.get(TAG_APPLIED_PANEL_SIDE)
            if not side:
                continue
            key = child.get(TAG_APPLIED_PANEL_KEY) or side
            if key in existing or key not in wanted_keys:
                extras.append(child)
            else:
                existing[key] = child
        for child in extras:
            _remove_root_with_children(child)

        for key, side, condition, segment in targets:
            wants_panel = condition in APPLIED_PANEL_END_TYPES
            panel_obj = existing.get(key)

            if not wants_panel:
                if panel_obj is not None:
                    _remove_root_with_children(panel_obj)
                if side in ('LEFT', 'RIGHT'):
                    self._apply_panel_front_miter(layout, side, None)
                continue

            if panel_obj is None:
                panel = PanelFaceFrameCabinet()
                panel.create(f'Applied Panel {side[0]}', bay_qty=1)
                panel_obj = panel.obj
                panel_obj.parent = self.obj
                panel_obj[TAG_APPLIED_PANEL_SIDE] = side
            panel_obj[TAG_APPLIED_PANEL_KEY] = key

            # Stamp the parent cabinet's style onto the panel root so the
            # panel's own recalc tail (_reapply_cabinet_style) materials its
            # parts. The inset-panel fronts and the auto split mid-rails /
            # mid-stiles are torn down and rebuilt every recalc; with no
            # STYLE_NAME the panel's own recalc leaves the rebuilt parts
            # unmaterialed (rendered white). A parent recalc would walk
            # them, but a panel-scoped recalc (e.g. the panel dim writes
            # below) has no following parent walk. _apply_door_styles_to_
            # fronts is a no-op on INSET_PANEL roles, so this only adds the
            # finish. Re-stamped each reconcile to track a parent restyle.
            parent_style = self.obj.get('STYLE_NAME')
            if parent_style:
                panel_obj['STYLE_NAME'] = parent_style
                # The panel's working / false fronts follow the job's
                # overlay: write the style's overlay floats + inset depth
                # onto the panel cabinet. Without this the panel kept the
                # CLASSIC defaults, so full-inset jobs got overlay-style
                # fronts sitting proud of the panel frame.
                from .props_hb_face_frame import get_style_props
                for cs in get_style_props().cabinet_styles:
                    if cs.name == parent_style:
                        cs.apply_overlay_to_cabinet(panel_obj)
                        break

            location, rotation_z, width, height, depth = (
                applied_panel_geometry(layout, side)
            )
            if segment is not None:
                # Rotated 180, the panel's origin is its RIGHT end and
                # its width runs back toward -X. The plane is this
                # stretch's own back face, which is what puts a shallow
                # bay's panel on the bay rather than out at the cabinet
                # back.
                location = (segment['right_x'], segment['y'], segment['z'])
                width = segment['width']
                height = segment['top_z'] - segment['z']
            ext_bl, ext_br = self._back_ext_effective()
            # Finished-end overhang (applied panel). BACK is rotated 180
            # so panel +X runs cabinet -X from origin x=dim_x: extend_left
            # widens the far end past x=0, extend_right shifts the origin
            # +X and widens. LEFT (rotZ=-90, +X->-Y) has its back edge at
            # the origin, so a back overhang shifts origin +Y and widens.
            # RIGHT (rotZ=+90, +X->+Y) has its back edge at the FAR end,
            # so a back overhang only widens.
            if side == 'BACK':
                # Trim the paneled back at each end that carries a return
                # closeout so it butts the return post instead of running
                # behind it. Rotated 180, the origin is the RIGHT end, so a
                # right return shifts the origin -X and narrows; a left return
                # (far end) only narrows - mirroring the extend_r / extend_l
                # grows below.
                # These are cabinet-end treatments, so with the back split
                # into segments only the segment that reaches that end
                # takes them; an internal edge meets its neighbour.
                at_left = segment is None or segment['start_bay'] == 0
                at_right = (segment is None
                            or segment['end_bay'] == len(layout.bays) - 1)
                ret_l = (self._finished_side_return_width(cab, layout, 'LEFT')
                         if at_left else 0.0)
                ret_r = (self._finished_side_return_width(cab, layout, 'RIGHT')
                         if at_right else 0.0)
                ext_l = cab.back_finished_extend_left if at_left else 0.0
                ext_r = cab.back_finished_extend_right if at_right else 0.0
                bl = ext_bl if at_left else 0.0
                br = ext_br if at_right else 0.0
                # Splayed back extension widens the back plane the same
                # way it widens the carcass / finished back.
                location = (location[0] + ext_r - ret_r + br,
                            location[1], location[2])
                width = (width + ext_l + ext_r - ret_l - ret_r + bl + br)
            elif side == 'LEFT':
                eb = cab.left_side_finished_extend_back
                location = (location[0], location[1] + eb, location[2])
                width = width + eb
                # Mitered angled joint: the panel runs to the FF FRONT
                # plane (width + fft); the bisector cut trims both
                # members (see _apply_panel_front_miter below).
                if self._panel_miter_angles(layout, 'LEFT')[0]:
                    width += layout.fft
                location, rotation_z, width = self._splay_covering(
                    'LEFT', ext_bl, location, rotation_z, width,
                    self._back_ext_canonical_depth(layout, 'LEFT'))
            else:  # RIGHT
                width = width + cab.right_side_finished_extend_back
                if self._panel_miter_angles(layout, 'RIGHT')[0]:
                    # Front-anchored: the origin moves forward to the
                    # FF front plane and the width grows to match.
                    location = (location[0], location[1] - layout.fft,
                                location[2])
                    width += layout.fft
                location, rotation_z, width = self._splay_covering(
                    'RIGHT', ext_br, location, rotation_z, width,
                    self._back_ext_canonical_depth(layout, 'RIGHT'),
                    front_anchored=True)
            panel_obj.location = location
            panel_obj.rotation_euler = (0.0, 0.0, rotation_z)
            panel_props = panel_obj.face_frame_cabinet
            # Writing width / height / depth fires _update_cabinet_dim
            # on the panel root which calls recalculate_face_frame_cabinet
            # on IT. The _RECALCULATING guard is keyed by id(root), so
            # the cabinet's outer recalc isn't blocked - the panel runs
            # its own recalc. Three writes -> three panel recalcs; cheap,
            # panels are small.
            panel_props.width = width
            panel_props.height = height
            panel_props.depth = depth

            # Working frames get real drawer boxes, running back into
            # the cavity the missing carcass side opened up. Sides only
            # - a working back would reach into the cabinet the same
            # way, but back conditions stay decorative for now.
            if condition == 'WORKING_FF' and side in ('LEFT', 'RIGHT'):
                span = (solver.carcass_inner_right_x(layout)
                        - solver.carcass_inner_left_x(layout))
                panel_obj[TAG_APPLIED_BOX_DEPTH] = min(
                    max(span, 0.0), APPLIED_BOX_MAX_DEPTH)
            elif TAG_APPLIED_BOX_DEPTH in panel_obj:
                del panel_obj[TAG_APPLIED_BOX_DEPTH]

            # Sizing first - apply_panel_split_structure reads the
            # panel's bay.location.z to compute the mid rail position,
            # and bay.location.z is downstream of the panel's
            # bottom_rail_width, which apply_panel_sizing sets. If
            # sizing runs second, the split rebuild reads the panel's
            # DEFAULT bot_rail (1.5") instead of the correct value
            # (door rail + bay bottom rail + ...) and the mid rail
            # lands too high. The split rebuild does NOT modify the
            # panel's only bay - only its descendants - so it's safe
            # for sizing to run first.
            from . import applied_panel_sizing
            applied_panel_sizing.apply_panel_sizing(
                self.obj, panel_obj, side, condition,
            )
            applied_panel_sizing.apply_panel_split_structure(
                self.obj, panel_obj, side, condition,
            )
            # Toe-kick corner notch on bottom rail + facing stile;
            # a BACK panel takes end cuts for an inset kick instead.
            # No-op for non-NOTCH toe kicks.
            applied_panel_sizing.apply_panel_toe_kick_notch(
                self.obj, panel_obj, side,
            )
            # X-Frame End braces (wipe-and-rebuild; removes the part
            # when the panel's X Frame flag is off).
            applied_panel_sizing.apply_panel_x_frame(
                self.obj, panel_obj, side,
            )

            # Stamp a right-click menu onto the panel's menu-less parts
            # (inset panel fronts, pivots) so clicking any part of the
            # applied panel surfaces the panel's own prompts via the
            # part-commands menu. Face-frame parts already carry that
            # MENU_ID; cabinet_prompts resolves to the panel root.
            for part in panel_obj.children_recursive:
                if part.get('hb_part_role') and not part.get('MENU_ID'):
                    part['MENU_ID'] = (
                        'HOME_BUILDER_MT_face_frame_part_commands')

            # Miter the panel into the face frame front on angled sides
            # (splayed back extension or angled-front cabinet).
            if side in ('LEFT', 'RIGHT'):
                self._apply_panel_front_miter(layout, side, panel_obj)

    # =====================================================================
    # Applied finished back (single 3/4 part layered on the carcass back)
    # =====================================================================
    def _reconcile_finished_back(self, layout):
        """Spawn / resize / remove the FINISHED back panels.

        One 3/4 panel per stretch of bays whose back is FINISHED, laid
        directly on that stretch's carcass back - so a bay set finished
        on its own, or a run of bays at a different depth, carries its
        panel on its own plane rather than out at the cabinet back. With
        the whole cabinet finished that is a single full-width panel,
        which is what it has always been.

        The carcass back itself stays at its normal back_thickness. Same
        delete-on-condition-change / resize-in-place pattern as the
        applied panels - the part holds no user state, so
        reuse-when-present keeps it stable across recalcs without
        rebuilding. Excluding the toe kick is still deferred.
        """
        segments = [seg for seg in solver.applied_back_segments(layout)
                    if seg['condition'] == 'FINISHED']
        wanted = {seg['start_bay'] for seg in segments}
        by_bay = {}
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_FINISHED_BACK:
                continue
            bay = child.get('hb_segment_start_bay')
            if bay not in wanted or bay in by_bay:
                bpy.data.objects.remove(child, do_unlink=True)
                continue
            by_bay[bay] = child
        for seg in segments:
            self._build_finished_back(layout, seg, by_bay.get(seg['start_bay']))

    def _build_finished_back(self, layout, segment, existing):
        """One FINISHED back panel, on this segment's own back plane."""
        cab = self.obj.face_frame_cabinet
        thickness = inch(0.75)
        if existing is None:
            part = CabinetPart()
            part.create('Finished Back')
            part.obj.parent = self.obj
            part.obj['hb_part_role'] = PART_ROLE_FINISHED_BACK
            part.obj['CABINET_PART'] = True
            # Same orientation as the carcass back: rotation x=90 / y=-90
            # with Mirror Y=True extrudes Thickness in -Y from origin.
            # Origin sits at Y=+thickness so the part fills [0, thickness]
            # in cabinet Y - flush against the carcass back's outer face,
            # extending behind the cabinet by 3/4.
            part.obj.rotation_euler.x = math.radians(90)
            part.obj.rotation_euler.y = math.radians(-90)
            part.set_input('Mirror Y', True)
            part.obj['hb_segment_start_bay'] = segment['start_bay']
            existing = part.obj
        else:
            part = GeoNodeCutpart(existing)

        # Finished-end overhang: grow the panel past the cabinet's left
        # (-X) / right (+X) end. Width spans +X from origin x=0, so
        # extending the left end shifts the origin -X and widens; the
        # right end just widens. Negative values inset that edge.
        # Both are cabinet-end treatments, so a segment that stops short
        # of an end takes neither there - it meets its neighbour.
        at_left = segment['start_bay'] == 0
        at_right = segment['end_bay'] == len(layout.bays) - 1
        ext_l = cab.back_finished_extend_left if at_left else 0.0
        ext_r = cab.back_finished_extend_right if at_right else 0.0
        # Shorten the back at each end that carries a return closeout so it
        # butts the return post's outer face instead of running behind it.
        # The return panel's outer face sits `return width` in from that
        # side's outer face, so trimming the back by the same amount (and
        # shifting the origin +X for a left return) lands them flush.
        ret_l = (self._finished_side_return_width(cab, layout, 'LEFT')
                 if at_left else 0.0)
        ret_r = (self._finished_side_return_width(cab, layout, 'RIGHT')
                 if at_right else 0.0)
        # The panel lies on this segment's back face: y = that plane plus
        # its own thickness, since Mirror Y extrudes it back toward the
        # carcass.
        existing.location = (segment['x'] - ext_l + ret_l,
                             segment['y'] + thickness, 0.0)
        part.set_input('Length',    layout.dim_z)
        part.set_input('Width',
                       segment['width'] + ext_l + ext_r - ret_l - ret_r)
        part.set_input('Thickness', thickness)

    def _extend_finished_side_panels(self, layout):
        """Run a FINISHED carcass side panel past the cabinet back by the
        per-side extend amount.

        Only the carcass-side FINISHED case lives here. An applied /
        beadboard / shiplap side carries its overhang on its own applied
        part (handled in that reconciler); a FINISHED side has no applied
        part - the carcass side IS the finished face - so it is grown
        directly.

        The side panel's origin sits at its back edge (cabinet Y=0) with
        Width (depth) extruding -Y, so a positive extend shifts the origin
        +Y and widens, pushing the back out while the square front edge
        stays put (verified empirically). The Width base is recomputed from
        the solver rather than read back, so the extend never accumulates;
        the part loop has already written the square location/Width this
        recalc, so a zero extend needs no reset (self-correcting).

        Skipped in angled mode, where the side geometry is reshaped by the
        angled cutter / trapezoidal back (§18) and a naive +Y grow would
        fight those passes - left as a v1 limit.
        """
        if layout.is_angled:
            return
        cab = self.obj.face_frame_cabinet
        specs = (
            (PART_ROLE_LEFT_SIDE, cab.left_finished_end_condition,
             cab.left_side_finished_extend_back, solver.left_side_dims),
            (PART_ROLE_RIGHT_SIDE, cab.right_finished_end_condition,
             cab.right_side_finished_extend_back, solver.right_side_dims),
        )
        for role, condition, extend, dims_fn in specs:
            if condition != 'FINISHED' or extend == 0.0:
                continue
            child = next((c for c in self.obj.children
                          if c.get('hb_part_role') == role), None)
            if child is None or child.hide_viewport:
                continue
            base_width = dims_fn(layout)[1]  # (length, width=depth, thickness)
            child.location.y += extend
            GeoNodeCutpart(child).set_input('Width', base_width + extend)

    def _finished_side_return_width(self, cab, layout, side):
        """Effective return-closeout width on `side` ('LEFT' / 'RIGHT'), or
        0.0 when the return isn't active. Active requires a non-angled
        cabinet, a back with a finished surface to return into
        (RETURN_BACK_CONDITIONS), and that side carrying a finished
        surface of its own (RETURN_SIDE_CONDITIONS), extended back
        (extend > 0), with a positive return width.
        Single source of truth shared by the return-part builder and the
        back sizing (the finished/paneled/textured back field is
        shortened by this width so it butts the return post instead of
        running behind it).
        """
        if layout.is_angled:
            return 0.0
        if cab.back_finished_end_condition not in RETURN_BACK_CONDITIONS:
            return 0.0
        if side == 'LEFT':
            condition = cab.left_finished_end_condition
            extend = cab.left_side_finished_extend_back
            width = cab.left_side_return_width
        else:
            condition = cab.right_finished_end_condition
            extend = cab.right_side_finished_extend_back
            width = cab.right_side_return_width
        if (condition not in RETURN_SIDE_CONDITIONS
                or extend <= 0.0 or width <= 0.0):
            return 0.0
        return width

    def _reconcile_finished_side_returns(self, layout):
        """Spawn / resize / remove the return closeout on a FINISHED or
        PANELED side that is extended back past a FINISHED or PANELED back.

        Coordinate frame: cabinet back plane at Y=0, body toward -Y, and an
        extended side grows in +Y to its rear edge at Y=extend. The closeout
        wraps that exposed back corner with two 3/4-deep members:

          * RETURN panel - parallel to the side, depth = the side's extend-back
            amount, running Y[0, extend] so its front edge dies into the
            (shortened) back. Sits inboard of the side outer face by the return
            width (behind the stile).
          * STILE - the rearmost / outermost member, X-span = the return width,
            capping the rear at Y[extend, extend+3/4]. Runs full height to the
            floor.

        Each member is a flat FINISHED cutpart (default) or a PANELED applied
        panel (PanelFaceFrameCabinet) per its *_return_panel_type /
        *_return_stile_type prop; both kinds occupy the same footprint, so the
        inner_x-keyed back shortening is unaffected by the choice.

        Gated (via _finished_side_return_width) on the side being FINISHED or
        PANELED, extended back (extend>0), a nonzero return width, and a
        FINISHED or PANELED back to return into. Anything failing the gate
        removes both parts (idempotent). Skipped in angled mode, matching
        _extend_finished_side_panels.
        """
        cab = self.obj.face_frame_cabinet
        thk = inch(0.75)  # 3/4 finished stock / applied-panel depth
        # outer_x = the side's visible outer face = the face-frame outer face
        # (X=0 left, dim_x right); correct for FINISHED and PANELED sides (do
        # NOT use the scribe offset, which is 0.75 for PANELED). mirror_z sets
        # the finished return panel's Thickness direction: OFF left / ON right,
        # so its body runs toward the side and its inboard face lands at
        # inner_x, where the shortened back butts it.
        specs = (
            ('LEFT', PART_ROLE_LEFT_SIDE_RETURN,
             PART_ROLE_LEFT_SIDE_RETURN_STILE,
             cab.left_side_finished_extend_back, cab.left_side_return_width,
             0.0, False, cab.left_side_return_panel_type,
             cab.left_side_return_stile_type),
            ('RIGHT', PART_ROLE_RIGHT_SIDE_RETURN,
             PART_ROLE_RIGHT_SIDE_RETURN_STILE,
             cab.right_side_finished_extend_back, cab.right_side_return_width,
             layout.dim_x, True, cab.right_side_return_panel_type,
             cab.right_side_return_stile_type),
        )
        for (side, return_role, stile_role, extend, return_width, outer_x,
             mirror_z, panel_type, stile_type) in specs:
            wants = self._finished_side_return_width(cab, layout, side) > 0.0
            # inner_x = the return panel's inboard face (where the shortened
            # back butts) = return width in from the outer face.
            inboard = 1.0 if side == 'LEFT' else -1.0
            inner_x = outer_x + inboard * return_width

            # ---- Return panel ----
            # Finished: side-oriented cutpart (rot Y=-90), Width=depth=extend,
            # Thickness toward the outer face (mirror_z). Paneled: applied
            # panel, width=extend along +Y (rot Z=+90), body on the same side
            # of inner_x as the finished part.
            rp_origin_x = inner_x if side == 'RIGHT' else inner_x - thk
            self._reconcile_return_member(
                return_role, wants, panel_type, 'Side Return ' + side[0],
                finished=dict(loc=(inner_x, extend, 0.0), rot_x=0.0,
                              mirror_z=mirror_z, length=layout.dim_z,
                              width=extend, thickness=thk),
                paneled=dict(loc=(rp_origin_x, 0.0, 0.0),
                             rot_z=math.radians(90), width=extend,
                             height=layout.dim_z, depth=thk, side=side))

            # ---- Rear stile ----
            # Finished: back-oriented cutpart (rot X=90, Y=-90), Width=return
            # width in +X from the lower-X end, 3/4 cap at Y=extend..+3/4.
            # Paneled: applied panel facing rear (rot Z=180), same rear cap.
            self._reconcile_return_member(
                stile_role, wants, stile_type, 'Side Return Stile ' + side[0],
                finished=dict(loc=(min(outer_x, inner_x), extend + thk, 0.0),
                              rot_x=math.radians(90), mirror_z=False,
                              length=layout.dim_z, width=return_width,
                              thickness=thk),
                paneled=dict(loc=(max(outer_x, inner_x), extend, 0.0),
                             rot_z=math.radians(180), width=return_width,
                             height=layout.dim_z, depth=thk, side=side))

    def _reconcile_return_member(self, role, wants, kind, name,
                                 finished, paneled):
        """Build / resize / remove one return member (the return panel or the
        rear stile) as a flat FINISHED cutpart or a PANELED applied panel.
        Found by TAG_RETURN_MEMBER (falling back to the legacy hb_part_role
        tag on pre-type parts); a kind change or a failed gate removes the
        existing member the right way and rebuilds. `finished` / `paneled` are
        geometry dicts built by the caller.
        """
        existing = next((c for c in self.obj.children
                         if c.get(TAG_RETURN_MEMBER) == role
                         or c.get('hb_part_role') == role), None)
        if not wants:
            if existing is not None:
                self._remove_return_member(existing)
            return
        current_kind = (existing.get('hb_return_member_kind', 'FINISHED')
                        if existing is not None else None)
        if existing is not None and current_kind != kind:
            self._remove_return_member(existing)
            existing = None
        if kind == 'PANELED':
            self._build_return_paneled(role, name, existing, paneled)
        elif kind in ('BEADBOARD', 'SHIPLAP', 'V_GROOVE'):
            self._build_return_textured(role, name, existing, finished, kind)
        else:
            self._build_return_finished(role, name, existing, finished)

    def _build_return_finished(self, role, name, existing, geo):
        """Flat 3/4 finished cutpart. rot_x distinguishes the side-oriented
        return panel (0) from the back-oriented stile (90); both add Y=-90.
        """
        if existing is None:
            part = CabinetPart()
            part.create(name)
            part.obj.parent = self.obj
            part.obj['CABINET_PART'] = True
            part.obj.rotation_euler.x = geo['rot_x']
            part.obj.rotation_euler.y = math.radians(-90)
            part.set_input('Mirror Y', True)
            part.set_input('Mirror Z', geo['mirror_z'])
            existing = part.obj
        else:
            part = GeoNodeCutpart(existing)
        existing['hb_part_role'] = role
        existing[TAG_RETURN_MEMBER] = role
        existing['hb_return_member_kind'] = 'FINISHED'
        existing.location = geo['loc']
        part.set_input('Length', geo['length'])
        part.set_input('Width', geo['width'])
        part.set_input('Thickness', geo['thickness'])

    def _build_return_textured(self, role, name, existing, geo, condition):
        """BEADBOARD / SHIPLAP return member: same footprint and
        orientation as the flat finished cutpart, but the visible
        geometry is the carved static mesh (_textured_panel_mesh, the
        same carve the textured side/back fields use -- 3/4 stock here,
        beads running vertically). The hidden driven cutpart keeps
        L/W/T for downstream reads; the carve puts the textured face on
        the member's exterior (the return panel's inboard face, the
        stile's rear face)."""
        if existing is None:
            part = CabinetPart()
            part.create(name)
            part.obj.parent = self.obj
            part.obj['CABINET_PART'] = True
            part.obj.rotation_euler.x = geo['rot_x']
            part.obj.rotation_euler.y = math.radians(-90)
            part.set_input('Mirror Y', True)
            part.set_input('Mirror Z', geo['mirror_z'])
            existing = part.obj
        else:
            part = GeoNodeCutpart(existing)
        existing['hb_part_role'] = role
        existing[TAG_RETURN_MEMBER] = role
        existing['hb_return_member_kind'] = condition
        existing.location = geo['loc']
        part.set_input('Length', geo['length'])
        part.set_input('Width', geo['width'])
        part.set_input('Thickness', geo['thickness'])
        self._textured_panel_mesh(
            existing, geo['length'], geo['width'], geo['thickness'],
            condition, geo['mirror_z'],
            shiplap_vertical=_shiplap_vertical(self.obj.face_frame_cabinet))

    def _build_return_paneled(self, role, name, existing, geo):
        """PANELED applied panel (PanelFaceFrameCabinet) filling the member's
        footprint (width along its long axis, 3/4 depth, frame face outward),
        stamped with the parent style so its rebuilt parts get the finish.
        """
        if existing is None:
            panel = PanelFaceFrameCabinet()
            panel.create(name, bay_qty=1)
            existing = panel.obj
            existing.parent = self.obj
        existing[TAG_RETURN_MEMBER] = role
        existing['hb_return_member_kind'] = 'PANELED'
        parent_style = self.obj.get('STYLE_NAME')
        if parent_style:
            existing['STYLE_NAME'] = parent_style
        existing.location = geo['loc']
        existing.rotation_euler = (0.0, 0.0, geo['rot_z'])
        pp = existing.face_frame_cabinet
        pp.width = geo['width']
        pp.height = geo['height']
        pp.depth = geo['depth']
        # Match the top / bottom rail widths to the cabinet's side panels.
        self._match_return_member_rails(existing, geo['side'])

    def _match_return_member_rails(self, panel_obj, side):
        """Set a paneled return member's top / bottom rail widths to match the
        cabinet's PANELED side panels, so the rails read consistently with the
        sides. Uses the same auto-size resolver against that side's condition
        (falling back to PANELED when the side itself isn't an applied-panel
        type); skipped when auto sizing is off, exactly like the side panels.
        Only the rails are matched - stiles stay the member's own. Rails render
        per-bay as well as at panel level, so both are written; per-part unlock
        overrides are respected.
        """
        from . import applied_panel_sizing
        cab = self.obj.face_frame_cabinet
        side_cond = (cab.left_finished_end_condition if side == 'LEFT'
                     else cab.right_finished_end_condition)
        cond = side_cond if side_cond in APPLIED_PANEL_END_TYPES else 'PANELED'
        sizes = applied_panel_sizing.resolve_panel_sizing(self.obj, side, cond)
        if sizes is None:
            return
        top_rw = sizes['top_rail_width']
        bot_rw = sizes['bottom_rail_width']
        pp = panel_obj.face_frame_cabinet
        with suspend_recalc():
            if not pp.unlock_top_rail:
                pp.top_rail_width = top_rw
            if not pp.unlock_bottom_rail:
                pp.bottom_rail_width = bot_rw
            for child in panel_obj.children_recursive:
                if not child.get(TAG_BAY_CAGE):
                    continue
                bay = child.face_frame_bay
                if not bay.unlock_top_rail:
                    bay.top_rail_width = top_rw
                if not bay.unlock_bottom_rail:
                    bay.bottom_rail_width = bot_rw

    def _remove_return_member(self, obj):
        """Remove a return member; paneled members are roots with children."""
        if obj.get('hb_return_member_kind') == 'PANELED':
            _remove_root_with_children(obj)
        else:
            bpy.data.objects.remove(obj, do_unlink=True)

    # =====================================================================
    # Applied flush-X strips (single 1/4 part on the front of a side)
    # =====================================================================
    def _reconcile_full_overlay_stiles(self, layout):
        """Full-overlay cabinets with a WALL end stile get an extra
        1.25\"-wide face-frame part doubled in FRONT of that stile, the
        height of the door front, flush to the cabinet side. Spawn / resize
        / remove per side. Mirrors the end-stile build (rotation + mirror
        flags) shifted one face-frame thickness forward.

        BLIND corner sides get the same applied part sized to the
        corner detail instead: inner edge a 1/4" reveal off the door
        front (which pulls back to a 1/4" overlay on that side - see
        solver.front_overlay), outer end running past the FF end to the
        partner cabinet's planes and mitered 45 degrees so the two
        cabinets' applied stiles close the corner. Geometry comes from
        _corner_fo_stile_geometry; the miter is a hidden wedge cutter
        (same pattern as the mid-stile miter).
        """
        cab = self.obj.face_frame_cabinet
        is_full = _resolve_style_overlay(self.obj) == 'FULL'
        last = layout.bay_count - 1
        side_specs = (
            ('LEFT',  cab.left_stile_type,  0,    0.0),
            ('RIGHT', cab.right_stile_type, last, solver.face_frame_length(layout)),
        )
        existing = {
            child.get(TAG_FO_STILE_SIDE): child
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_FULL_OVERLAY_STILE
            and child.get(TAG_FO_STILE_SIDE) in ('LEFT', 'RIGHT')
        }
        wall_width = inch(1.25)
        for side, stile_type, bi, ff_x in side_specs:
            wants_wall = is_full and stile_type == 'WALL'
            corner_geo = None
            if is_full and stile_type == 'BLIND' and not layout.is_angled:
                corner_geo = self._corner_fo_stile_geometry(layout, side)
            part_obj = existing.get(side)
            if not (wants_wall or corner_geo is not None):
                if part_obj is not None:
                    bpy.data.objects.remove(part_obj, do_unlink=True)
                self._clear_corner_fo_miter(side, None)
                continue
            bay = layout.bays[bi]
            bottom_rail = solver.effective_bottom_rail_width(layout, bi)
            # Door front = clear opening + the top/bottom overlay it laps.
            opening_h = (bay['height'] - bay['top_rail_width']
                         - bottom_rail - bay['kick_height'])
            door_h = (opening_h + layout.default_top_overlay
                      + layout.default_bottom_overlay)
            door_bottom_z = (solver.bay_bottom_z(layout, bi) + bottom_rail
                             - layout.default_bottom_overlay)
            if corner_geo is not None:
                x_anchor, width, seam = corner_geo
                pos = (x_anchor, -layout.dim_y - layout.fft, door_bottom_z)
            else:
                width = wall_width
                # One fft FORWARD of the FF outer plane -> right in front
                # of the stile (perp_offset positive is INTO the cabinet).
                pos = solver.ff_perpendicular_offset(
                    layout, ff_x, -layout.fft, door_bottom_z)
            if part_obj is None:
                part = CabinetPart()
                part.create(f'FO Stile {side[0]}')
                part.obj.parent = self.obj
                part.obj['hb_part_role'] = PART_ROLE_FULL_OVERLAY_STILE
                part.obj['CABINET_PART'] = True
                part.obj[TAG_FO_STILE_SIDE] = side
                part.obj.rotation_euler.y = math.radians(-90)
                part.obj.rotation_euler.z = math.radians(90)
                part.set_input('Mirror Y', side == 'LEFT')
                part.set_input('Mirror Z', True)
                part_obj = part.obj
            else:
                part = GeoNodeCutpart(part_obj)
            part_obj.location = pos
            part.set_input('Length', door_h)
            part.set_input('Width', width)
            part.set_input('Thickness', layout.fft)
            if corner_geo is not None:
                self._apply_corner_fo_miter(part_obj, layout, side, seam)
            else:
                self._clear_corner_fo_miter(side, part_obj)

    FO_CORNER_MITER_MOD_NAME = 'FO Corner Miter'
    FO_CORNER_REVEAL = inch(0.25)

    @staticmethod
    def _settled_world_matrix(obj):
        """obj's world matrix with its OWN local transform read fresh.

        The blind-corner apply shifts the blind cabinet's location and
        the recalc drain runs before the depsgraph refreshes
        matrix_world, so reading obj.matrix_world there is stale by the
        void shift - the applied corner stile then lands short by
        exactly that amount. Recompose only the cabinet's own level
        (parent world @ parent_inverse @ fresh basis): the parent's
        matrix_world must be used as-is because walls are positioned by
        constraints, which matrix_basis composition would drop - and
        parents don't move inside the drain."""
        if obj.parent is None:
            return obj.matrix_basis.copy()
        return (obj.parent.matrix_world
                @ obj.matrix_parent_inverse @ obj.matrix_basis)

    def _corner_fo_stile_geometry(self, layout, side):
        """Cabinet-local geometry for the applied overlay stile on a
        FULL-overlay blind corner side: (x_anchor, width, seam).

        The inner edge sits reveal + corner overlay inboard of the
        corner stile's inner edge (a 1/4" reveal off the door front,
        which takes the 1/4" corner overlay). The outer end runs past
        the FF end so the part's BACK face reaches the partner
        cabinet's FF front plane and its FRONT face reaches the
        partner's applied-stile front plane - the 45-degree seam
        between those two lines is where the partner's applied stile
        meets it, closing the corner at any corner spacing. seam is
        (x_at_ff_plane, x_at_applied_plane) for the wedge cutter.
        Returns None when no perpendicular blind partner resolves.
        """
        from mathutils import Vector
        pair_name = self.obj.get('HB_BLIND_PAIR')
        partner = bpy.data.objects.get(pair_name) if pair_name else None
        if partner is None:
            # Corners configured before HB_BLIND_PAIR was stamped (or via
            # side channels that skip the dialog): reuse the right-click
            # editor's recovery, which falls back to geometric detection.
            from .operators import ops_placement
            resolved = ops_placement._blind_corner_pair_for(self.obj)
            if resolved is None:
                return None
            blind_obj, placed_obj, _blind_side = resolved
            partner = placed_obj if blind_obj is self.obj else blind_obj
        if partner is self.obj:
            return None
        pff = getattr(partner, 'face_frame_cabinet', None)
        if pff is None or pff.depth <= 0:
            return None
        # Settled matrices, NOT matrix_world: the blind-corner apply
        # moves the blind cabinet inside the same recalc drain, and the
        # depsgraph hasn't refreshed matrix_world yet at that point.
        mw_p = self._settled_world_matrix(partner)
        mw_inv = self._settled_world_matrix(self.obj).inverted()
        # Partner's front direction in OUR local frame must run along
        # our width axis, else this isn't a 90-degree corner.
        front_dir = (mw_inv.to_3x3() @ (mw_p.to_3x3() @ Vector((0.0, -1.0, 0.0))))
        if abs(front_dir.x) < 0.99:
            return None
        p_fft = pff.face_frame_thickness
        x_bff = (mw_inv @ (mw_p @ Vector((0.0, -pff.depth, 0.0)))).x
        x_bap = (mw_inv @ (mw_p @ Vector((0.0, -pff.depth - p_fft, 0.0)))).x
        pullback = (solver.FULL_CORNER_SIDE_OVERLAY + self.FO_CORNER_REVEAL)
        if side == 'LEFT':
            x_inner = layout.ff_inset_left + layout.lsw - pullback
            x_outer = min(x_bff, x_bap)
            width = x_inner - x_outer
            x_anchor = x_outer
        else:
            x_inner = (layout.dim_x - layout.ff_inset_right
                       - layout.rsw + pullback)
            x_outer = max(x_bff, x_bap)
            width = x_outer - x_inner
            x_anchor = x_outer
        if width <= self.FO_CORNER_REVEAL:
            return None
        return x_anchor, width, (x_bff, x_bap)

    def _ensure_corner_fo_miter_cutter(self, side):
        role = 'FO_STILE_MITER_CUTTER'
        for child in self.obj.children:
            if (child.get('hb_part_role') == role
                    and child.get(TAG_FO_STILE_SIDE) == side):
                return child
        name = f'FO Stile Miter Cutter {side.title()}'
        mesh = bpy.data.meshes.new(name)
        cutter = hb_utils.new_object(name, mesh)
        cutter['hb_part_role'] = role
        cutter[TAG_FO_STILE_SIDE] = side
        cutter.parent = self.obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in self.obj.users_collection:
            coll.objects.link(cutter)
            break
        return cutter

    def _apply_corner_fo_miter(self, part_obj, layout, side, seam):
        """Rebuild the corner side's miter wedge (a vertical prism over
        the triangle between the partner's FF-front and applied-front
        lines) and ensure the boolean on the applied stile."""
        from mathutils import Vector
        x_bff, x_bap = seam
        cutter = self._ensure_corner_fo_miter_cutter(side)
        corner = Vector((x_bff, -layout.dim_y))
        miter_dir = Vector((x_bap - x_bff, -layout.fft)).normalized()
        open_dir = Vector((-1.0, 0.0)) if side == 'LEFT' else Vector((1.0, 0.0))
        self._miter_wedge_mesh(cutter, corner, miter_dir, open_dir,
                               -0.05, layout.dim_z + 0.05)
        mod = part_obj.modifiers.get(self.FO_CORNER_MITER_MOD_NAME)
        if mod is None:
            mod = part_obj.modifiers.new(
                name=self.FO_CORNER_MITER_MOD_NAME, type='BOOLEAN')
            mod.operation = 'DIFFERENCE'
            mod.solver = 'EXACT'
        if mod.object is not cutter:
            mod.object = cutter

    def _clear_corner_fo_miter(self, side, part_obj):
        """Drop the corner miter modifier + cutter for a side that is no
        longer a FULL-overlay blind corner (or lost its part)."""
        if part_obj is not None:
            mod = part_obj.modifiers.get(self.FO_CORNER_MITER_MOD_NAME)
            if mod is not None:
                part_obj.modifiers.remove(mod)
        for child in list(self.obj.children):
            if (child.get('hb_part_role') == 'FO_STILE_MITER_CUTTER'
                    and child.get(TAG_FO_STILE_SIDE) == side):
                bpy.data.objects.remove(child, do_unlink=True)

    def _reconcile_flush_x_strips(self, layout):
        """Spawn / resize / remove the FLUSH_X applied strip on each
        side. Triggered when *_finished_end_condition == 'FLUSH_X'.

        The strip is a single 1/4 thick part. Outer face flush with
        the cabinet's exterior side plane (X=0 on left, dim_x on
        right); inner face touches the side panel since FLUSH_X auto-
        scribes to 1/4 in the solver. Y starts at the back of the
        face frame (lined up with the side panel) and extends back
        into the cabinet by *_flush_x_amount. Z span matches the side
        panel.
        """
        cab = self.obj.face_frame_cabinet
        side_specs = (
            ('LEFT',  cab.left_finished_end_condition,
             cab.left_flush_x_amount, 0),
            ('RIGHT', cab.right_finished_end_condition,
             cab.right_flush_x_amount, layout.bay_count - 1),
        )

        existing = {
            child.get(TAG_FLUSH_X_SIDE): child
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_FLUSH_X
            and child.get(TAG_FLUSH_X_SIDE) in ('LEFT', 'RIGHT')
        }

        for side, condition, amount, bay_index in side_specs:
            wants = condition == 'FLUSH_X'
            strip = existing.get(side)

            if not wants:
                if strip is not None:
                    bpy.data.objects.remove(strip, do_unlink=True)
                continue

            thickness = FLUSH_X_THICKNESS
            # Run the strip the full height of the cabinet side. For
            # NOTCH / FLUSH toe kicks side_bottom_z is the floor (0.0),
            # so the strip drops to the floor like the carcass side it
            # covers instead of stopping at the top of the kick. FLOATING
            # / uppers keep it at the bay bottom (side_bottom_z ==
            # bay_bottom_z there), preserving the old behavior.
            bottom_z = solver.side_bottom_z(layout, bay_index, side)
            top_z = (solver.left_side_top_z(layout)
                     if side == 'LEFT'
                     else solver.right_side_top_z(layout))
            length = top_z - bottom_z
            # Width along cabinet -Y from origin (Mirror Y=True flips
            # +Y to -Y). Strip's front edge sits at the back of the
            # face frame (-dim_y + fft) so it aligns with the side
            # panel; from there it extends back into the cabinet by
            # `amount`. Origin Y is the strip's back edge:
            #   origin_y - amount = -dim_y + fft   (front edge)
            #   origin_y         = -dim_y + fft + amount (back edge)
            # Angled-front cabinets: the strip's front edge follows that
            # side's own depth (where the angled face frame meets it).
            if layout.is_angled:
                depth_side = (solver.effective_left_depth(layout)
                              if side == 'LEFT'
                              else solver.effective_right_depth(layout))
            else:
                depth_side = layout.dim_y
            origin_y = -depth_side + layout.fft + amount
            origin_x = 0.0 if side == 'LEFT' else layout.dim_x

            if strip is None:
                part = CabinetPart()
                part.create(f'Flush X {side[0]}')
                part.obj.parent = self.obj
                part.obj['hb_part_role'] = PART_ROLE_FLUSH_X
                part.obj['CABINET_PART'] = True
                part.obj[TAG_FLUSH_X_SIDE] = side
                # Match the carcass side rotation/mirror flags so the
                # strip's Length axis goes +Z, Width goes -Y, Thickness
                # goes +X (left) or -X (right). Mirror Z differs between
                # sides exactly as the carcass sides do.
                part.obj.rotation_euler.y = math.radians(-90)
                part.set_input('Mirror Y', True)
                part.set_input('Mirror Z', side == 'LEFT')
                strip = part.obj
            else:
                part = GeoNodeCutpart(strip)

            strip.location = (origin_x, origin_y, bottom_z)
            part.set_input('Length',    length)
            part.set_input('Width',     amount)
            part.set_input('Thickness', thickness)
            self._drive_flush_x_notch(strip, layout, side, bay_index, thickness)

    def _drive_flush_x_notch(self, strip, layout, side, bay_index, thickness):
        """Drive a FLUSH_X strip's 'Notch Front Bottom' modifier so a
        full-height strip clears the toe-kick recess on base / tall
        cabinets, mirroring _update_side_corner_notch for the carcass
        side it covers. Active only for a NOTCH toe kick when the strip
        actually reaches the floor - not when that side is stile-to-floor,
        kick-inset, a floating bay, or FLUSH / FLOATING / uppers. The
        modifier is added lazily so strips built before notch support are
        upgraded in place on the next recalc. Route Depth cuts the full
        1/4\" strip thickness; the strip shares the side's Mirror Y so
        Flip Y = True targets the front face and Flip X = False the bottom.
        """
        mod = strip.modifiers.get('Notch Front Bottom')
        if mod is None:
            cpm = GeoNodeCutpart(strip).add_part_modifier(
                'CPM_CORNERNOTCH', 'Notch Front Bottom')
            cpm.set_input('Flip X', False)
            cpm.set_input('Flip Y', True)
            mod = cpm.mod
        if mod.node_group is None:
            return
        if side == 'LEFT':
            stile_to_floor = solver.left_stile_to_floor(layout)
            has_inset = layout.kick_inset_left > 0
        else:
            stile_to_floor = solver.right_stile_to_floor(layout)
            has_inset = layout.kick_inset_right > 0
        bay_floating = (
            0 <= bay_index < len(layout.bays)
            and bool(layout.bays[bay_index].get('floating_bay'))
        )
        notch_depth = solver.kick_notch_depth(layout)
        active = (layout.has_toe_kick
                  and layout.toe_kick_type == 'NOTCH'
                  and not stile_to_floor
                  and not has_inset
                  and not bay_floating
                  and notch_depth > 1e-6
                  and 0 <= bay_index < len(layout.bays))
        if active:
            kick = layout.bays[bay_index]['kick_height']
            setback = notch_depth
            route = thickness
        else:
            kick = setback = route = 0.0
        ng = mod.node_group
        for input_name, value in (
            ('X', kick),
            ('Y', setback),
            ('Route Depth', route),
        ):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = active
        mod.show_render = active

    # =====================================================================
    # Per-bay finish liner panels (left / right / top / back)
    # =====================================================================
    def _reconcile_bay_finish_panels(self, layout):
        """Spawn / resize / remove finish liner panels for finished bays
        and finished openings.

        A finished region (a whole bay via finish_bay, or a single opening
        via finish_opening) gets 1/4 finish-material liner panels on its
        inner faces so the exterior finish reads inside it. FULL finish
        lines the full cavity depth on the LEFT / RIGHT / TOP faces only -
        the back and the bay floor get no applied part; the carcass BACK /
        BOTTOM panels behind the region are cut from finish stock instead
        (solver's finish_carcass flag splits those segments so unfinished
        neighbouring bays keep interior panels). A finished OPENING adds
        no ceiling part either - the panel over it is a real part
        already - so a FULL opening finish is its two sides (plus a back
        when the bay around it is unfinished). FLUSH finish lines the FF
        opening with a band flush to the FF front face, running
        finish_*_flush_depth back (0 = full depth) on all four sides with
        no BACK panel (open behind for an appliance). A removed bay bottom
        runs the verticals to the floor. The geometry is identical for
        bays and openings - only the region bounds differ - so both route
        through _finish_region_specs.

        A bay-level finish supersedes per-opening finishes within that bay
        (the bay liner already covers everything). Liners are keyed by
        (bay_index, opening_index, face) - opening_index -1 for a bay-level
        liner - so they reuse in place and sweep cleanly. Angled cabinets
        are deferred (bay-local Y here assumes square).
        """
        existing = {}
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_BAY_FINISH:
                continue
            key = (child.get(TAG_BAY_FINISH_BAY),
                   child.get(TAG_BAY_FINISH_OPENING, -1),
                   child.get(TAG_BAY_FINISH_FACE))
            existing[key] = child

        # Floor candidates are re-stamped from scratch every recalc so a
        # region that stops being finished (or moves) releases the part
        # it was finishing.
        for child in self.obj.children_recursive:
            if (child.get('hb_part_role') in FINISH_FLOOR_ROLES
                    and child.get(TAG_FINISH_FLOOR)):
                del child[TAG_FINISH_FLOOR]
        bay_cages = {c.get('hb_bay_index'): c for c in self.obj.children
                     if c.get('IS_FACE_FRAME_BAY_CAGE')}

        wanted = set()
        if not layout.is_angled:
            # Shared with solver.finish_liner_insets, which keeps the
            # interior parts clear of these panels.
            t = solver.FINISH_LINER_THICKNESS
            for bi, bay in enumerate(layout.bays):
                bay_left_x, bay_right_x = solver._cage_x_bounds(layout, bi)
                _, bay_dim_y, bay_dim_z = solver.bay_cage_dims(layout, bi)
                bay_bottom = (solver.bay_bottom_z(layout, bi)
                              + solver.effective_bottom_rail_width(layout, bi))
                bay_top = bay_bottom + bay_dim_z
                bay_to_floor = bool(bay.get('remove_bottom'))

                if bay.get('finish_bay'):
                    region = dict(
                        left_x=bay_left_x, right_x=bay_right_x,
                        bottom_z=bay_bottom, top_z=bay_top,
                        cage_dim_y=bay_dim_y,
                        reveals=solver._bay_root_reveals(layout, bi),
                        bay_index=bi,
                    )
                    texture = bay.get('finish_bay_texture', 'NONE')
                    specs = self._finish_region_specs(
                        layout, region, bool(bay.get('finish_bay_flush')),
                        bay.get('finish_bay_flush_depth', 0.0), bay_to_floor, t,
                        # A textured bay takes a BACK liner to carry the
                        # texture: the carcass back behind it is finish
                        # stock, and flat.
                        want_back=texture not in ('NONE', ''))
                    for face, spec in specs:
                        self._emit_bay_finish_panel(bi, -1, face, spec, t,
                                                    existing, texture)
                        wanted.add((bi, -1, face))
                    continue

                # No bay-level finish -> check each opening leaf. The leaf
                # rects are bay-local; the bay cage origin (bay_left_x,
                # bay_bottom) maps them to cabinet-local. An opening only
                # reaches the floor when the bay bottom is removed AND it's
                # the bottom-most leaf (cage_z == 0).
                bay_tree = solver.bay_openings(layout, bi)
                for leaf in bay_tree['leaves']:
                    op_obj = bpy.data.objects.get(leaf['obj_name'])
                    if op_obj is None:
                        continue
                    op = op_obj.face_frame_opening
                    if not op.finish_opening:
                        continue
                    oi = leaf['opening_index']
                    op_left_x = bay_left_x + leaf['cage_x']
                    op_bottom = bay_bottom + leaf['cage_z']
                    region = dict(
                        left_x=op_left_x,
                        right_x=op_left_x + leaf['cage_dim_x'],
                        bottom_z=op_bottom,
                        top_z=op_bottom + leaf['cage_dim_z'],
                        cage_dim_y=leaf['cage_dim_y'],
                        reveals={'left':   leaf['reveal_left'],
                                 'right':  leaf['reveal_right'],
                                 'top':    leaf['reveal_top'],
                                 'bottom': leaf['reveal_bottom']},
                        vert_top_z=self._finish_opening_ceiling_z(
                            bay_tree, leaf, bay_bottom),
                        bay_index=bi,
                    )
                    op_to_floor = bay_to_floor and abs(leaf['cage_z']) < 1e-6
                    # A lone finished opening can't split the bay's back
                    # panel horizontally, so it takes a BACK liner. When
                    # the bay reads finished as a whole the carcass back
                    # is already finish stock and the liner would double
                    # up on it.
                    texture = op.finish_opening_texture
                    textured = texture not in ('NONE', '')
                    specs = self._finish_region_specs(
                        layout, region, bool(op.finish_opening_flush),
                        op.finish_opening_flush_depth, op_to_floor, t,
                        want_back=(not bay.get('finish_carcass')) or textured,
                        want_top=False)
                    for face, spec in specs:
                        self._emit_bay_finish_panel(bi, oi, face, spec, t,
                                                    existing, texture)
                        wanted.add((bi, oi, face))
                    # The floor gets no liner - the part the opening sits
                    # on is finished instead.
                    if op.finish_opening_material == 'FINISH':
                        self._stamp_finish_opening_floor(bay_cages.get(bi), leaf)

        for key, child in existing.items():
            if key not in wanted:
                bpy.data.objects.remove(child, do_unlink=True)

    def _stamp_finish_opening_floor(self, bay_cage, leaf):
        """Mark the part a finished opening sits on so the material walk
        gives it the exterior finish.

        The floor is never lined - the shop finishes the panel that is
        already there. Which panel that is depends on where the leaf
        sits in its bay: a leaf resting on the bay floor is handled by
        the solver (solver.bay_finish_bottom splits the carcass bottom
        so unfinished neighbouring bays keep an interior floor), so what
        is left here is a leaf resting on the bay shelf / division under
        it. Opening cages and bay backings are both positioned in
        BAY-LOCAL coordinates (split nodes are pinned to the bay origin),
        so the leaf's cage_z can be matched straight against a backing's
        top face without mapping either into cabinet space. That also
        means the backing search MUST stay inside the owning bay - every
        bay repeats the same local coordinates, so a cabinet-wide scan
        happily matches a sibling bay's shelf at the same height.
        """
        if abs(leaf['cage_z']) < 1e-6 or bay_cage is None:
            return
        tol = inch(1.0 / 32.0)
        left = leaf['cage_x']
        right = left + leaf['cage_dim_x']
        for child in bay_cage.children_recursive:
            if child.get('hb_part_role') not in (PART_ROLE_BAY_SHELF,
                                                 PART_ROLE_BAY_DIVISION):
                continue
            # A V-split backing is a vertical panel (rotated -90 about
            # Y); only a horizontal one can be a floor.
            if abs(child.rotation_euler.y) > 1e-6:
                continue
            part = GeoNodeCutpart(child)
            top_z = child.location.z + part.get_input('Thickness')
            if abs(top_z - leaf['cage_z']) > tol:
                continue
            length = part.get_input('Length')
            if (child.location.x <= left + tol
                    and child.location.x + length >= right - tol):
                child[TAG_FINISH_FLOOR] = True
                return

    def _finish_opening_ceiling_z(self, bay_tree, leaf, bay_bottom):
        """Cabinet-local Z of the underside of the shelf over a finished
        opening, or None when the opening's own top is the real one.

        An opening's cage stops at the BOTTOM edge of the rail above it,
        but the shelf behind that rail hangs from the rail's TOP edge -
        so the cavity carries on past the cage by the rail's width less
        the shelf's thickness, three quarters of an inch on a 1-1/2"
        rail. A liner cut to the cage leaves exactly that band of bare
        carcass side showing above it, which is visible through the
        opening. The liner has to run up to the shelf.

        The rail and its shelf come out of the same splitter, so they
        are matched by splitter rather than by hunting for a panel at
        the right height: a splitter whose bottom edge is this leaf's
        top edge, then that splitter's own backing. A split with its
        backing removed pairs with nothing and the liner stays where it
        was - there is no shelf there to reach.
        """
        tol = inch(1.0 / 64.0)
        leaf_top = leaf['cage_z'] + leaf['cage_dim_z']
        left = leaf['cage_x']
        right = left + leaf['cage_dim_x']
        keys = {(s['split_node_name'], s['splitter_index'])
                for s in bay_tree['splitters']
                if abs(s['z'] - leaf_top) <= tol}
        if not keys:
            return None
        for backing in bay_tree['backings']:
            if backing.get('axis') != 'H':
                continue
            if (backing['split_node_name'],
                    backing['splitter_index']) not in keys:
                continue
            # The backing spans its parent cage, which contains this
            # leaf whenever the splitter is the one directly above it.
            if (backing['x'] > left + tol
                    or backing['x'] + backing['length'] < right - tol):
                continue
            if backing['z'] > leaf_top + tol:
                return bay_bottom + backing['z']
        return None

    def _finish_region_specs(self, layout, region, flush, raw_depth, to_floor,
                             t, want_back=False, want_top=True):
        """Build the (face, spec) list for one finished region.

        `want_top` covers the ceiling of a FULL finish. A finished
        OPENING passes False: the panel over it is a real part already,
        so an applied 1/4 ceiling is a part the shop does not build.
        Only a FLUSH finish tops the region, and there the top is part
        of the band that wraps the FF opening.

        `region` is cabinet-local: left_x / right_x / bottom_z / top_z, the
        cavity depth cage_dim_y, and the four reveals (cage edge -> FF
        opening edge). See _reconcile_bay_finish_panels for the FULL vs
        FLUSH and to_floor semantics; the math here is shared by bays and
        openings.
        """
        left_x = region['left_x']; right_x = region['right_x']
        bottom_z = region['bottom_z']; top_z = region['top_z']
        cage_dim_x = right_x - left_x
        cage_dim_y = region['cage_dim_y']
        rev = region['reveals']
        ff_back_y = -layout.dim_y + layout.fft
        cavity_back_y = ff_back_y + cage_dim_y

        if flush:
            # FLUSH band lining the FF opening, flush with the FF front
            # face. Visible faces sit at the FF opening edges (no reveal)
            # with thickness OUTBOARD (LEFT -X, RIGHT +X, TOP +Z, BOTTOM
            # -Z). No BACK panel - open behind for an appliance.
            op_left_x   = left_x + rev['left']
            op_right_x  = right_x - rev['right']
            op_bottom_z = 0.0 if to_floor else bottom_z + rev['bottom']
            op_top_z    = top_z - rev['top']
            op_height   = op_top_z - op_bottom_z
            op_width    = op_right_x - op_left_x
            ff_front_y  = -layout.dim_y
            max_depth   = layout.fft + cage_dim_y
            depth = max_depth if raw_depth <= 0.0 else min(raw_depth, max_depth)
            band_back_y = ff_front_y + depth   # Mirror-Y anchor edge
            specs = [
                ('LEFT',  dict(rot=(0.0, math.radians(-90), 0.0),
                               mirror_y=True, mirror_z=False,
                               loc=(op_left_x, band_back_y, op_bottom_z),
                               length=op_height, width=depth)),
                ('RIGHT', dict(rot=(0.0, math.radians(-90), 0.0),
                               mirror_y=True, mirror_z=True,
                               loc=(op_right_x, band_back_y, op_bottom_z),
                               length=op_height, width=depth)),
                ('TOP',   dict(rot=(0.0, 0.0, 0.0),
                               mirror_y=True, mirror_z=False,
                               loc=(op_left_x, band_back_y, op_top_z),
                               length=op_width, width=depth)),
            ]
            if not to_floor:
                specs.append(
                    ('BOTTOM', dict(rot=(0.0, 0.0, 0.0),
                                    mirror_y=True, mirror_z=True,
                                    loc=(op_left_x, band_back_y, op_bottom_z),
                                    length=op_width, width=depth)))
        else:
            # FULL finish lining the full cavity depth on the cavity
            # walls. The sides and the ceiling are applied 1/4 parts;
            # the FLOOR never is - the part the region sits on (carcass
            # bottom or the bay shelf below it) is cut from finish stock
            # instead. The BACK is finish stock too when the whole bay
            # is finished (want_back False, the carcass back splits per
            # bay), but a single finished opening inside an unfinished
            # bay can't split the bay's back panel horizontally, so it
            # gets a liner there instead.
            vert_bottom_z = 0.0 if to_floor else bottom_z
            # The sides (and the back) run to the shelf over the region
            # when that sits above the region's own top - see
            # _finish_opening_ceiling_z. The ceiling part, where one is
            # built at all, still caps the region itself.
            ceiling_z     = region.get('vert_top_z')
            vert_top_z    = top_z if ceiling_z is None else ceiling_z
            vert_height   = vert_top_z - vert_bottom_z
            # How the box goes together: the back is one full-width
            # sheet and the sides butt into its front face, the way it
            # is built. Cut to the cavity they shared the same quarter
            # inch at both back corners. The ceiling butts the same way,
            # and is already held between the sides in X.
            #
            # No liner back (a finished BAY, where the carcass back is
            # finish stock already) and the sides run the full depth to
            # butt that panel instead.
            back_t     = t if want_back else 0.0
            side_y     = cavity_back_y - back_t
            side_depth = max(cage_dim_y - back_t, 0.0)
            specs = [
                ('LEFT',  dict(rot=(0.0, math.radians(-90), 0.0),
                               mirror_y=True, mirror_z=True,
                               loc=(left_x, side_y, vert_bottom_z),
                               length=vert_height, width=side_depth)),
                ('RIGHT', dict(rot=(0.0, math.radians(-90), 0.0),
                               mirror_y=True, mirror_z=False,
                               loc=(right_x, side_y, vert_bottom_z),
                               length=vert_height, width=side_depth)),
            ]
            if want_top:
                specs.append(
                    ('TOP',   dict(rot=(0.0, 0.0, 0.0),
                                   mirror_y=True, mirror_z=True,
                                   loc=(left_x + t, side_y, top_z),
                                   length=max(cage_dim_x - 2 * t, 0.0),
                                   width=side_depth)))
            if want_back:
                specs.append(
                    ('BACK', dict(rot=(math.radians(90), math.radians(-90), 0.0),
                                  mirror_y=True, mirror_z=False,
                                  loc=(left_x, cavity_back_y, vert_bottom_z),
                                  length=vert_height, width=cage_dim_x)))

        # A liner running to the floor crosses the toe-kick recess at the
        # cabinet front, and without a notch it fills the recess it is
        # standing in. Only the side panels reach the front; the back
        # sits behind the kick and the top is nowhere near it.
        self._add_finish_liner_notch(layout, region, to_floor, specs)
        return specs

    @staticmethod
    def _add_finish_liner_notch(layout, region, to_floor, specs):
        """Mark the side liners of a to-floor region for a kick notch.

        Carried on the spec rather than applied here so the emit step
        stays the one place a liner's geometry is written. The recess
        only exists for a NOTCH kick, and a setback inside the face
        frame band leaves nothing to cut.
        """
        if not to_floor:
            return
        if not (layout.has_toe_kick and layout.toe_kick_type == 'NOTCH'):
            return
        notch_depth = solver.kick_notch_depth(layout)
        if notch_depth <= 1e-6:
            return
        bay_index = region.get('bay_index', -1)
        if not (0 <= bay_index < len(layout.bays)):
            return
        kick = layout.bays[bay_index]['kick_height']
        if kick <= 1e-6:
            return
        for face, spec in specs:
            if face in ('LEFT', 'RIGHT'):
                spec['notch'] = (kick, notch_depth)

    def _emit_bay_finish_panel(self, bay_index, opening_index, face, spec,
                               thickness, existing, texture='NONE'):
        """Create or reuse one (bay_index, opening_index, face) finish liner
        and write its transform + cutpart dims from `spec`. opening_index
        is -1 for a whole-bay liner. Reuse-by-key keeps object identity
        stable so downstream view instances don't break.
        """
        key = (bay_index, opening_index, face)
        strip = existing.get(key)
        if strip is None:
            if opening_index < 0:
                name = f'Bay Finish {bay_index + 1} {face.title()}'
            else:
                name = f'Opening Finish {bay_index + 1}.{opening_index} {face.title()}'
            part = CabinetPart()
            part.create(name)
            part.obj.parent = self.obj
            part.obj['hb_part_role'] = PART_ROLE_BAY_FINISH
            part.obj['CABINET_PART'] = True
            part.obj[TAG_BAY_FINISH_BAY] = bay_index
            part.obj[TAG_BAY_FINISH_OPENING] = opening_index
            part.obj[TAG_BAY_FINISH_FACE] = face
            strip = part.obj
        else:
            part = GeoNodeCutpart(strip)
        rx, ry, rz = spec['rot']
        strip.rotation_euler = (rx, ry, rz)
        part.set_input('Mirror Y', spec['mirror_y'])
        part.set_input('Mirror Z', spec['mirror_z'])
        strip.location = spec['loc']
        part.set_input('Length',    spec['length'])
        part.set_input('Width',     spec['width'])
        part.set_input('Thickness', thickness)
        self._drive_finish_liner_notch(strip, spec, thickness)
        self._texture_finish_panel(strip, spec, thickness, texture)

    @staticmethod
    def _drive_finish_liner_notch(strip, spec, thickness):
        """Cut (or stop cutting) a liner's front-bottom toe-kick notch.

        Liners are reused by key, so one that stops running to the floor
        has to have its cut turned off again rather than merely not
        turned on. Added lazily, so a liner built before notch support
        upgrades in place. The side liners share the carcass side's
        Mirror Y, so Flip Y = True is the front face and Flip X = False
        the bottom -- the same pair every other part cut for this recess
        uses.
        """
        notch = spec.get('notch')
        mod = strip.modifiers.get('Notch Front Bottom')
        if mod is None:
            if notch is None:
                return
            cpm = GeoNodeCutpart(strip).add_part_modifier(
                'CPM_CORNERNOTCH', 'Notch Front Bottom')
            cpm.set_input('Flip X', False)
            cpm.set_input('Flip Y', True)
            mod = cpm.mod
        if mod.node_group is None:
            return
        if notch is None:
            kick = setback = route = 0.0
        else:
            kick, setback = notch
            route = thickness
        ng = mod.node_group
        for input_name, value in (('X', kick), ('Y', setback),
                                  ('Route Depth', route)):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = notch is not None
        mod.show_render = notch is not None

    def _texture_finish_panel(self, strip, spec, thickness, texture):
        """Carve a finish liner, or hand it back to its cutpart.

        Same static-mesh treatment the textured ends use, with one turn
        of the handle: the mesh builder always carves the plane at local
        z=0 and grows the material away from it, but a liner's visible
        face is the one AWAY from its cutpart origin -- the origin plane
        lies against the carcass and the cavity looks at the far face.
        So carve with the mirror flipped (grooves at z=0, body on the
        other side) and slide the mesh back by a thickness, which lands
        the body exactly where the cutpart put it with the grooves on
        the face the cavity sees. Same trick the misc-board panels use
        to get their grooves onto the top face.
        """
        if texture in ('NONE', ''):
            if strip.get(TAG_STATIC_TEXTURED):
                # Back to the live cutpart: drop the carved mesh and let
                # the modifier draw again.
                if strip.data is not None:
                    strip.data.clear_geometry()
                mod_name = getattr(strip.home_builder, 'mod_name', '')
                mod = strip.modifiers.get(mod_name) if mod_name else None
                if mod is not None:
                    mod.show_viewport = True
                    mod.show_render = True
                del strip[TAG_STATIC_TEXTURED]
            return
        try:
            pitch = float(self.obj.face_frame_cabinet.shiplap_board_width) * 0.0254
        except (ValueError, AttributeError):
            pitch = TEXTURED_SHIPLAP_PITCH
        self._textured_panel_mesh(strip, spec['length'], spec['width'],
                                  thickness, texture,
                                  mirror_z=not spec['mirror_z'],
                                  shiplap_pitch=pitch,
                                  shiplap_vertical=_shiplap_vertical(
                                      self.obj.face_frame_cabinet),
                                  v_groove_spacing=_v_groove_spacing(
                                      self.obj.face_frame_cabinet))
        dz = -thickness if spec['mirror_z'] else thickness
        strip.data.transform(Matrix.Translation((0.0, 0.0, dz)))
        strip.data.update()

    # =====================================================================
    # Applied textured panels (BEADBOARD / SHIPLAP, 1/4 carved parts)
    # =====================================================================

    @staticmethod
    def _textured_panel_mesh(part_obj, length, width, thickness,
                             condition, mirror_z,
                             shiplap_pitch=TEXTURED_SHIPLAP_PITCH,
                             shiplap_vertical=False,
                             v_groove_spacing=TEXTURED_V_GROOVE_SPACING):
        """Write the carved static mesh for a textured panel into
        ``part_obj``'s mesh data and hide its GN cutpart display.

        Cutpart-local space (verified against the GN output): local X
        runs 0..length (bottom -> top), local Y runs 0..-width, and the
        EXTERIOR face sits on the z=0 plane with the material extending
        -z when Mirror Z is set (LEFT panels) else +z (RIGHT / BACK).

        BEADBOARD: vertical quirk-bead grooves (door_builder's BEAD
        section) along local X, repeated across the width, pattern
        centered like a grooved door panel. V_GROOVE: the same vertical
        layout with a 90-degree vee cut at TEXTURED_V_GROOVE_SPACING.
        SHIPLAP: nickel-gap plank reveals (KERF section) along local Y,
        repeated up the length at TEXTURED_SHIPLAP_PITCH from the
        bottom -- or, with ``shiplap_vertical``, standing planks across
        the width, balanced so both end planks match. Grooves that
        don't fit leave a plain slab.
        """
        import bmesh
        from ..common import door_builder

        s = -1.0 if mirror_z else 1.0
        sec = door_builder._groove_section(
            {'BEADBOARD': 'BEAD', 'V_GROOVE': 'VEE'}.get(condition, 'KERF'))
        hw = max(du for du, dv in sec)
        deep = max(dv for du, dv in sec)
        if deep >= thickness:
            sec = None

        # Groove centers along the repeat axis (u), and the span the
        # cross-section is drawn across. Beadboard and v-groove share the
        # vertical layout and differ only in section and spacing.
        across_width = (condition in ('BEADBOARD', 'V_GROOVE')
                        or (condition == 'SHIPLAP' and shiplap_vertical))
        if condition in ('BEADBOARD', 'V_GROOVE'):
            span_u, run = width, length      # profile across Y, extrude X
            spacing = (v_groove_spacing
                       if condition == 'V_GROOVE'
                       else TEXTURED_BEADBOARD_SPACING)
            margin = max(2.0 * hw, 0.004)
            k = 1 + int(span_u / spacing) if spacing > 0 else 0
            centers = [span_u / 2.0 + (i + 0.5) * spacing
                       for i in range(-k, k + 1)]
        elif across_width:
            # Standing shiplap: whole planks centered on the panel with
            # a matching part plank at each end. Of the two ways to
            # center (one more or one fewer whole plank) take the one
            # whose end planks come out wider, so a near-fit does not
            # leave slivers at the edges.
            span_u, run = width, length
            margin = 0.5 * 0.0254
            centers = FaceFrameCabinet._balanced_courses(span_u,
                                                         shiplap_pitch)
        else:
            span_u, run = length, width      # profile across X, extrude Y
            pitch = shiplap_pitch
            margin = 0.5 * 0.0254
            n = int(span_u / pitch) if pitch > 0 else 0
            centers = [i * pitch for i in range(1, n + 1)]
        if sec is not None:
            centers = sorted(c for c in centers
                             if c - hw >= margin and c + hw <= span_u - margin)
        else:
            centers = []

        # Closed profile loop in (u, z): back face, up the far edge,
        # then the exterior face (z=0) walked back with grooves cut
        # toward the material side (z = s * dv).
        z_in = s * thickness
        loop = [(0.0, z_in), (span_u, z_in), (span_u, 0.0)]
        for c in reversed(centers):
            for du, dv in reversed(sec):
                loop.append((c + du, s * dv))
        loop.append((0.0, 0.0))

        bm = bmesh.new()
        if across_width:
            ring0 = [bm.verts.new((0.0, -u, z)) for u, z in loop]
            ring1 = [bm.verts.new((run, -u, z)) for u, z in loop]
        else:
            ring0 = [bm.verts.new((u, 0.0, z)) for u, z in loop]
            ring1 = [bm.verts.new((u, -run, z)) for u, z in loop]
        bm.faces.new(ring0)
        bm.faces.new(list(reversed(ring1)))
        n = len(loop)
        for i in range(n):
            j = (i + 1) % n
            bm.faces.new((ring0[i], ring0[j], ring1[j], ring1[i]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(part_obj.data)
        bm.free()

        # Hide the driven cutpart display; it stays as the L/W/T
        # carrier for downstream reads.
        mod_name = getattr(part_obj.home_builder, 'mod_name', '')
        mod = part_obj.modifiers.get(mod_name) if mod_name else None
        if mod is not None:
            mod.show_viewport = False
            mod.show_render = False
        part_obj[TAG_STATIC_TEXTURED] = True

    @staticmethod
    def _balanced_courses(span, pitch):
        """Groove positions for standing planks across ``span``: whole
        planks centered, part planks of equal width at both ends, and
        the end planks as wide as the pitch allows."""
        if pitch <= 0.0 or span < pitch:
            return []
        whole = int(span / pitch + 1e-9)
        best = []
        best_end = -1.0
        for k in (whole, whole - 1):
            if k < 1:
                continue
            end = (span - k * pitch) / 2.0
            if end < 1e-6:
                # Exact fit: whole planks only, no end pieces.
                grooves = [i * pitch for i in range(1, k)]
                end = pitch
            else:
                grooves = [end + i * pitch for i in range(0, k + 1)]
            if end > best_end:
                best, best_end = grooves, end
        return best

    def _reconcile_textured_panels(self, layout):
        """Spawn / resize / remove BEADBOARD or SHIPLAP applied panels.

        One reconciler covers all three sides. One 1/4 part per side -
        same overall position as a PANELED applied panel (LEFT / RIGHT)
        or FINISHED back (BACK), without the face frame structure. The
        part's driven cutpart carries L/W/T; the visible geometry is a
        static carved mesh (see _textured_panel_mesh).

        Resize-in-place when the role is unchanged. Condition flips
        between BEADBOARD <-> SHIPLAP rebuild the part since the role
        changes.
        """
        cab = self.obj.face_frame_cabinet
        side_specs = (
            ('LEFT',  cab.left_finished_end_condition),
            ('RIGHT', cab.right_finished_end_condition),
            ('BACK',  cab.back_finished_end_condition),
        )

        existing = {
            child.get(TAG_TEXTURED_PANEL_SIDE): child
            for child in self.obj.children
            if child.get(TAG_TEXTURED_PANEL_SIDE) in ('LEFT', 'RIGHT', 'BACK')
        }

        for side, condition in side_specs:
            desired_role = TEXTURED_PANEL_ROLES.get(condition)
            part_obj = existing.get(side)

            if desired_role is None:
                if part_obj is not None:
                    bpy.data.objects.remove(part_obj, do_unlink=True)
                continue

            # Role mismatch -> drop and recreate so material assignment
            # tracks the chosen condition cleanly.
            if (part_obj is not None
                    and part_obj.get('hb_part_role') != desired_role):
                bpy.data.objects.remove(part_obj, do_unlink=True)
                part_obj = None

            thickness = inch(0.25)

            # LEFT / RIGHT skins track the carcass side panel's vertical
            # extent (side_bottom_z runs to the floor for NOTCH / FLUSH
            # toe kicks) and get the same front-bottom corner notch a
            # FLUSH_X strip gets so they clear a NOTCH kick recess.
            # Angled-front cabinets size each skin to that side's own
            # depth; a splayed back extension rotates the skin onto the
            # splayed line via _splay_covering (rot_z below).
            ext_bl, ext_br = self._back_ext_effective()
            rot_z = 0.0
            if side == 'LEFT':
                bottom_z = solver.side_bottom_z(layout, 0, 'LEFT')
                location = (0.0, 0.0, bottom_z)
                length = solver.left_side_top_z(layout) - bottom_z
                depth_side = (solver.effective_left_depth(layout)
                              if layout.is_angled else layout.dim_y)
                width = depth_side - layout.fft
                rot_x, rot_y = 0.0, math.radians(-90)
                mirror_y, mirror_z = True, True
            elif side == 'RIGHT':
                last = layout.bay_count - 1
                bottom_z = solver.side_bottom_z(layout, last, 'RIGHT')
                location = (layout.dim_x, 0.0, bottom_z)
                length = solver.right_side_top_z(layout) - bottom_z
                depth_side = (solver.effective_right_depth(layout)
                              if layout.is_angled else layout.dim_y)
                width = depth_side - layout.fft
                rot_x, rot_y = 0.0, math.radians(-90)
                mirror_y, mirror_z = True, False
            else:  # BACK
                # Origin sits at Y=+thickness so the part fills [0, thickness]
                # in cabinet Y - directly behind the carcass back, same as
                # FINISHED_BACK but 1/4 thick.
                location = (0.0, thickness, 0.0)
                length = layout.dim_z
                width = layout.dim_x
                rot_x, rot_y = math.radians(90), math.radians(-90)
                mirror_y, mirror_z = True, False  # no z-mirror needed

            # Finished-end overhang. BACK grows past the L/-X and R/+X
            # ends (Width spans +X from origin x=0, same as the finished
            # back). LEFT / RIGHT have their back edge at the origin with
            # Width extruding -Y, so a back overhang shifts origin +Y and
            # widens; the square front stays put.
            if side == 'BACK':
                el = cab.back_finished_extend_left
                er = cab.back_finished_extend_right
                # A splayed back extension widens the back plane too,
                # same as the carcass / finished back.
                # Side-return closeouts shorten the field so it butts the
                # return post instead of running behind it (mirrors the
                # finished-back trim in _reconcile_finished_back).
                ret_l = self._finished_side_return_width(cab, layout, 'LEFT')
                ret_r = self._finished_side_return_width(cab, layout, 'RIGHT')
                location = (location[0] - el - ext_bl + ret_l, location[1],
                            location[2])
                width = width + el + er + ext_bl + ext_br - ret_l - ret_r
            else:
                eb = (cab.left_side_finished_extend_back if side == 'LEFT'
                      else cab.right_side_finished_extend_back)
                location = (location[0], location[1] + eb, location[2])
                width = width + eb
                ext = ext_bl if side == 'LEFT' else ext_br
                location, rot_z, width = self._splay_covering(
                    side, ext, location, rot_z, width,
                    self._back_ext_canonical_depth(layout, side))

            if part_obj is None:
                part = CabinetPart()
                label = {'BEADBOARD': 'Beadboard',
                         'V_GROOVE': 'V-Groove'}.get(condition, 'Shiplap')
                part.create(f'{label} {side[0]}')
                part.obj.parent = self.obj
                part.obj['hb_part_role'] = desired_role
                part.obj['CABINET_PART'] = True
                part.obj[TAG_TEXTURED_PANEL_SIDE] = side
                part.obj.rotation_euler.x = rot_x
                part.obj.rotation_euler.y = rot_y
                part.set_input('Mirror Y', mirror_y)
                part.set_input('Mirror Z', mirror_z)
                part_obj = part.obj
            else:
                part = GeoNodeCutpart(part_obj)

            part_obj.location = location
            part_obj.rotation_euler.z = rot_z
            part.set_input('Length',    length)
            part.set_input('Width',     width)
            part.set_input('Thickness', thickness)
            try:
                pitch = float(cab.shiplap_board_width) * 0.0254
            except (ValueError, AttributeError):
                pitch = TEXTURED_SHIPLAP_PITCH
            self._textured_panel_mesh(part_obj, length, width, thickness,
                                      condition, mirror_z,
                                      shiplap_pitch=pitch,
                                      shiplap_vertical=_shiplap_vertical(cab),
                                      v_groove_spacing=_v_groove_spacing(cab))
            # Toe-kick corner notch (the CPM runs on the static mesh
            # since the cutpart GN is hidden). BACK skins never notch.
            if side in ('LEFT', 'RIGHT'):
                bay_index = 0 if side == 'LEFT' else layout.bay_count - 1
                self._drive_flush_x_notch(part_obj, layout, side,
                                          bay_index, thickness)

    # =====================================================================
    # Helpers - rail reconciliation + bay cage update
    # =====================================================================
    def _reconcile_rails(self, role, segments):
        """Match existing rail children of the given role against the desired
        segment list. Delete rails whose start_bay isn't in the segment set;
        create rails for segments that don't have a matching object yet.

        Identity key is hb_segment_start_bay. After this call every segment
        has exactly one rail object with the matching key; the dispatch loop
        in recalculate() then writes geometry to each.
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        # Pass 1: delete obsolete rails
        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != role:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        # Pass 2: figure out which starts already exist
        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == role
        }

        # Pass 3: create rails for segments that don't have an object yet
        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_rail_part(role, seg['start_bay'])

    def _reconcile_front_drop_fillers(self, segments):
        """Match drop-filler children against solver.front_drop_filler_
        segments. Three-pass delete/match/create like _reconcile_rails,
        keyed by (hb_segment_start_bay, hb_drop_filler_side) since a bay
        can carry one filler per side.
        """
        wanted = {(seg['bay'], seg['side']) for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_FRONT_DROP_FILLER:
                continue
            key = (child.get('hb_segment_start_bay'),
                   child.get('hb_drop_filler_side'))
            if key not in wanted:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing = {
            (child.get('hb_segment_start_bay'),
             child.get('hb_drop_filler_side'))
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_FRONT_DROP_FILLER
        }

        for seg in segments:
            if (seg['bay'], seg['side']) in existing:
                continue
            self._create_front_drop_filler(seg['bay'], seg['side'])

    def _create_front_drop_filler(self, bay_index, side):
        """Create one drop-filler stile keyed to its bay + side. Oriented
        like an end stile (Length vertical); the LEFT filler mirrors the
        left stile's Mirror Y so width extends into the band, the RIGHT
        filler mirrors the right stile's."""
        side_label = 'Left' if side == 'LEFT' else 'Right'
        filler = CabinetPart()
        filler.create(f'{side_label} Drop Filler {bay_index + 1}')
        filler.obj.parent = self.obj
        filler.obj['hb_part_role'] = PART_ROLE_FRONT_DROP_FILLER
        filler.obj['CABINET_PART'] = True
        filler.obj['hb_segment_start_bay'] = bay_index
        filler.obj['hb_drop_filler_side'] = side
        filler.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        filler.obj.rotation_euler.y = math.radians(-90)
        filler.obj.rotation_euler.z = math.radians(90)
        filler.set_input('Mirror Y', side == 'LEFT')
        filler.set_input('Mirror Z', True)
        return filler

    def _reconcile_carcass_bottoms(self, segments):
        """Match Bottom carcass children against segments. Three-pass
        delete/match/create keyed by hb_segment_start_bay - same shape
        as _reconcile_rails. Also cleans up any legacy non-segment Bottom
        (its hb_segment_start_bay is None which is never in wanted_starts).
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_BOTTOM:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_BOTTOM
        }

        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_carcass_bottom_part(seg['start_bay'])

    def _create_carcass_bottom_part(self, start_bay_index):
        """Create one carcass bottom part (bay floor) keyed to its segment."""
        bottom = CabinetPart()
        bottom.create(f'Bottom {start_bay_index + 1}')
        bottom.obj.parent = self.obj
        bottom.obj['hb_part_role'] = PART_ROLE_BOTTOM
        bottom.obj['CABINET_PART'] = True
        bottom.obj['hb_segment_start_bay'] = start_bay_index
        bottom.set_input('Mirror Y', True)
        bottom.set_input('Mirror Z', False)
        return bottom

    def _reconcile_kick_subfronts(self, segments):
        """Match Toe Kick Subfront children against segments. Three-pass
        delete/match/create keyed by hb_segment_start_bay - same shape
        as _reconcile_carcass_bottoms. Also deletes any legacy single-
        piece kick subfront (no hb_segment_start_bay marker).
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_TOE_KICK_SUBFRONT:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_TOE_KICK_SUBFRONT
        }

        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_kick_subfront_part(seg['start_bay'])

    def _create_kick_subfront_part(self, start_bay_index):
        """Create one toe kick subfront part keyed to its segment.
        Same orientation as the bottom rail: rotation X=90 + Mirror Z
        so Length=X, Width=Z, Thickness extends +Y into the cabinet.
        """
        kick = CabinetPart()
        kick.create(f'Toe Kick Subfront {start_bay_index + 1}')
        kick.obj.parent = self.obj
        kick.obj['hb_part_role'] = PART_ROLE_TOE_KICK_SUBFRONT
        kick.obj['CABINET_PART'] = True
        kick.obj['hb_segment_start_bay'] = start_bay_index
        kick.obj.rotation_euler.x = math.radians(90)
        kick.set_input('Mirror Z', True)
        return kick

    def _reconcile_kick_subrears(self, segments):
        """Match Toe Kick Rear Beam children against segments. Same
        three-pass delete/match/create as _reconcile_kick_subfronts.
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_TOE_KICK_SUBREAR:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_TOE_KICK_SUBREAR
        }

        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_kick_subrear_part(seg['start_bay'])

    def _create_kick_subrear_part(self, start_bay_index):
        """Create one rear kick beam part keyed to its segment. Same
        orientation as the subfront: rotation X=90 + Mirror Z so
        Length=X, Width=Z, Thickness extends toward the cabinet front.
        """
        beam = CabinetPart()
        beam.create(f'Toe Kick Rear Beam {start_bay_index + 1}')
        beam.obj.parent = self.obj
        beam.obj['hb_part_role'] = PART_ROLE_TOE_KICK_SUBREAR
        beam.obj['CABINET_PART'] = True
        beam.obj['hb_segment_start_bay'] = start_bay_index
        beam.obj.rotation_euler.x = math.radians(90)
        beam.set_input('Mirror Z', True)
        return beam

    def _reconcile_finish_kicks(self, segments):
        """Match Finish Toe Kick children against segments. Three-pass
        delete/match/create keyed by hb_segment_start_bay - same shape
        as _reconcile_kick_subfronts.
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_FINISH_TOE_KICK:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_FINISH_TOE_KICK
        }

        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_finish_kick_part(seg['start_bay'])

    def _create_finish_kick_part(self, start_bay_index):
        """Create one finish toe kick part keyed to its segment. Same
        orientation as the kick subfront.
        """
        fk = CabinetPart()
        fk.create(f'Finish Toe Kick {start_bay_index + 1}')
        fk.obj.parent = self.obj
        fk.obj['hb_part_role'] = PART_ROLE_FINISH_TOE_KICK
        fk.obj['CABINET_PART'] = True
        fk.obj['hb_segment_start_bay'] = start_bay_index
        fk.obj.rotation_euler.x = math.radians(90)
        fk.set_input('Mirror Z', True)
        return fk

    def _ensure_corner_finish_kick(self, role, name):
        """Lazy-create a corner finish kick (left or right) if absent.
        Single piece per corner - filler that varies in Thickness to
        bridge the stile back to the main finish kick front when stile-
        to-floor is on. Same orientation as the main finish kick.
        """
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                return child
        fk = CabinetPart()
        fk.create(name)
        fk.obj.parent = self.obj
        fk.obj['hb_part_role'] = role
        fk.obj['CABINET_PART'] = True
        fk.obj.rotation_euler.x = math.radians(90)
        fk.set_input('Mirror Z', True)
        return fk.obj

    def _create_mid_finish_kick(self, gap_index, side):
        """Create one mid-stile finish toe kick filler, keyed by gap +
        side. Same orientation as the end-stile corner finish kick."""
        label = 'Left' if side == 'LEFT' else 'Right'
        fk = CabinetPart()
        fk.create(f'Finish Toe Kick {label} (Mid {gap_index + 1})')
        fk.obj.parent = self.obj
        fk.obj['hb_part_role'] = PART_ROLE_MID_FINISH_KICK
        fk.obj['CABINET_PART'] = True
        fk.obj['hb_mid_stile_index'] = gap_index
        fk.obj['hb_mid_kick_side'] = side
        fk.obj.rotation_euler.x = math.radians(90)
        fk.set_input('Mirror Z', True)
        return fk.obj

    def _reconcile_mid_finish_kicks(self, layout):
        """Match mid-stile finish toe kick fillers against to-floor gaps.

        Two per to-floor mid stile (LEFT + RIGHT of the dropped division),
        keyed by (hb_mid_stile_index, hb_mid_kick_side). Creates the
        missing ones and removes any whose gap is no longer to-floor (or
        out of range / finish kick disabled). Positioned + sized in the
        main part loop (PART_ROLE_MID_FINISH_KICK branch)."""
        n_gaps = max(0, layout.bay_count - 1)
        wanted = set()
        for gi in range(n_gaps):
            if solver.has_mid_finish_kick(layout, gi):
                wanted.add((gi, 'LEFT'))
                wanted.add((gi, 'RIGHT'))
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_MID_FINISH_KICK:
                continue
            key = (child.get('hb_mid_stile_index'),
                   child.get('hb_mid_kick_side'))
            if key not in wanted:
                bpy.data.objects.remove(child, do_unlink=True)
        existing = {(c.get('hb_mid_stile_index'), c.get('hb_mid_kick_side'))
                    for c in self.obj.children
                    if c.get('hb_part_role') == PART_ROLE_MID_FINISH_KICK}
        for gi, side in wanted:
            if (gi, side) not in existing:
                self._create_mid_finish_kick(gi, side)

    def _ensure_partition_skin_slot2(self, layout):
        """Lazy-create the slot-2 partition skin (floating-bay finish) per
        gap if absent. Slots 0/1 are created up front at gap creation; slot
        2 was added later, so this backfills existing cabinets. Sized + hidden
        by the PARTITION_SKIN part-loop branch from partition_skin_panels."""
        n_gaps = max(0, layout.bay_count - 1)
        existing = {
            (c.get('hb_mid_stile_index'), c.get('hb_partition_skin_slot'))
            for c in self.obj.children
            if c.get('hb_part_role') == PART_ROLE_PARTITION_SKIN
        }
        for gi in range(n_gaps):
            if (gi, 2) in existing:
                continue
            skin = CabinetPart()
            skin.create(f'Partition Skin {gi + 1}.2')
            skin.obj.parent = self.obj
            skin.obj['hb_part_role'] = PART_ROLE_PARTITION_SKIN
            skin.obj['CABINET_PART'] = True
            skin.obj['hb_mid_stile_index'] = gi
            skin.obj['hb_partition_skin_slot'] = 2
            skin.obj.rotation_euler.y = math.radians(-90)
            skin.set_input('Mirror Y', True)
            skin.set_input('Mirror Z', True)
            skin.obj.hide_viewport = True
            skin.obj.hide_render = True

    def _drive_partition_skin_floor_notch(self, skin_obj, layout, gap_index, skin):
        """Drive the slot-2 (floating-finish) partition skin's 'Notch Front
        Bottom' modifier so the floor-dropped skin clears the toe-kick recess
        at the cabinet front.

        Active for a NOTCH toe kick when the slot-2 skin is present, UNLESS the
        gap's mid stile is itself dropped to the floor (the stile-to-floor
        construction already finishes the front, so no notch). Added lazily so
        skins built before notch support upgrade in place. Flip X=False (bottom)
        / Flip Y=True (front) match the mid-division's bottom-front corner (the
        skin shares the mid-division orientation)."""
        mod = skin_obj.modifiers.get('Notch Front Bottom')
        if mod is None:
            cpm = GeoNodeCutpart(skin_obj).add_part_modifier(
                'CPM_CORNERNOTCH', 'Notch Front Bottom')
            cpm.set_input('Flip X', False)
            cpm.set_input('Flip Y', True)
            mod = cpm.mod
        if mod.node_group is None:
            return
        notch_depth = solver.kick_notch_depth(layout)
        active = (skin is not None
                  and layout.has_toe_kick
                  and layout.toe_kick_type == 'NOTCH'
                  and notch_depth > 1e-6
                  and gap_index < len(layout.mid_stiles)
                  and not bool(layout.mid_stiles[gap_index].get('to_floor')))
        if active:
            # The floating bay carries the lift in its kick_height, so read the
            # NON-floating neighbour's kick for the real toe-kick height.
            bay_a = layout.bays[gap_index]
            neighbor_idx = (gap_index + 1
                            if bool(bay_a.get('floating_bay')) else gap_index)
            kick = layout.bays[neighbor_idx]['kick_height']
            setback = notch_depth
            route = skin['thickness']
        else:
            kick = setback = route = 0.0
        ng = mod.node_group
        for input_name, value in (('X', kick), ('Y', setback),
                                  ('Route Depth', route)):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = active
        mod.show_render = active

    def _drive_mid_div_floor_notch(self, div_obj, layout, gap_index, panel):
        """Drive a mid division's 'Notch Front Bottom' modifier so a
        division that runs to the floor clears the toe-kick recess at the
        cabinet front.

        The floor drop happens where a neighbouring bay has its carcass
        removed and this division becomes the void's side wall; without
        the notch it stands proud of the kick beside it. Gating lives in
        solver.mid_division_floor_notch. Added lazily so divisions built
        before notch support upgrade in place. Flip X=False (bottom) /
        Flip Y=True (front) match the partition skin, which shares the
        mid-division orientation."""
        mod = div_obj.modifiers.get('Notch Front Bottom')
        if mod is None:
            cpm = GeoNodeCutpart(div_obj).add_part_modifier(
                'CPM_CORNERNOTCH', 'Notch Front Bottom')
            cpm.set_input('Flip X', False)
            cpm.set_input('Flip Y', True)
            mod = cpm.mod
        if mod.node_group is None:
            return
        active, kick = solver.mid_division_floor_notch(layout, gap_index)
        notch_depth = solver.kick_notch_depth(layout)
        active = active and notch_depth > 1e-6
        if active:
            setback = notch_depth
            route = panel['thickness']
        else:
            kick = setback = route = 0.0
        ng = mod.node_group
        for input_name, value in (('X', kick), ('Y', setback),
                                  ('Route Depth', route)):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = active
        mod.show_render = active

    def _ensure_kick_return(self, role, name, mirror_z):
        """Lazy-create a left or right kick return - a vertical
        closeout panel at the inset X position running full carcass
        depth from cabinet back to main kick front. Rotation X=90 +
        Z=-90 so Length runs -Y; mirror_z flips Thickness direction
        (+X for left, -X for right).
        """
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                return child
        ret = CabinetPart()
        ret.create(name)
        ret.obj.parent = self.obj
        ret.obj['hb_part_role'] = role
        ret.obj['CABINET_PART'] = True
        ret.obj.rotation_euler.x = math.radians(90)
        ret.obj.rotation_euler.z = math.radians(-90)
        ret.set_input('Mirror Z', mirror_z)
        return ret.obj

    def _ensure_loose_kick_part(self, role, name, kind, mirror_z):
        """Lazy-create one board of the loose toe-kick ladder.

        kind 'RAIL' (front / rear): subfront orientation - rotation X=90
        + Mirror Z, so Length runs along X, Width up in Z, Thickness +Y.
        kind 'END' (left / right): kick-return orientation - rotation
        X=90 + Z=-90, so Length runs -Y front-to-back, Width up in Z,
        Thickness along X (mirror_z flips it +X / -X). Position + dims
        are written by the dispatch loop from the solver each recalc;
        the part is hidden when the cabinet isn't a LOOSE kick.
        """
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        part.obj.rotation_euler.x = math.radians(90)
        if kind == 'END':
            part.obj.rotation_euler.z = math.radians(-90)
        part.set_input('Mirror Z', mirror_z)
        return part.obj

    def _ensure_blind_panel(self, role, name, mirror_y):
        """Lazy-create a left or right blind panel - a 1/4" vertical
        partition that sits just behind the face frame, parallel to it,
        extending inboard from the cabinet end by blind_amount. Closes
        off the dead corner space when an adjacent perpendicular cabinet
        butts against this end. Same rotation convention as the end
        stiles (Y=-90 + Z=90); mirror_y flips Width direction so the
        panel grows inboard from each respective end (True for LEFT,
        False for RIGHT, matching left/right stile setup).
        """
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                return child
        panel = CabinetPart()
        panel.create(name)
        panel.obj.parent = self.obj
        panel.obj['hb_part_role'] = role
        panel.obj['CABINET_PART'] = True
        panel.obj.rotation_euler.y = math.radians(-90)
        panel.obj.rotation_euler.z = math.radians(90)
        panel.set_input('Mirror Y', mirror_y)
        panel.set_input('Mirror Z', False)
        return panel.obj

    def _find_blind_section_part(self, role, side):
        """Existing blind-section part of the given role/side, or None.
        Blind-section parts share hb_part_role with regular parts (DOOR
        leaves must, so the style + material walks dress them), so they
        carry hb_blind_section_side as the discriminating key.
        """
        for child in self.obj.children:
            if (child.get('hb_part_role') == role
                    and child.get('hb_blind_section_side') == side):
                return child
        return None

    def _ensure_blind_section_door(self, side):
        """Lazy-create the blind-section door leaf for one end - the
        hinged / top-retracting / swing-up front over the garage-level
        blind section. Same conventions as _create_front_part (rotation
        y=-90 z=90, Mirror Y=True, role DOOR) so _reapply_cabinet_style
        applies the cabinet's door style and front material for free.
        Persistent across recalcs (hidden when the treatment doesn't
        want it), unlike opening fronts which are wiped and rebuilt.
        """
        existing = self._find_blind_section_part(PART_ROLE_DOOR, side)
        if existing is not None:
            return existing
        door = CabinetPart()
        door.create(f'Blind Section Door {side.capitalize()}')
        door.obj.parent = self.obj
        door.obj['hb_part_role'] = PART_ROLE_DOOR
        door.obj['hb_blind_section_side'] = side
        door.obj['CABINET_PART'] = True
        door.obj.rotation_euler.y = math.radians(-90)
        door.obj.rotation_euler.z = math.radians(90)
        door.set_input('Mirror Y', True)
        return door.obj

    def _ensure_blind_section_tambour(self, side):
        """Lazy-create the blind-section tambour - a plain slat-stack
        mesh like the corner garage tambour. Deliberately NOT a
        CABINET_PART: it's purchased tambour stock, and the material
        walk's plain-mesh branch puts the exterior finish on the mesh
        slot via its role.
        """
        existing = self._find_blind_section_part(
            PART_ROLE_BLIND_SECTION_TAMBOUR, side)
        if existing is not None:
            return existing
        mesh = bpy.data.meshes.new('Blind Section Tambour')
        tam = hb_utils.new_object(
            f'Blind Section Tambour {side.capitalize()}', mesh)
        for coll in self.obj.users_collection:
            coll.objects.link(tam)
        tam.parent = self.obj
        tam['hb_part_role'] = PART_ROLE_BLIND_SECTION_TAMBOUR
        tam['hb_blind_section_side'] = side
        return tam

    def _clear_part_pulls(self, part_obj):
        """Remove pull instances under a persistent part. Needed because
        blind-section doors survive recalc (opening fronts are wiped
        wholesale, pulls included), so pulls would accumulate.
        """
        for child in list(part_obj.children):
            if child.get('hb_part_role') == 'PULL':
                bpy.data.objects.remove(child, do_unlink=True)

    def _ensure_blind_garage_frame_part(self, role, side, pos, name,
                                        kind):
        """Lazy-create one member of the garage-level dead-zone face
        frame. kind 'STILE': end-stile orientation (rot y=-90 z=90,
        Mirror Y by side, Mirror Z); kind 'RAIL': rail orientation
        (rot x=90, Mirror Z). Keyed (role, side, pos) - pos separates
        the BOTTOM and MID rails.
        """
        for child in self.obj.children:
            if (child.get('hb_part_role') == role
                    and child.get('hb_blind_section_side') == side
                    and child.get('hb_blind_rail_pos') == pos):
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj['hb_part_role'] = role
        part.obj['hb_blind_section_side'] = side
        part.obj['hb_blind_rail_pos'] = pos
        part.obj['CABINET_PART'] = True
        if kind == 'STILE':
            part.obj.rotation_euler.y = math.radians(-90)
            part.obj.rotation_euler.z = math.radians(90)
            part.set_input('Mirror Y', side == 'LEFT')
            part.set_input('Mirror Z', True)
        else:
            part.obj.rotation_euler.x = math.radians(90)
            part.set_input('Mirror Z', True)
        return part.obj

    def _update_blind_garage_frame(self, side, active, full, ext,
                                   amount):
        """Garage-level dead-zone face frame for one side: a stile at
        the cabinet end plus bottom and garage-top rail extensions, so
        the blind section reads as a real framed opening. Skipped for
        the flush PANEL treatment (the panel closes the section with
        no frame, the pre-existing look). In full-width mode the rails
        run through to the bay's own frame edge because the butt-line
        stile above no longer reaches the garage level.
        """
        cab_props = self.obj.face_frame_cabinet
        fft = cab_props.face_frame_thickness
        from . import props_hb_face_frame as ff_props
        stile_w = (ff_props._style_stile_width_for(cab_props, 'STANDARD')
                   or inch(2.0))
        low = side.lower()
        end_stile_w = getattr(cab_props, f'{low}_stile_width')
        rail_w = cab_props.bottom_rail_width
        mid_rail_w = cab_props.bay_mid_rail_width

        def _find(role, pos):
            for child in self.obj.children:
                if (child.get('hb_part_role') == role
                        and child.get('hb_blind_section_side') == side
                        and child.get('hb_blind_rail_pos') == pos):
                    return child
            return None

        # Never grow the objects on a cabinet that doesn't use the
        # frame: find-only when inactive, ensure when active.
        stile = _find(PART_ROLE_BLIND_GARAGE_STILE, 'STILE')
        rails = {pos: _find(PART_ROLE_BLIND_GARAGE_RAIL, pos)
                 for pos in ('BOTTOM', 'MID')}
        if active:
            if stile is None:
                stile = self._ensure_blind_garage_frame_part(
                    PART_ROLE_BLIND_GARAGE_STILE, side, 'STILE',
                    f'Garage End Stile {side.capitalize()}', 'STILE')
            for pos in ('BOTTOM', 'MID'):
                if rails[pos] is None:
                    rails[pos] = self._ensure_blind_garage_frame_part(
                        PART_ROLE_BLIND_GARAGE_RAIL, side, pos,
                        f'Garage {pos.capitalize()} Rail '
                        f'{side.capitalize()}', 'RAIL')
        for obj_ in (stile, *rails.values()):
            if obj_ is not None:
                obj_.hide_viewport = not active
                obj_.hide_render = not active
        if not active:
            return

        if side == 'LEFT':
            stile.location = (0.0, -cab_props.depth, 0.0)
            rail_x0 = stile_w
            rail_x1 = amount + (end_stile_w if full else 0.0)
        else:
            stile.location = (cab_props.width, -cab_props.depth, 0.0)
            rail_x0 = (cab_props.width - amount
                       - (end_stile_w if full else 0.0))
            rail_x1 = cab_props.width - stile_w
        sp = CabinetPart(stile)
        sp.set_input('Length', ext)
        sp.set_input('Width', stile_w)
        sp.set_input('Thickness', fft)

        length = max(rail_x1 - rail_x0, 0.0)
        for pos, z, w in (('BOTTOM', 0.0, rail_w),
                          ('MID', ext - mid_rail_w, mid_rail_w)):
            rail = rails[pos]
            rail.location = (rail_x0, -cab_props.depth, z)
            rp = CabinetPart(rail)
            rp.set_input('Length', length)
            rp.set_input('Width', w)
            rp.set_input('Thickness', fft)

    def _raise_blind_end_stile(self, side, ext):
        """Full-width bottom: the butt-line end stile stops at the
        garage top instead of running to the counter, so the garage
        level carries no mid stile and the bottom reads as ONE framed
        opening. Runs after the dispatch loop wrote the solver's
        full-band geometry; manual parts are left alone.
        """
        role = (PART_ROLE_LEFT_STILE if side == 'LEFT'
                else PART_ROLE_RIGHT_STILE)
        for child in self.obj.children:
            if child.get('hb_part_role') != role:
                continue
            if child.get('IS_MANUAL_PART'):
                return
            delta = ext - child.location.z
            if delta <= 0.0:
                return
            part = GeoNodeCutpart(child)
            try:
                cur = part.get_input('Length')
            except Exception:
                return
            child.location.z = ext
            part.set_input('Length', max(cur - delta, 0.0))
            return

    def _garage_opening_span_x(self):
        """Cabinet-local (x0, x1) of the garage bottom opening's FF
        opening, or None when the cabinet has no garage opening. Read
        off the solved opening cage transform - valid because the
        bay-cage pass runs before the blind-section pass each recalc.
        """
        for child in self.obj.children_recursive:
            if (child.get(TAG_OPENING_CAGE)
                    and child.get('SIZE_ROLE') == 'GARAGE_BOTTOM'):
                x0 = 0.0
                o = child
                while o is not None and o is not self.obj:
                    x0 += o.location.x
                    o = o.parent
                try:
                    dim_x = GeoNodeCage(child).get_input('Dim X')
                except Exception:
                    return None
                return (x0, x0 + dim_x)
        return None

    def _update_blind_section_parts(self, layout):
        """Build / hide the garage-level blind-section treatment parts
        per side. Split mode (cab_props.garage_blind_section): PANEL
        and OPEN need no parts here (the blind panel's own z-range
        handles them); DOOR / RETRACTING / SWING_UP carry a styled
        leaf, TAMBOUR a slat stack, each spanning just the dead zone.
        Full-width mode (cab_props.garage_bottom_full, the "3-opening"
        configuration): the section part spans from the cabinet end
        across the garage opening (TAMBOUR / RETRACTING / SWING_UP),
        or no part at all for DOORS - the opening's own overlay-
        extended leaves cover the whole bottom.
        """
        from types import SimpleNamespace
        cab_props = self.obj.face_frame_cabinet
        ext = float(self.obj.get('hb_garage_extension', 0.0))
        treatment = getattr(cab_props, 'garage_blind_section', 'PANEL')
        full = getattr(cab_props, 'garage_bottom_full', False)
        bottom_front = getattr(cab_props, 'garage_bottom_front', 'DOORS')
        reveal = inch(0.125)
        dt = cab_props.door_thickness
        standoff = (solver.DOOR_TO_FRAME_GAP
                    - cab_props.default_door_inset_amount)
        scene_props = bpy.context.scene.hb_face_frame
        garage_span = self._garage_opening_span_x() if full else None

        # A blind side only carries garage-level treatments when THAT
        # end's bay is the garage bay (its bottom reaches the counter).
        # A cabinet blind on both ends with the garage at one end - two
        # blind corners on one run - must leave the other end alone:
        # its dead zone exists only at upper level, where the blind
        # panel closes it.
        bays = sorted(
            [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )

        def side_garage_active(side):
            if ext <= 0.0 or not bays:
                return False
            bp = (bays[0] if side == 'LEFT' else bays[-1]).face_frame_bay
            bay_bottom = cab_props.height - bp.top_offset - bp.height
            return bay_bottom <= inch(0.25)

        for side in ('LEFT', 'RIGHT'):
            low = side.lower()
            amount = getattr(cab_props, f'blind_amount_{low}')
            is_blind = (getattr(cab_props, f'{low}_stile_type') == 'BLIND'
                        and getattr(cab_props, f'blind_{low}')
                        and amount > 0)
            active = is_blind and side_garage_active(side)
            if full:
                merged = active and garage_span is not None
                want_door = (merged
                             and bottom_front in ('RETRACTING', 'SWING_UP'))
                want_tambour = merged and bottom_front == 'TAMBOUR'
                # Section rect runs from the cabinet end across the
                # garage opening to its far FF edge.
                if side == 'LEFT':
                    sec_x0, sec_x1 = 0.0, (garage_span[1]
                                           if garage_span else amount)
                else:
                    sec_x0, sec_x1 = ((garage_span[0]
                                       if garage_span else
                                       cab_props.width - amount),
                                      cab_props.width)
            else:
                want_door = (active
                             and treatment in ('DOOR', 'RETRACTING',
                                               'SWING_UP'))
                want_tambour = active and treatment == 'TAMBOUR'
                if side == 'LEFT':
                    sec_x0, sec_x1 = 0.0, amount
                else:
                    sec_x0, sec_x1 = cab_props.width - amount, cab_props.width

            # Only ensure a part the treatment actually wants; a side
            # that never uses a treatment never grows the objects.
            door = self._find_blind_section_part(PART_ROLE_DOOR, side)
            if door is None and want_door:
                door = self._ensure_blind_section_door(side)
            if door is not None:
                door.hide_viewport = not want_door
                door.hide_render = not want_door
                self._clear_part_pulls(door)
                if want_door:
                    length = max(ext - 2.0 * reveal, 0.0)
                    width = max(sec_x1 - sec_x0 - 2.0 * reveal, 0.0)
                    door.location = (
                        sec_x0 + reveal, -cab_props.depth - standoff,
                        reveal)
                    part = CabinetPart(door)
                    part.set_input('Length', length)
                    part.set_input('Width', width)
                    part.set_input('Thickness', dt)
                    if full or treatment in ('RETRACTING', 'SWING_UP'):
                        # Flip-style pull: flat bar near the door
                        # bottom, same routing the corner garage uses.
                        self._create_pull_for_front(
                            SimpleNamespace(obj=door), PART_ROLE_DOOR,
                            {'part_dims': (length, width, dt),
                             'hinge': 'TOP'})
                    else:
                        # Hinged: standard vertical pull; hinge sits at
                        # the corner end, pull at the inner (blind
                        # stile) edge. The helper's hinge-side
                        # heuristic reads location.x, meaningless
                        # here, so override Y like the corner side
                        # doors do.
                        pull = self._create_pull_for_front(
                            SimpleNamespace(obj=door), PART_ROLE_DOOR,
                            {'part_dims': (length, width, dt)})
                        if pull is not None:
                            h_off = scene_props.pull_horizontal_offset
                            if side == 'LEFT':
                                pull.location.y = -(width - h_off)
                            else:
                                pull.location.y = -h_off

            tam = self._find_blind_section_part(
                PART_ROLE_BLIND_SECTION_TAMBOUR, side)
            if tam is None and want_tambour:
                tam = self._ensure_blind_section_tambour(side)
            if tam is not None:
                tam.hide_viewport = not want_tambour
                tam.hide_render = not want_tambour
                if want_tambour:
                    from . import types_face_frame_corner as corner
                    tam.location = (sec_x0, -cab_props.depth, 0.0)
                    corner._rebuild_tambour_slats(
                        tam, sec_x1 - sec_x0, ext,
                        cab_props.face_frame_thickness
                        + corner.TAMBOUR_INSET)

            # Garage-level dead-zone face frame: every treatment except
            # the flush blind panel gets the cabinet-end stile + rail
            # extensions; full-width mode additionally pulls the butt-
            # line end stile up to the garage top so the bottom carries
            # no mid stile.
            frame_active = active and (full or treatment != 'PANEL')
            self._update_blind_garage_frame(side, frame_active, full,
                                            ext, amount)
            if full and active:
                self._raise_blind_end_stile(side, ext)

    def _blind_panel_z_range(self, side='LEFT'):
        """Return (z_origin, z_height) for blind panel placement on the
        given end ('LEFT' / 'RIGHT'). Sits above the toe kick recess (or
        directly on the floor for upper / panel cabinets) and runs to
        the top of the cabinet. On uppers the panel follows the blind
        end BAY's vertical band: with an appliance-garage extension the
        garage bay drops to the counter while locked bays keep the old
        mount, so a panel on a non-garage end must not hang below its
        bay. Subclasses can override if a class needs a different
        baseline (e.g. lap drawer wanting to sit above the lap reveal).
        """
        cab_props = self.obj.face_frame_cabinet
        z_origin = cab_props.toe_kick_height if self._has_toe_kick() else 0.0
        z_top = cab_props.height
        if cab_props.cabinet_type == 'UPPER':
            bays = sorted(
                [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
                key=lambda c: c.get('hb_bay_index', 0),
            )
            if bays:
                bp = (bays[0] if side == 'LEFT' else bays[-1]).face_frame_bay
                # Mirrors solver bay_bottom_z for UPPER:
                # dim_z - top_offset - height.
                z_top = cab_props.height - bp.top_offset
                z_origin = max(z_origin, z_top - bp.height)
        # Appliance-garage extension with the blind section treated as
        # anything but the closed panel (open / door / tambour /
        # retracting / swing-up): the panel starts above the garage
        # zone; the treatment part covers (or deliberately opens) the
        # section below.
        garage_ext = float(self.obj.get('hb_garage_extension', 0.0))
        if (garage_ext > 0.0
                and (getattr(cab_props, 'garage_blind_section',
                             'PANEL') != 'PANEL'
                     or getattr(cab_props, 'garage_bottom_full', False))):
            z_origin = max(z_origin, garage_ext)
        z_height = max(z_top - z_origin, 0.0)
        return (z_origin, z_height)

    def _reconcile_carcass_backs(self, segments):
        """Match Back carcass children against segments. Same three-pass
        delete/match/create as _reconcile_carcass_bottoms.
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_BACK:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_BACK
        }

        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_carcass_back_part(seg['start_bay'])

    def _create_carcass_back_part(self, start_bay_index):
        """Create one carcass back panel keyed to its segment."""
        back = CabinetPart()
        back.create(f'Back {start_bay_index + 1}')
        back.obj.parent = self.obj
        back.obj['hb_part_role'] = PART_ROLE_BACK
        back.obj['CABINET_PART'] = True
        back.obj['hb_segment_start_bay'] = start_bay_index
        back.obj.rotation_euler.x = math.radians(90)
        back.obj.rotation_euler.y = math.radians(-90)
        back.set_input('Mirror Y', True)
        return back


    def _cleanup_role(self, role):
        """Remove all children with the given hb_part_role.

        Used when the cabinet's top-construction style differs from what
        was previously built (e.g., a base cabinet that has leftover
        solid TOP parts from the old architecture, or a tall cabinet
        with stretcher leftovers from a type change).
        """
        to_delete = [
            child for child in list(self.obj.children)
            if child.get('hb_part_role') == role
        ]
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

    def _reconcile_carcass_tops(self, segments):
        """Match solid Top carcass children against segments. Same
        three-pass delete/match/create as _reconcile_carcass_bottoms /
        _backs. Used for Upper / Tall cabinets only.
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != PART_ROLE_TOP:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == PART_ROLE_TOP
        }

        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_carcass_top_part(seg['start_bay'])

    def _apply_top_sink_cutout(self, top_obj, seg):
        """Cut (or clear) the centered sink opening in a carcass top.

        The hole is centered on the panel in both directions, in the
        part's own Length / Width space. Sized off the cabinet, clamped
        so it always leaves material around it; a cabinet narrower or
        shallower than the opening gets no cut rather than a panel in
        two pieces.
        """
        cab = self.obj.face_frame_cabinet
        name = 'Sink Cutout'
        existing = top_obj.modifiers.get(name)
        margin = inch(1.0)
        length = seg['length']
        width = seg['panel_dim_y']
        cw = min(getattr(cab, 'top_sink_cutout_width', 0.0),
                 length - 2.0 * margin)
        cd = min(getattr(cab, 'top_sink_cutout_depth', 0.0),
                 width - 2.0 * margin)
        wants = ((getattr(cab, 'top_sink_cutout', False)
                  or solver.is_floating_vanity(cab))
                 and cw > 0.0 and cd > 0.0)
        if not wants:
            if existing is not None:
                top_obj.modifiers.remove(existing)
            return
        cpm = CabinetPartModifier(top_obj)
        if existing is None:
            cpm.add_node('CPM_CUTOUT', name)
        else:
            cpm.mod = existing
        cpm.mod.show_viewport = True
        cpm.mod.show_render = True
        cpm.set_input('X', (length - cw) / 2.0)
        cpm.set_input('End X', (length + cw) / 2.0)
        cpm.set_input('Y', (width - cd) / 2.0)
        cpm.set_input('End Y', (width + cd) / 2.0)
        cpm.set_input('Route Depth', seg['thickness'])

    def _create_carcass_top_part(self, start_bay_index):
        """Create one solid carcass top part keyed to its segment.

        Mirror Y = True so the panel extends from y=-mt back into the
        cabinet by panel_dim_y. Mirror Z = True so it extends down by
        thickness from its z=bay_top_z origin.
        """
        top = CabinetPart()
        top.create(f'Top {start_bay_index + 1}')
        top.obj.parent = self.obj
        top.obj['hb_part_role'] = PART_ROLE_TOP
        top.obj['CABINET_PART'] = True
        top.obj['hb_segment_start_bay'] = start_bay_index
        top.set_input('Mirror Y', True)
        top.set_input('Mirror Z', True)
        return top

    def _reconcile_stretchers(self, role, segments):
        """Match stretcher children against segments. Generic over front
        vs rear: caller passes PART_ROLE_FRONT_STRETCHER or
        PART_ROLE_REAR_STRETCHER. Same three-pass delete/match/create
        shape as _reconcile_carcass_bottoms / _backs.
        """
        wanted_starts = {seg['start_bay'] for seg in segments}

        to_delete = []
        for child in list(self.obj.children):
            if child.get('hb_part_role') != role:
                continue
            if child.get('hb_segment_start_bay') not in wanted_starts:
                to_delete.append(child)
        for child in to_delete:
            bpy.data.objects.remove(child, do_unlink=True)

        existing_starts = {
            child.get('hb_segment_start_bay')
            for child in self.obj.children
            if child.get('hb_part_role') == role
        }

        for seg in segments:
            if seg['start_bay'] in existing_starts:
                continue
            self._create_stretcher_part(role, seg['start_bay'])

    def _create_stretcher_part(self, role, start_bay_index):
        """Create one stretcher part keyed to its segment.

        Front and rear differ only in name prefix and Mirror Y. Both
        sit at z = bay_top_z(start) and extend down (-Z) by thickness.
          - Front: Mirror Y = False (depth extends back into cabinet)
          - Rear:  Mirror Y = True  (depth extends forward into cabinet)
        """
        if role == PART_ROLE_FRONT_STRETCHER:
            name = f'Front Stretcher {start_bay_index + 1}'
            mirror_y = False
        else:
            name = f'Rear Stretcher {start_bay_index + 1}'
            mirror_y = True
        s = CabinetPart()
        s.create(name)
        s.obj.parent = self.obj
        s.obj['hb_part_role'] = role
        s.obj['CABINET_PART'] = True
        s.obj['hb_segment_start_bay'] = start_bay_index
        s.set_input('Mirror Y', mirror_y)
        s.set_input('Mirror Z', True)
        return s

    def _create_rail_part(self, role, start_bay_index):
        """Create a single rail part with the given role and start_bay key."""
        if role == PART_ROLE_TOP_RAIL:
            name = f'Top Rail {start_bay_index + 1}'
        else:
            name = f'Bottom Rail {start_bay_index + 1}'

        rail = CabinetPart()
        rail.create(name)
        rail.obj.parent = self.obj
        rail.obj['hb_part_role'] = role
        rail.obj['CABINET_PART'] = True
        rail.obj['hb_segment_start_bay'] = start_bay_index
        rail.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        rail.obj.rotation_euler.x = math.radians(90)
        if role == PART_ROLE_TOP_RAIL:
            rail.set_input('Mirror Y', True)
            rail.set_input('Mirror Z', True)
        else:
            rail.set_input('Mirror Z', True)
        return rail

    def _update_side_far_notch(self, side_obj, layout):
        """Drive the 'Notch Rear Bottom' modifier - the toe-kick notch a
        combined island end needs at its FAR end.

        A combined end runs past the other run's face frame as well as
        its own, so it crosses two toe kicks and has to be notched at
        both ends. This is the far one; _update_side_corner_notch cuts
        the near one. Same modifier, mirrored in Y: the notch sits at
        the part's local Y origin (Flip Y off) instead of at its far
        edge, and the origin is the end that was extended back.

        The kick it clears belongs to the OTHER run, so its height and
        setback are read off the numbers island_pair caches when the
        arrangement is synced - including the gates that leave it
        square (no kick, a flush kick, a stile already carried to the
        floor, an inset kick). Added lazily and left inactive rather
        than absent, so separating an end re-squares the panel.
        """
        kick, setback_raw, far_fft = island_pair.far_end_notch(
            self.obj, 'LEFT'
            if side_obj.get('hb_part_role') in (PART_ROLE_LEFT_SIDE,
                                                PART_ROLE_LEFT_SIDE_SEAM)
            else 'RIGHT')
        # Same shallowing as solver.kick_notch_depth, against the FAR
        # run's frame: the setback is measured off that run's face frame
        # outer face, and a board running past it starts one frame
        # thickness behind that plane.
        setback = max(0.0, setback_raw - far_fft)
        mod = side_obj.modifiers.get('Notch Rear Bottom')
        if mod is None:
            if kick <= 0.0:
                return          # never combined - no modifier needed
            wrapper = GeoNodeCutpart(side_obj)
            cpm = wrapper.add_part_modifier(
                'CPM_CORNERNOTCH', 'Notch Rear Bottom')
            cpm.set_input('Flip X', False)
            cpm.set_input('Flip Y', False)
            mod = cpm.mod
        if mod.node_group is None:
            return
        role = side_obj.get('hb_part_role')
        thickness = (solver.left_side_thickness(layout)
                     if role in (PART_ROLE_LEFT_SIDE, PART_ROLE_LEFT_SIDE_SEAM)
                     else solver.right_side_thickness(layout))
        active = kick > 0.0 and setback > 0.0 and thickness > 0.0
        ng = mod.node_group
        for input_name, value in (
            ('X', kick if active else 0.0),
            ('Y', setback if active else 0.0),
            ('Route Depth', thickness if active else 0.0),
        ):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = active
        mod.show_render = active

    def _update_side_corner_notch(self, side_obj, layout, bay_index):
        """Drive the side's 'Notch Front Bottom' modifier from the
        cabinet's toe kick type. Active only for NOTCH and only when
        that side's stile is NOT extending to the floor - a stile-to-
        floor stile already encloses the kick corner from the front,
        so a notched side would leave an exposed gap behind it. FLUSH
        / FLOATING / uppers also leave the notch inactive. Adds the
        modifier lazily so cabinets built before NOTCH support are
        upgraded in place on the next recalc.
        """
        mod = side_obj.modifiers.get('Notch Front Bottom')
        if mod is None:
            wrapper = GeoNodeCutpart(side_obj)
            cpm = wrapper.add_part_modifier(
                'CPM_CORNERNOTCH', 'Notch Front Bottom')
            cpm.set_input('Flip X', False)
            cpm.set_input('Flip Y', True)
            mod = cpm.mod
        if mod.node_group is None:
            return
        role = side_obj.get('hb_part_role')
        if role == PART_ROLE_LEFT_SIDE:
            stile_to_floor = solver.left_stile_to_floor(layout)
            has_inset = layout.kick_inset_left > 0
            side_thickness = solver.left_side_thickness(layout)
        else:
            stile_to_floor = solver.right_stile_to_floor(layout)
            has_inset = layout.kick_inset_right > 0
            side_thickness = solver.right_side_thickness(layout)
        # End bay flagged floating_bay forces the side to anchor at the
        # bay bottom (see solver.side_bottom_z), so the notch becomes
        # redundant just like the has_inset case.
        bay_floating = (
            0 <= bay_index < len(layout.bays)
            and bool(layout.bays[bay_index].get('floating_bay'))
        )
        # Side already floats by kick_height when there's an inset on
        # this side, so the notch (which only existed to clear the
        # recess in a floor-anchored side) becomes redundant.
        # A setback inside the face-frame band leaves nothing behind
        # the frame to cut, and the kick reads flush.
        notch_depth = solver.kick_notch_depth(layout)
        active = (layout.has_toe_kick
                  and layout.toe_kick_type == 'NOTCH'
                  and not stile_to_floor
                  and not has_inset
                  and not bay_floating
                  and notch_depth > 1e-6
                  and 0 <= bay_index < len(layout.bays))
        if active:
            bay = layout.bays[bay_index]
            kick = bay['kick_height']
            setback = notch_depth
            # Route Depth must cut through the FULL side thickness, not
            # just the cabinet's material_thickness default. FINISHED
            # sides are 3/4" thick (vs 1/2" default), and a notch that
            # only cuts 1/2" would leave 1/4" of material in the kick
            # recess.
            thickness = side_thickness
        else:
            kick = setback = thickness = 0.0
        ng = mod.node_group
        for input_name, value in (
            ('X', kick),
            ('Y', setback),
            ('Route Depth', thickness),
        ):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = active
        mod.show_render = active

    # Flip Z on a CPM_CUTOUT is read in the part's PRE-MIRROR frame, so
    # the value that routes the INNER face is not the same on both sides:
    # the left side builds Mirror Z = True and the right Mirror Z = False
    # (see _build_carcass_parts), which puts each panel's material on the
    # opposite side of local z = 0 while local z = 0 stays the OUTER face
    # on both. Flip Z = the side's Mirror Z would enter from that outer
    # face - a visible route down the show side of a finished end.
    _BACK_NOTCH_FLIP_Z = {PART_ROLE_LEFT_SIDE: False,
                          PART_ROLE_RIGHT_SIDE: True,
                          PART_ROLE_LEFT_SIDE_SEAM: False,
                          PART_ROLE_RIGHT_SIDE_SEAM: True}

    def _update_side_back_notch(self, side_obj, layout, bay_index):
        """Drive the side's 'Back Notch' modifier - the rabbet a FINISHED
        end carries down its back edge for the carcass back to land in
        (solver.back_notch_depth; the back widens into it in
        carcass_back_segments).

        Runs the full length of the side, one back thickness wide off the
        back edge. Added lazily so cabinets built before back notching
        are upgraded in place on their next recalc, and inactive (rather
        than absent) on every other condition so flipping a side back to
        FINISHED re-cuts it.

        Skipped on angled / back-extended cabinets: there the back is
        trapezoidal and the side splays off the cabinet back plane, so a
        square rabbet taken off local Y would not line up with it. Those
        keep the butted back they have today.
        """
        cab = self.obj.face_frame_cabinet
        role = side_obj.get('hb_part_role')
        mod = side_obj.modifiers.get('Back Notch')
        if mod is None:
            wrapper = GeoNodeCutpart(side_obj)
            cpm = wrapper.add_part_modifier('CPM_CUTOUT', 'Back Notch')
            cpm.set_input('Flip Z', self._BACK_NOTCH_FLIP_Z.get(role, False))
            mod = cpm.mod
        if mod.node_group is None:
            return
        side = ('LEFT' if role in (PART_ROLE_LEFT_SIDE, PART_ROLE_LEFT_SIDE_SEAM)
                else 'RIGHT')
        depth = solver.back_notch_depth(layout, side)
        splayed = bool(layout.is_angled
                       or getattr(cab, 'extend_back_left', 0.0)
                       or getattr(cab, 'extend_back_right', 0.0))
        active = depth > 0.0 and not splayed
        if active:
            part = GeoNodeCutpart(side_obj)
            length = part.get_input('Length')
            width = part.get_input('Width')
            # Y is measured from the panel's FRONT edge, not from its
            # origin: the sides build Mirror Y = True and the cutout
            # reads Y in the pre-mirror frame (the same reason Flip Z
            # differs per side). The back edge is therefore at Y =
            # Width, and the notch is the last back_thickness of it.
            # Square anchoring already puts the side's Y origin on this
            # bay's back plane, so the offset is 0; it is non-zero only
            # if the two ever diverge.
            in_range = 0 <= bay_index < len(layout.bays)
            bay = layout.bays[bay_index] if in_range else layout.bays[0]
            back_y = -layout.dim_y + bay['depth']
            offset = max(0.0, side_obj.location.y - back_y)
            y1 = max(0.0, width - offset)
            y0 = max(0.0, y1 - solver.back_thickness(layout))
        else:
            length = y0 = y1 = depth = 0.0
        ng = mod.node_group
        for input_name, value in (
            ('X', 0.0),
            ('End X', length),
            ('Y', y0),
            ('End Y', y1),
            ('Route Depth', depth),
        ):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = active
        mod.show_render = active

    def _update_mid_div_notches(self, mid_div_obj, panel):
        """Drive the two CPM_CORNERNOTCH modifiers on a slot-0 mid-div.

        The build path adds 'Notch Top Front' and 'Notch Top Back' with
        their Flip flags pre-set. Each recalc updates X / Y / Route Depth
        and toggles show_viewport / show_render based on the solver's
        notch flags. The two gate independently: a front-dropped (sink /
        cooktop) bay's front stretcher terminates at the division face
        instead of crossing, so only the rear notch is cut there. Slot-1
        mid-divs (diff-depth case) have no notch modifiers and silently
        no-op here.
        """
        back_active = panel.get('notch_active', False)
        front_active = panel.get('notch_front_active', back_active)
        size_x = panel.get('notch_x', 0.0)
        size_y = panel.get('notch_y', 0.0)
        route = panel.get('notch_route_depth', 0.0)
        for name, active in (('Notch Top Front', front_active),
                             ('Notch Top Back', back_active)):
            mod = mid_div_obj.modifiers.get(name)
            if mod is None:
                continue  # slot 1 lacks these modifiers
            ng = mod.node_group
            if ng is None:
                continue
            for input_name, value in (
                ('X', size_x),
                ('Y', size_y),
                ('Route Depth', route),
            ):
                node_input = ng.interface.items_tree.get(input_name)
                if node_input is not None:
                    hb_utils.set_gn_input(mod, node_input.identifier, value)
            mod.show_viewport = active
            mod.show_render = active

    def _bay_has_false_front(self, bay_obj):
        """True when any opening in the bay is a FALSE_FRONT -- the
        cleanest signal that the bay houses a sink basin (a working
        drawer can't sit in front of one)."""
        for child in bay_obj.children_recursive:
            if not child.get(TAG_OPENING_CAGE):
                continue
            if child.face_frame_opening.front_type == 'FALSE_FRONT':
                return True
        return False

    def _create_appliance_annotation(self, bay_obj, kind):
        """One GeoNodeRectangle (square outline + centered word) flat on
        top of the bay, parented to the bay cage so it rides the cabinet
        into every 2D view. Bay-local frame: origin front-left-bottom,
        +Y toward the back, top at Dim Z."""
        cage = GeoNodeCage(bay_obj)
        dim_x = cage.get_input('Dim X')
        dim_y = cage.get_input('Dim Y')
        dim_z = cage.get_input('Dim Z')
        margin = min(APPLIANCE_ANNO_SIDE_MARGIN, dim_x * 0.25)
        rect = GeoNodeRectangle()
        rect.create(f"{kind.title()} Annotation")
        rect.obj.parent = bay_obj
        rect.obj.location = (margin, dim_y / 4.0, dim_z + APPLIANCE_ANNO_Z_LIFT)
        rect.set_input('Dim X', dim_x - margin * 2.0)
        rect.set_input('Dim Y', dim_y / 2.0)
        rect.set_input('Line Thickness', APPLIANCE_ANNO_LINE_THICKNESS)
        rect.set_input('Text', kind)
        rect.set_input('Text Size', APPLIANCE_ANNO_TEXT_SIZE)
        rect.set_input('Text Y Offset', APPLIANCE_ANNO_TEXT_Y_OFFSET)
        rect.obj['hb_part_role'] = PART_ROLE_APPLIANCE_ANNOTATION
        rect.obj['IS_2D_ANNOTATION'] = True
        rect.obj['APPLIANCE_ANNOTATION'] = True
        rect.obj['IS_SINK_ANNOTATION' if kind == 'SINK'
                 else 'IS_COOKTOP_ANNOTATION'] = True
        return rect

    def _apply_appliance_annotations(self, layout):
        """Wipe-and-recreate the square + word annotation on every
        appliance bay (same lifecycle as accessory labels, so it tracks
        bay size/drop). Triggers: an APPLIANCE_BAY stamp on the bay cage
        (set by hb_face_frame.add_appliance_to_bay), or -- for the
        dedicated SinkFaceFrameCabinet -- the bay holding the false
        front (the basin bay), no stamp required."""
        for child in list(self.obj.children_recursive):
            if child.get('hb_part_role') == PART_ROLE_APPLIANCE_ANNOTATION:
                bpy.data.objects.remove(child, do_unlink=True)

        class_name = self.obj.get('CLASS_NAME')
        is_sink_cabinet = class_name == 'SinkFaceFrameCabinet'
        is_cooktop_cabinet = class_name == 'CooktopFaceFrameCabinet'
        sink_cutters = []
        from ..common import appliance_geo
        galley_sink = appliance_geo.opening_appliance(self.obj)
        if galley_sink is not None:
            sink_cutters.append(appliance_geo.sink_clearance_cutter(galley_sink))
        for bay_obj in [c for c in self.obj.children if c.get(TAG_BAY_CAGE)]:
            if bay_obj.hide_viewport:
                self._update_countertop_appliance_in_bay(bay_obj, None)
                continue
            kind = bay_obj.get('APPLIANCE_BAY')
            if not kind and is_sink_cabinet and self._bay_has_false_front(bay_obj):
                kind = 'SINK'
            if not kind and is_cooktop_cabinet:
                kind = 'COOKTOP'
            if kind in ('SINK', 'COOKTOP'):
                self._create_appliance_annotation(bay_obj, kind)
            # After the annotation: the appliance decides whether it shows.
            cutter = self._update_countertop_appliance_in_bay(
                bay_obj, kind if kind in ('SINK', 'COOKTOP') else None)
            if cutter is not None:
                sink_cutters.append(cutter)
        # The top stretchers span every bay, so they are cut once, by
        # the first sink; a second sink in one cabinet is not handled.
        self._apply_sink_clearance(
            [c for c in self.obj.children
             if c.get('hb_part_role') in (PART_ROLE_FRONT_STRETCHER,
                                          PART_ROLE_REAR_STRETCHER,
                                          PART_ROLE_MID_DIVISION,
                                          PART_ROLE_BAY_DIVISION)],
            sink_cutters[0] if sink_cutters else None)
        # A cabinet-wide sink reaches into every bay, so the interior
        # parts of every bay clear it too.
        if galley_sink is not None:
            self._apply_sink_clearance(
                [c for c in self.obj.children_recursive
                 if c.get('hb_part_role') in self.SINK_CLEARANCE_INTERIOR_ROLES],
                sink_cutters[0])

    SINK_CLEARANCE_MOD_NAME = 'Sink Clearance'
    SINK_CLEARANCE_INTERIOR_ROLES = frozenset({
        PART_ROLE_BAY_SHELF, PART_ROLE_ADJUSTABLE_SHELF, PART_ROLE_GLASS_SHELF,
        PART_ROLE_TRAY_LOCKED_SHELF, PART_ROLE_INTERIOR_FIXED_SHELF,
        'TRAY_DIVIDER', 'ROLLOUT_SPACER', 'PULLOUT_SPACER',
    })
    SINK_CLEARANCE_SHELF_ROLES = frozenset({
        PART_ROLE_BAY_SHELF, PART_ROLE_ADJUSTABLE_SHELF, PART_ROLE_GLASS_SHELF,
        PART_ROLE_TRAY_LOCKED_SHELF, PART_ROLE_INTERIOR_FIXED_SHELF,
    })

    def _update_countertop_appliance_in_bay(self, bay_obj, kind):
        """A sink or cooktop bay carries the appliance model itself, hung
        from the cabinet top; the annotation above stays the 2D symbol.
        Any other bay carries none. The bay's shelves are cut around the
        appliance; returns its clearance cutter so the caller can cut
        the cabinet-wide parts too."""
        from ..common import appliance_geo
        cutter = None
        if kind is not None:
            top_z = self.get_input('Dim Z') - bay_obj.location.z
            cage = appliance_geo.sync_bay_appliance(bay_obj, kind, top_z)
            if cage is not None:
                cutter = appliance_geo.sink_clearance_cutter(cage)
        else:
            appliance_geo.remove_opening_appliance(bay_obj)
        self._apply_sink_clearance(
            [c for c in bay_obj.children_recursive
             if c.get('hb_part_role') in self.SINK_CLEARANCE_SHELF_ROLES],
            cutter)
        return cutter

    def _apply_sink_clearance(self, parts, cutter):
        """Every part carries a boolean DIFFERENCE against the sink's
        clearance cutter, or loses it when there is no sink -- the same
        lazy-cutter + boolean pattern as the angled cuts."""
        for part in parts:
            mod = part.modifiers.get(self.SINK_CLEARANCE_MOD_NAME)
            if cutter is None:
                if mod is not None:
                    part.modifiers.remove(mod)
                continue
            if mod is None:
                mod = part.modifiers.new(name=self.SINK_CLEARANCE_MOD_NAME,
                                         type='BOOLEAN')
                mod.operation = 'DIFFERENCE'
            if mod.object is not cutter:
                mod.object = cutter

    def _update_bay_cage(self, bay_obj, layout, bay_index):
        """Position and size a single bay cage from the solver. Cascades
        to the bay's opening cage children so they stay in sync with the
        bay's face frame opening dimensions.
        """
        if bay_index >= layout.bay_count:
            bay_obj.hide_viewport = True
            for child in bay_obj.children:
                if child.get(TAG_OPENING_CAGE):
                    child.hide_viewport = True
            return
        bay_obj.hide_viewport = False
        bay = FaceFrameBay(bay_obj)
        pos = solver.bay_cage_position(layout, bay_index)
        dim_x, dim_y, dim_z = solver.bay_cage_dims(layout, bay_index)
        bay_obj.location = pos
        # Rotate the bay around Z so its local +X aligns with the FF
        # direction; opening cages, front pivots, fronts, and any
        # interior items inherit the angle automatically through the
        # parent transform. Zero in square cabinets. bay_front_angle
        # collapses to face_frame_angle on single-bay cabinets and
        # resolves per bay on angled_multi (only the end bay whose side
        # is unlocked rotates; middle bays stay square).
        bay_obj.rotation_euler.z = solver.bay_front_angle(layout, bay_index)
        bay.set_input('Dim X', dim_x)
        bay.set_input('Dim Y', dim_y)
        bay.set_input('Dim Z', dim_z)
        bay.set_input('Mirror Y', False)
        self._update_openings_in_bay(bay_obj, layout, bay_index)

    def _update_openings_in_bay(self, bay_obj, layout, bay_index):
        """Reconcile a bay's tree against the solver's parts list.

        bay_openings() returns three lists:
          - leaves: each maps to an opening cage object (matched by name)
          - splitters: each maps to a bay mid rail or mid stile part
          - backings: each maps to a bay division or shelf part

        Opening cages are matched in place (by obj.name) so their props
        survive across recalcs. Splitters and backings are deleted and
        recreated each pass since they hold no user state - all of
        their parameters are derived from the split node's props.

        Split-node empties are forced to local origin so opening cage
        bay-local coords stay accurate at any tree depth.
        """
        parts = solver.bay_openings(layout, bay_index)
        leaves_by_name = {r['obj_name']: r for r in parts['leaves']}
        cage_dim_y = solver.bay_cage_dims(layout, bay_index)[1]

        # Snapshot descendants by tag UP FRONT. The opening loop below
        # calls _update_fronts_in_opening, which removes pivot and
        # front-part children of each cage; if we walked
        # children_recursive directly, those removed refs would still
        # be in our iteration and the next .get() would raise
        # "StructRNA of type Object has been removed". Filtering down
        # to cages and split nodes (neither of which is touched by the
        # inner deletions) keeps every ref live across the loop.
        all_descendants = list(bay_obj.children_recursive)
        split_nodes = [d for d in all_descendants
                       if d.get(TAG_SPLIT_NODE)]
        opening_cages = [d for d in all_descendants
                         if d.get(TAG_OPENING_CAGE)]

        # Pass 1a: pin split-node empties to local origin
        for sn in split_nodes:
            sn.location = (0.0, 0.0, 0.0)

        # Pass 1b: opening cages - in-place match by obj.name
        # Where the appliance openings sit, top to bottom, so Auto can
        # tell a microwave over an oven from a lone oven.
        appliance_zs = sorted(
            leaves_by_name[c.name]['cage_z'] for c in opening_cages
            if c.name in leaves_by_name
            and c.face_frame_opening.front_type == 'APPLIANCE')
        for cage in opening_cages:
            rect = leaves_by_name.get(cage.name)
            if rect is None:
                cage.hide_viewport = True
                self._update_appliance_in_opening(cage, live=False)
                continue
            cage.hide_viewport = False
            op = FaceFrameOpening(cage)
            cage.location = (rect['cage_x'], 0.0, rect['cage_z'])
            op.set_input('Dim X', rect['cage_dim_x'])
            op.set_input('Dim Y', cage_dim_y)
            op.set_input('Dim Z', rect['cage_dim_z'])
            op.set_input('Mirror Y', False)
            self._update_fronts_in_opening(cage, layout, rect)
            self._update_interior_items_in_opening(cage, layout, rect)
            self._update_appliance_in_opening(cage, rect,
                                              appliance_zs=appliance_zs)

        # Pass 2: splitters (mid rails / mid stiles) - delete & recreate
        self._reconcile_bay_splitters(bay_obj, parts['splitters'])
        # Pass 3: backings (divisions / shelves) - delete & recreate.
        # Backings are carcass-deep partitions; for face-frame only
        # roots (panels) we still call the reconcile with an empty
        # rect list so its internal wipe cleans up any stale backings
        # (e.g. on a panel that had splits before this gate landed).
        # remove_carcass on this bay also drops backings - same wipe
        # path so existing ones are cleaned up when the flag is set.
        bay_drops_carcass = bay_obj.face_frame_bay.remove_carcass
        if not self._has_carcass() or bay_drops_carcass:
            backing_rects = []
        else:
            backing_rects = parts['backings']
        self._reconcile_bay_backings(bay_obj, backing_rects)

    def _reconcile_bay_splitters(self, bay_obj, splitter_rects):
        """Delete every existing bay splitter (mid rail / mid stile)
        anywhere under the bay, then rebuild from `splitter_rects`.

        Each rect carries the parent split-node name; the new part is
        parented to that split node so cleanup cascades when the split
        is removed. Coords from the rect are bay-local; with the split
        node defensively pinned at (0,0,0), bay-local equals
        split-node-local for these parts.
        """
        for descendant in list(bay_obj.children_recursive):
            # BAY_SPLITTER_ROLES catches mid rails / mid stiles. The
            # IS_BAY_SPLITTER_RAIL marker also catches a bay splitter that
            # was retagged BOTTOM_RAIL (remove_bottom open-bottom bays) so
            # the rebuild stays idempotent -- real cabinet bottom rails are
            # parented to the cabinet, never under the bay, so they are out
            # of this sweep's reach.
            if (descendant.get('hb_part_role') in BAY_SPLITTER_ROLES
                    or descendant.get('IS_BAY_SPLITTER_RAIL')):
                bpy.data.objects.remove(descendant, do_unlink=True)

        for rect in splitter_rects:
            split_obj = bpy.data.objects.get(rect['split_node_name'])
            if split_obj is None:
                continue
            if rect['role'] == 'BAY_MID_RAIL':
                self._create_bay_mid_rail(split_obj, rect)
            else:
                self._create_bay_mid_stile(split_obj, rect)

    def _reconcile_bay_backings(self, bay_obj, backing_rects):
        """Delete every existing bay backing part anywhere under the
        bay, then rebuild from `backing_rects`. Same pattern as
        _reconcile_bay_splitters; backings are parented to their split
        node so cleanup cascades naturally."""
        for descendant in list(bay_obj.children_recursive):
            if descendant.get('hb_part_role') in BAY_BACKING_ROLES:
                bpy.data.objects.remove(descendant, do_unlink=True)

        for rect in backing_rects:
            split_obj = bpy.data.objects.get(rect['split_node_name'])
            if split_obj is None:
                continue
            self._create_bay_backing(split_obj, rect)

    def _create_bay_mid_rail(self, split_obj, rect):
        """Mid rail orientation matches the bay's bottom rail (rotation
        X=90, Mirror Z=True): Length goes +X, Width goes +Z, Thickness
        goes +Y from the part origin. Origin sits at the rail's
        bottom-front-left corner in bay-local coords."""
        rail = CabinetPart()
        idx = rect['splitter_index'] + 1
        # A remove_bottom bay's lowest framed splitter is the section's
        # bottom rail, not a mid rail (e.g. refrigerator cabinet). Tag it
        # BOTTOM_RAIL so downstream consumers / the toe-kick detail
        # reader classify it correctly; IS_BAY_SPLITTER_RAIL keeps the
        # reconcile sweep able to clean it on rebuild.
        as_bottom = bool(rect.get('as_bottom_rail'))
        rail.create(f'Bottom Rail {idx}' if as_bottom
                    else f'Bay Mid Rail {idx}')
        rail.obj.parent = split_obj
        rail.obj['hb_part_role'] = (PART_ROLE_BOTTOM_RAIL if as_bottom
                                    else PART_ROLE_BAY_MID_RAIL)
        rail.obj['IS_BAY_SPLITTER_RAIL'] = True
        rail.obj['CABINET_PART'] = True
        rail.obj['hb_split_node_name'] = rect['split_node_name']
        rail.obj['hb_splitter_index'] = rect['splitter_index']
        rail.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        rail.obj.rotation_euler.x = math.radians(90)
        rail.set_input('Mirror Z', True)
        rail.obj.location = (rect['x'], rect['y'], rect['z'])
        rail.set_input('Length', rect['length'])
        rail.set_input('Width', rect['splitter_width'])
        rail.set_input('Thickness', rect['thickness'])
        return rail

    def _create_bay_mid_stile(self, split_obj, rect):
        """Mid stile orientation matches the cabinet-level left end
        stile (rotation y=-90, z=90, Mirror Y=True, Mirror Z=True):
        Length goes +Z, Width goes +X, Thickness goes +Y. Origin at
        the stile's bottom-front-left corner in bay-local coords."""
        stile = CabinetPart()
        idx = rect['splitter_index'] + 1
        stile.create(f'Bay Mid Stile {idx}')
        stile.obj.parent = split_obj
        stile.obj['hb_part_role'] = PART_ROLE_BAY_MID_STILE
        stile.obj['CABINET_PART'] = True
        stile.obj['hb_split_node_name'] = rect['split_node_name']
        stile.obj['hb_splitter_index'] = rect['splitter_index']
        stile.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        stile.obj.rotation_euler.y = math.radians(-90)
        stile.obj.rotation_euler.z = math.radians(90)
        stile.set_input('Mirror Y', True)
        stile.set_input('Mirror Z', True)
        stile.obj.location = (rect['x'], rect['y'], rect['z'])
        stile.set_input('Length', rect['length'])
        stile.set_input('Width', rect['splitter_width'])
        stile.set_input('Thickness', rect['thickness'])
        return stile

    def _create_bay_backing(self, split_obj, rect):
        """Backing (division / shelf) - carcass-deep panel behind a
        splitter. For H-splits (rect['axis'] == 'H') the backing is a
        horizontal panel: no rotation, Length+X, Width+Y, Thickness+Z.
        For V-splits the backing is a vertical panel: rotation y=-90
        with Mirror Y=True and Mirror Z=True (matches cabinet-level
        mid division), Length+Z, Width+Y, Thickness+X.
        """
        part = CabinetPart()
        kind_label = 'Division' if rect['role'] == 'BAY_DIVISION' else 'Shelf'
        idx = rect['splitter_index'] + 1
        part.create(f'Bay {kind_label} {idx}')
        part.obj.parent = split_obj
        role = (PART_ROLE_BAY_DIVISION if rect['role'] == 'BAY_DIVISION'
                else PART_ROLE_BAY_SHELF)
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        part.obj['hb_split_node_name'] = rect['split_node_name']
        part.obj['hb_splitter_index'] = rect['splitter_index']
        # Same right-click menu as the splitter it backs. Without this a
        # backing has no MENU_ID and the part commands never open on it,
        # which took the shelf entries in that menu out of reach.
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        if rect['axis'] == 'H':
            # Horizontal panel - no rotation, default mirror flags
            part.obj.location = (rect['x'], rect['y'], rect['z'])
            part.set_input('Length', rect['length'])
            part.set_input('Width', rect['width'])
            part.set_input('Thickness', rect['thickness'])
        else:
            # Vertical division panel: rotation Y=-90 with Mirror Z=True
            # gives Length+Z, Width+Y, Thickness+X. Mirror Y is left
            # off so Width extends +Y from the origin (back of face
            # frame in bay-local toward the back panel) - the cabinet-
            # level mid division uses Mirror Y=True, but in a bay-
            # internal context that flips depth backward and lands the
            # division outside the carcass.
            part.obj.rotation_euler.y = math.radians(-90)
            part.set_input('Mirror Y', False)
            part.set_input('Mirror Z', True)
            part.obj.location = (rect['x'], rect['y'], rect['z'])
            part.set_input('Length', rect['length'])
            part.set_input('Width', rect['width'])
            part.set_input('Thickness', rect['thickness'])
        return part

    def _update_appliance_in_opening(self, opening_obj, rect=None,
                                     live=True, appliance_zs=()):
        """An appliance opening houses its appliance model, sized on
        every recalc to the frame opening -- between the stiles and
        under the rail, which the rect's reveals measure in from the
        carcass cavity. A refrigerator cabinet's opening takes the
        refrigerator; an APPLIANCE front takes the wall oven or
        microwave its Appliance setting names, between its fillers. Any
        other opening, or one that has gone away, carries none."""
        from ..common import appliance_geo
        kind = None
        span = None
        if live and rect is not None:
            x0 = rect['reveal_left']
            width = (rect['cage_dim_x'] - rect['reveal_left']
                     - rect['reveal_right'])
            z0 = rect['reveal_bottom']
            height = (rect['cage_dim_z'] - rect['reveal_top']
                      - rect['reveal_bottom'])
            props = opening_obj.face_frame_opening
            if opening_obj.get('SIZE_ROLE') == 'REFRIGERATOR':
                kind = 'REFRIGERATOR'
            elif props.front_type == 'APPLIANCE':
                choice = props.appliance_kind
                if choice == 'AUTO':
                    # A short opening is a microwave; so is the top of
                    # a stack of two, which is a microwave over an oven.
                    top_of_stack = (len(appliance_zs) >= 2
                                    and rect['cage_z'] >= appliance_zs[-1]
                                    - 1e-6)
                    choice = ('MICROWAVE' if height < inch(20.0)
                              or top_of_stack else 'OVEN')
                kind = {'OVEN': 'WALL_OVEN',
                        'MICROWAVE': 'MICROWAVE'}.get(choice)
                left, right = solver.appliance_filler_widths(rect, props)
                x0 += left
                width -= left + right
            span = (x0, width, z0, height)
        if kind is not None:
            appliance_geo.sync_opening_appliance(opening_obj, kind, span)
        else:
            appliance_geo.remove_opening_appliance(opening_obj)

    def _update_fronts_in_opening(self, opening_obj, layout, rect):
        """Reconcile front parts under an opening cage.

        Structure: opening cage -> front pivot empty -> front part.
        The pivot holds the swing rotation (DOOR / PULLOUT-as-door) or
        slide translation (DRAWER_FRONT / PULLOUT slide) so the front
        part itself sits at a fixed local transform inside the pivot.
        Pulling the visual open state out of the part keeps the part's
        geometry math independent of swing_percent.

        `rect` is the opening's solver rect (from bay_openings) - it
        provides cage size and reveals so the solver can size the
        front without re-walking the bay tree.

        v1 strategy: delete-and-recreate the pivot + part on every
        recalc. Front parts hold no user state, so identity loss is
        cheap. Once front parts grow editable per-part props (style,
        material override) this can switch to in-place reconciliation.
        Also handles legacy doors that were direct children of the
        opening (pre-pivot) by deleting them.
        """
        # Manual fronts: the user applied + hand-edited the front(s) under
        # this opening via hb_face_frame.make_part_editable. The flag lives on
        # the OPENING cage (not the front) because front objects are torn down
        # and rebuilt here on every recalc - the opening survives. Skip the
        # wipe + rebuild so the applied front persists; Revert clears the flag
        # to resume normal rebuilding.
        if opening_obj.get('IS_MANUAL_FRONT'):
            return
        op_props = opening_obj.face_frame_opening
        front_type = op_props.front_type
        cab_props = self.obj.face_frame_cabinet

        # Wipe existing pivots, parts, and any legacy direct-child fronts.
        # Use children_recursive so pull instances parented under the door
        # part (grandchildren of the pivot) also get cleaned.
        for child in list(opening_obj.children):
            role = child.get('hb_part_role')
            if role == PART_ROLE_FRONT_PIVOT:
                # Reverse so deeper descendants unparent before ancestors.
                for sub in reversed(list(child.children_recursive)):
                    if sub.name in bpy.data.objects:
                        bpy.data.objects.remove(sub, do_unlink=True)
                bpy.data.objects.remove(child, do_unlink=True)
            elif role in FRONT_PART_ROLES:
                bpy.data.objects.remove(child, do_unlink=True)

        if front_type == 'NONE':
            return

        for leaf_index, leaf in enumerate(solver.front_leaves(
            layout, rect, cab_props, op_props
        )):
            pivot = self._create_front_pivot(opening_obj)
            pivot.location = leaf['pivot_position']
            pivot.rotation_euler = leaf['pivot_rotation']

            front = self._create_front_part(
                pivot, leaf['role'], leaf['name']
            )
            # Which leaf of the opening this is (0 = leftmost). Fronts
            # are rebuilt every recalc, so per-LEAF overrides stored on
            # the opening (the round-top door shape) key off this.
            front.obj['HB_LEAF_INDEX'] = leaf_index
            front.obj.location = leaf['part_position']
            length, width, thickness = leaf['part_dims']
            front.set_input('Length', length)
            front.set_input('Width', width)
            front.set_input('Thickness', thickness)

            # Textured inset panel (beadboard / shiplap): carve the
            # static mesh in place of the plain slab. The carve puts the
            # grooves on the part's local z=0 face with the material
            # extending -z (mirror_z), so shift the part back one
            # thickness along the pivot's front axis: the panel body
            # lands where the slab sat and the grooves face the room.
            if leaf['role'] == PART_ROLE_INSET_PANEL:
                tex = getattr(op_props, 'inset_panel_type', 'PANEL')
                if tex in ('BEADBOARD', 'SHIPLAP', 'V_GROOVE'):
                    front.obj.location.y = (
                        leaf['part_position'][1] - thickness)
                    self._textured_panel_mesh(
                        front.obj, length, width, thickness, tex, True)

            # Per-leaf frame-width override (tri-view mirror doors zero the
            # interior stiles where mirrors meet). Stamped onto the door
            # object so assign_style_to_front sets these per-side widths
            # instead of the uniform door-style stile/rail width. Cleared
            # when the leaf carries no override so a normal door reverts.
            _ovr = leaf.get('frame_override')
            _OVR_KEYS = {
                'left_stile':  'HB_FRAME_OVR_LEFT_STILE',
                'right_stile': 'HB_FRAME_OVR_RIGHT_STILE',
                'top_rail':    'HB_FRAME_OVR_TOP_RAIL',
                'bottom_rail': 'HB_FRAME_OVR_BOTTOM_RAIL',
            }
            for _k, _prop in _OVR_KEYS.items():
                if _ovr is not None and _k in _ovr:
                    front.obj[_prop] = _ovr[_k]
                elif _prop in front.obj:
                    del front.obj[_prop]

            # Drawer-look doors swap the single door pull for one pull
            # per applied drawer front; the panels are added below and
            # inherit the leaf swing. v1: single-leaf LEFT / RIGHT only.
            drawer_look = (
                leaf['role'] == PART_ROLE_DOOR
                and getattr(op_props, 'drawer_look_divisions', 'NONE') != 'NONE'
                and op_props.hinge_side in ('LEFT', 'RIGHT')
            )
            # Tri-view mirror doors carry no pulls (touch-open per the
            # production spec) -- both the three-bay build and legacy
            # single-opening builds.
            no_pulls = (self.obj.get('HB_NO_DOOR_PULLS')
                        or self.obj.get('HB_TRIVIEW_DOORS'))
            if not drawer_look and not no_pulls:
                self._create_pull_for_front(front, leaf['role'], leaf,
                                            op_props)
            self._create_drawer_box_for_front(pivot, leaf, rect, op_props)
            if drawer_look:
                self._build_drawer_look_fronts(front, leaf, op_props)

        # Sink apron: a fixed face-frame-depth panel across the top of a
        # DOOR opening (apron / farmhouse sink). The door(s) stay full
        # height; the apron sits behind them in the face-frame band
        # (y from the FF front face back by fft). Built directly here -
        # not via the leaf/pivot path - so it carries no door style or
        # pull; PART_ROLE_APRON is in FRONT_PART_ROLES so it's wiped on
        # the next rebuild. Same orientation as a front part (Length ->
        # vertical, Width -> horizontal, Thickness -> depth).
        if op_props.add_apron and front_type == 'DOOR':
            # Full interior width (the whole opening cage, x from 0), and
            # set BEHIND the face frame: the FF back plane is bay-local
            # y = 0, and a front part's Thickness extends -Y from its
            # origin, so an origin at y = +fft puts the apron body in
            # y[0, fft] - just behind the frame, in the interior.
            full_w = rect['cage_dim_x']
            top_z = rect['cage_dim_z'] - rect['reveal_top']
            apron_h = min(op_props.apron_height,
                          top_z - rect['reveal_bottom'])
            if full_w > 0.0 and apron_h > 0.0:
                fft = cab_props.face_frame_thickness
                apron = CabinetPart()
                apron.create('Apron')
                apron.obj.parent = opening_obj
                apron.obj['hb_part_role'] = PART_ROLE_APRON
                apron.obj['CABINET_PART'] = True
                # Interior part: shows up in 'Interiors' selection mode and is
                # routed into the Dashed freestyle collection on 2D layout
                # views (both keyed off this tag in hb_layouts).
                apron.obj['IS_FACE_FRAME_INTERIOR_PART'] = True
                apron.obj.rotation_euler.y = math.radians(-90)
                apron.obj.rotation_euler.z = math.radians(90)
                apron.set_input('Mirror Y', True)
                apron.obj.location = (0.0, fft, top_z - apron_h)
                apron.set_input('Length', apron_h)
                apron.set_input('Width', full_w)
                apron.set_input('Thickness', fft)

        # APPLIANCE openings: filler stiles at the left/right inboard edges so
        # the clear opening matches the appliance width. Built directly here
        # (no front pivot); PART_ROLE_APPLIANCE_FILLER is in FRONT_PART_ROLES so
        # they wipe + rebuild on every recalc. Oriented like a stile (Length ->
        # vertical, Width -> horizontal, Thickness -> face-frame depth) and
        # parented to the opening cage so they ride the angled-FF rotation the
        # same way the apron does.
        if front_type == 'APPLIANCE':
            left_w, right_w = solver.appliance_filler_widths(rect, op_props)
            clear_h = (rect['cage_dim_z'] - rect['reveal_top']
                       - rect['reveal_bottom'])
            fft = cab_props.face_frame_thickness
            z0 = rect['reveal_bottom']
            filler_specs = []
            if left_w > 0.0:
                filler_specs.append(
                    ('Left Appliance Filler', rect['reveal_left'], left_w))
            if right_w > 0.0:
                x_right = rect['cage_dim_x'] - rect['reveal_right'] - right_w
                filler_specs.append(
                    ('Right Appliance Filler', x_right, right_w))
            for fname, x0, fw in filler_specs:
                if clear_h <= 0.0 or fw <= 0.0:
                    continue
                filler = CabinetPart()
                filler.create(fname)
                filler.obj.parent = opening_obj
                filler.obj['hb_part_role'] = PART_ROLE_APPLIANCE_FILLER
                filler.obj['CABINET_PART'] = True
                filler.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
                filler.obj.rotation_euler.y = math.radians(-90)
                filler.obj.rotation_euler.z = math.radians(90)
                filler.set_input('Mirror Y', True)
                # Mirror Z False so the filler's thickness sits in the
                # face-frame plane (proud), not behind it.
                filler.set_input('Mirror Z', False)
                filler.obj.location = (x0, 0.0, z0)
                filler.set_input('Length', clear_h)
                filler.set_input('Width', fw)
                filler.set_input('Thickness', fft)

    def _build_drawer_look_fronts(self, front, leaf, op_props):
        """Lay N applied drawer fronts on a DOOR leaf so it reads exactly
        like a real N-drawer stack but opens as one door.

        Heights, reveals and the drawer-front style mirror a real stack:
        a short top front (the scene Top Drawer Opening Height) with the
        rest equal, reveals = the cabinet mid-rail width less the two
        overlapping overlays, and the panels picked up by
        _apply_door_styles_to_fronts as DRAWER_LOOK_FRONT (drawer-front
        style). The carrier leaf is rendered as a flat slab (skipped by
        that styling pass) and recessed one front thickness along its
        outward normal, so the proud fronts sit at the normal front plane
        and the slab shows through the reveals as the faux mid rails. Each
        front gets its own drawer pull. The panels live under the front
        pivot, so the per-recalc pivot wipe clears them.

        v1 scope: single-leaf LEFT / RIGHT swing doors.
        """
        divisions = getattr(op_props, 'drawer_look_divisions', 'NONE')
        if leaf['role'] != PART_ROLE_DOOR or divisions == 'NONE':
            return
        if op_props.hinge_side not in ('LEFT', 'RIGHT'):
            return
        n = int(divisions)
        length, width, thickness = leaf['part_dims']
        cab_props = self.obj.face_frame_cabinet
        overlays = (solver.resolved_overlay(cab_props, op_props, 'top')
                    + solver.resolved_overlay(cab_props, op_props, 'bottom'))
        # Reveal between fronts = mid-rail width less the two overlapping
        # front overlays, matching a real drawer stack.
        reveal = max(0.0, cab_props.bay_mid_rail_width - overlays)
        # FULL INSET (negative overlay): the fronts sit flush in the
        # frame, so the reveals can't read as rails - add real proud
        # mid-rail strips between the fronts instead.
        inset = overlays < 0.0
        # Front heights come from per-drawer OPENING heights, exactly like a
        # standard drawer stack: the available run (leaf less the two outer
        # overlays and the n-1 mid rails) is shared among the openings -
        # user-held (unlock_size) heights kept, the rest splitting the
        # remainder equally - then front height = opening height + overlays.
        # spec is bottom -> top; the top opening defaults to the scene Top
        # Drawer Opening Height (seeded by _update_drawer_look_divisions).
        rail_w = cab_props.bay_mid_rail_width
        available = length - overlays - (n - 1) * rail_w
        openings = getattr(op_props, 'drawer_look_openings', None)
        if openings is not None and len(openings) == n:
            spec = [(o.size, bool(o.unlock_size)) for o in openings]
        else:
            top_oh = bpy.context.scene.hb_face_frame.top_drawer_opening_height
            spec = [(0.0, False)] * (n - 1) + [(top_oh, True)]
        held_total = sum(s for s, held in spec if held)
        auto = [k for k, (s, held) in enumerate(spec) if not held]
        share = (available - held_total) / len(auto) if auto else 0.0
        # Write the auto-computed opening height back into the locked
        # (not unlock_size) rows so their disabled UI field shows the
        # real height. Safe mid-recalc: the size update callback bails
        # on the _RECALCULATING guard, so this can't loop.
        if openings is not None and len(openings) == n:
            for k, (s, held) in enumerate(spec):
                if not held and abs(openings[k].size - share) > 1e-6:
                    openings[k].size = share
        heights = [(s if held else share) + overlays for (s, held) in spec]
        if any(h <= 0.0 for h in heights):
            return

        # The carrier leaf is the swinging "door": flat slab, recessed by
        # one front thickness along its outward normal so the proud fronts
        # land at the normal front plane.
        carrier = front.obj
        carrier['HB_DRAWER_LOOK_CARRIER'] = True
        outward = carrier.rotation_euler.to_matrix() @ Vector((0.0, 0.0, 1.0))
        carrier.location = carrier.location - outward * thickness

        scene_props = bpy.context.scene.hb_face_frame
        z = 0.0
        for i, h in enumerate(heights):
            panel = CabinetPart()
            panel.create("Drawer-Look Front " + str(i + 1))
            panel.obj.parent = carrier
            panel.obj['hb_part_role'] = PART_ROLE_DRAWER_LOOK_FRONT
            panel.obj['CABINET_PART'] = True
            # Identity local rotation: the panel shares the carrier's local
            # frame (X = vertical, -Y = horizontal, +Z = outward). Full
            # width + tiled height cover the slab except the reveals; z =
            # thickness mounts the panel proud of the recessed slab.
            panel.obj.rotation_euler = (0.0, 0.0, 0.0)
            panel.set_input('Mirror Y', True)
            panel.obj.location = (z, 0.0, thickness)
            panel.set_input('Length', h)
            panel.set_input('Width', width)
            panel.set_input('Thickness', thickness)
            self._add_drawer_look_pull(panel.obj, h, width, thickness,
                                       scene_props)
            if inset and i < n - 1:
                rail_h = cab_props.bay_mid_rail_width
                rail = CabinetPart()
                rail.create("Drawer-Look Rail " + str(i + 1))
                rail.obj.parent = carrier
                rail.obj['hb_part_role'] = PART_ROLE_DRAWER_LOOK_RAIL
                rail.obj['CABINET_PART'] = True
                rail.obj.rotation_euler = (0.0, 0.0, 0.0)
                rail.set_input('Mirror Y', True)
                # Mirror Z flips the cutpart's thickness axis so the rail
                # builds back into the frame rather than proud-outward.
                rail.set_input('Mirror Z', True)
                # Centered in the gap, full width, proud of the fronts by
                # one thickness (matches a real inset stack's mid rail).
                rail.obj.location = (z + h + (reveal - rail_h) / 2.0,
                                     0.0, thickness * 2.0)
                rail.set_input('Length', rail_h)
                rail.set_input('Width', width)
                rail.set_input('Thickness', thickness)
            z += h + reveal

    def _add_drawer_look_pull(self, panel_obj, length, width, thickness,
                              scene_props):
        """A centered horizontal drawer pull on one drawer-look panel,
        mounted on its proud front face (same orientation the drawer-pull
        branch of _create_pull_for_front uses)."""
        pull_obj = pulls.resolve_pull_object(scene_props, 'drawer')
        if pull_obj is None:
            return
        instance = hb_utils.new_object("Pull - " + panel_obj.name,
                                        pull_obj.data)
        bpy.context.scene.collection.objects.link(instance)
        instance.parent = panel_obj
        instance.location = (length / 2.0, -width / 2.0, thickness)
        instance.rotation_euler = (math.radians(-90.0), 0.0,
                                   math.radians(90.0))
        instance['hb_part_role'] = 'PULL'
        instance['IS_CABINET_PULL'] = True

    def _create_front_pivot(self, opening_obj):
        """Create an Empty parented to the opening cage, used as the
        rotation/translation pivot for one front leaf. The empty is
        kept very small in the viewport - the user drives the swing
        through the opening's swing_percent slider, not by grabbing the
        empty directly, so the gizmo doesn't need to be prominent.
        """
        pivot = hb_utils.new_object('Front Pivot', None)
        bpy.context.scene.collection.objects.link(pivot)
        pivot.empty_display_type = 'PLAIN_AXES'
        pivot.empty_display_size = 0.001
        pivot.parent = opening_obj
        pivot['hb_part_role'] = PART_ROLE_FRONT_PIVOT
        return pivot

    def _create_front_part(self, pivot_obj, role, name):
        """Create a front CabinetPart parented to the given pivot empty.

        Orientation: rotation y=-90, z=90 with Mirror Y=True. Mirror Z
        is intentionally NOT set so the CPM_5PIECEDOOR modifier renders
        its panel / rails on the correct face - Mirror Z flips the
        thickness axis inside the cutpart, which inverts the asymmetric
        5-piece geometry. The leaf's part_position picks the X / Z
        offsets so the panel anchors against the pivot's hinge corner;
        compensation for the dropped Mirror Z (if any visible shift on
        slab fronts) lives in solver.front_leaves.
        """
        part = CabinetPart()
        part.create(name)
        part.obj.parent = pivot_obj
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        part.obj.rotation_euler.y = math.radians(-90)
        part.obj.rotation_euler.z = math.radians(90)
        part.set_input('Mirror Y', True)
        return part

    def _z_in_cabinet(self, obj):
        """Walk obj's parent chain up to (but not including) the cabinet
        root, summing each parent's local Z. Returns the Z position of
        obj's local origin in cabinet-local space.

        Reads obj.location directly rather than matrix_world so the
        result is correct mid-recalc, before the depsgraph evaluates
        any newly-set transforms. Valid because none of the ancestors
        on this chain (pivot, opening, split, bay) carry rotations
        that translate Z at recalc-time (pivots are at swing 0).
        """
        z = 0.0
        cur = obj
        while cur is not None and cur is not self.obj:
            z += cur.location.z
            cur = cur.parent
        return z

    def _create_pull_for_front(self, front_part, role, leaf,
                               op_props=None):
        """Attach a pull instance to `front_part` based on the cabinet's
        type and the front's role (DOOR / DRAWER_FRONT / PULLOUT_FRONT).
        INSET_PANEL skips, and a FALSE_FRONT only gets one when its
        opening asks for it (false_front_pull) - a dead front in a bank
        of drawers still has to read as a drawer. Returns the pull
        Object (or None if no pull is selected or the asset can't be
        loaded).

        op_props (the owning opening's props, when the caller has one)
        carries the per-opening pull override: a stored pull file wins
        over the scene-wide selection, and the 'NONE' sentinel drops
        the pull from this front entirely.

        The pull is parented to `front_part` so it inherits the swing /
        slide animation. Position is computed in front-part local space
        (X = Length axis, -Y = Width axis, -Z = out of cabinet). Pull
        rotation_euler.x = +90 deg maps the asset's bar axis along
        the door's vertical and orients its body in -Z (outward).
        """
        if role == PART_ROLE_INSET_PANEL:
            return None
        if role == PART_ROLE_FALSE_FRONT and not getattr(
                op_props, 'false_front_pull', False):
            return None
        scene_props = bpy.context.scene.hb_face_frame
        kind = 'drawer' if role in (PART_ROLE_DRAWER_FRONT, PART_ROLE_PULLOUT_FRONT, PART_ROLE_TILT_OUT, PART_ROLE_FALSE_FRONT) else 'door'
        # A pullout front carries a drawer-style pull - drawer pull
        # asset, horizontal bar - but it's a full door-height front, so
        # its vertical placement follows the door / cabinet-type formula
        # (top-of-door on a base cabinet), not the drawer formula.
        is_pullout = role == PART_ROLE_PULLOUT_FRONT
        # A flip door (TOP / BOTTOM hinge) has its hinge along a horizontal
        # edge, so the pull sits centered on the OPPOSITE edge with a
        # horizontal bar (like a drawer pull), not on the left/right edge
        # like a swing door. hinge is threaded in via the leaf descriptor.
        hinge = leaf.get('hinge')
        is_flip = (kind == 'door' and hinge in ('TOP', 'BOTTOM'))
        pull_obj = None
        override = (getattr(op_props, 'pull_override', '')
                    if op_props is not None else '')
        if override == 'NONE':
            return None
        if override:
            pull_obj = pulls.resolve_pull_override(
                getattr(op_props, 'pull_override_category', ''),
                override, scene_props)
        if pull_obj is None:
            pull_obj = pulls.resolve_pull_for(
                scene_props, kind,
                self.obj.face_frame_cabinet.cabinet_type)
        if pull_obj is None:
            return None

        cabinet_type = self.obj.face_frame_cabinet.cabinet_type
        length, width, thickness = leaf['part_dims']
        h_offset = scene_props.pull_horizontal_offset

        # The pull asset's origin sits at the bar's center, so naive
        # placement at "X from edge" puts the pull's CENTER at that
        # distance and the pull spills half-its-length past the edge.
        # User-facing offsets are edge-to-nearest-pull-edge, so subtract
        # half the bar length on edge-anchored vertical formulas.
        # Centered placements (length/2 etc) keep their middle anchor
        # and don't shift. Bar axis maps to part-X on doors and part-Y
        # on drawers; the asset's X span is the right dim either way.
        half_pull_len = pulls.pull_length(pull_obj) / 2.0

        # Vertical (X axis on door): zone-dependent. Pullout fronts are
        # excluded from the drawer branch so they fall through to the
        # cabinet-type branch below and sit at the top of the door like
        # a door pull. Their pull is rotated flat, though, so the bar's
        # vertical extent is ~0 - the half-bar-length edge correction
        # that vertical door-pull bars need doesn't apply, so vert_half
        # is 0 for pullouts.
        vert_half = 0.0 if is_pullout else half_pull_len
        # Per-opening pinned placement (Set Pull Location...) for swing
        # doors and pullouts; drawers and flip doors keep their own rules.
        loc_override = (getattr(op_props, 'pull_location_override', 'AUTO')
                        if op_props is not None else 'AUTO')
        if kind == 'drawer' and not is_pullout:
            loc_override = 'AUTO'
        if is_flip:
            loc_override = 'AUTO'
        if loc_override == 'TOP':
            x = length - scene_props.pull_vertical_location_base - vert_half
        elif loc_override == 'MIDDLE':
            x = length / 2.0
        elif loc_override == 'BOTTOM':
            x = scene_props.pull_vertical_location_upper + vert_half
        elif loc_override == 'TALL':
            x = min(scene_props.pull_vertical_location_tall + vert_half,
                    length - scene_props.pull_vertical_location_base - vert_half)
        elif is_flip:
            # Flip door: pull centered on the UNHINGED edge. TOP hinge
            # (flip up) -> unhinged edge is the bottom, so the pull sits
            # near the door bottom; BOTTOM hinge (flip / tilt down) ->
            # unhinged edge is the top, near the door top. The bar is
            # rotated flat below (no vertical extent), so no half-bar edge
            # correction is needed here.
            if hinge == 'TOP':
                x = scene_props.pull_vertical_location_upper
            else:  # BOTTOM
                x = length - scene_props.pull_vertical_location_base
        elif kind == 'drawer' and not is_pullout:
            if scene_props.center_pulls_on_drawer_front:
                x = length / 2.0
            else:
                # Off-center moves the pull toward the top of the
                # drawer. Reuse the base vertical offset so the user
                # only has one offset to tune.
                x = length - scene_props.pull_vertical_location_base - half_pull_len
        elif cabinet_type == 'UPPER':
            x = scene_props.pull_vertical_location_upper + vert_half
        elif cabinet_type == 'TALL':
            # Three-way decision based on the door's vertical position
            # AND its length:
            #   - High door (bottom above the tall threshold) -> UPPER:
            #     small offset from door bottom, like an upper cabinet.
            #   - Door long enough to fit the tall offset AND the full
            #     pull bar above it -> TALL: offset from door bottom
            #     (~36" reach height). The placement below centers the
            #     bar at tall_offset + vert_half, so the bar's TOP
            #     lands at tall_offset + 2 * vert_half - comparing the
            #     length against the offset alone let doors barely
            #     past the threshold (e.g. a 36-1/4" door with a 36"
            #     offset) keep the tall placement with the bar hanging
            #     off the door top.
            #   - Otherwise -> BASE: offset from door TOP, so the pull
            #     stays on the door regardless of how short it is.
            door_bottom_z = self._z_in_cabinet(front_part.obj)
            tall_offset = scene_props.pull_vertical_location_tall
            if door_bottom_z >= tall_offset:
                x = scene_props.pull_vertical_location_upper + vert_half
            elif length >= tall_offset + 2.0 * vert_half:
                x = tall_offset + vert_half
            else:
                x = length - scene_props.pull_vertical_location_base - vert_half
        else:
            # BASE / LAP_DRAWER: measure DOWN from top of door.
            x = length - scene_props.pull_vertical_location_base - vert_half

        # Horizontal (Y axis on door): the leaf builder positions a
        # right-hinged door's local origin at the UNHINGED corner
        # (door.location.x is offset by -width so the door extends
        # back across the cabinet). Detecting that lets us flip the
        # pull to the correct edge without needing to thread
        # hinge_side through the leaf descriptor.
        if kind == 'drawer' or is_flip:
            # Drawers and flip doors: pull horizontally centered.
            # (center_pulls_on_drawer_front controls the drawer pull's
            # vertical position, not horizontal.)
            y = -width / 2.0
        elif front_part.obj.location.x < 0.0:
            # Right-hinged door: hinge at Y = -width, unhinged at Y = 0.
            y = -h_offset
        else:
            # Left-hinged door (incl. DOUBLE Left leaf): hinge at Y = 0,
            # unhinged at Y = -width.
            y = -(width - h_offset)

        # Mounting plane: pull sits flush against the door front face.
        # Without Mirror Z, the cutpart's geometry extends +Z from
        # part-local origin, so part-local z=0 is the BACK face
        # (against the cabinet) and z=+thickness is the FRONT face
        # (toward the viewer). The pull mounts on the front face.
        z = thickness

        instance = hb_utils.new_object(f"Pull - {front_part.obj.name}", pull_obj.data)
        bpy.context.scene.collection.objects.link(instance)
        instance.parent = front_part.obj
        instance.location = (x, y, z)
        # rotation_x = -90 deg: pull body (modeled in -Y) ends up extending
        # in door-local +Z, which is away from the cabinet (beyond the
        # door front). Bar axis stays along door-local +X = vertical for
        # doors. For drawers (and pullouts) we add rotation_z = 90 deg
        # so the bar runs horizontal across the drawer front. Flip doors
        # (TOP / BOTTOM hinge) use the same horizontal-bar orientation.
        rot_z = math.radians(90.0) if (kind == 'drawer' or is_flip) else 0.0
        instance.rotation_euler = (math.radians(-90.0), 0.0, rot_z)
        instance['hb_part_role'] = 'PULL'
        instance['IS_CABINET_PULL'] = True
        return instance


    def _cabinet_local_offset(self, obj):
        """Accumulate parent-chain locations from obj up to (excluding)
        the cabinet root. Valid for unrotated chains (bay / opening
        cages, slide pivots); avoids matrix_world, which is stale
        mid-recalc."""
        x = y = z = 0.0
        cur = obj
        while cur is not None and cur is not self.obj:
            x += cur.location.x
            y += cur.location.y
            z += cur.location.z
            cur = cur.parent
        return x, y, z

    # Drawer-interior accessory geometry. Accessories carrying a render
    # hint (stamped onto the interior item as accessory_render when
    # picked from the browser) build real parts inside the drawer box,
    # parented to it so they slide out with the front and die with the
    # pivot wipe on the next rebuild. DRAWER_INSERT_BUILDERS maps the
    # hint to the builder; accessories without one stay data-only.
    # Fallback inside faces of the box, used only when the drawer box
    # asset doesn't publish its own (see _drawer_box_interior): wall
    # thickness, and the top of the bottom panel an insert stands on.
    DRAWER_BOX_SIDE_TH = inch(0.625)
    DRAWER_BOX_INSIDE_FLOOR = inch(0.75)
    # Headroom an insert leaves under the rim of the box.
    DRAWER_INSERT_RIM_GAP = inch(0.75)
    # Removable divider stock. A render hint may name its own
    # thickness (TH) when a product is cut from something else.
    DRAWER_DIVIDER_TH = inch(0.375)
    # Insert stock: tray walls and partitions, and the thinner panel
    # the bottoms, ribs and sloped shelves are made from.
    INSERT_WALL_TH = inch(0.375)
    INSERT_PANEL_TH = inch(0.25)
    # Cutlery tray: the utensil slots come on a fixed pitch and the
    # cross compartment behind them is a fixed depth, so a tray trimmed
    # to a wider drawer grows its side compartments, not its slots.
    CUTLERY_SLOT_PITCH = inch(2.875)
    CUTLERY_CROSS_DEPTH = inch(4.0)
    # Knife block: ribs on a fixed pitch with a saw-kerf gap between
    # them, and the step up from one tier to the next.
    KNIFE_RIB_PITCH = inch(0.75)
    KNIFE_RIB_GAP = inch(0.25)
    KNIFE_TIER_RISE = inch(1.25)
    # Stepped spice shelves: run and rise of one step.
    SPICE_STEP_RUN = inch(3.5)
    SPICE_STEP_RISE = inch(2.25)
    # Letter-slot organizer: heavier plywood, a wide bay in the middle
    # for paper with equal letter slots out to each side.
    ORGANIZER_PANEL_TH = inch(0.5)
    ORGANIZER_PAPER_BAY = inch(12.0)
    ORGANIZER_SLOT_WIDTH = inch(4.5)

    def _emit_drawer_insert(self, box_obj, name, mb, role=None):
        """Turn a collected DrawerInsertMesh into one child object of
        the drawer box. One object per physical unit: a tray with a
        dozen partitions is still one thing the user can click."""
        if not mb.faces:
            return None
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(mb.verts, [], mb.faces)
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        bm.free()
        mesh.update()
        obj = hb_utils.new_object(name, mesh)
        for coll in box_obj.users_collection:
            coll.objects.link(obj)
            break
        obj.parent = box_obj
        obj['hb_part_role'] = role or PART_ROLE_DRAWER_INSERT
        obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_drawer_box_commands'
        obj['IS_FINISHED'] = True
        return obj

    @classmethod
    def _drawer_box_interior(cls, box_obj):
        """(side, front, floor) inside faces of a drawer box, in box
        local space, read off the box asset itself.

        An insert has to sit ON the box bottom, and the bottom is a
        panel let into the sides part way up - assuming it is at z=0
        buries the insert in it. The asset publishes the numbers
        (material / bottom thickness and where the bottom sits), so
        take them from there and only fall back to the class defaults
        when a box is built some other way. A box with no subfront has
        no front panel, so its inside starts at the front face.
        """
        side = cls.DRAWER_BOX_SIDE_TH
        floor = cls.DRAWER_BOX_INSIDE_FLOOR
        front = side
        for mod in box_obj.modifiers:
            if mod.type != 'NODES' or mod.node_group is None:
                continue
            ids = {}
            for socket in mod.node_group.interface.items_tree:
                if getattr(socket, 'in_out', '') == 'INPUT':
                    ids[socket.name] = socket.identifier
            th = hb_utils.try_get_gn_input(
                mod, ids.get('Material Thickness', ''), None)
            bottom_th = hb_utils.try_get_gn_input(
                mod, ids.get('Bottom Thickness', ''), None)
            bottom_z = hb_utils.try_get_gn_input(
                mod, ids.get('Drawer Bottom Z Location', ''), None)
            if th:
                side = front = th
            if bottom_th is not None and bottom_z is not None:
                floor = bottom_z + bottom_th
            if hb_utils.try_get_gn_input(
                    mod, ids.get('Remove Subfront', ''), False):
                front = 0.0
            break
        return side, front, floor

    def _spawn_drawer_inserts(self, box_obj, dx, dy, dz, op_props):
        """Build geometry for every rendered accessory in this drawer.

        Inserts that take up drawer floor are packed left to right in
        list order, each one trimmed to what is left; typing a position
        or a size pins one wherever it belongs. A removable divider
        spans the box rather than taking a slice of it, but it still
        joins the pack: running front to back it butts the accessory
        before it and moves the cursor on by its own thickness.
        """
        items = [it for it in getattr(op_props, 'interior_items', ())
                 if it.kind == 'ACCESSORY'
                 and getattr(it, 'accessory_render', '')]
        if not items:
            return
        side, front, floor = self._drawer_box_interior(box_obj)
        inner = SimpleNamespace(
            x0=side, x1=dx - side, y0=front, y1=dy - side, z0=floor,
            # Inserts stand on the box bottom and stop under the rim.
            h=max(dz - floor - self.DRAWER_INSERT_RIM_GAP, inch(1.0)),
            slots=0)
        if (inner.x1 - inner.x0 < inch(1.0)
                or inner.y1 - inner.y0 < inch(1.0)):
            return
        fill_w = self._drawer_insert_fill_width(inner, items)
        cursor = inner.x0
        for item in items:
            kind, params = parse_render_hint(item.accessory_render)
            spec = DRAWER_INSERT_BUILDERS.get(kind)
            if spec is None:
                continue
            builder = getattr(self, spec[0])
            if not spec[2]:
                # Spans the box rather than taking a slice of it, but it
                # is still handed the cursor: a front-to-back divider
                # butts the accessory before it and moves the cursor on.
                moved = builder(box_obj, inner, item, params, cursor)
                if moved is not None:
                    cursor = moved
                continue
            off = getattr(item, 'insert_offset', 0.0)
            if off > 0.0001:
                cursor = inner.x0 + off
            for _i in range(max(getattr(item, 'accessory_qty', 1), 1)):
                rect = self._drawer_insert_rect(inner, item, params,
                                                spec[1], cursor, fill_w)
                if rect is None:
                    break
                builder(box_obj, rect, item, params)
                cursor = rect.x1

    @staticmethod
    def _drawer_insert_fill_width(inner, items):
        """Width for each insert that has no size of its own: what the
        sized ones leave, split evenly. Lets a drawer of spice shelves +
        knife block + cutlery tray lay itself out with nothing typed."""
        widths = []
        for item in items:
            kind, params = parse_render_hint(item.accessory_render)
            spec = DRAWER_INSERT_BUILDERS.get(kind)
            if spec is None or not spec[2]:
                continue
            w = getattr(item, 'insert_width', 0.0)
            if w < 1e-6:
                w = inch(params.get('W', 0.0))
            widths.extend([w] * max(getattr(item, 'accessory_qty', 1), 1))
        fillers = sum(1 for w in widths if w < 1e-6)
        if fillers < 2:
            return 0.0
        left = (inner.x1 - inner.x0) - sum(w for w in widths if w > 1e-6)
        return max(left, 0.0) / fillers

    def _drawer_insert_rect(self, inner, item, params, default_h, cursor,
                            fill_w=0.0):
        """Footprint and height for one packed insert. Each size falls
        back from the typed override to the published size that came
        with the render hint, then to the drawer's fill width."""
        tol = 1e-6
        x0 = min(max(cursor, inner.x0), inner.x1)
        avail_w = inner.x1 - x0
        avail_d = inner.y1 - inner.y0
        if avail_w < inch(1.0) or avail_d < inch(1.0):
            return None
        w = getattr(item, 'insert_width', 0.0)
        if w < tol:
            w = inch(params.get('W', 0.0))
        if w < tol:
            # No size of its own: take the drawer's fill width, but no
            # wider than the product is built (WMAX).
            w = fill_w if fill_w > inch(1.0) else avail_w
            wmax = inch(params.get('WMAX', 0.0))
            if wmax > tol:
                w = min(w, wmax)
        w = min(w, avail_w)
        y0 = inner.y0 + min(max(getattr(item, 'insert_from_front', 0.0),
                                0.0), avail_d - inch(1.0))
        d = getattr(item, 'insert_depth', 0.0)
        if d < tol:
            d = inch(params.get('D', 0.0))
        if d < tol:
            d = inner.y1 - y0
            dmax = inch(params.get('DMAX', 0.0))
            if dmax > tol:
                d = min(d, dmax)
        d = min(d, inner.y1 - y0)
        h = getattr(item, 'insert_height', 0.0)
        if h < tol:
            h = inch(params.get('H', default_h))
        h = min(max(h, inch(0.5)), inner.h)
        slots = int(getattr(item, 'insert_slots', 0)
                    or params.get('SLOTS', 0))
        return SimpleNamespace(x0=x0, x1=x0 + w, y0=y0, y1=y0 + d,
                               z0=inner.z0, h=h, slots=max(slots, 0))

    def _build_drawer_dividers(self, box_obj, rect, item, params,
                               cursor=None):
        """Removable partitions dropped into the box: full-width (or
        full-depth) panels. One object each - they lift out
        individually.

        A front-to-back divider added after another accessory butts
        against it, which is what it is for: the accessory ahead of it
        rarely fills the drawer, and the divider closes off what is
        left. Anything else - the first thing in the drawer, a typed
        position, a divider running side to side - spaces evenly as
        before. Returns the packing cursor to carry on from, or None
        when it took no space.
        """
        th = inch(params.get('TH', 0.0))
        if th < 1e-6:
            th = self.DRAWER_DIVIDER_TH
        if (rect.x1 - rect.x0 < th * 2) or (rect.y1 - rect.y0 < th * 2):
            return None
        z0, z1 = rect.z0, rect.z0 + rect.h
        qty = max(getattr(item, 'accessory_qty', 1), 1)
        lengthwise = getattr(item, 'divider_lengthwise', False)
        off = getattr(item, 'divider_offset', 0.0)
        span0, span1 = ((rect.x0, rect.x1) if lengthwise
                        else (rect.y0, rect.y1))
        span = span1 - span0
        against = (lengthwise and off <= 0.0001 and cursor is not None
                   and cursor > rect.x0 + 1e-6
                   and cursor < rect.x1 - th)
        if against:
            centers = [cursor + th / 2.0]
            # Extras split what is left beyond it, so a quantity still
            # means something once the first one is spoken for.
            rest = cursor + th
            step = (span1 - rest) / qty
            centers += [rest + step * (i + 1) for i in range(qty - 1)]
        elif qty == 1 and off > 0.0001:
            # Typed position: divider center that far from the front
            # (or the left side when running front-to-back).
            centers = [span0 + min(max(off, th), span - th)]
        else:
            step = span / (qty + 1)
            centers = [span0 + step * (i + 1) for i in range(qty)]
        for c in centers:
            mb = DrawerInsertMesh()
            if lengthwise:
                mb.box(c - th / 2.0, c + th / 2.0, rect.y0, rect.y1,
                       z0, z1)
            else:
                mb.box(rect.x0, rect.x1, c - th / 2.0, c + th / 2.0,
                       z0, z1)
            self._emit_drawer_insert(box_obj, 'Drawer Divider', mb,
                                     role=PART_ROLE_DRAWER_DIVIDER)
        if not against:
            return None
        # Whatever comes next starts clear of the last one placed.
        return max(centers) + th / 2.0

    def _tray_walls(self, mb, rect, th):
        """Bottom panel with four walls standing on it - the shell every
        boxed insert starts from.

        Parts butt, they don't run through each other: the bottom is one
        panel across the whole footprint, the walls sit on top of it,
        and the front and back butt between the two sides. Returns
        (ix0, ix1, iy0, iy1, zb): the inside faces of the walls and the
        floor every part inside stands on.
        """
        zb = rect.z0 + self.INSERT_PANEL_TH
        z1 = rect.z0 + rect.h
        mb.box(rect.x0, rect.x1, rect.y0, rect.y1, rect.z0, zb)
        mb.box(rect.x0, rect.x0 + th, rect.y0, rect.y1, zb, z1)
        mb.box(rect.x1 - th, rect.x1, rect.y0, rect.y1, zb, z1)
        mb.box(rect.x0 + th, rect.x1 - th, rect.y0, rect.y0 + th, zb, z1)
        mb.box(rect.x0 + th, rect.x1 - th, rect.y1 - th, rect.y1, zb, z1)
        return (rect.x0 + th, rect.x1 - th, rect.y0 + th, rect.y1 - th, zb)

    @staticmethod
    def _partition_spans(a, b, count, th):
        """Near edges of the partitions that split the clear span
        [a, b] into ``count`` equal compartments.

        Each partition occupies its own thickness between two
        compartments, so the compartments come out equal and nothing
        overlaps. Empty when they would not fit.
        """
        if count < 2:
            return []
        clear = (b - a) - th * (count - 1)
        if clear <= th:
            return []
        comp = clear / count
        return [a + comp * (i + 1) + th * i for i in range(count - 1)]

    def _insert_name(self, item, fallback):
        return (getattr(item, 'accessory_label', '') or fallback)[:60]

    def _build_tray_insert(self, box_obj, rect, item, params, mb=None,
                           slots=None):
        """An open box, optionally split into equal front-to-back
        compartments. Covers the plain utensil / storage boxes, and
        gives the compartmented inserts their shell."""
        own = mb is None
        mb = mb if mb is not None else DrawerInsertMesh()
        th = self.INSERT_WALL_TH
        if rect.x1 - rect.x0 < th * 3 or rect.y1 - rect.y0 < th * 3:
            return mb
        ix0, ix1, iy0, iy1, zb = self._tray_walls(mb, rect, th)
        z1 = rect.z0 + rect.h
        n = rect.slots if slots is None else slots
        # Partitions stand on the bottom and butt between the front and
        # back walls.
        for p in self._partition_spans(ix0, ix1, n, th):
            mb.box(p, p + th, iy0, iy1, zb, z1)
        if own:
            self._emit_drawer_insert(
                box_obj, self._insert_name(item, 'Drawer Tray'), mb)
        return mb

    def _build_cutlery_insert(self, box_obj, rect, item, params):
        """Cutlery tray: a band of equal utensil slots with a cross
        compartment behind them, side compartments left and right, and
        one compartment across the back. The slot band keeps its pitch
        and the side compartments take up the slack, which is how the
        tray is trimmed to the drawer it ships in.

        A published configuration pins the layout through the hint:
        CORE = slot core width, COREX = the core's offset from the
        left side (omitted = centred), BAND = back compartment depth,
        CROSS = cross compartment depth (0 = none), MIDSPLIT = a rail
        across the middle slot that far from the front. Without them
        the tray lays itself out from the drawer size.

        SHELL=0 builds the divider set on its own: no perimeter walls
        and no bottom, standing straight on the drawer floor. That is
        how the silverware dividers ship -- the drawer's own sides and
        back are the ones they are captured by, so modelling a box
        around them puts a second wall inside the drawer.
        """
        th = self.INSERT_WALL_TH
        shell = params.get('SHELL', 1.0) >= 0.5
        name = self._insert_name(item, 'Cutlery Tray')
        if shell:
            mb = self._build_tray_insert(box_obj, rect, item, params,
                                         mb=DrawerInsertMesh(), slots=1)
            ix0, ix1 = rect.x0 + th, rect.x1 - th
            iy0, iy1 = rect.y0 + th, rect.y1 - th
            zb = rect.z0 + self.INSERT_PANEL_TH
        else:
            mb = DrawerInsertMesh()
            ix0, ix1 = rect.x0, rect.x1
            iy0, iy1 = rect.y0, rect.y1
            zb = rect.z0
        z1 = rect.z0 + rect.h
        if ix1 - ix0 < inch(3.0) or iy1 - iy0 < inch(6.0):
            # Too small to lay out: the shell is still a usable tray,
            # but a shell-less insert would be an empty object.
            if shell:
                self._emit_drawer_insert(box_obj, name, mb)
            return
        # Rail across the back, butted between the two side walls; the
        # compartment behind it is the back band, the slot core takes
        # the rest. core_back is the rail's FRONT face, so everything
        # running forward from it stops there rather than into it.
        if 'BAND' in params:
            band = inch(params['BAND'])
        else:
            band = min(max((iy1 - iy0) * 0.25, inch(4.0)), inch(6.625))
        core_back = iy1
        if band > th and (iy1 - band) - iy0 >= inch(6.0):
            core_back = iy1 - band
            mb.box(ix0, ix1, core_back, core_back + th, zb, z1)
        slots = max(min(rect.slots or 5, 12), 2)
        core_w = inch(params.get('CORE', 0.0))
        if core_w < th:
            core_w = self.CUTLERY_SLOT_PITCH * slots
        core_w = min(core_w, ix1 - ix0)
        # COREX pins the core that far from the left side -- 0 = flush
        # left, which is how the configurations with a single side
        # compartment are drawn. Without it the core is centred and the
        # slack is shared by a compartment on each side.
        if 'COREX' in params:
            cx0 = min(max(ix0 + inch(params['COREX']), ix0), ix1 - core_w)
        else:
            cx0 = (ix0 + ix1) / 2.0 - core_w / 2.0
        cx1 = cx0 + core_w
        # Partitions bounding the slot core run its full depth. Where
        # the drawer leaves no room for side compartments the core is
        # bounded by the tray's own sides instead.
        # Without a shell those two partitions ARE the insert's outer
        # walls, so they are built whatever the drawer leaves either
        # side of the core -- except on a side the core is flush with,
        # where the drawer's own wall already closes it.
        kx0, kx1 = ix0, ix1
        if not shell or (cx0 - ix0 > inch(1.0) and ix1 - cx1 > inch(1.0)):
            if shell or cx0 - ix0 > th:
                mb.box(cx0, cx0 + th, iy0, core_back, zb, z1)
                kx0 = cx0 + th
            else:
                kx0 = cx0
            if shell or ix1 - cx1 > th:
                mb.box(cx1 - th, cx1, iy0, core_back, zb, z1)
                kx1 = cx1 - th
            else:
                kx1 = cx1
        # Cross compartment at the back of the core: its rail butts
        # between whatever bounds the core.
        cross = inch(params['CROSS']) if 'CROSS' in params else \
            self.CUTLERY_CROSS_DEPTH
        slot_back = core_back
        if cross > th and core_back - iy0 > cross + inch(4.0):
            slot_back = core_back - cross - th
            mb.box(kx0, kx1, slot_back, slot_back + th, zb, z1)
        spans = self._partition_spans(kx0, kx1, slots, th)
        for p in spans:
            mb.box(p, p + th, iy0, slot_back, zb, z1)
        # A short compartment at the front of the middle slot (the
        # vendor's "E"/"F" trays): rail butted between that slot's
        # partitions, its front face MIDSPLIT from the tray front.
        mid = inch(params.get('MIDSPLIT', 0.0))
        if mid > th and slots >= 2 and len(spans) == slots - 1:
            i = slots // 2
            left = kx0 if i == 0 else spans[i - 1] + th
            right = kx1 if i == slots - 1 else spans[i]
            if (right - left > th and
                    slot_back - (iy0 + mid + th) > inch(1.0)):
                mb.box(left, right, iy0 + mid, iy0 + mid + th, zb, z1)
        self._emit_drawer_insert(box_obj, name, mb)

    def _build_knife_block_insert(self, box_obj, rect, item, params):
        """Knife block: a ribbed bed across the back of a panel, the
        blades sliding front to back between the ribs, with a handle
        rest rail in front of it. A second tier steps up behind the
        first so the back row stays reachable."""
        mb = DrawerInsertMesh()
        bt = self.INSERT_PANEL_TH
        th = self.INSERT_WALL_TH
        z_base = rect.z0 + bt
        z_top = rect.z0 + rect.h
        w = rect.x1 - rect.x0
        d = rect.y1 - rect.y0
        if w < inch(2.0) or d < inch(6.0):
            return
        mb.box(rect.x0, rect.x1, rect.y0, rect.y1, rect.z0, z_base)
        tiers = max(int(params.get('TIERS', 1)), 1)
        bed_d = min(d - inch(3.0), d * (0.55 + 0.1 * (tiers - 1)))
        if bed_d < inch(2.0) * tiers:
            tiers = 1
            bed_d = max(d - inch(3.0), inch(2.0))
        bed_front = rect.y1 - bed_d
        tier_d = bed_d / tiers
        rail_y = max(bed_front - inch(1.5), rect.y0 + inch(0.5))
        mb.box(rect.x0, rect.x1, rail_y, rail_y + th, z_base,
               min(z_base + inch(0.75), z_top))
        margin = inch(0.25)
        bx0, bx1 = rect.x0 + margin, rect.x1 - margin
        pitch = self.KNIFE_RIB_PITCH
        if rect.slots > 0:
            pitch = (bx1 - bx0) / rect.slots
        count = max(int((bx1 - bx0) / pitch), 1)
        gap = min(self.KNIFE_RIB_GAP, pitch * 0.4)
        sx0 = (bx0 + bx1) / 2.0 - (pitch * count) / 2.0
        for t in range(tiers):
            ty0 = bed_front + tier_d * t
            ty1 = ty0 + tier_d
            rise = self.KNIFE_TIER_RISE * t
            zb = min(z_base + rise, z_top)
            top = min(zb + inch(1.0), z_top)
            if rise > 0.0:
                mb.box(rect.x0, rect.x1, ty0, ty1, z_base, zb)
            if top - zb < inch(0.125):
                continue
            for i in range(count):
                x0 = sx0 + pitch * i
                mb.box(x0, x0 + pitch - gap, ty0, ty1, zb, top)
        self._emit_drawer_insert(
            box_obj, self._insert_name(item, 'Knife Block'), mb)

    def _build_spice_insert(self, box_obj, rect, item, params):
        """Stepped shelves: bottles lie on their sides on shelves that
        climb toward the back of the drawer, each shelf carried on a
        riser at its high end so the labels stay readable."""
        mb = DrawerInsertMesh()
        bt = self.INSERT_PANEL_TH
        z_base = rect.z0 + bt
        w = rect.x1 - rect.x0
        d = rect.y1 - rect.y0
        if w < inch(2.0) or d < inch(4.0):
            return
        mb.box(rect.x0, rect.x1, rect.y0, rect.y1, rect.z0, z_base)
        rise = min(self.SPICE_STEP_RISE, max(rect.h - bt, inch(0.75)))
        steps = max(int(d / (self.SPICE_STEP_RUN + bt)), 1)
        run = d / steps - bt
        if run < inch(1.0):
            return
        y = rect.y0
        for _s in range(steps):
            y1 = y + run
            mb.prism(rect.x0, rect.x1,
                     [(y, z_base + bt), (y1, z_base + rise),
                      (y1, z_base + rise - bt), (y, z_base)])
            mb.box(rect.x0, rect.x1, y1, y1 + bt, z_base, z_base + rise)
            y = y1 + bt
        self._emit_drawer_insert(
            box_obj, self._insert_name(item, 'Spice Insert'), mb)

    def _build_pigeon_hole_insert(self, box_obj, rect, item, params):
        """Letter-slot organizer: upright slots on a fixed width either
        side of a wider bay for paper."""
        mb = DrawerInsertMesh()
        th = self.ORGANIZER_PANEL_TH
        z1 = rect.z0 + rect.h
        if rect.x1 - rect.x0 < inch(6.0) or rect.y1 - rect.y0 < inch(3.0):
            return
        ix0, ix1, iy0, iy1, zb = self._tray_walls(mb, rect, th)
        # The paper bay is the clear span in the middle; the two
        # partitions that bound it stand outside it, and the letter
        # slots divide what is left on each side.
        bay = min(self.ORGANIZER_PAPER_BAY, (ix1 - ix0) * 0.5)
        mid = (ix0 + ix1) / 2.0
        b0, b1 = mid - bay / 2.0, mid + bay / 2.0
        for p in (b0 - th, b1):
            if p > ix0 and p + th < ix1:
                mb.box(p, p + th, iy0, iy1, zb, z1)
        for s0, s1 in ((ix0, b0 - th), (b1 + th, ix1)):
            width = s1 - s0
            if width < inch(2.0):
                continue
            count = max(int(round(width / self.ORGANIZER_SLOT_WIDTH)), 1)
            for p in self._partition_spans(s0, s1, count, th):
                mb.box(p, p + th, iy0, iy1, zb, z1)
        self._emit_drawer_insert(
            box_obj, self._insert_name(item, 'Letter Slot Organizer'), mb)

    @staticmethod
    def _stamp_drawer_box_construction(obj, op_props):
        """Tag a drawer / rollout box with the opening's construction
        pick so downstream consumers (drawings, reports, exports) can
        list every box system a job uses. A blank pick leaves the box
        untagged - it is built to the project default.
        """
        if op_props is None:
            return
        code = getattr(op_props, 'drawer_box_construction', '')
        if code:
            obj['DRAWER_BOX_CONSTRUCTION'] = code
            label = getattr(op_props, 'drawer_box_construction_label', '')
            obj['DRAWER_BOX_CONSTRUCTION_NAME'] = label or code
        # Slide pick rides the same stamp path: per-opening override for
        # the odd heavy duty drawer, blank = project default.
        slide_code = getattr(op_props, 'drawer_slides', '')
        if slide_code:
            obj['DRAWER_SLIDES'] = slide_code
            slide_label = getattr(op_props, 'drawer_slides_label', '')
            obj['DRAWER_SLIDES_NAME'] = slide_label or slide_code

    def _create_drawer_box_for_front(self, pivot_obj, leaf, rect,
                                     op_props=None):
        """Spawn a drawer box behind a drawer or pullout front.

        Skips quietly if the role isn't drawer/pullout, if the scene-level
        toggle is off, or if any computed dimension goes nonpositive (very
        narrow openings with large clearances). The box is parented to the
        front pivot rather than the front part: the pivot's local axes
        match the opening cage's (no rotation for slide leaves), so the
        box can be placed and sized in opening-local terms without
        composing through the front's rotated frame. Anchoring to
        pivot_anchor_position (swing=0) instead of pivot_position lets
        the box ride the slide animation - the pivot's animated Y carries
        the box forward; if we used pivot_position the box would stay at
        a fixed world Y and the front would slide out without it.

        Box dimensions fit inside the face frame opening hole minus
        per-side clearances. Box depth is the full bay cavity depth
        (cage_dim_y) minus rear clearance, so its front face sits flush
        with the back of the face frame.
        """
        if leaf['role'] not in (PART_ROLE_DRAWER_FRONT, PART_ROLE_PULLOUT_FRONT):
            return None
        scene_props = bpy.context.scene.hb_face_frame
        if not scene_props.include_drawer_boxes:
            return None

        side_clr = scene_props.drawer_box_side_clearance
        top_clr = scene_props.drawer_box_top_clearance
        rear_clr = scene_props.drawer_box_rear_clearance
        bottom_clr = scene_props.drawer_box_bottom_clearance

        cage_x = rect['cage_dim_x']
        cage_y = rect['cage_dim_y']
        cage_z = rect['cage_dim_z']
        # Working face frame panel: the box runs back into the host
        # cabinet's cavity, not the panel's own 3/4 reserve.
        applied_depth = self.obj.get(TAG_APPLIED_BOX_DEPTH)
        if applied_depth:
            cage_y = max(cage_y, float(applied_depth))
        rl = rect['reveal_left']
        rr = rect['reveal_right']
        rt = rect['reveal_top']
        rb = rect['reveal_bottom']

        # Anchor the box's front face against the back of the drawer
        # front so the two read as connected. The pivot's swing=0 Y now
        # sits AT the drawer front's back face (the front part extends
        # -Y from the pivot by door_thickness to its outer face), so the
        # back of the front lives at anchor_y. The box passes through
        # the FF opening from there and extends back to cage_dim_y -
        # rear_clr; box_dx already sits within the opening reveals, so
        # it clears the rails and stiles.
        anchor = leaf.get('pivot_anchor_position', leaf['pivot_position'])
        a_x, a_y, a_z = anchor
        front_back_y = a_y

        box_dx = cage_x - rl - rr - 2.0 * side_clr
        box_dy = (cage_y - rear_clr) - front_back_y
        box_dz = cage_z - rt - rb - top_clr - bottom_clr

        # Snap to a stock box height. Clearance-derived sizing cuts the
        # box to the opening, which produces boxes that are not made -
        # most visibly a pullout behind a tall door, drawn as a drawer
        # nearly the height of the door. The box keeps its bottom
        # clearance and the extra room stays above it.
        if scene_props.use_stock_drawer_box_heights:
            opening_dz = cage_z - rt - rb
            stock_dz = stock_drawer_box_height(opening_dz)
            if stock_dz is not None:
                box_dz = min(stock_dz, opening_dz - bottom_clr)

        # A rollout riding above this drawer takes the top of the
        # opening: the reserve is its height, the gap under it, and the
        # top clearance the box would have had anyway. Applied before
        # the explicit overrides so a typed height still wins - the
        # drafter who types one is answering this question themselves.
        if op_props is not None and getattr(op_props,
                                            'rollout_above_drawer', False):
            reserve = (op_props.rollout_above_height
                       + op_props.rollout_above_gap + top_clr)
            box_dz = min(box_dz, cage_z - rt - rb - bottom_clr - reserve)

        # Per-opening size overrides (right-click the box -> Drawer Box
        # Size...). Overridden axes replace the clearance-derived size,
        # clamped so the box can't exceed the opening hole or run past
        # the carcass back. Height keeps the bottom-clearance anchor;
        # depth grows rearward from the front anchor.
        if op_props is not None:
            if getattr(op_props, 'drawer_box_override_width', False):
                box_dx = min(op_props.drawer_box_width, cage_x - rl - rr)
            if getattr(op_props, 'drawer_box_override_height', False):
                box_dz = min(op_props.drawer_box_height,
                             cage_z - rt - rb - bottom_clr)
            if getattr(op_props, 'drawer_box_override_depth', False):
                box_dy = min(op_props.drawer_box_depth,
                             cage_y - front_back_y)
        if box_dx <= 0.0 or box_dy <= 0.0 or box_dz <= 0.0:
            return None

        # Box origin (front-left-bottom corner) in opening-local coords.
        # The centered-width form reduces to rl + side_clr at the auto
        # width and keeps an overridden width centered in the hole.
        op_x = rl + ((cage_x - rl - rr) - box_dx) / 2.0
        op_y = front_back_y
        op_z = rb + bottom_clr

        # Pipe chase interaction: shorten, notch, or leave the box per
        # the opening's chase_fit (see _chase_fit_box).
        box_dy, notch_w = self._chase_fit_box(
            pivot_obj.parent, op_props, op_x, op_y, box_dx, box_dy, rear_clr)
        if box_dy <= 0.0:
            return None
        chase_notch = notch_w is not None

        box = GeoNodeDrawerBox()
        box.create('Drawer Box')
        box.obj.parent = pivot_obj
        box.obj.location = (op_x - a_x, op_y - a_y, op_z - a_z)
        box.set_input('Dim X', box_dx)
        box.set_input('Dim Y', box_dy)
        box.set_input('Dim Z', box_dz)
        box.obj['hb_part_role'] = PART_ROLE_DRAWER_BOX
        box.obj['CABINET_PART'] = True
        box.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_drawer_box_commands'
        self._stamp_drawer_box_construction(box.obj, op_props)
        if op_props is not None:
            self._spawn_drawer_inserts(box.obj, box_dx, box_dy, box_dz,
                                       op_props)
        if op_props is not None and getattr(op_props, 'sink_duo', False):
            self._apply_sink_duo_notch(box.obj, box_dx, box_dy, box_dz,
                                       op_props)
        if chase_notch:
            # _iter_pipe_chase_cut_targets picks this up and booleans
            # the chase cutter into the box. The notch does NOT change
            # the box's Dim inputs - the box ships full size and the
            # notch is a custom shop operation, so publish the notch
            # rect for drawings / reports to flag.
            box.obj['HB_CHASE_FIT'] = 'NOTCH'
            box.obj['CHASE_NOTCHED'] = True
            box.obj['CHASE_NOTCH_WIDTH'] = notch_w
            box.obj['CHASE_NOTCH_DEPTH'] = intrusion
        return box

    @staticmethod
    def _apply_sink_duo_notch(box_obj, box_dx, box_dy, box_dz, op_props):
        """U-shaped (sink duo) drawer box: boolean a centered notch into
        the box from the back so it wraps the sink basin / plumbing.
        The cutter is a wire child of the box (both are wiped and
        rebuilt every recalc together); the notch rect is published on
        the box for drawings / reports. The box's Dim inputs stay full
        size -- the U is a shop operation on the built box."""
        margin = inch(0.5)
        notch_w = min(getattr(op_props, 'sink_duo_notch_width', 0.0),
                      box_dx)
        notch_d = getattr(op_props, 'sink_duo_notch_depth', 0.0)
        if notch_d <= 0.0:
            notch_d = box_dy * (2.0 / 3.0)
        notch_d = min(notch_d, box_dy)
        if notch_w <= 0.0 or notch_d <= 0.0:
            return
        x0 = (box_dx - notch_w) / 2.0
        x1 = x0 + notch_w
        mesh = bpy.data.meshes.new('Sink Duo Cutter')
        cutter = hb_utils.new_object('Sink Duo Cutter', mesh)
        cutter['hb_part_role'] = PART_ROLE_DRAWER_BOX_CUTTER
        cutter.parent = box_obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in box_obj.users_collection:
            coll.objects.link(cutter)
            break
        bm = bmesh.new()
        bmesh.ops.create_cube(bm, size=1.0)
        for v in bm.verts:
            v.co.x = x0 if v.co.x < 0.0 else x1
            v.co.y = (box_dy - notch_d) if v.co.y < 0.0 else box_dy + margin
            v.co.z = -margin if v.co.z < 0.0 else box_dz + margin
        bm.to_mesh(mesh)
        bm.free()
        _seed_cutter_material(cutter, box_obj)
        mod = box_obj.modifiers.new(name='Sink Duo Notch', type='BOOLEAN')
        mod.operation = 'DIFFERENCE'
        # Cut faces read the cutter's material (the material walk keeps
        # the cutter on the box's interior finish); without this they
        # come through unshaded in material view.
        mod.material_mode = 'TRANSFER'
        # MANIFOLD, not EXACT: the drawer box mesh is several closed
        # box islands, and EXACT degenerates on it (drops faces without
        # cutting). Every input here is a closed solid, which is what
        # the manifold solver requires.
        mod.solver = 'MANIFOLD'
        mod.object = cutter
        box_obj['SINK_DUO'] = True
        box_obj['SINK_DUO_NOTCH_WIDTH'] = notch_w
        box_obj['SINK_DUO_NOTCH_DEPTH'] = notch_d

    @staticmethod
    def _apply_finger_scoop(box_obj, box_dx, box_dz, thickness):
        """Cut the finger scoop into the front of a rollout box.

        The scoop is how a rollout is actually built -- a shaped notch
        centred in the top edge of the box front, there to pull on -- so
        a box drawn square understated it on every drawing.

        Same idiom as the sink duo notch: a wire cutter child and a
        boolean, both wiped and rebuilt with the box, and the feature
        published on the box for drawings and reports. Skipped on a box
        too small to take it, which leaves the front square rather than
        cutting most of it away.
        """
        if thickness <= 0.0:
            return False
        clear_span = box_dx - 2.0 * thickness
        if clear_span <= inch(_SCOOP_TOP_WIDTH + 2.0 * _SCOOP_CORNER + 0.5):
            return False
        if box_dz - inch(_SCOOP_DEPTH) < inch(0.5):
            return False

        # Through the front only. The back is a box depth away, but the
        # cutter still stops short of it so nothing else can be nicked.
        y0 = -inch(0.5)
        y1 = thickness + inch(0.05)
        over = inch(0.25)
        cx, zt = box_dx / 2.0, box_dz

        mesh = bpy.data.meshes.new('Finger Scoop Cutter')
        cutter = hb_utils.new_object('Finger Scoop Cutter', mesh)
        cutter['hb_part_role'] = PART_ROLE_DRAWER_BOX_CUTTER
        cutter.parent = box_obj
        cutter.display_type = 'WIRE'
        cutter.hide_render = True
        cutter.hide_viewport = True
        for coll in box_obj.users_collection:
            coll.objects.link(cutter)
            break

        # The profile, lidded above the box top so the cut region is a
        # closed face rather than an open curve.
        poly = [(cx + inch(px), zt - inch(pd))
                for px, pd in _finger_scoop_profile()]
        poly.append((poly[-1][0], zt + over))
        poly.append((poly[0][0], zt + over))

        bm = bmesh.new()
        verts = [bm.verts.new((x, y0, z)) for x, z in poly]
        face = bm.faces.new(verts)
        ext = bmesh.ops.extrude_face_region(bm, geom=[face])
        moved = [e for e in ext['geom'] if isinstance(e, bmesh.types.BMVert)]
        bmesh.ops.translate(bm, vec=(0.0, y1 - y0, 0.0), verts=moved)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        bm.free()

        _seed_cutter_material(cutter, box_obj)
        mod = box_obj.modifiers.new(name='Finger Scoop', type='BOOLEAN')
        mod.operation = 'DIFFERENCE'
        # Cut faces read the cutter's material, as the profile and
        # corner-treatment cuts do -- the material walk puts the box's
        # interior finish on the cutter for exactly this.
        mod.material_mode = 'TRANSFER'
        # MANIFOLD for the same reason the sink duo notch uses it: the
        # box is several closed islands and EXACT drops faces on it.
        mod.solver = 'MANIFOLD'
        mod.object = cutter
        box_obj['FINGER_SCOOP'] = True
        box_obj['FINGER_SCOOP_WIDTH'] = inch(_SCOOP_TOP_WIDTH)
        box_obj['FINGER_SCOOP_DEPTH'] = inch(_SCOOP_DEPTH)
        return True

    def _update_interior_items_in_opening(self, opening_obj, layout, rect):
        """Rebuild the opening's interior parts (shelves, accessory
        labels, ...). Same wipe-and-recreate strategy as fronts:
        interior parts hold no user state worth preserving across
        recalcs - their geometry is fully derived from the InteriorItem
        collection on the opening props.

        Panel roots (face-frame only) never have interior parts; we
        still run the wipe to clean up anything stale, then clear the
        collection and return before the spawn loop.
        """
        op_props = opening_obj.face_frame_opening

        # Wipe existing interior children. Match either by role tag or
        # by the explicit ACCESSORY marker we set on text objects, since
        # text-data objects can't carry the same custom prop conventions
        # quite as cleanly as mesh parts.
        for child in list(opening_obj.children):
            if child.get('hb_part_role') in INTERIOR_PART_ROLES:
                # A boolean operand has to be an object, so a part's
                # cutters hang off the PART rather than off the opening
                # and this loop never sees them. Take them with their
                # host: removing the host alone leaves them behind as
                # loose wire objects that nothing ever collects.
                for sub in list(child.children):
                    if sub.get('hb_part_role') != PART_ROLE_DRAWER_BOX_CUTTER:
                        continue
                    sub_data = sub.data
                    bpy.data.objects.remove(sub, do_unlink=True)
                    if (isinstance(sub_data, bpy.types.Mesh)
                            and sub_data.users == 0):
                        bpy.data.meshes.remove(sub_data)
                data = child.data
                bpy.data.objects.remove(child, do_unlink=True)
                # Orphaned data (per-part meshes like shelf nosings,
                # accessory font curves) would otherwise pile up until
                # the next save. Shared data keeps users and is skipped.
                if data is not None and data.users == 0:
                    if isinstance(data, bpy.types.Mesh):
                        bpy.data.meshes.remove(data)
                    elif isinstance(data, bpy.types.Curve):
                        bpy.data.curves.remove(data)

        if not self._has_carcass():
            if len(op_props.interior_items) > 0:
                op_props.interior_items.clear()
            return

        # Share remainder between unlocked siblings of every split
        # node so users can edit either side of a divider and have
        # the other yield. No-op when the opening uses the flat path.
        # Runs before cage sizing so the leaf wireframes pick up the
        # redistributed sizes.
        self._redistribute_interior_split_tree(opening_obj, rect)

        # Bring leaf cage dims + child locations into sync with the
        # tree props before reading any rects from the tree (no-op
        # when the opening uses the flat path).
        self._update_interior_tree_cages(opening_obj, rect)

        # Sync auto-computed shelf counts for any unlocked items before
        # the solver reads them. Writing shelf_qty fires its update
        # callback which would re-enter recalculate_face_frame_cabinet,
        # but the _RECALCULATING guard short-circuits that. When a tree
        # exists, every leaf's items get the same auto rule applied
        # against the leaf's own height (so a fixed shelf splitting an
        # opening into halves seeds each half independently).
        for region_props, region_z in self._walk_interior_regions(
            opening_obj, rect,
        ):
            for item in region_props.interior_items:
                if (item.kind in ('ADJUSTABLE_SHELF',
                                  'HALF_DEPTH_SHELF',
                                  'QUARTER_DEPTH_SHELF')
                        and not item.unlock_shelf_qty):
                    # The item's bottom offset shrinks the space the
                    # stack distributes in, so the auto count reads the
                    # remaining height, not the full region height.
                    item_h = max(
                        0.0,
                        region_z - getattr(item, 'bottom_offset', 0.0),
                    )
                    auto_qty = solver.auto_shelf_qty(item_h, layout.dim_y)
                    if item.shelf_qty != auto_qty:
                        item.shelf_qty = auto_qty
                elif (item.kind == 'ROLLOUT'
                      and len(item.rollout_boxes) == 0 and item.qty > 0):
                    # One-time migration of rollouts saved before per-box
                    # heights: seed one box per qty at the old uniform
                    # height. Guarded on an empty collection so it runs once;
                    # the writes re-enter recalc but the _RECALCULATING guard
                    # absorbs that.
                    from . import props_hb_face_frame
                    preset = props_hb_face_frame.rollout_height_preset_for(
                        item.rollout_height)
                    for _ in range(item.qty):
                        box = item.rollout_boxes.add()
                        box.height_preset = preset
                        if preset == 'CUSTOM':
                            box.height = item.rollout_height

        # The rollout that rides above a drawer is a normal ROLLOUT
        # interior item - it just belongs to the cabinet rather than to
        # the user, so it is kept in step here and taken away again when
        # the option goes off.
        self._reconcile_rollout_above_drawer(opening_obj, rect)

        # Floating-shelf PRODUCTS dropped into this opening (library
        # placement with the cursor over the opening) auto-fit its span
        # like the adjustable shelves spawned below.
        self._fit_opening_floating_shelves(opening_obj, rect)

        for desc in solver.interior_descriptors_for_opening(
            opening_obj, layout, rect, self.obj.face_frame_cabinet,
        ):
            kind = desc['kind']
            if kind == 'ADJUSTABLE_SHELF':
                self._create_shelf_part(opening_obj, desc)
            elif kind == 'SHELF_NOSING':
                self._create_shelf_nosing(opening_obj, desc)
            elif kind == 'ACCESSORY':
                # Nothing is printed inside a drawer: what the drawer
                # holds is either modeled in the box or carried by the
                # item data alone.
                if op_props.front_type not in DRAWER_BOX_FRONT_TYPES:
                    self._create_accessory_label(opening_obj, desc)
            elif kind == 'ROLLOUT_BOX':
                self._create_rollout_box(opening_obj, desc)
            elif kind == 'GALLEY_ROLLOUT_TOP':
                self._create_galley_rollout_top(opening_obj, desc)
            elif kind == 'CLOSET_ROD':
                self._create_closet_rod_part(opening_obj, desc)
            elif kind in bar_storage.KINDS:
                self._create_bar_storage_part(opening_obj, desc)
            elif kind in ('INTERIOR_FF_RAIL', 'INTERIOR_FF_STILE'):
                self._create_interior_face_frame_part(
                    opening_obj, desc,
                )
            else:
                # All remaining mesh-based interior parts route through
                # the generic factory; orientation in the descriptor
                # drives rotation / mirror flags. Covers GLASS_SHELF,
                # PULLOUT_SHELF, PULLOUT_SPACER, ROLLOUT_SPACER,
                # TRAY_DIVIDER, TRAY_LOCKED_SHELF, VANITY_SHELF,
                # VANITY_SUPPORT.
                self._create_interior_mesh_part(opening_obj, desc)

    # Marks the ROLLOUT interior item this cabinet owns, so it can be
    # told apart from one the user added and taken away again when the
    # option goes off.
    ROLLOUT_ABOVE_MARK = 'managed_rollout_above'

    def _reconcile_rollout_above_drawer(self, opening_obj, rect):
        """Keep the rollout that rides above a drawer in step with the
        opening's option.

        It is a normal ROLLOUT interior item - same box, same slides,
        same spacer ladders - so everything downstream (the cutlist, the
        drawings, the open/close command) treats it as the rollout it
        is. The only difference is that the cabinet owns it: its height
        comes from the opening's rollout_above_height and it sits at the
        top of the opening, with the drawer box below shortened to suit
        (see _create_drawer_box_for_front).

        Writes here re-enter recalc; the _RECALCULATING guard absorbs
        that, the same way the rollout-box migration above does.
        """
        op_props = getattr(opening_obj, 'face_frame_opening', None)
        if op_props is None:
            return
        wants = (getattr(op_props, 'rollout_above_drawer', False)
                 and op_props.front_type in ('DRAWER_FRONT', 'PULLOUT'))

        managed = [item for item in op_props.interior_items
                   if item.get(self.ROLLOUT_ABOVE_MARK)]
        if not wants:
            for item in managed:
                index = list(op_props.interior_items).index(item)
                op_props.interior_items.remove(index)
            return

        if managed:
            item = managed[0]
            # More than one can only come from a duplicate; keep the first.
            for extra in managed[1:]:
                op_props.interior_items.remove(
                    list(op_props.interior_items).index(extra))
        else:
            item = op_props.interior_items.add()
            item[self.ROLLOUT_ABOVE_MARK] = True
            item.kind = 'ROLLOUT'
            item.qty = 1

        cage_z = rect['cage_dim_z']
        height = op_props.rollout_above_height
        scene_props = bpy.context.scene.hb_face_frame
        top_clr = scene_props.drawer_box_top_clearance
        # The rollout hangs at the top of the opening; the drawer box
        # takes what is left under it.
        bottom_gap = max(cage_z - top_clr - height, 0.0)

        if item.kind != 'ROLLOUT':
            item.kind = 'ROLLOUT'
        if item.qty != 1:
            item.qty = 1
        if len(item.rollout_boxes) != 1:
            item.rollout_boxes.clear()
            item.rollout_boxes.add()
        box = item.rollout_boxes[0]
        if box.height_preset != 'CUSTOM':
            box.height_preset = 'CUSTOM'
        if abs(box.height - height) > 1e-6:
            box.height = height
        if abs(item.bottom_gap - bottom_gap) > 1e-6:
            item.bottom_gap = bottom_gap

    def _fit_opening_floating_shelves(self, opening_obj, rect):
        """Auto-fit floating-shelf PRODUCTS parented into this opening.

        A shelf placed from the library with the cursor over an opening
        parents to the opening cage; every host recalc re-fits it here
        so it tracks the opening exactly like an adjustable shelf:
        width = opening span minus the shelf side clearances, depth =
        opening depth minus the back setback, front at the opening
        front plane. The user's vertical location is kept, clamped
        inside the opening. The shelf's own recalc is invoked directly
        because prop updates are absorbed by the host's recalc guard.
        """
        shelves = [c for c in opening_obj.children
                   if c.get(FLOATING_SHELF_TAG)]
        if not shelves:
            return
        dx = rect['cage_dim_x']
        dz = rect['cage_dim_z']
        dy = rect['cage_dim_y']
        width = max(0.0, dx - 2.0 * solver.SHELF_X_CLEARANCE)
        depth = max(0.0, dy - solver.SHELF_BACK_SETBACK)
        for sh in shelves:
            props = sh.face_frame_cabinet
            sh.location = (
                solver.SHELF_X_CLEARANCE, depth,
                min(max(sh.location.z, 0.0), max(0.0, dz - props.height)))
            sh.rotation_euler = (0.0, 0.0, 0.0)
            props.width = width
            props.depth = depth
            fs = FloatingShelfFaceFrameCabinet()
            fs.obj = sh
            fs.recalculate()

    def _create_shelf_part(self, opening_obj, desc):
        """Horizontal panel oriented as Length+X, Width+Y, Thickness+Z
        (matches the carcass bottom panel and H-axis bay backings - no
        rotation, no mirror flags beyond the GeoNodeCage default).

        Tagged IS_FACE_FRAME_INTERIOR_PART so the 'Interiors' selection
        mode picks shelves up alongside any future interior parts.
        """
        part = CabinetPart()
        part.create(desc['name'])
        part.obj.parent = opening_obj
        part.obj['hb_part_role'] = desc['role']
        part.obj['CABINET_PART'] = True
        part.obj['IS_FACE_FRAME_INTERIOR_PART'] = True
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_interior_part_commands'
        part.obj.location = desc['position']
        length, width, thickness = desc['dims']
        part.set_input('Length', length)
        part.set_input('Width', width)
        part.set_input('Thickness', thickness)
        return part

    def _create_shelf_nosing(self, opening_obj, desc):
        """Solid-stock nosing profile on the front edge of an
        adjustable shelf. A plain swept mesh, deliberately NOT tagged
        CABINET_PART: it is molding stock, not a sheet-stock cutpart,
        so part-collection passes (reports, machining) must not pick
        it up as one. The material walk finds it by role instead.
        """
        obj = shelf_nosing.build_nosing_object(
            desc['name'], desc['length'], desc['style'],
            desc['shelf_thickness'], desc['height'],
        )
        bpy.context.scene.collection.objects.link(obj)
        obj.parent = opening_obj
        obj.location = desc['position']
        obj['hb_part_role'] = desc['role']
        obj['IS_FACE_FRAME_INTERIOR_PART'] = True
        obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_interior_part_commands'
        return obj

    def _create_accessory_label(self, opening_obj, desc):
        """Blender text object centered in the opening, rotated to face
        the front of the cabinet. The hb_part_role tag lets the wipe
        pass find and remove it on the next recalc, same way it finds
        shelves.
        """
        font_curve = bpy.data.curves.new(type='FONT', name=desc['name'])
        font_curve.body = desc['text']
        font_curve.size = desc['size']
        font_curve.align_x = 'CENTER'
        font_curve.align_y = 'CENTER'
        text_obj = hb_utils.new_object(desc['name'], font_curve)
        bpy.context.scene.collection.objects.link(text_obj)
        # Resolved annotation font + color (Calibri by default).
        apply_label_style(text_obj, bpy.context.scene)
        text_obj.parent = opening_obj
        text_obj.location = desc['position']
        text_obj.rotation_euler = desc['rotation']
        text_obj['hb_part_role'] = desc['role']
        # Annotation tag so the end-of-recalc cabinet-style pass
        # (toggle_cabinet_color) colors it as annotation text rather
        # than repainting it the default white.
        text_obj['IS_2D_ANNOTATION'] = True
        return text_obj

    def _redistribute_interior_split_tree(self, opening_obj, rect):
        """Top-level entry: walk the opening's interior tree and share
        the remainder among unlocked siblings of every split node. No-op
        when the opening uses the flat path. Mirrors the front-frame
        _redistribute_split_node convention so editing either child of
        a divider feels the same as editing either child of a bay split.
        """
        root = solver._interior_tree_root(opening_obj)
        if root is None:
            return
        self._redistribute_interior_node(root, rect)

    def _redistribute_interior_node(self, node, rect):
        """If node is a split, share remainder among its unlocked
        children and recurse. Leaves end the recursion. Writes happen
        inside the cabinet's _RECALCULATING guard so per-prop update
        callbacks short-circuit and don't re-enter recalc.
        """
        if not node.get(TAG_INTERIOR_SPLIT_NODE):
            return
        sp = node.face_frame_interior_split
        children = sorted(
            [c for c in node.children
             if c.get(TAG_INTERIOR_REGION)
             or c.get(TAG_INTERIOR_SPLIT_NODE)],
            key=lambda c: c.get('hb_interior_child_index', 0),
        )
        if len(children) != 2:
            return

        is_h = (sp.axis == 'H')
        parent_dim = rect['cage_dim_z'] if is_h else rect['cage_dim_x']
        div_t = sp.divider_thickness

        locked_total = 0.0
        unlocked = []
        for c in children:
            size_val, unlock = solver._read_interior_node_size(c)
            # unlock=True means hold the stored size (matches the
            # naming convention from front-frame's split tree).
            if unlock:
                locked_total += size_val
            else:
                unlocked.append(c)

        remainder = max(0.0, parent_dim - div_t - locked_total)
        share = remainder / len(unlocked) if unlocked else 0.0

        # Reuse _DISTRIBUTING_WIDTHS as the system-write guard so the
        # interior-size update callback knows these writes are not
        # user edits and skips the auto-lock.
        _DISTRIBUTING_WIDTHS.add(id(self.obj))
        try:
            for c in unlocked:
                if c.get(TAG_INTERIOR_REGION):
                    c.face_frame_interior_region.size = share
                else:
                    c.face_frame_interior_split.size = share
        finally:
            _DISTRIBUTING_WIDTHS.discard(id(self.obj))

        # Recurse with each child's resolved sub-rect
        for c in children:
            size_val, _ = solver._read_interior_node_size(c)
            if is_h:
                child_rect = {
                    'cage_dim_x': rect['cage_dim_x'],
                    'cage_dim_y': rect['cage_dim_y'],
                    'cage_dim_z': size_val,
                }
            else:
                child_rect = {
                    'cage_dim_x': size_val,
                    'cage_dim_y': rect['cage_dim_y'],
                    'cage_dim_z': rect['cage_dim_z'],
                }
            self._redistribute_interior_node(c, child_rect)

    def _update_interior_tree_cages(self, opening_obj, rect):
        """Walk the opening's interior tree and bring each cage's
        Dim X/Y/Z + each child's location into sync with the current
        tree props (axis, divider_thickness, child sizes). No-op when
        the opening has no tree.

        Mirrors the layout math in solver._walk_interior_node so the
        wireframe leaf cages render in the same positions the
        descriptor walker computes for items.
        """
        root = solver._interior_tree_root(opening_obj)
        if root is None:
            return
        # The root sits at the opening's origin and inherits the full
        # rect; downstream relative offsets accumulate via parent-child.
        root.location = (0.0, 0.0, 0.0)
        self._size_interior_node(root, rect)

    def _size_interior_node(self, node, rect):
        """Recurse: at leaves, write Dim X/Y/Z on the cage; at split
        nodes, compute child rects + relative offsets, update child
        locations, and recurse.
        """
        if node.get(TAG_INTERIOR_REGION):
            region = FaceFrameInteriorRegion(node)
            region.set_input('Dim X', rect['cage_dim_x'])
            region.set_input('Dim Y', rect['cage_dim_y'])
            region.set_input('Dim Z', rect['cage_dim_z'])
            return

        if not node.get(TAG_INTERIOR_SPLIT_NODE):
            return

        sp = node.face_frame_interior_split
        children = sorted(
            [c for c in node.children
             if c.get(TAG_INTERIOR_REGION)
             or c.get(TAG_INTERIOR_SPLIT_NODE)],
            key=lambda c: c.get('hb_interior_child_index', 0),
        )
        if len(children) != 2:
            return

        div_t = sp.divider_thickness
        cage_x = rect['cage_dim_x']
        cage_y = rect['cage_dim_y']
        cage_z = rect['cage_dim_z']
        size_a, _ = solver._read_interior_node_size(children[0])
        size_b, _ = solver._read_interior_node_size(children[1])

        if sp.axis == 'H':
            children[0].location = (0.0, 0.0, 0.0)
            children[1].location = (0.0, 0.0, size_a + div_t)
            self._size_interior_node(children[0], {
                'cage_dim_x': cage_x, 'cage_dim_y': cage_y,
                'cage_dim_z': size_a,
            })
            self._size_interior_node(children[1], {
                'cage_dim_x': cage_x, 'cage_dim_y': cage_y,
                'cage_dim_z': size_b,
            })
        else:
            children[0].location = (0.0, 0.0, 0.0)
            children[1].location = (size_a + div_t, 0.0, 0.0)
            self._size_interior_node(children[0], {
                'cage_dim_x': size_a, 'cage_dim_y': cage_y,
                'cage_dim_z': cage_z,
            })
            self._size_interior_node(children[1], {
                'cage_dim_x': size_b, 'cage_dim_y': cage_y,
                'cage_dim_z': cage_z,
            })

    def _walk_interior_regions(self, opening_obj, opening_rect):
        """Yield (region_props, region_height) pairs covering every
        leaf in the opening's interior tree. When the opening has no
        tree, yields exactly one pair: the opening's own props + the
        face frame opening height. Used by the auto-shelf-qty pass so
        each leaf seeds its shelf count from its own height, not the
        whole opening's. The catalog shelf table is keyed on the FACE
        FRAME opening height, not the carcass cage height -- the cage
        runs top rail to top panel and can sit a bracket above the
        opening the dealer measures (e.g. a 13 7/8" opening in an 18"
        upper has a ~15 3/4" cage, which wrongly earned 1 shelf).
        """
        ff_opening_h = (opening_rect['cage_dim_z']
                        - opening_rect['reveal_top']
                        - opening_rect['reveal_bottom'])
        root = solver._interior_tree_root(opening_obj)
        if root is None:
            yield (opening_obj.face_frame_opening, ff_opening_h)
            return

        def _recurse(node, dim_z):
            if node.get(TAG_INTERIOR_REGION):
                yield (node.face_frame_interior_region, dim_z)
                return
            if not node.get(TAG_INTERIOR_SPLIT_NODE):
                return
            sp = node.face_frame_interior_split
            children = sorted(
                [c for c in node.children
                 if c.get(TAG_INTERIOR_REGION)
                 or c.get(TAG_INTERIOR_SPLIT_NODE)],
                key=lambda c: c.get('hb_interior_child_index', 0),
            )
            if len(children) != 2:
                return
            size_a, _ = solver._read_interior_node_size(children[0])
            size_b, _ = solver._read_interior_node_size(children[1])
            if sp.axis == 'H':
                yield from _recurse(children[0], size_a)
                yield from _recurse(children[1], size_b)
            else:
                # V-split doesn't change Z extent for either child.
                yield from _recurse(children[0], dim_z)
                yield from _recurse(children[1], dim_z)

        yield from _recurse(root, ff_opening_h)

    def _create_interior_mesh_part(self, opening_obj, desc):
        """Generic interior mesh-part factory. Reads desc['orientation']
        for rotation / mirror conventions:

          HORIZONTAL  - no rotation, no mirror; origin = front-left-bottom.
                        Length+X, Width+Y, Thickness+Z.
          VERTICAL    - rotation_euler.y = -90 deg, Mirror Y, Mirror Z.
                        Origin = back-bottom; length runs +Z (up), width
                        runs -Y (forward). Matches Mid Division /
                        Partition Skin convention.

        Tagged IS_FACE_FRAME_INTERIOR_PART so the wipe pass picks it up
        on every recalc.
        """
        part = CabinetPart()
        part.create(desc['name'])
        part.obj.parent = opening_obj
        part.obj['hb_part_role'] = desc['role']
        part.obj['CABINET_PART'] = True
        part.obj['IS_FACE_FRAME_INTERIOR_PART'] = True
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_interior_part_commands'
        part.obj.location = desc['position']

        orientation = desc.get('orientation', 'HORIZONTAL')
        if orientation == 'VERTICAL':
            part.obj.rotation_euler.y = math.radians(-90)
            part.set_input('Mirror Y', True)
            part.set_input('Mirror Z', True)
        # HORIZONTAL falls through with default rotation/mirror.

        length, width, thickness = desc['dims']
        part.set_input('Length', length)
        part.set_input('Width', width)
        part.set_input('Thickness', thickness)
        return part

    def _create_galley_rollout_top(self, opening_obj, desc):
        """A workstation roll-out's plywood top: a plain slab over the
        box, with the bowl or bin opening cut by a hidden cutter that
        is wiped and remade with the top on every recalc."""
        part = self._create_interior_mesh_part(opening_obj, desc)
        dx, dy, t = desc['dims']
        px, py, pz = desc['position']
        kind = desc.get('galley_top', 'NONE')
        verts, faces = [], []

        def box(x0, x1, y0, y1, z0, z1):
            b = len(verts)
            verts.extend([(x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
                          (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)])
            for f in ((0, 3, 2, 1), (4, 5, 6, 7), (0, 1, 5, 4),
                      (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)):
                faces.append(tuple(b + k for k in f))

        def cylinder(cx, cy, radius, z0, z1, segments=48):
            b = len(verts)
            for z in (z0, z1):
                for i in range(segments):
                    a = 2.0 * math.pi * i / segments
                    verts.append((cx + radius * math.cos(a),
                                  cy + radius * math.sin(a), z))
            for i in range(segments):
                j = (i + 1) % segments
                faces.append((b + i, b + j, b + segments + j, b + segments + i))
            faces.append(tuple(reversed(range(b, b + segments))))
            faces.append(tuple(range(b + segments, b + 2 * segments)))

        z0, z1 = -inch(1.0), t + inch(1.0)
        cx, cy = dx / 2.0, dy / 2.0
        if kind == 'BOWL_10':
            cylinder(cx, cy, inch(5.25), z0, z1)
        elif kind == 'BOWL_14':
            cylinder(cx, cy, inch(7.0), z0, z1)
        elif kind == 'BINS':
            w, d, gap = inch(6.125), inch(3.625), inch(1.0)
            for x in (cx - gap / 2.0 - w, cx + gap / 2.0):
                box(x, x + w, cy - d / 2.0, cy + d / 2.0, z0, z1)
        if not faces:
            return part
        mesh = bpy.data.meshes.new(desc['name'] + ' Cutter')
        mesh.from_pydata(verts, [], faces)
        mesh.validate()
        mesh.update()
        cutter = hb_utils.new_object(desc['name'] + ' Cutter', mesh)
        cutter.parent = opening_obj
        cutter.location = (px, py, pz)
        cutter['hb_part_role'] = 'GALLEY_TOP_CUTTER'
        cutter['IS_FACE_FRAME_INTERIOR_PART'] = True
        cutter.display_type = 'WIRE'
        cutter.hide_viewport = True
        cutter.hide_render = True
        for coll in opening_obj.users_collection:
            coll.objects.link(cutter)
        mod = part.obj.modifiers.new(name='Top Opening', type='BOOLEAN')
        mod.operation = 'DIFFERENCE'
        mod.object = cutter
        return part

    def _create_interior_face_frame_part(self, opening_obj, desc):
        """Optional face frame member at an interior split node - a rail
        for a fixed shelf (kind INTERIOR_FF_RAIL) or a stile for a
        division (kind INTERIOR_FF_STILE). Rotation / mirror conventions
        match the bay mid rail and mid stile so the part lands inline
        with the cabinet face frame plane. Parented to the opening cage
        in opening-local coords and tagged IS_FACE_FRAME_INTERIOR_PART
        so the interior wipe pass rebuilds it each recalc.
        """
        part = CabinetPart()
        part.create(desc['name'])
        part.obj.parent = opening_obj
        part.obj['hb_part_role'] = desc['role']
        part.obj['CABINET_PART'] = True
        part.obj['IS_FACE_FRAME_INTERIOR_PART'] = True
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_interior_part_commands'
        part.obj.location = desc['position']

        if desc['kind'] == 'INTERIOR_FF_STILE':
            # Mid-stile orientation: Length+Z, Width+X, Thickness+Y.
            part.obj.rotation_euler.y = math.radians(-90)
            part.obj.rotation_euler.z = math.radians(90)
            part.set_input('Mirror Y', True)
            part.set_input('Mirror Z', True)
        else:
            # Mid-rail orientation: Length+X, Width+Z, Thickness+Y.
            part.obj.rotation_euler.x = math.radians(90)
            part.set_input('Mirror Z', True)

        length, width, thickness = desc['dims']
        part.set_input('Length', length)
        part.set_input('Width', width)
        part.set_input('Thickness', thickness)
        return part

    def _create_bar_storage_part(self, opening_obj, desc):
        """Bar storage insert (wine rack / cubby / stemware / plate
        rack family). One derived mesh per insert, built in
        bar_storage.py from the opening size. Like shelf nosings it is
        deliberately NOT tagged CABINET_PART: it is a purchased catalog
        unit, not sheet-stock cutparts, so part-collection passes
        (reports, machining) must not pick it up. The material walk
        finds it by role and applies the exterior finish ("Finished to
        match exterior").
        """
        w, depth, h = desc['dims']
        obj = bar_storage.build_bar_storage_object(
            desc['kind'], desc['name'], w, h, depth,
        )
        if obj is None:
            return None
        bpy.context.scene.collection.objects.link(obj)
        obj.parent = opening_obj
        obj.location = desc['position']
        obj['hb_part_role'] = desc['role']
        obj['IS_FACE_FRAME_INTERIOR_PART'] = True
        obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_interior_part_commands'
        return obj

    def _create_closet_rod_part(self, opening_obj, desc):
        """Hang rod across the opening. Reuses the closets library's rod
        node group (round/oval profile with end cups) and the scene rod
        options for profile + finish, so rods look the same regardless of
        which library the cabinet came from. Like bar storage it is NOT
        tagged CABINET_PART: it is hardware, not a sheet-stock cutpart.
        """
        from ...hb_types import GeoNodeObject
        from ..closets import const_closets as closet_const
        rod = GeoNodeObject()
        rod.create('GeoNodeClosetRod', desc['name'])
        rod.obj.parent = opening_obj
        rod.obj['hb_part_role'] = desc['role']
        rod.obj['IS_FACE_FRAME_INTERIOR_PART'] = True
        rod.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_interior_part_commands'
        rod.obj.location = desc['position']
        rod.set_input('Dim X', desc['dims'][0])
        rod.set_input('Radius', closet_const.ROD_RADIUS)
        rod.set_input('Cup Depth', closet_const.ROD_CUP_DEPTH)
        rod.set_input('Cup Depth 2', closet_const.ROD_CUP_DEPTH_2)
        props = getattr(bpy.context.scene, 'hb_closets', None)
        rod.set_input(
            'Is Oval',
            getattr(props, 'closet_rod_type', 'OVAL') == 'OVAL')
        try:
            from ..closets import pulls_closets
            rod_mat = pulls_closets.load_finish_material(
                getattr(props, 'closet_rod_finish', 'Polished Chrome'))
            if rod_mat is not None:
                rod.set_input('Material', rod_mat)
        except Exception:
            pass
        return rod

    def _create_rollout_box(self, opening_obj, desc):
        """Drawer box for ROLLOUT items. Uses GeoNodeDrawerBox parented
        to the opening cage in opening-local coords; origin sits at the
        box's front-left-bottom corner.
        """
        box = GeoNodeDrawerBox()
        box.create(desc['name'])
        box.obj.parent = opening_obj
        box.obj['hb_part_role'] = desc['role']
        box.obj['CABINET_PART'] = True
        box.obj['IS_FACE_FRAME_INTERIOR_PART'] = True
        box.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_interior_part_commands'
        # Rollouts are drawer boxes too, so they follow the opening's
        # construction pick just like the box behind a drawer front.
        op_props = opening_obj.face_frame_opening
        self._stamp_drawer_box_construction(box.obj, op_props)
        box.obj.location = desc['position']
        dx, dy, dz = desc['dims']
        # A rollout under a sink meets the pipe chase the same way a
        # drawer box does -- U-shape it around the chase, or shorten it
        # to clear the covers, per the opening's chase_fit.
        try:
            rear_clr = bpy.context.scene.hb_face_frame.drawer_box_rear_clearance
        except AttributeError:
            rear_clr = 0.0
        dy, notch_w = self._chase_fit_box(
            opening_obj, op_props, desc['position'][0], desc['position'][1],
            dx, dy, rear_clr)
        if dy <= 0.0:
            bpy.data.objects.remove(box.obj, do_unlink=True)
            return None
        box.set_input('Dim X', dx)
        box.set_input('Dim Y', dy)
        box.set_input('Dim Z', dz)
        if notch_w is not None:
            # _iter_pipe_chase_cut_targets picks this up and booleans the
            # chase cutter into the box. The notch does NOT change the
            # box's Dim inputs -- the box ships full size and the notch is
            # a custom shop operation, so publish the rect for drawings.
            box.obj['HB_CHASE_FIT'] = 'NOTCH'
            box.obj['CHASE_NOTCHED'] = True
            box.obj['CHASE_NOTCH_WIDTH'] = notch_w
        # Per-box U-notch (the rollout equivalent of the sink duo drawer).
        # The indices are stamped so the right-click command can walk back
        # from this object to the rollout_boxes entry that owns it.
        item_index = desc.get('item_index', -1)
        box_index = desc.get('box_index', -1)
        box.obj[TAG_ROLLOUT_ITEM_INDEX] = item_index
        box.obj[TAG_ROLLOUT_BOX_INDEX] = box_index
        box_props = rollout_box_props(opening_obj, item_index, box_index)
        if box_props is not None and getattr(box_props, 'sink_duo', False):
            self._apply_sink_duo_notch(box.obj, dx, dy, dz, box_props)
        # Finger scoop last, and defaulting ON when the item predates the
        # option: it is standard construction, so a box that came through
        # here square was already wrong on the drawing. The U-notch above
        # cannot collide with it -- that cut comes in from the back.
        item_props = rollout_item_props(opening_obj, item_index)
        if item_props is None or getattr(item_props, 'finger_scoop', True):
            self._apply_finger_scoop(
                box.obj, dx, dz, box.get_input('Material Thickness'))
        return box

    def _has_toe_kick(self):
        """Whether this cabinet sits on a toe kick. Subclasses override."""
        return False

    def _has_carcass(self):
        """Whether this root has carcass parts (sides, top, bottom, back,
        stretchers, mid divisions). False for panel-only roots that are
        just a face frame. Subclasses override.
        """
        return True

    def add_temporary_parts(self):
        """Phase 3a stub. Phase 3d implements lazy add/remove of optional
        parts (blind panels, inset toe kicks, nailers, blocking, LED notches).
        """
        pass


# ---------------------------------------------------------------------------
# Cabinet subclasses
# ---------------------------------------------------------------------------
class BaseFaceFrameCabinet(FaceFrameCabinet):
    """Standard base cabinet with toe kick. Sits on the floor."""
    default_cabinet_type = 'BASE'

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            self.default_width = props.default_cabinet_width
            self.default_height = props.base_cabinet_height
            self.default_depth = props.base_cabinet_depth

    def _has_toe_kick(self):
        return True

    def create(self, name="Base Cabinet", bay_qty=1):
        self.create_cabinet_root(name)
        self.create_carcass(has_toe_kick=True, bay_qty=bay_qty)


class FloatingBaseFaceFrameCabinet(BaseFaceFrameCabinet):
    """Base cabinet whose body is lifted off the floor on a separate
    base assembly. Same construction as BASE; toe kick type forced to
    FLOATING at create-time so the carcass sides anchor at the bay
    bottom and no recessed kick subfront is emitted.
    """

    def create(self, name="Floating Base Cabinet", bay_qty=1):
        self.create_cabinet_root(name)
        # Toe kick type override: kick_height keeps its default (the
        # gap between floor and body); change it from the cabinet
        # prompts if a taller reveal is wanted.
        cab_props = self.obj.face_frame_cabinet
        cab_props.toe_kick_type = 'FLOATING'
        self.create_carcass(has_toe_kick=True, bay_qty=bay_qty)


class FurnitureFaceFrameCabinet(BaseFaceFrameCabinet):
    """Shared base for freestanding furniture products (dressers, night
    stands): a base cabinet with a flush (wide-bottom-rail) kick instead
    of a recessed toe kick. The drawer / door layout is applied by the
    placement operator via default_bay_config; the flush kick is forced
    here at create time so it holds regardless of the scene toe-kick
    default. Subclasses set the default height, the bay layout (by name),
    and whether a veneer wood top is added.
    """

    def create(self, name="Furniture Cabinet", bay_qty=1):
        self.create_cabinet_root(name)
        # Furniture base: the face frame's bottom rail runs to the floor
        # (no recess), rather than the NOTCH default.
        self.obj.face_frame_cabinet.toe_kick_type = 'FLUSH'
        self.create_carcass(has_toe_kick=True, bay_qty=bay_qty)


class FiveDrawerDresserCabinet(FurnitureFaceFrameCabinet):
    """48"-tall dresser: split top row (two drawers) over three single
    drawers - five fronts. Gets a veneer wood top (added in a later pass)."""

    def __init__(self):
        super().__init__()
        # Spec height; overrides the inherited base_cabinet_height.
        self.default_height = inch(48.0)

    def create(self, name="5 Drawer Dresser", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        # Veneer wood top - an overhanging slab on the case. Setting the
        # prop fires the recalc callback, which builds it via
        # _apply_furniture_top now that the carcass exists.
        self.obj.face_frame_cabinet.furniture_top = True


class SixDrawerDresserCabinet(FurnitureFaceFrameCabinet):
    """60"-tall dresser: five equal rows, the top row split into two
    side-by-side drawers (six fronts). Carries a veneer wood top like the
    five-drawer."""

    def __init__(self):
        super().__init__()
        # Spec height; overrides the inherited base_cabinet_height.
        self.default_height = inch(60.0)

    def create(self, name="6 Drawer Dresser", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        # Veneer wood top - same overhanging slab as the five-drawer.
        self.obj.face_frame_cabinet.furniture_top = True


class NightStandFaceFrameCabinet(FurnitureFaceFrameCabinet):
    """24"-tall night stand: double doors, flush kick, veneer wood top.
    The double-door layout is applied by the placement operator via
    default_bay_config."""

    def __init__(self):
        super().__init__()
        self.default_height = inch(24.0)

    def create(self, name="Night Stand", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        self.obj.face_frame_cabinet.furniture_top = True


class ThreeDrawerNightStandCabinet(FurnitureFaceFrameCabinet):
    """24"-tall night stand: a single column of three equal drawers,
    flush kick, veneer wood top."""

    def __init__(self):
        super().__init__()
        self.default_height = inch(24.0)

    def create(self, name="3 Drawer Night Stand", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        self.obj.face_frame_cabinet.furniture_top = True


class WindowSeatFaceFrameCabinet(FurnitureFaceFrameCabinet):
    """18"-tall window seat: a standard BASE cabinet with a flush
    (wide-bottom-rail) kick. The flush kick comes from
    FurnitureFaceFrameCabinet (its sole behavior); unlike the dresser /
    night stand products this one gets NO furniture wood top. Each bay
    defaults to a recessed inset panel filling the opening - applied by
    the placement operator via default_bay_config ('INSET_PANEL')."""

    def __init__(self):
        super().__init__()
        # Spec height; overrides the inherited base_cabinet_height.
        self.default_height = inch(18.0)

    def create(self, name="Window Seat", bay_qty=1):
        # Flush kick is forced by the FurnitureFaceFrameCabinet create;
        # no furniture_top write here keeps the top open (no veneer slab).
        super().create(name, bay_qty=bay_qty)


class SinkFaceFrameCabinet(BaseFaceFrameCabinet):
    """Standard base cabinet sized for a sink. Default width is pulled
    from sink_cabinet_width; the bay defaults to false-front-over-doors
    via default_bay_config so the sink basin clears the upper drawer
    position with its own apron. Otherwise a plain BASE construction.
    """

    single_placement = True

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            self.default_width = scene.hb_face_frame.sink_cabinet_width


class CooktopFaceFrameCabinet(BaseFaceFrameCabinet):
    """Base cabinet for a drop-in cooktop: a false front over doors, the
    same construction as the sink cabinet, with the cooktop model
    carried in its bay. Width is seeded from the scene range_width, the
    size a cooktop shares with a range."""

    single_placement = True

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            self.default_width = scene.hb_face_frame.range_width


# ---------------------------------------------------------------------------
# Galley workstation sink base
#
# One long workstation sink over a run of equal openings. Front and
# back aprons hang from the top for the sink to rest between, 1 1/2 in
# supporting partitions stand on the floor under every mid stile and
# against each side, with cleats directly beneath them, and the sink
# spans the end partitions. Sizes are the workstation's, IWS 2 to 7;
# the even sizes end in an 18 in sink base opening.
# ---------------------------------------------------------------------------

GALLEY_SIZES = (
    # key, label, cabinet width, bays, width of the last (sink base) bay
    ('IWS2', "IWS 2", inch(28.0), 1, None),
    ('IWS3', "IWS 3", inch(39.75), 2, None),
    ('IWS4', "IWS 4", inch(51.75), 3, inch(18.0)),
    ('IWS5', "IWS 5", inch(62.0), 3, None),
    ('IWS6', "IWS 6", inch(77.75), 4, inch(18.0)),
    ('IWS7', "IWS 7", inch(83.25), 4, None),
)
GALLEY_SIZE_TABLE = {k: (w, bays, sink_bay) for k, _l, w, bays, sink_bay in GALLEY_SIZES}
GALLEY_APRON_H = inch(10.75)
GALLEY_MATERIAL = inch(0.75)      # aprons, end partitions and cleats
GALLEY_PARTITION_T = inch(1.5)    # a mid partition, built up
GALLEY_FRONT_SETBACK = inch(4.0)


_GALLEY_SEED_PENDING = set()


def _schedule_galley_seed(cab_name):
    """Seed a workstation cabinet's storage openings on the next timer
    tick, outside the recalc that noticed they were empty, under one
    recalc suspension so the writes land as a single rebuild."""
    if cab_name in _GALLEY_SEED_PENDING:
        return
    _GALLEY_SEED_PENDING.add(cab_name)

    def run():
        _GALLEY_SEED_PENDING.discard(cab_name)
        root = bpy.data.objects.get(cab_name)
        if root is None:
            return None
        cab = FaceFrameCabinet(root)
        try:
            with suspend_recalc():
                cab.seed_galley_storage(solver.FaceFrameLayout(root))
        except Exception:
            import traceback
            traceback.print_exc()
        return None

    bpy.app.timers.register(run, first_interval=0.0)


def galley_size_from_name(name):
    """'Galley IWS 4' -> 'IWS4'; None when the name carries no size."""
    m = re.search(r'IWS\s*(\d)', name or '')
    return 'IWS%s' % m.group(1) if m and 'IWS%s' % m.group(1) in GALLEY_SIZE_TABLE else None


def apply_galley_size(root_obj):
    """Size a workstation cabinet to its galley_size: the cabinet width,
    and the last bay pinned to the sink base opening on the sizes that
    have one, the rest sharing the remainder. Bays are made at
    placement, so a size with a different bay count only sets the
    width."""
    props = root_obj.face_frame_cabinet
    width, bays, sink_bay = GALLEY_SIZE_TABLE.get(
        props.galley_size, GALLEY_SIZE_TABLE['IWS3'])
    bay_objs = sorted([c for c in root_obj.children if c.get(TAG_BAY_CAGE)],
                      key=lambda c: c.get('hb_bay_index', 0))
    with suspend_recalc():
        props.width = width
        if len(bay_objs) == bays:
            for i, bay_obj in enumerate(bay_objs):
                bp = bay_obj.face_frame_bay
                if sink_bay is not None and i == bays - 1:
                    bp.width = sink_bay
                else:
                    bp.unlock_width = False


class GalleyWorkstationFaceFrameCabinet(BaseFaceFrameCabinet):
    """Sink base for a Galley workstation sink. A plain BASE construction
    with as many bays as the size calls for; the aprons, partitions,
    cleats and the sink are added by the recalc (see
    _apply_galley_parts). One subclass per size carries the library
    name and the width the placement preview needs."""

    single_placement = True
    size = 'IWS3'

    def __init__(self):
        super().__init__()
        self.default_width = GALLEY_SIZE_TABLE[self.size][0]

    def create(self, name="Galley Workstation", bay_qty=None):
        size = galley_size_from_name(name) or self.size
        width, bays, sink_bay = GALLEY_SIZE_TABLE[size]
        super().create(name, bay_qty=bays)
        # The size's update sizes the cabinet; one recalc at the end.
        with suspend_recalc():
            self.obj.face_frame_cabinet.galley_size = size


class GalleyIWS2Cabinet(GalleyWorkstationFaceFrameCabinet):
    size = 'IWS2'


class GalleyIWS3Cabinet(GalleyWorkstationFaceFrameCabinet):
    size = 'IWS3'


class GalleyIWS4Cabinet(GalleyWorkstationFaceFrameCabinet):
    size = 'IWS4'


class GalleyIWS5Cabinet(GalleyWorkstationFaceFrameCabinet):
    size = 'IWS5'


class GalleyIWS6Cabinet(GalleyWorkstationFaceFrameCabinet):
    size = 'IWS6'


class GalleyIWS7Cabinet(GalleyWorkstationFaceFrameCabinet):
    size = 'IWS7'


class ADASinkCabinet(SinkFaceFrameCabinet):
    """Accessible sink: a shallow box carried clear of the floor, raked
    away underneath so a wheelchair user's knees go under it.

    Built to the shop drawing: a 28" x 21" box 16" tall, floating 17"
    off the floor on the toe kick, which puts its top at 33". The sides
    keep their full height for the 8" against the wall, rake down over
    the next 5", and finish as a 5-1/2" band across the front 8" - an
    11-5/8" raked edge. The rake faces the room, because that is the
    side the knees come in from. The front is a flat band the height of
    that rake band - no stiles, no lower rail, nothing hung off it - and
    there is no carcass bottom, so the plumbing is reachable and nothing
    projects into the knee space.

    Every one of those is a field: the box sizes are the cabinet's, the
    float is its toe kick height, and the rake is the three Raked Sides
    numbers. The rake published on the root is what a drawing reads.
    """

    def __init__(self):
        super().__init__()
        # Overall, floor to top: a 16" box floating 17" up, per the
        # drawing. The toe kick height set at create is the float.
        self.default_width = inch(28.0)
        self.default_depth = inch(21.0)
        self.default_height = inch(33.0)

    def create(self, name="ADA Sink", bay_qty=1):
        self.create_cabinet_root(name)
        cab = self.obj.face_frame_cabinet
        # Carried clear of the floor: the toe kick is the gap beneath.
        cab.toe_kick_type = 'FLOATING'
        cab.toe_kick_height = inch(17.0)
        # Raked underside, to the drawing: full height for the 8"
        # against the wall, then raked down to a 5-1/2" band across the
        # front 8", which is where the knees go under.
        cab.ada_side_shape = True
        cab.ada_side_wall_run = inch(8.0)
        cab.ada_side_front_run = inch(8.0)
        cab.ada_side_front_height = inch(5.5)
        # The front is a flat band the height of the raked band, not a
        # frame with a front in it: the face frame collapses to that one
        # member, so there are no stiles down the ends and no rail under
        # it for a door to hang from. Unlocked so assigning a style
        # cannot write the usual widths back over them.
        cab.unlock_top_rail = True
        cab.unlock_bottom_rail = True
        cab.unlock_left_stile = True
        cab.unlock_right_stile = True
        cab.top_rail_width = cab.ada_side_front_height
        cab.bottom_rail_width = 0.0
        cab.left_stile_width = 0.0
        cab.right_stile_width = 0.0
        self.create_carcass(has_toe_kick=True, bay_qty=bay_qty)
        self.obj[ADA_SINK_TAG] = True
        # Open underneath for the plumbing, and a false front over it -
        # removable on site, so nothing swings into the knee space.
        bays = [c for c in self.obj.children if c.get(TAG_BAY_CAGE)]
        openings = [o for bay in bays for o in bay.children
                    if o.get(TAG_OPENING_CAGE)]
        with suspend_recalc():
            for bay_obj in bays:
                bay_obj.face_frame_bay.remove_bottom = True
            for opening in openings:
                # Nothing hangs off the front: the band above IS the
                # front, and a door here would swing into the knee space.
                opening.face_frame_opening.front_type = 'NONE'
        self.recalculate()


class UpperFaceFrameCabinet(FaceFrameCabinet):
    """Upper (wall) cabinet. No toe kick; mounts above the counter."""
    default_cabinet_type = 'UPPER'

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            self.default_width = props.default_cabinet_width
            self.default_height = props.upper_cabinet_height
            self.default_depth = props.upper_cabinet_depth

    def _has_toe_kick(self):
        return False

    def create(self, name="Upper Cabinet", bay_qty=1):
        self.create_cabinet_root(name)
        self.create_carcass(has_toe_kick=False, bay_qty=bay_qty)
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            self.obj.location.z = scene.hb_face_frame.default_wall_cabinet_location


class FloatingVanityCabinet(FloatingBaseFaceFrameCabinet):
    """Floating vanity: a floating base built as a vanity.

    Nothing about it is a new kind of cabinet - it is the floating toe
    kick that already exists, with the vanity construction switched on:
    a closed top instead of stretchers (a sink sits on it), that top 1/2
    thick over a 3/4 back, and a 12" x 12" opening for the basin. The
    toe kick height is the gap it floats above the floor, so raising it
    lifts the vanity.

    It places like any base cabinet - same sizes, same defaults - and
    comes in with the floating kick and the vanity construction already
    on. The catalog's floor for one of these is a 20" box.
    """

    def create(self, name="Floating Vanity", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        cab = self.obj.face_frame_cabinet
        cab.floating_vanity = True
        # Written rather than left to the checkbox's derived value, so
        # the field a drafter reads matches the part that gets built.
        # Ticking the box on an existing cabinet still derives it.
        cab.back_thickness = inch(0.75)
        # Sized here so they read on the cabinet and can be tuned; the
        # construction itself follows the checkbox.
        cab.top_sink_cutout_width = inch(12.0)
        cab.top_sink_cutout_depth = inch(12.0)
        self.recalculate()


class BookcaseUpperFaceFrameCabinet(UpperFaceFrameCabinet):
    """Open-shelf upper bookcase meant to sit on top of base cabinets.
    Same upper construction (no toe kick), but each bay has its bottom
    panel removed (open underneath) and the default mount height is 36"
    off the floor (default_z_location) instead of the over-counter wall
    location. The open-with-shelves layout is applied by the placement
    operator via default_bay_config ('OPEN_WITH_SHELVES')."""

    # Placement reads this for the floor->bottom mount height (see
    # ops_placement._upper_mount_z); 36" sits it on a base-cabinet run.
    default_z_location = inch(36.0)

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            # Keep the same top-of-cabinet clearance from the ceiling as a
            # standard upper (top sits at ceiling - top_clearance), but
            # start at the lower 36" mount instead of the 54" wall location
            # -> taller by the difference. upper_cabinet_height already
            # bakes in (ceiling - top_clearance - wall_location), so adding
            # back (wall_location - our mount Z) re-tops it at the ceiling
            # clearance from the lower start.
            self.default_height = (
                props.upper_cabinet_height
                + (props.default_wall_cabinet_location - self.default_z_location))

    def create(self, name="Bookcase Upper", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        # Mount height for the direct-create / thumbnail path (placement
        # applies the same value via default_z_location).
        self.obj.location.z = self.default_z_location
        # Open underneath: drop each bay's bottom panel. Snapshot the bay
        # refs first - each remove_bottom write triggers a recalc that
        # reconciles carcass parts; suspend_recalc batches them.
        bay_objs = [c for c in self.obj.children if c.get(TAG_BAY_CAGE)]
        with suspend_recalc():
            for bay_obj in bay_objs:
                bay_obj.face_frame_bay.remove_bottom = True


class HutchUpperFaceFrameCabinet(UpperFaceFrameCabinet):
    """Upper cabinet whose left/right sides and end stiles drop down to the
    countertop, leaving an open recess below the box (a hutch). Standard
    upper body, mount, and height; the 'extend ends down' construction
    option is turned on at create with the drop defaulted to the gap
    between the wall-cabinet mount and the base-cabinet top."""

    def create(self, name="Hutch Upper", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        cab = self.obj.face_frame_cabinet
        cab.extend_left_end_down = True
        cab.extend_right_end_down = True
        # The dropped ends show their inside face from the counter up.
        cab.left_side_finish_inside = True
        cab.right_side_finish_inside = True
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            # Drop both ends to the counter: the wall-cabinet mount minus the
            # base-cabinet height. Editable per-side per-cabinet afterward.
            drop = (props.default_wall_cabinet_location
                    - props.base_cabinet_height)
            cab.extend_left_end_down_amount = drop
            cab.extend_right_end_down_amount = drop


class StandardRecessedMedicineCabinet(UpperFaceFrameCabinet):
    """Recessed medicine cabinet - a shallow wall-mounted upper box
    (3.75" deep x 16.25" wide x 22.75" tall). No finished ends: it sits
    recessed in the wall, so the ends aren't exposed (finish-end auto is
    turned off both sides). Front comes from default_bay_config; a single
    door at this width."""

    # Placement sinks this product into the wall so the face frame sits
    # flush with the wall face (read by the wall-placement operator).
    recess_into_wall = True

    def __init__(self):
        super().__init__()
        self.default_width = inch(16.25)
        self.default_height = inch(22.75)
        self.default_depth = inch(3.75)

    def create(self, name="Standard Recessed Medicine Cabinet", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        cab = self.obj.face_frame_cabinet
        # No finished ends - recessed in the wall, ends not exposed.
        cab.left_finish_end_auto = False
        cab.right_finish_end_auto = False
        cab.left_finished_end_condition = 'UNFINISHED'
        cab.right_finished_end_condition = 'UNFINISHED'


class MedicineCabinetFaceFrameCabinet(UpperFaceFrameCabinet):
    """Surface-mounted medicine cabinet - a standard upper cabinet (same
    default width / height / mount) at a shallow 6" depth. Ends finish
    normally (it projects from the wall), unlike the recessed variant."""

    def __init__(self):
        super().__init__()
        self.default_depth = inch(6.0)

    def create(self, name="Medicine Cabinet", bay_qty=1):
        super().create(name, bay_qty=bay_qty)


class OverstoolCabinetFaceFrameCabinet(MedicineCabinetFaceFrameCabinet):
    """Over-the-toilet cabinet: standard upper width / height at a 9" depth,
    but BOTH carcass side panels extend 7" below the box as furniture legs,
    with a decorative profile cut into the bottom-front corner of each side.
    Only the sides drop - the face frame, end stiles, doors and box stay at
    box bottom."""

    def __init__(self):
        # Deeper than the medicine cabinet it derives from (6") - over a
        # toilet it needs room for the tank/lid clearance.
        super().__init__()
        self.default_depth = inch(9.0)

    def create(self, name="Overstool Cabinet", bay_qty=1):
        super().create(name, bay_qty=bay_qty)
        cab = self.obj.face_frame_cabinet
        cab.extend_sides_down = True
        cab.extend_sides_down_amount = inch(7.0)
        cab.side_front_profile = True


class TriViewMedicineCabinetFaceFrameCabinet(MedicineCabinetFaceFrameCabinet):
    """Tri-view medicine cabinet, built per the production spec: a
    surface-mount upper (6" deep) with THREE REAL BAYS.

    - Face frame: 1-5/16" stiles -- ends AND both mid stiles -- pinned
      via the unlock flags so a style re-apply keeps them.
    - One mirror door per bay, hinged R / R / L. Every door edge takes a
      5/8" overlay (CLIPtop Blumotion 5/8"-overlay hinges), so two
      adjacent doors overlay 5/8 + 5/8 = 1-1/4" of each 1-5/16" mid
      stile and read a 1/16" reveal between the mirrors.
    - Door trim: 1-1/4" wood frame with the MEETING edges left open (no
      trim member) so the mirrors run visually edge-to-edge; only the
      two outer doors keep their outer stile. Stamped as LOCKED
      Set-Door-Frame overrides on each opening cage (the durable store),
      so cabinet edits and style re-applies keep the per-side widths.

    Earlier builds were a SINGLE opening carrying three butting leaves
    driven by the HB_TRIVIEW_DOORS flag (see solver.front_leaves); that
    solver path remains for files placed before this construction, but
    new placements use the standard three-bay machinery -- which is also
    what gives the product its mid stiles, per production."""

    TRIVIEW_STILE_W = inch(1.3125)   # 1-5/16" end + mid stiles
    TRIVIEW_OVERLAY = inch(0.625)    # 5/8" overlay hinges
    TRIVIEW_TRIM_W = inch(1.25)      # 1-1/4" wood door trim

    def create(self, name="Tri-View Medicine Cabinet", bay_qty=3):
        super().create(name, bay_qty=3)
        cab = self.obj.face_frame_cabinet
        # Mirror doors are touch-open: no pulls on any front.
        self.obj['HB_NO_DOOR_PULLS'] = True

        with suspend_recalc():
            # 1-5/16" stiles on the ends and both gaps. Unlock BEFORE
            # width so the write isn't treated as a style-cascade value.
            cab.unlock_left_stile = True
            cab.unlock_right_stile = True
            cab.left_stile_width = self.TRIVIEW_STILE_W
            cab.right_stile_width = self.TRIVIEW_STILE_W
            for entry in cab.mid_stile_widths:
                entry.unlock = True
                entry.width = self.TRIVIEW_STILE_W

            # Openings in bay order: one per bay (default upper config).
            bays = sorted(
                [c for c in self.obj.children if c.get(TAG_BAY_CAGE)],
                key=lambda b: b.face_frame_bay.bay_index)
            openings = []
            for bay in bays:
                for c in bay.children:
                    if c.get(TAG_OPENING_CAGE):
                        openings.append(c)
                        break

            hinges = ('RIGHT', 'RIGHT', 'LEFT')
            trims = (
                (self.TRIVIEW_TRIM_W, 0.0),   # left door: outer stile only
                (0.0, 0.0),                   # center door: no stiles
                (0.0, self.TRIVIEW_TRIM_W),   # right door: outer stile only
            )
            for op_obj, hinge, (left_trim, right_trim) in zip(
                    openings, hinges, trims):
                fop = op_obj.face_frame_opening
                for side in ('left', 'right', 'top', 'bottom'):
                    setattr(fop, f'unlock_{side}_overlay', True)
                    setattr(fop, f'{side}_overlay', self.TRIVIEW_OVERLAY)
                fop.hinge_side = hinge
                fop.front_type = 'DOOR'
                # Locked door-frame override on the opening cage: the
                # same durable store the Set Door Frame dialog writes.
                op_obj['HB_FRAME_OVR_LEFT_STILE'] = left_trim
                op_obj['HB_FRAME_OVR_RIGHT_STILE'] = right_trim
                op_obj['HB_FRAME_OVR_TOP_RAIL'] = self.TRIVIEW_TRIM_W
                op_obj['HB_FRAME_OVR_BOTTOM_RAIL'] = self.TRIVIEW_TRIM_W
                op_obj['HB_FRAME_OVR_MID_RAIL_MODE'] = 'NONE'
                op_obj['HB_FRAME_OVR_MID_RAIL_LOCATION'] = 0.0
                op_obj['HB_FRAME_FRAME_LOCKED'] = True
                # Fixed door look: plain square wood frame + flat mirror
                # panel, regardless of the assigned door style (see
                # _apply_mirror_door_front in props_hb_face_frame).
                op_obj['HB_MIRROR_DOOR'] = True


class TallFaceFrameCabinet(FaceFrameCabinet):
    """Tall cabinet (pantry, oven, broom). Toe kick present, full-tall."""
    default_cabinet_type = 'TALL'

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            self.default_width = props.default_cabinet_width
            self.default_height = props.tall_cabinet_height
            self.default_depth = props.tall_cabinet_depth

    def _has_toe_kick(self):
        return True

    def create(self, name="Tall Cabinet", bay_qty=1):
        self.create_cabinet_root(name)
        self.create_carcass(has_toe_kick=True, bay_qty=bay_qty)


class RefrigeratorCabinet(TallFaceFrameCabinet):
    """Tall cabinet configured to house a refrigerator: doors above,
    open zone below for the fridge.

    Construction differences from a standard tall cabinet:
    - Bay's bottom panel removed (refrigerator zone is open underneath).
    - Both end stiles extend to the floor since there's no kick recess
      to clear behind them.
    - Toe kick height is 0 (no kick recess); the open fridge zone runs
      to the floor.
    - Carcass back is raised by refrigerator_height so it spans only
      the door zone, leaving the lower zone open at the back as well.
    - Bay tree is preset to doors-on-top + appliance-on-bottom, with
      the appliance opening pinned to the scene refrigerator_height.
    """

    single_placement = True

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            self.default_width = props.refrigerator_cabinet_width

    def create(self, name="Refrigerator Cabinet", bay_qty=1):
        self.create_cabinet_root(name)
        cab_props = self.obj.face_frame_cabinet
        cab_props.extend_left_stile_to_floor = True
        cab_props.extend_right_stile_to_floor = True
        # No toe kick: the open fridge zone runs to the floor and the end
        # stiles already extend down, so there's no kick recess. Set
        # BEFORE the back_bottom_inset formula below (and create_carcass)
        # so both the single build recalc and that formula read 0.
        cab_props.toe_kick_height = 0.0
        # Raise the back so it only spans the door zone above the
        # refrigerator. Mirrors the standard back z_origin formula
        # (top of rail - mt) anchored at the top of the rail above the
        # appliance opening: kick + appliance + rail - mt. That rail is
        # the cabinet's BOTTOM rail, not a mid rail: the bays carry
        # remove_bottom (set below), so the appliance opening runs open
        # to the kick and the member capping it is built as the bay's
        # bottom rail (see solver._walk_tree). Captured at create-time;
        # the user can tweak from the cabinet prompts after (same
        # formula in _update_refrigerator_opening_height).
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            # Seed the per-cabinet opening height from the scene default
            # via dict-set so its update callback (which would walk for a
            # not-yet-built opening node) doesn't fire mid-create.
            cab_props['refrigerator_opening_height'] = (
                scene.hb_face_frame.refrigerator_height)
            cab_props.back_bottom_inset = (
                cab_props.toe_kick_height
                + scene.hb_face_frame.refrigerator_height
                + cab_props.bottom_rail_width
                - cab_props.material_thickness
            )
        self.create_carcass(has_toe_kick=True, bay_qty=bay_qty)
        # Drop the bottom panel on each bay so the carcass is open
        # underneath the refrigerator zone. Snapshot the bay refs
        # first because the recalc that fires from each remove_bottom
        # write reconciles back / bottom / kick parts and would
        # invalidate sibling references mid-iteration over
        # self.obj.children. suspend_recalc batches the writes into
        # a single recalc on exit.
        bay_objs = [c for c in self.obj.children if c.get(TAG_BAY_CAGE)]
        with suspend_recalc():
            for bay_obj in bay_objs:
                bay_obj.face_frame_bay.remove_bottom = True

        # ----- Refrigerator stiles (in lieu of leg) -----
        # Two optional lower stiles (floor -> top of fridge opening), one per
        # end, hidden unless refrigerator_stile_left/right is on. Built here (not
        # in create_carcass) so only refrigerator cabinets carry them; the
        # generic recalc positions/hides them by role. Mirror the End Stile setup
        # so a lower stile lines up exactly beneath its (raised) end stile.
        left_refrig = CabinetPart()
        left_refrig.create('Left Refrigerator Stile')
        left_refrig.obj.parent = self.obj
        left_refrig.obj['hb_part_role'] = PART_ROLE_LEFT_REFRIG_STILE
        left_refrig.obj['CABINET_PART'] = True
        left_refrig.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        left_refrig.obj.rotation_euler.y = math.radians(-90)
        left_refrig.obj.rotation_euler.z = math.radians(90)
        left_refrig.set_input('Mirror Y', True)
        left_refrig.set_input('Mirror Z', True)

        right_refrig = CabinetPart()
        right_refrig.create('Right Refrigerator Stile')
        right_refrig.obj.parent = self.obj
        right_refrig.obj['hb_part_role'] = PART_ROLE_RIGHT_REFRIG_STILE
        right_refrig.obj['CABINET_PART'] = True
        right_refrig.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        right_refrig.obj.rotation_euler.y = math.radians(-90)
        right_refrig.obj.rotation_euler.z = math.radians(90)
        right_refrig.set_input('Mirror Y', False)
        right_refrig.set_input('Mirror Z', True)


class BuiltInTallFaceFrameCabinet(TallFaceFrameCabinet):
    """Tall cabinet for a built-in range / oven. Placed like a
    refrigerator: dropped at a fixed width instead of filling the wall
    gap (single_placement). Width is seeded from the scene range_width
    and stays editable during placement (type a width) and from the
    cabinet prompts afterward. The built-in appliance bay layout is
    applied by name via bay_presets.default_bay_config.
    """

    single_placement = True

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            self.default_width = scene.hb_face_frame.range_width


class BookcaseFaceFrameCabinet(TallFaceFrameCabinet):
    """Bookcase: a tall cabinet at a fixed 12" depth with a single open
    bay of adjustable shelves. Depth is locked here rather than pulled
    from tall_cabinet_depth so the bookcase stays shallow regardless of
    the tall-cabinet default; the open-with-shelves bay is applied by
    the placement operator via default_bay_config.
    """

    def __init__(self):
        super().__init__()
        self.default_depth = inch(12.0)

    def create(self, name="Bookcase", bay_qty=1):
        super().create(name, bay_qty=bay_qty)


class BookcaseStorageUnitFaceFrameCabinet(BookcaseFaceFrameCabinet):
    """Bookcase with a storage base: open adjustable shelves on top over a
    double-door cabinet below. Same 12" deep tall body as the plain
    bookcase; the split layout is applied by the placement operator via
    default_bay_config ('BOOKCASE_STORAGE')."""

    def create(self, name="Bookcase Storage Unit", bay_qty=1):
        super().create(name, bay_qty=bay_qty)


class LapDrawerFaceFrameCabinet(FaceFrameCabinet):
    """Lap drawer cabinet: a base cabinet configured to float above the
    counter with a single drawer bay. Built on the BASE construction
    (stretchers + toe kick) and overridden at create-time to FLOATING
    with a 27" lift, so the carcass sits at the lap-drawer reveal.
    """
    default_cabinet_type = 'BASE'

    def __init__(self):
        super().__init__()
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            self.default_width = props.default_cabinet_width
            self.default_height = props.base_cabinet_height
            self.default_depth = props.base_cabinet_depth

    def _has_toe_kick(self):
        return True

    def create(self, name="Lap Drawer Cabinet", bay_qty=1):
        self.create_cabinet_root(name)
        # Lap-drawer-specific toe kick: floating construction with the
        # cabinet body lifted to counter height. Set before create_carcass
        # so the single recalc that builds the parts uses these values.
        cab_props = self.obj.face_frame_cabinet
        cab_props.toe_kick_type = 'FLOATING'
        cab_props.toe_kick_height = inch(27.0)
        self.create_carcass(has_toe_kick=True, bay_qty=bay_qty)


# ---------------------------------------------------------------------------
# Helpers - cabinet lookup and recalc-from-prop-update
# ---------------------------------------------------------------------------
class PanelFaceFrameCabinet(FaceFrameCabinet):
    """Standalone face frame panel: no carcass, just rails / stiles /
    bays / openings. Same machinery as a cabinet, with carcass parts
    gated off. Default 24" x 30" x 0.75" matches a typical applied
    panel size.
    """
    default_cabinet_type = 'PANEL'

    def __init__(self):
        super().__init__()
        self.default_width = inch(24.0)
        self.default_height = inch(30.0)
        self.default_depth = inch(0.75)

    def _has_toe_kick(self):
        return False

    def _has_carcass(self):
        return False

    def create(self, name="Panel", bay_qty=1):
        self.create_cabinet_root(name)
        self.create_carcass(has_toe_kick=False, bay_qty=bay_qty)


class FaceFrameAndDoorsCabinet(PanelFaceFrameCabinet):
    """Standalone face frame + doors: a carcass-less panel (identical to the
    Panel product) whose openings default to working DOORS instead of inset
    panels. Split / change openings afterward exactly like a Panel.

    `default_opening_front_type` is read by default_front_type_for_root when
    each opening is first built. Panel-derived, so it MUST be registered in
    WRAP_CLASS_REGISTRY or recalc re-wraps it as the base carcass cabinet
    (it would gain a carcass) - see Panel / Mirror Frame.

    Openings are pinned to the placed bay count (panel_split_auto off):
    the applied-panel width ladder re-splits a standalone panel to ~18"
    openings on every recalc, which turned a 1-bay placement preview
    into a 2-bay product for anything over 20" wide. Doors follow door
    conventions, not panel aesthetics - the user splits bays manually
    (or re-enables Auto Openings) when they want more.

    fill_manual_bays: the placement modal drags / gap-fills like a
    cabinet and STARTS at one bay - the default-cabinet branch derived
    a bay count from the drag width (>36" placed 2+ bays), pre-splitting
    the frame the user meant to lay out themselves. The Up / Down arrow
    keys still adjust the bay count manually during placement.
    """
    default_opening_front_type = 'DOOR'
    fill_manual_bays = True

    def create(self, name="Face Frame and Doors", bay_qty=1):
        self.create_cabinet_root(name)
        # Raw ID-prop write: set BEFORE the carcass builds so no
        # create-time recalc can apply the ladder, and without firing
        # the prop's update callback (which would recalc mid-create).
        self.obj.face_frame_cabinet["panel_split_auto"] = False
        self.create_carcass(has_toe_kick=False, bay_qty=bay_qty)


class MirrorFrameFaceFrameCabinet(PanelFaceFrameCabinet):
    """Mirror frame: the same flat face-frame panel as the 'Panel' product
    (no carcass - just rails / stiles), 38" wide x 28" tall x 0.75", hung on
    the wall and PLACED like an upper cabinet (mounts_as_upper).

    Built at the Panel DEFAULT size then resized - NOT created straight at
    38x28. A panel created directly at a wide width picks up stray carcass /
    blind parts (a latent quirk in the wide-bay create path); the normal
    draw-a-panel flow creates at default then resizes, which stays clean. We
    reproduce that clean path here."""

    mounts_as_upper = True

    def create(self, name="Mirror Frame", bay_qty=1):
        super().create(name, bay_qty=bay_qty)   # clean Panel at default size
        cab = self.obj.face_frame_cabinet
        cab.width = inch(38.0)
        cab.height = inch(28.0)
        # The inset panel filling the frame is the mirror: the material
        # walk paints INSET_PANEL parts of a cabinet carrying this flag
        # with the shared 'Door Panel Mirror' material (see
        # _apply_materials_to_cabinet).
        self.obj['HB_MIRROR_PANEL_FRONTS'] = True


class TubSkirtFaceFrameCabinet(PanelFaceFrameCabinet):
    """Tub skirt: the exact same flat face-frame panel as the 'Panel' product,
    just 24" tall by default instead of 30". Sits on the floor in front of a
    tub and is placed like a panel (NOT wall-mounted). Like any panel-derived
    class it MUST be registered in WRAP_CLASS_REGISTRY so recalc wraps it as a
    Panel (no carcass); an unregistered panel-derived class falls back to the
    base carcass cabinet (see Mirror Frame)."""

    def __init__(self):
        super().__init__()
        self.default_height = inch(24.0)

    def create(self, name="Tub Skirt", bay_qty=1):
        super().create(name, bay_qty=bay_qty)


class LegProductFaceFrameCabinet(FaceFrameCabinet):
    """Slim face-frame post / filler ("leg product").

    NOT a bay/opening product: a fixed parameterized assembly built from
    its own parts, parameterized by the cage width/height/depth plus the
    ``leg_product`` propgroup. Overrides ``recalculate()`` to build and
    lay out its parts directly instead of running bay reconciliation, so
    none of the carcass / solver machinery applies.

    Parts: left + right side panels (finished, with a front-bottom
    toe-kick notch), finished front Finish-X bands, an interior back +
    left/right nailers, a full-width face-frame stile, and a toe-kick
    stile + filler. ``finish_type`` drives which panels show / are
    finished; ``only_stile`` keeps just the stile; ``is_column`` drops
    the toe kick; the per-panel depth overrides and nailer toggles size
    the back. ``is_appliance_leg`` / ``is_island_leg`` are placement
    metadata only (no geometry effect yet).
    """
    single_placement = True
    default_cabinet_type = 'BASE'

    def __init__(self):
        super().__init__()
        self.default_width = inch(2.0)
        # Height / depth follow the scene's base-cabinet defaults so a
        # leg matches the base cabinets beside it (width stays a slim 2").
        scene = bpy.context.scene
        if hasattr(scene, 'hb_face_frame'):
            props = scene.hb_face_frame
            self.default_height = props.base_cabinet_height
            self.default_depth = props.base_cabinet_depth

    def _has_toe_kick(self):
        return False

    def _has_carcass(self):
        return False

    def create(self, name="Leg", bay_qty=1):
        # create_cabinet_root writes width/height/depth, which fire the
        # update callback -> recalculate(); CLASS_NAME is already set by
        # then, so the obj wraps as this class and our recalculate() runs
        # (ensuring + laying out parts). The explicit recalculate() below
        # is a harmless belt-and-suspenders for the LEG_PRODUCT_TAG write.
        self.create_cabinet_root(name)
        self.obj[LEG_PRODUCT_TAG] = True
        # Use the leg-specific right-click menu rather than the default
        # cabinet command menu (no bays / joins / wedge for a leg).
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_leg_product_commands'
        self.recalculate()

    # ------------------------------------------------------------------
    # Part lifecycle
    # ------------------------------------------------------------------
    def _ensure_leg_part(self, role, name, add_notch=False):
        """Lazily create one leg CabinetPart keyed by role. Side panels
        get a front-bottom corner-notch modifier for the toe-kick recess."""
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        if add_notch:
            # Front-bottom toe-kick notch. Flip orientation matches the
            # carcass side's "Notch Front Bottom"; verify against the
            # rendered panel and flip if the notch lands on the wrong
            # corner (the panels are rotated Ry=-90).
            cpm = part.add_part_modifier('CPM_CORNERNOTCH', 'Front Notch')
            cpm.set_input('Flip X', False)
            cpm.set_input('Flip Y', True)
        return part.obj

    def _ensure_leg_parts(self):
        """Ensure all leg parts exist. Returns a role -> object map. The
        finished front bands (Finish-X) carry a toe-kick notch like the
        side panels; the interior back / nailers do not."""
        spec = (
            (PART_ROLE_LEG_PANEL_LEFT, 'Leg Panel Left', True),
            (PART_ROLE_LEG_PANEL_RIGHT, 'Leg Panel Right', True),
            (PART_ROLE_LEG_FINISH_X_LEFT, 'Leg Finish Left X', True),
            (PART_ROLE_LEG_FINISH_X_RIGHT, 'Leg Finish Right X', True),
            (PART_ROLE_LEG_BACK, 'Leg Back', False),
            (PART_ROLE_LEG_NAILER_LEFT, 'Leg Nailer Left', False),
            (PART_ROLE_LEG_NAILER_RIGHT, 'Leg Nailer Right', False),
            (PART_ROLE_LEG_STILE, 'Leg Stile', False),
            (PART_ROLE_LEG_TK_STILE, 'Leg Toe Kick Stile', False),
            (PART_ROLE_LEG_TK_FILLER, 'Leg Toe Kick Filler', False),
            (PART_ROLE_LEG_FINISH_KICK, 'Leg Finish Toe Kick', False),
        )
        return {role: self._ensure_leg_part(role, name, add_notch)
                for role, name, add_notch in spec}

    @staticmethod
    def _set_notch(panel_obj, active, x, y, route_depth):
        """Drive a side panel's 'Front Notch' CPM_CORNERNOTCH inputs +
        visibility. No-op if the modifier is missing."""
        mod = panel_obj.modifiers.get('Front Notch')
        if mod is None or mod.node_group is None:
            return
        ng = mod.node_group
        for input_name, value in (('X', x), ('Y', y), ('Route Depth', route_depth)):
            node_input = ng.interface.items_tree.get(input_name)
            if node_input is not None:
                hb_utils.set_gn_input(mod, node_input.identifier, value)
        mod.show_viewport = active
        mod.show_render = active

    def _build_curved_leg_panel(self, width, height, depth, leg):
        """(Re)build the curved support-leg panel mesh in place.

        Profile in the leg's Y/Z plane (front at y = -depth, back at
        y = 0): the straight full-height edge and the narrow foot post
        sit at the BACK (against the wall), the full-depth arm crosses
        the top, and an S-curve (vertical tangents both ends) sweeps
        from the arm's front underside back onto the post -- so the
        knee-clearance void faces the ROOM at the front-bottom. The
        profile is extruded to the full cage width along X -- the leg's
        WIDTH is the panel thickness. Mesh data is regenerated every
        recalc so prop edits reshape the existing object (idempotent;
        parenting, role and tags survive)."""
        foot = min(max(leg.curved_foot_depth, inch(1.0)), depth)
        band = min(max(leg.curved_top_band_height, inch(1.0)), height)
        sweep = min(max(getattr(leg, 'curved_sweep_height', inch(12.0)),
                        inch(1.0)),
                    max(height - band - inch(1.0), inch(1.0)))
        obj = None
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_LEG_CURVED_PANEL:
                obj = child
                break
        if obj is None:
            mesh = bpy.data.meshes.new('Curved Leg Panel')
            obj = hb_utils.new_object('Curved Leg Panel', mesh)
            bpy.context.scene.collection.objects.link(obj)
            obj.parent = self.obj
            obj['hb_part_role'] = PART_ROLE_LEG_CURVED_PANEL
            obj['IS_FINISHED'] = True
            obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_leg_product_commands'
        obj.hide_viewport = False
        obj.hide_render = False
        obj.location = (0.0, 0.0, 0.0)

        # Profile outline: back-bottom (foot at the wall), up the back
        # edge, across the top arm to the front, down the arm's front
        # face, then the S-curve back onto the post and straight down
        # to the floor. The S is a cubic with VERTICAL tangents at both
        # ends: it leaves the arm tip dropping, sweeps toward the wall,
        # and lands on the post dropping -- the catalog bracket shape.
        segs = 24
        zb = height - band            # arm underside
        zp = zb - sweep               # post top (curve lands here)
        prof = [(0.0, 0.0), (0.0, height), (-depth, height),
                (-depth, zb)]
        k = 0.45 * sweep              # vertical handle length
        p1y, p1z = -depth, zb
        c1y, c1z = -depth, zb - k
        c2y, c2z = -foot, zp + k
        p2y, p2z = -foot, zp
        for i in range(1, segs + 1):
            t = i / segs
            u = 1.0 - t
            prof.append((
                u * u * u * p1y + 3 * u * u * t * c1y
                + 3 * u * t * t * c2y + t * t * t * p2y,
                u * u * u * p1z + 3 * u * u * t * c1z
                + 3 * u * t * t * c2z + t * t * t * p2z,
            ))
        # Straight post edge from the curve landing down to the floor;
        # the face closes back to the back-bottom corner along the floor.
        prof.append((-foot, 0.0))

        verts = [(0.0, y, z) for y, z in prof]
        verts += [(width, y, z) for y, z in prof]
        n = len(prof)
        faces = [list(range(n - 1, -1, -1)),           # left cap
                 list(range(n, 2 * n))]                # right cap
        for i in range(n):
            j = (i + 1) % n
            faces.append([i, j, n + j, n + i])
        me = obj.data
        me.clear_geometry()
        me.from_pydata(verts, [], faces)
        # from_pydata face winding is mixed (profile is authored CW);
        # recalc so all normals point outward.
        bm = bmesh.new()
        bm.from_mesh(me)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(me)
        bm.free()
        me.update()
        return obj

    # ------------------------------------------------------------------
    # Recalc (bespoke; bypasses the bay solver)
    # ------------------------------------------------------------------
    @hb_utils.with_children_index
    def recalculate(self):
        cab = self.obj.face_frame_cabinet
        leg = self.obj.leg_product

        width = cab.width
        height = cab.height
        depth = cab.depth
        # Keep the wireframe cage in sync, same as the base recalc.
        self.set_input('Dim X', width)
        self.set_input('Dim Y', depth)
        self.set_input('Dim Z', height)

        # Curved support leg: the whole leg is ONE profiled panel; every
        # standard part is hidden and the bespoke mesh is (re)built.
        if getattr(leg, 'curved', False):
            for child in self.obj.children:
                role = child.get('hb_part_role')
                if role and str(role).startswith('LEG_') \
                        and role != PART_ROLE_LEG_CURVED_PANEL:
                    child.hide_viewport = True
                    child.hide_render = True
            self._build_curved_leg_panel(width, height, depth, leg)
            return
        # Toggled back off: hide the curved panel if one was built, and
        # restore the stile (the only standard part whose visibility the
        # layout below does not manage).
        for child in self.obj.children:
            role = child.get('hb_part_role')
            if role == PART_ROLE_LEG_CURVED_PANEL:
                child.hide_viewport = True
                child.hide_render = True
            elif role == PART_ROLE_LEG_STILE:
                child.hide_viewport = False
                child.hide_render = False

        mt = leg.material_thickness
        fft = leg.face_frame_thickness
        tks = leg.toe_kick_setback
        tkh = 0.0 if leg.is_column else leg.toe_kick_height
        finish = leg.finish_type
        only_stile = leg.only_stile
        # A side carrying an applied paneled end (Paneled / False FF /
        # Working FF) hands its finished face to the applied panel, so
        # the leg's own side panel + Finish-X band on that side drop out.
        left_paneled = (cab.left_finished_end_condition
                        in APPLIED_PANEL_END_TYPES)
        right_paneled = (cab.right_finished_end_condition
                         in APPLIED_PANEL_END_TYPES)
        # v2 reads
        olp = leg.override_left_panel_depth
        orp = leg.override_right_panel_depth
        ibln = leg.include_back_left_nailer
        ibrn = leg.include_back_right_nailer
        has_back = ibln or ibrn
        b_width = leg.back_width
        bt = leg.back_thickness
        nt = leg.nailer_thickness
        nw = leg.nailer_width
        fx_width_l = leg.flush_x_panel_width
        fx_width_r = leg.flush_x_panel_width_right

        parts = self._ensure_leg_parts()
        L = parts[PART_ROLE_LEG_PANEL_LEFT]
        R = parts[PART_ROLE_LEG_PANEL_RIGHT]
        FXL = parts[PART_ROLE_LEG_FINISH_X_LEFT]
        FXR = parts[PART_ROLE_LEG_FINISH_X_RIGHT]
        BACK = parts[PART_ROLE_LEG_BACK]
        NL = parts[PART_ROLE_LEG_NAILER_LEFT]
        NR = parts[PART_ROLE_LEG_NAILER_RIGHT]
        STILE = parts[PART_ROLE_LEG_STILE]
        TKS = parts[PART_ROLE_LEG_TK_STILE]
        TKF = parts[PART_ROLE_LEG_TK_FILLER]
        TKFIN = parts[PART_ROLE_LEG_FINISH_KICK]

        # Back shifts the side panels forward by its thickness.
        back_off = bt if has_back else 0.0

        def place(obj, length, w, thickness, loc, rot, mirror):
            gn = GeoNodeCutpart(obj)
            gn.set_input('Length', length)
            gn.set_input('Width', w)
            gn.set_input('Thickness', thickness)
            obj.location = loc
            obj.rotation_euler = rot
            for k, v in mirror.items():
                gn.set_input(k, v)

        # --- Left side panel ---
        if finish == 'INTERMEDIATE':
            l_x = width / 2.0 - mt / 2.0
        elif finish == 'FINISH_RIGHT':
            l_x = width - mt
        else:  # FINISH_LEFT / FINISH_BOTH
            l_x = 0.0
        l_depth = olp if olp > 0.0 else depth - fft
        l_y = (0.0 if olp <= 0.0 else -depth + olp + fft) - back_off
        place(L, height, l_depth, mt, (l_x, l_y, 0.0),
              (0.0, math.radians(-90), 0.0),
              {'Mirror Y': True, 'Mirror Z': True})
        l_visible = not (finish == 'FINISH_RIGHT' or only_stile) and not left_paneled
        L.hide_viewport = not l_visible
        L.hide_render = not l_visible
        L['IS_FINISHED'] = (finish != 'INTERMEDIATE')

        # --- Right side panel ---
        r_depth = orp if orp > 0.0 else depth - fft
        r_y = (0.0 if orp <= 0.0 else -depth + orp + fft) - back_off
        place(R, height, r_depth, mt, (width, r_y, 0.0),
              (0.0, math.radians(-90), 0.0),
              {'Mirror Y': True, 'Mirror Z': False})
        r_visible = finish in ('FINISH_RIGHT', 'FINISH_BOTH') and not only_stile and not right_paneled
        R.hide_viewport = not r_visible
        R.hide_render = not r_visible
        R['IS_FINISHED'] = True

        # Flush toe kick: a setback smaller than the face-frame thickness
        # puts the kick plane at (or within) the face-frame band, so the
        # side panels take no notch and the kick stile runs the FULL
        # width in the face-frame plane -- setback 0 reads as a flush
        # toe / bottom rail.
        flush_tk = tks < fft

        # --- Toe-kick notch on the visible panels ---
        notch_on = ((not leg.is_column) and (not only_stile) and tkh > 0.0
                    and not flush_tk)
        self._set_notch(L, notch_on and l_visible, tkh, tks - fft, mt)
        self._set_notch(R, notch_on and r_visible, tkh, tks - fft, mt)

        # --- Face-frame stile (full width across the front) ---
        place(STILE, height - tkh, width, fft, (0.0, -depth, tkh),
              (0.0, math.radians(-90), math.radians(90)),
              {'Mirror Y': True, 'Mirror Z': True})
        STILE['IS_FINISHED'] = True

        # --- Toe-kick stile + filler (between the side panels; full
        # width when flush) ---
        tk_full = only_stile or flush_tk
        tk_width = width - (0.0 if tk_full else mt * 2.0)
        tk_x = 0.0 if tk_full else mt
        # A recessed kick between the panels only shows when this leg
        # owns both faces (or is a bare stile); a FLUSH kick sits in the
        # face-frame plane, so it shows for every finish type.
        tk_visible = ((not leg.is_column)
                      and (only_stile or flush_tk or finish == 'FINISH_BOTH'))

        place(TKS, tkh, tk_width, fft, (tk_x, -depth + tks, 0.0),
              (0.0, math.radians(-90), math.radians(90)),
              {'Mirror Y': True, 'Mirror Z': True})
        TKS.hide_viewport = not tk_visible
        TKS.hide_render = not tk_visible
        TKS['IS_FINISHED'] = True

        # The horizontal filler bridges the setback depth; a flush kick
        # has nothing to bridge.
        tkf_visible = tk_visible and tks > 0.0 and not flush_tk
        place(TKF, tks, tk_width, fft, (tk_x, -depth + tks + fft, tkh),
              (0.0, 0.0, math.radians(90)),
              {'Mirror Y': True, 'Mirror X': True})
        TKF.hide_viewport = not tkf_visible
        TKF.hide_render = not tkf_visible
        TKF['IS_FINISHED'] = True

        # Finished facing over the toe-kick stile - the same 0.25"
        # cosmetic board a cabinet's recessed kick carries. A board's
        # origin plane is its front face with Thickness running back,
        # so sitting it ft forward of the kick stile puts its back face
        # on the stile's front. A flush kick is already in the face
        # frame plane, so there is nothing to face.
        tkfin_t = cab.finish_toe_kick_thickness
        tkfin_visible = (tk_visible and not flush_tk
                         and cab.include_finish_toe_kick
                         and tkfin_t > 0.0)
        place(TKFIN, tkh, tk_width, tkfin_t,
              (tk_x, -depth + tks - tkfin_t, 0.0),
              (0.0, math.radians(-90), math.radians(90)),
              {'Mirror Y': True, 'Mirror Z': True})
        TKFIN.hide_viewport = not tkfin_visible
        TKFIN.hide_render = not tkfin_visible
        TKFIN['IS_FINISHED'] = True

        # --- Finished front bands (Finish-X) -------------------------
        # A finished band covering the front few inches on the side
        # whose panel is NOT the primary finished face - each side has
        # its own depth, since a leg often meets a different neighbour
        # on either hand. Its
        # "thickness" (set_input Thickness) is the band's X extent.
        #
        # The band is a finished end, so it is built only where that
        # side asks for one, exactly as a cabinet end does: the side's
        # finished-end condition must BE the flush band. It used to
        # follow finish_type alone, which grew a pair of 4" finished
        # bands on every intermediate leg - an unfinished post between
        # two cabinets - with no setting that could take them off.
        notch_route_ext = inch(0.1)
        fxl_wanted = cab.left_finished_end_condition == 'FLUSH_X'
        fxr_wanted = cab.right_finished_end_condition == 'FLUSH_X'

        # Left band: on the sides whose panel isn't the finished face.
        fxl_t = (width - mt) if finish == 'FINISH_RIGHT' else (width / 2.0 - mt / 2.0)
        place(FXL, height, fx_width_l, fxl_t,
              (0.0, -depth + fft + fx_width_l, 0.0),
              (0.0, math.radians(-90), 0.0),
              {'Mirror Y': True, 'Mirror Z': True})
        fxl_vis = (fxl_wanted and not only_stile
                   and finish in ('INTERMEDIATE', 'FINISH_RIGHT'))
        FXL.hide_viewport = not fxl_vis
        FXL.hide_render = not fxl_vis
        FXL['IS_FINISHED'] = True
        self._set_notch(FXL, notch_on and fxl_vis, tkh, tks - fft, fxl_t + notch_route_ext)

        # Right band: shown for FINISH_LEFT / INTERMEDIATE.
        fxr_t = (width - mt) if finish == 'FINISH_LEFT' else (width / 2.0 - mt / 2.0)
        place(FXR, height, fx_width_r, fxr_t,
              (width, -depth + fft + fx_width_r, 0.0),
              (0.0, math.radians(-90), 0.0),
              {'Mirror Y': True, 'Mirror Z': False})
        fxr_vis = (fxr_wanted and not only_stile
                   and finish in ('FINISH_LEFT', 'INTERMEDIATE'))
        FXR.hide_viewport = not fxr_vis
        FXR.hide_render = not fxr_vis
        FXR['IS_FINISHED'] = True
        self._set_notch(FXR, notch_on and fxr_vis, tkh, tks - fft, fxr_t + notch_route_ext)

        # --- Interior back + nailers ---------------------------------
        # Back spans only the included nailer side(s); it sits at y=0
        # (the very back) and the side panels were shifted forward to
        # clear it.
        back_w = (b_width if ibln else 0.0) + (b_width if ibrn else 0.0)
        back_x = width / 2.0 + (b_width if ibrn else 0.0)
        place(BACK, height, back_w, bt, (back_x, 0.0, 0.0),
              (0.0, math.radians(-90), math.radians(-90)),
              {'Mirror Y': True, 'Mirror Z': True})
        BACK.hide_viewport = not has_back
        BACK.hide_render = not has_back

        # Horizontal nailers at the top back, one per included side.
        place(NL, b_width, nw, nt, (width / 2.0, 0.0, height),
              (math.radians(90), 0.0, 0.0),
              {'Mirror X': True, 'Mirror Y': True})
        NL.hide_viewport = not ibln
        NL.hide_render = not ibln

        place(NR, b_width, nw, nt, (width / 2.0, 0.0, height),
              (math.radians(90), 0.0, 0.0),
              {'Mirror X': False, 'Mirror Y': True})
        NR.hide_viewport = not ibrn
        NR.hide_render = not ibrn

        # --- Applied finished-end panels (Left / Right) --------------
        # The leg recalc bypasses the bay solver, so the shared
        # _reconcile_applied_panels needs a minimal layout snapshot: just
        # the fields applied_panel_geometry and the scribe-offset helpers
        # read (overall dims, face-frame thickness, each side's finish
        # condition + scribe). Only Left / Right are offered in the leg
        # UI; Back stays UNFINISHED so no back panel is built. A side left
        # UNFINISHED produces no panel, so this is opt-in and cheap.
        leg_layout = SimpleNamespace(
            dim_x=width,
            dim_y=depth,
            dim_z=height,
            fft=fft,
            l_fin_end=cab.left_finished_end_condition,
            r_fin_end=cab.right_finished_end_condition,
            l_scribe=cab.left_scribe,
            r_scribe=cab.right_scribe,
            # Legs are never angled, but the miter / splay passes the
            # reconcile always runs (even for cleanup on UNFINISHED
            # sides) gate on these fields, so they must be present.
            is_angled=False,
            angled_multi=False,
            # A leg has no carcass toe kick for a return to wrap, so
            # the panel sits at the leg's own bottom. Absent, the
            # applied-panel pass raised partway through and left the
            # leg half laid out.
            kick_inset_left=0.0,
            kick_inset_right=0.0,
            # Carcass stock thickness - a working face frame sizes its
            # rails off it.
            mt=mt,
        )
        self._reconcile_applied_panels(leg_layout)
        self._reconcile_leg_textured_panels(
            cab, width, height, depth - fft,
            notch=(notch_on, tkh, tks - fft))

    def _reconcile_leg_textured_panels(self, cab, width, height, panel_depth,
                                       notch=(False, 0.0, 0.0)):
        """Beadboard / shiplap / v-groove skins on the leg's Left / Right.

        The cabinet pass that builds these reads the bay solver for
        every dimension it needs, and a leg has no bays - so it gets its
        own, sized from the post itself. Same part as a cabinet's skin: a
        carved 1/4" panel applied to the outside of the side, the finish
        face looking out - notched at the front bottom for the toe kick
        like the side panel it covers.
        """
        thickness = inch(0.25)
        existing = {
            child.get(TAG_TEXTURED_PANEL_SIDE): child
            for child in self.obj.children
            if child.get(TAG_TEXTURED_PANEL_SIDE) in ('LEFT', 'RIGHT')
        }
        try:
            pitch = float(cab.shiplap_board_width) * 0.0254
        except (ValueError, AttributeError):
            pitch = TEXTURED_SHIPLAP_PITCH

        for side in ('LEFT', 'RIGHT'):
            condition = (cab.left_finished_end_condition if side == 'LEFT'
                         else cab.right_finished_end_condition)
            desired_role = TEXTURED_PANEL_ROLES.get(condition)
            part_obj = existing.get(side)
            if desired_role is None:
                if part_obj is not None:
                    bpy.data.objects.remove(part_obj, do_unlink=True)
                continue
            # Condition flips (beadboard <-> shiplap) change the role, and
            # the role is what the material walk keys off, so rebuild.
            if (part_obj is not None
                    and part_obj.get('hb_part_role') != desired_role):
                bpy.data.objects.remove(part_obj, do_unlink=True)
                part_obj = None
            mirror_z = side == 'LEFT'
            # Outside the post, not over it: the skin adds its thickness
            # to that end, the same way a cabinet's does.
            x = -thickness if side == 'LEFT' else width + thickness
            if part_obj is None:
                part = CabinetPart()
                label = {'BEADBOARD': 'Beadboard',
                         'V_GROOVE': 'V-Groove'}.get(condition, 'Shiplap')
                part.create(f'Leg {label} {side[0]}')
                part.obj.parent = self.obj
                part.obj['hb_part_role'] = desired_role
                part.obj['CABINET_PART'] = True
                part.obj['IS_FINISHED'] = True
                part.obj[TAG_TEXTURED_PANEL_SIDE] = side
                part.obj.rotation_euler = (0.0, math.radians(-90), 0.0)
                part.set_input('Mirror Y', True)
                part.set_input('Mirror Z', mirror_z)
                cpm = part.add_part_modifier('CPM_CORNERNOTCH', 'Front Notch')
                cpm.set_input('Flip X', False)
                cpm.set_input('Flip Y', True)
                part_obj = part.obj
            else:
                part = GeoNodeCutpart(part_obj)
            part_obj.location = (x, 0.0, 0.0)
            part.set_input('Length', height)
            part.set_input('Width', panel_depth)
            part.set_input('Thickness', thickness)
            self._textured_panel_mesh(part_obj, height, panel_depth,
                                      thickness, condition, mirror_z,
                                      shiplap_pitch=pitch,
                                      shiplap_vertical=_shiplap_vertical(cab),
                                      v_groove_spacing=_v_groove_spacing(cab))
            # The notch cuts the carved mesh - the cutpart's own display
            # is hidden by now, so the modifier has the static mesh to
            # work on, same as a cabinet's skin.
            notch_on, tkh, notch_y = notch
            self._set_notch(part_obj, notch_on, tkh, notch_y, thickness)


class FloatingShelfFaceFrameCabinet(FaceFrameCabinet):
    """Wall-mounted floating shelf (a hollow finished slab).

    NOT a bay/opening product: a fixed parameterized box built directly,
    parameterized by the cage width / depth + height (height = the
    shelf's overall thickness) and the ``floating_shelf`` propgroup.
    Overrides ``recalculate()`` to build its parts (front board, inset
    top + bottom, and finish-gated left/right end panels) instead of the
    carcass / solver machinery. No back - it mounts open against a wall.

    ``follow_cursor_z`` makes placement track the cursor's height on the
    wall instead of dropping to floor / a fixed upper height. LED routes
    (top / bottom cutouts) are a later pass.
    """
    single_placement = False
    fill_no_bays = True       # fill the wall gap, but always one piece
    follow_cursor_z = True    # mount at the cursor's height on the wall
    default_cabinet_type = 'BASE'

    def __init__(self):
        super().__init__()
        scene = getattr(bpy.context, 'scene', None)
        ff_scene = getattr(scene, 'hb_face_frame', None) if scene else None
        self.default_width = getattr(ff_scene, 'default_cabinet_width', inch(36.0))
        self.default_depth = inch(12.0)
        self.default_height = inch(2.5)   # shelf overall thickness

    def _has_toe_kick(self):
        return False

    def _has_carcass(self):
        return False

    def create(self, name="Floating Shelf", bay_qty=1):
        self.create_cabinet_root(name)
        self.obj[FLOATING_SHELF_TAG] = True
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_floating_shelf_commands'
        self.recalculate()

    def _ensure_shelf_part(self, role, name, add_groove=False):
        # MENU_ID is (re)stamped on existing parts too so shelves built
        # before the parts had their own right-click menu pick it up on
        # their next recalc. The shared part menu carries Add Cutout and
        # Make Editable.
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                child['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        if add_groove:
            # Light groove (LED channel) for Heavy Duty shelves; driven
            # + toggled in recalculate().
            part.add_part_modifier('CPM_CUTOUT', 'Groove')
        return part.obj

    def _ensure_shelf_parts(self):
        spec = (
            (PART_ROLE_SHELF_FRONT, 'Shelf Front', False),
            (PART_ROLE_SHELF_TOP, 'Shelf Top', True),
            (PART_ROLE_SHELF_BOTTOM, 'Shelf Bottom', True),
            (PART_ROLE_SHELF_PANEL_LEFT, 'Shelf Panel Left', False),
            (PART_ROLE_SHELF_PANEL_RIGHT, 'Shelf Panel Right', False),
        )
        return {role: self._ensure_shelf_part(role, name, g)
                for role, name, g in spec}

    @staticmethod
    def _set_groove(panel_obj, active, x0, y0, x1, y1, depth, flip_z):
        """Drive a shelf panel's 'Groove' CPM_CUTOUT (X/Y/End X/End Y/
        Route Depth/Flip Z) + visibility. No-op if missing."""
        mod = panel_obj.modifiers.get('Groove')
        if mod is None or mod.node_group is None:
            return
        ng = mod.node_group
        for name, val in (('X', x0), ('Y', y0), ('End X', x1),
                          ('End Y', y1), ('Route Depth', depth)):
            ni = ng.interface.items_tree.get(name)
            if ni is not None:
                hb_utils.set_gn_input(mod, ni.identifier, val)
        fz = ng.interface.items_tree.get('Flip Z')
        if fz is not None:
            hb_utils.set_gn_input(mod, fz.identifier, flip_z)
        mod.show_viewport = active
        mod.show_render = active

    @hb_utils.with_children_index
    def recalculate(self):
        cab = self.obj.face_frame_cabinet
        shelf = self.obj.floating_shelf

        width = cab.width
        thickness = cab.height   # Dim Z = shelf overall thickness
        depth = cab.depth
        self.set_input('Dim X', width)
        self.set_input('Dim Y', depth)
        self.set_input('Dim Z', thickness)

        mt = shelf.material_thickness
        fl = shelf.finish_left
        fr = shelf.finish_right

        parts = self._ensure_shelf_parts()
        FRONT = parts[PART_ROLE_SHELF_FRONT]
        TOP = parts[PART_ROLE_SHELF_TOP]
        BOTTOM = parts[PART_ROLE_SHELF_BOTTOM]
        LP = parts[PART_ROLE_SHELF_PANEL_LEFT]
        RP = parts[PART_ROLE_SHELF_PANEL_RIGHT]

        def place(obj, length, w, th, loc, rot, mirror):
            # A Make Editable part owns its mesh and transform (its GN
            # was applied, so set_input would fail anyway) - leave it
            # alone; Revert to Parametric re-adds the GN and the next
            # recalc re-drives it here.
            if obj.get('IS_MANUAL_PART'):
                return
            gn = GeoNodeCutpart(obj)
            gn.set_input('Length', length)
            gn.set_input('Width', w)
            gn.set_input('Thickness', th)
            obj.location = loc
            obj.rotation_euler = rot
            for k, v in mirror.items():
                gn.set_input(k, v)

        inset_l = mt if fl else 0.0
        inset_r = mt if fr else 0.0
        inner_len = width - inset_l - inset_r
        inner_depth = depth - mt

        # Front board: full width, stands `thickness` tall at the front.
        place(FRONT, width, thickness, mt, (0.0, -depth, 0.0),
              (math.radians(-90), 0.0, 0.0), {'Mirror Y': True})
        FRONT['IS_FINISHED'] = True

        # Top + bottom: horizontal panels between the end panels, behind
        # the front board, spanning the remaining depth.
        place(TOP, inner_len, inner_depth, mt, (inset_l, -depth + mt, thickness),
              (0.0, 0.0, 0.0), {'Mirror Z': True})
        TOP['IS_FINISHED'] = True
        place(BOTTOM, inner_len, inner_depth, mt, (inset_l, -depth + mt, 0.0),
              (0.0, 0.0, 0.0), {})
        BOTTOM['IS_FINISHED'] = True

        # End panels: close each end when finished. A finished panel
        # runs the full depth and miters into the front board at 45
        # through the corner (the shop's construction) instead of
        # butting behind it.
        place(LP, depth if fl else inner_depth, thickness, mt,
              (0.0, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True, 'Mirror Z': True})
        if not LP.get('IS_MANUAL_PART'):
            LP.hide_viewport = not fl
            LP.hide_render = not fl
        LP['IS_FINISHED'] = True

        place(RP, depth if fr else inner_depth, thickness, mt,
              (width, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True})
        if not RP.get('IS_MANUAL_PART'):
            RP.hide_viewport = not fr
            RP.hide_render = not fr
        RP['IS_FINISHED'] = True

        self._apply_box_end_miter('LEFT', fl, FRONT, LP,
                                  width, depth, mt, thickness)
        self._apply_box_end_miter('RIGHT', fr, FRONT, RP,
                                  width, depth, mt, thickness)

        # --- Light groove (Heavy Duty shelves only) ---
        # A routed LED channel on the top and/or bottom face, set a
        # distance in from the rear edge. Panel-local Y runs front (0)
        # -> rear (inner_depth), so measure in from inner_depth.
        hd = shelf.shelf_type == 'HEAVY_DUTY'
        g_w = shelf.groove_width
        g_depth = shelf.groove_depth
        y_far = inner_depth - shelf.groove_distance_from_rear  # rear edge of groove
        y_near = y_far - g_w                                   # front edge of groove
        gx0, gx1 = -0.005, inner_len + 0.005                   # span full length
        # Flip Z picks the cut face; top cuts its top face, bottom its
        # bottom. Verify against the render and flip if reversed.
        # A manual part's Groove modifier stays live on the applied mesh
        # (Make Editable only applies the cutpart) - leave it alone too.
        if not TOP.get('IS_MANUAL_PART'):
            self._set_groove(TOP, hd and shelf.include_groove_top,
                             gx0, y_near, gx1, y_far, g_depth, True)
        if not BOTTOM.get('IS_MANUAL_PART'):
            self._set_groove(BOTTOM, hd and shelf.include_groove_bottom,
                             gx0, y_near, gx1, y_far, g_depth, False)


# Per-style standard build for the Mantle product, inches:
# (overall_height, crown_projection). Contemporary is a plain hollow box
# (projection 0). The crown styles read like the catalog sections: a top
# slab overhangs a set-back core, with the crown band sloping from under
# the slab's front edge back to the core. The crown band is a straight
# sloped board for now - swap in the real moulding profiles per style as
# they get authored.
MANTLE_STYLE_SPECS = {
    'CONTEMPORARY': (5.0, 0.0),
    'TRADITIONAL': (3.75, 2.75),
    'SHAKER': (4.25, 3.0),
    'VICTORIAN': (5.75, 2.75),
    'CLASSIC': (5.5, 3.0),
    'COLONIAL': (7.5, 1.75),
}

# Standard moulding per style (the crown_profile 'DEFAULT' choice), as
# molding-pack profile refs. The moulding is extruded around the mantle
# front and finished ends; the style spec's projection is only the
# fallback when no molding pack provides the profile.
MANTLE_STYLE_CROWN = {
    'TRADITIONAL': 'Crown Molding/51 Crown',
    'SHAKER': 'Crown Molding/Shaker Cove',
    'VICTORIAN': 'Crown Molding/Beaded Crown',
    'CLASSIC': 'Other/Mantle',
    'COLONIAL': 'Crown Molding/51 Crown',
}

# Standard base moulding at the surround's leg feet per style (the
# base_profile 'DEFAULT' choice): Contemporary is a solid lumber base
# with a 3/8" radius edge, Shaker a square-edge board, everything else
# the standard base.
MANTLE_SURROUND_BASE = {
    'CONTEMPORARY': 'Base Molding/3_8 Radius Edge',
    'SHAKER': 'Base Molding/Square Edge',
}
MANTLE_SURROUND_BASE_FALLBACK = 'Base Molding/Standard Base'

# Standard leg height for the surround (floor to the underside of the
# shelf assembly) when it first turns on.
MANTLE_SURROUND_LEG_H_IN = 60.0


def mantle_style_spec(style):
    return MANTLE_STYLE_SPECS.get(style, MANTLE_STYLE_SPECS['CONTEMPORARY'])


def apply_mantle_style(obj):
    """Re-seed a mantle's overall height from its style's standard build
    and rebuild. Called from the style prop's update callback. With the
    surround on the cage height is floor-to-top - the style only
    restyles the shelf zone, so the overall height is left alone."""
    root = find_cabinet_root(obj)
    if root is None or not root.get(MANTLE_TAG):
        return
    mp = root.mantle_product
    overall_h, _proj = mantle_style_spec(mp.mantle_style)
    if mp.include_surround:
        recalculate_face_frame_cabinet(root)
    else:
        # Setting height fires the normal dim update -> recalculate.
        root.face_frame_cabinet.height = inch(overall_h)


def apply_mantle_surround(obj):
    """Legs & Header toggle: keep the shelf where it reads on the wall.
    Turning the surround ON drops the product to the floor and grows the
    height so the shelf top stays put; OFF restores a wall-mounted shelf
    at its old elevation. Called from the prop's update callback; the
    height write fires the rebuild."""
    root = find_cabinet_root(obj)
    if root is None or not root.get(MANTLE_TAG):
        return
    mp = root.mantle_product
    cab = root.face_frame_cabinet
    overall_h, _proj = mantle_style_spec(mp.mantle_style)
    top = root.location.z + cab.height
    if mp.include_surround:
        root.location.z = 0.0
        cab.height = max(top, inch(overall_h + MANTLE_SURROUND_LEG_H_IN))
    else:
        root.location.z = max(top - inch(overall_h), 0.0)
        cab.height = inch(overall_h)


class MantleFaceFrameProduct(FaceFrameCabinet):
    """Fireplace mantle shelf - a wall-mounted product in its own right
    (NOT a floating-shelf variant): a hollow box build at the top with a
    style-driven under-crown band wrapping the front and any finished
    end.

    NOT a bay/opening product: a fixed parameterized assembly built
    directly from the cage width / depth / height (height = the overall
    assembly height including the crown drop) and the ``mantle_product``
    propgroup. Style picks the standard build (box height + crown
    projection/drop); ``finish_left`` / ``finish_right`` close that end
    with a panel and return the crown around it. The crown band is a v1
    sloped-board approximation of the catalog mouldings.

    ``single_placement`` places one fixed-width beam at the cursor
    height (a mantle spans the fireplace, not the wall gap).

    With ``include_surround`` the product becomes a full floor-standing
    mantle surround: the shelf assembly stays at the top of the cage
    and legs + a header fill below it - plain boards or applied panel
    assemblies per ``surround_build``, with a base moulding wrapped
    around each leg's foot.
    """
    single_placement = True
    fill_no_bays = False
    follow_cursor_z = True
    default_cabinet_type = 'BASE'

    def __init__(self):
        super().__init__()
        self.default_width = inch(72.0)
        self.default_depth = inch(10.0)
        overall_h, _proj = mantle_style_spec('CONTEMPORARY')
        self.default_height = inch(overall_h)

    def _has_toe_kick(self):
        return False

    def _has_carcass(self):
        return False

    def create(self, name="Mantle", bay_qty=1):
        self.create_cabinet_root(name)
        self.obj[MANTLE_TAG] = True
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_mantle_commands'
        self.recalculate()

    def _ensure_mantle_part(self, role, name):
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                child['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        return part.obj

    def _ensure_mantle_parts(self):
        spec = (
            (PART_ROLE_MANTLE_FRONT, 'Mantle Front'),
            (PART_ROLE_MANTLE_TOP, 'Mantle Top'),
            (PART_ROLE_MANTLE_BOTTOM, 'Mantle Bottom'),
            (PART_ROLE_MANTLE_PANEL_LEFT, 'Mantle Panel Left'),
            (PART_ROLE_MANTLE_PANEL_RIGHT, 'Mantle Panel Right'),
            (PART_ROLE_MANTLE_CROWN_FRONT, 'Mantle Crown Front'),
            (PART_ROLE_MANTLE_CROWN_LEFT, 'Mantle Crown Left'),
            (PART_ROLE_MANTLE_CROWN_RIGHT, 'Mantle Crown Right'),
        )
        return {role: self._ensure_mantle_part(role, name)
                for role, name in spec}

    def _crown_sweep_obj(self):
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_MANTLE_CROWN_SWEEP:
                return child
        return None

    def _rebuild_crown_sweep(self, ref, width, depth, z_slab, fl, fr,
                             avail=None):
        """Extrude the crown moulding profile around the mantle: along
        the front and returned down each finished end, mitred at the
        corners by the curve bevel. Returns the profile's front depth
        (the core setback) when the sweep built, else None (caller
        falls back to the flat sloped boards).

        The profile is reloaded every rebuild - cheap, and it keeps the
        clamp (profiles taller than the under-slab space are scaled
        down to it) correct when the height or style changes. `avail`
        is that under-slab space (defaults to z_slab; the surround
        passes the shelf zone so the crown stays off the header).
        """
        from ...molding import packages
        sweep = self._crown_sweep_obj()

        def _hide():
            if sweep is not None:
                old = sweep.data.bevel_object
                if old is not None:
                    sweep.data.bevel_object = None
                    bpy.data.objects.remove(old, do_unlink=True)
                sweep.hide_viewport = True
                sweep.hide_render = True
            return None

        if avail is None:
            avail = z_slab
        if not ref:
            return _hide()
        crown_h = packages.profile_top_height(ref, None)
        proj = packages.profile_front_depth(ref, None)
        if crown_h <= 1e-5 or proj <= 1e-5:
            return _hide()

        if sweep is None:
            curve_data = bpy.data.curves.new('Mantle Crown', 'CURVE')
            sweep = hb_utils.new_object('Mantle Crown', curve_data)
            for coll in self.obj.users_collection:
                coll.objects.link(sweep)
            sweep.parent = self.obj
            sweep['hb_part_role'] = PART_ROLE_MANTLE_CROWN_SWEEP
            sweep['IS_MANTLE_CROWN'] = True
        curve = sweep.data
        curve.dimensions = '2D'
        curve.fill_mode = 'NONE'
        curve.bevel_mode = 'OBJECT'
        curve.use_fill_caps = True

        old = curve.bevel_object
        height = avail if crown_h > avail - 1e-4 else None
        coll = (self.obj.users_collection[0] if self.obj.users_collection
                else bpy.context.scene.collection)
        prof = packages.make_profile_object(
            ref, None, 'Mantle Crown Profile', coll, height=height)
        if prof is None:
            return _hide()
        curve.bevel_object = prof
        prof.parent = sweep
        if old is not None and old is not prof:
            bpy.data.objects.remove(old, do_unlink=True)
        eff_h = min(crown_h, avail)

        curve.splines.clear()
        # The front run mounts on the CORE face (set back by the
        # profile's projection) so the moulding's front lands flush
        # with the cage front under the slab edge. The returns mount on
        # the full-width end panels at the cage sides - the body stays
        # full width (it lines up with the surround legs) and the
        # returns wrap proud of it, covered by the slab's grown side
        # overhang.
        mt = self.obj.mantle_product.material_thickness
        proj = min(proj, max(depth - mt, 0.0))
        y_front = -depth + proj
        pts = []
        if fl:
            pts.append((0.0, 0.0))
        pts += [(0.0, y_front), (width, y_front)]
        if fr:
            pts.append((width, 0.0))
        spline = curve.splines.new('BEZIER')
        spline.use_smooth = False
        spline.bezier_points.add(count=len(pts) - 1)
        for bp, (x, y) in zip(spline.bezier_points, pts):
            bp.co = (x, y, 0.0)
            bp.handle_left_type = 'VECTOR'
            bp.handle_right_type = 'VECTOR'

        sweep.location = (0.0, 0.0, z_slab - eff_h)
        sweep.rotation_euler = (0.0, 0.0, 0.0)
        sweep.hide_viewport = False
        sweep.hide_render = False
        sweep['IS_FINISHED'] = True
        return proj

    @staticmethod
    def _place(obj, length, w, th, loc, rot, mirror, show=True):
        if not obj.get('IS_MANUAL_PART'):
            obj.hide_viewport = not show
            obj.hide_render = not show
            if not show:
                return
            gn = GeoNodeCutpart(obj)
            gn.set_input('Length', length)
            gn.set_input('Width', w)
            gn.set_input('Thickness', th)
            obj.location = loc
            obj.rotation_euler = rot
            # Always drive all three mirrors - a stale True from a
            # previous pose would silently flip the part.
            for k in ('Mirror X', 'Mirror Y', 'Mirror Z'):
                gn.set_input(k, mirror.get(k, False))
        obj['IS_FINISHED'] = True

    @hb_utils.with_children_index
    def recalculate(self):
        cab = self.obj.face_frame_cabinet
        mp = self.obj.mantle_product

        width = cab.width
        height = cab.height   # overall assembly height incl. crown drop
        depth = cab.depth
        self.set_input('Dim X', width)
        self.set_input('Dim Y', depth)
        self.set_input('Dim Z', height)

        mt = mp.material_thickness
        fl = mp.finish_left
        fr = mp.finish_right
        overall_in, proj_in = mantle_style_spec(mp.mantle_style)

        # Surround (legs & header): the cage is floor-to-top - the
        # shelf assembly reads its style height at the top and the
        # legs / header fill everything below it.
        surround = mp.include_surround
        shelf_h = min(inch(overall_in), height) if surround else height
        z0 = height - shelf_h            # bottom of the shelf assembly

        proj = min(inch(proj_in), max(depth - mt, 0.0))
        has_crown = proj > 0.0001 and shelf_h > mt * 2

        parts = self._ensure_mantle_parts()
        FRONT = parts[PART_ROLE_MANTLE_FRONT]
        TOP = parts[PART_ROLE_MANTLE_TOP]
        BOTTOM = parts[PART_ROLE_MANTLE_BOTTOM]
        LP = parts[PART_ROLE_MANTLE_PANEL_LEFT]
        RP = parts[PART_ROLE_MANTLE_PANEL_RIGHT]
        CF = parts[PART_ROLE_MANTLE_CROWN_FRONT]
        CL = parts[PART_ROLE_MANTLE_CROWN_LEFT]
        CR = parts[PART_ROLE_MANTLE_CROWN_RIGHT]

        place = self._place

        inset_l = mt if fl else 0.0
        inset_r = mt if fr else 0.0
        inner_len = width - inset_l - inset_r

        if not has_crown:
            # --- Contemporary: plain hollow box, full-height front.
            # A finished end panel runs the full depth and miters into
            # the front board at 45 through the corner (the shop's
            # construction) instead of butting behind it.
            inner_depth = depth - mt
            place(FRONT, width, shelf_h, mt, (0.0, -depth, z0),
                  (math.radians(-90), 0.0, 0.0), {'Mirror Y': True})
            place(TOP, inner_len, inner_depth, mt,
                  (inset_l, -depth + mt, height),
                  (0.0, 0.0, 0.0), {'Mirror Z': True})
            place(BOTTOM, inner_len, inner_depth, mt,
                  (inset_l, -depth + mt, z0),
                  (0.0, 0.0, 0.0), {})
            place(LP, depth if fl else inner_depth, shelf_h, mt,
                  (0.0, 0.0, z0),
                  (math.radians(-90), 0.0, math.radians(90)),
                  {'Mirror X': True, 'Mirror Y': True, 'Mirror Z': True},
                  show=fl)
            place(RP, depth if fr else inner_depth, shelf_h, mt,
                  (width, 0.0, z0),
                  (math.radians(-90), 0.0, math.radians(90)),
                  {'Mirror X': True, 'Mirror Y': True}, show=fr)
            self._apply_box_end_miter('LEFT', fl, FRONT, LP,
                                      width, depth, mt, height)
            self._apply_box_end_miter('RIGHT', fr, FRONT, RP,
                                      width, depth, mt, height)
            for p in (CF, CL, CR):
                if not p.get('IS_MANUAL_PART'):
                    p.hide_viewport = True
                    p.hide_render = True
            self._rebuild_crown_sweep(None, width, depth, height, fl, fr)
            self._rebuild_surround(mp, width, depth, z0, mt, fl, fr)
            return

        # --- Crown styles (catalog sections): the top slab overhangs a
        # set-back core; the crown moulding is extruded from under the
        # slab's front edge, returned along each finished end. The
        # profile comes from the molding packs (crown_profile, DEFAULT
        # resolving per style); when no pack provides it, straight
        # sloped boards stand in.
        # Crown builds butt their panels (the crown covers the joint) -
        # drop any miters left from a contemporary build.
        self._apply_box_end_miter('LEFT', False, FRONT, LP,
                                  width, depth, mt, height)
        self._apply_box_end_miter('RIGHT', False, FRONT, RP,
                                  width, depth, mt, height)
        z_slab = height - mt          # underside of the top slab
        ref = mp.crown_profile
        if not ref or ref == 'DEFAULT':
            ref = MANTLE_STYLE_CROWN.get(mp.mantle_style)
        sweep_proj = self._rebuild_crown_sweep(
            ref, width, depth, z_slab, fl, fr, avail=z_slab - z0)
        if sweep_proj is not None:
            proj = min(sweep_proj, max(depth - mt, 0.0))
        core_y = -depth + proj        # core front face plane
        # The body stays full width (its ends line up with the surround
        # legs); the crown returns project past it at finished ends and
        # the slab side overhang grows by that projection so the slab
        # stays proud of the crown all around. The fallback boards
        # return flush at the cage sides (no extra growth).
        side_proj = proj if sweep_proj is not None else 0.0

        # Top slab: sits on top of the build (no Mirror Z - it extends
        # up from the slab line to the cage top), overhanging the crown
        # by top_overhang past the front and each finished end (the
        # side overhang carries the crown return's projection too, so
        # the slab edge stays proud of the crown all around).
        ov = max(mp.top_overhang, 0.0)
        ov_l = (side_proj + ov) if fl else 0.0
        ov_r = (side_proj + ov) if fr else 0.0
        place(TOP, width + ov_l + ov_r, depth + ov, mt,
              (-ov_l, -depth - ov, z_slab), (0.0, 0.0, 0.0), {})
        # Core face: set back behind the crown, slab underside to the
        # bottom of the shelf zone.
        place(FRONT, inner_len, z_slab - z0, mt, (inset_l, core_y, z0),
              (math.radians(-90), 0.0, 0.0), {'Mirror Y': True})
        # Bottom: closes the core underside back to the wall.
        place(BOTTOM, inner_len, depth - proj - mt, mt,
              (inset_l, core_y + mt, z0), (0.0, 0.0, 0.0), {})
        # End panels: close the core region of a finished end.
        place(LP, depth - proj, z_slab - z0, mt, (0.0, 0.0, z0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True, 'Mirror Z': True},
              show=fl)
        place(RP, depth - proj, z_slab - z0, mt, (width, 0.0, z0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True}, show=fr)

        # Fallback boards, only when no profile resolved. Width-axis
        # direction with rot.x = tilt - 90 is (0, sin t, -cos t): back
        # toward the wall and down; the returns get the same tilt with
        # a Z quarter-turn so they slope down and inward, trimmed to
        # the slope landing so the corner butts cleanly.
        boards = sweep_proj is None
        drop = z_slab - z0
        slope_len = math.hypot(proj, drop)
        tilt = math.atan2(proj, drop)
        crown_rot_x = math.radians(-90) + tilt
        place(CF, width, slope_len, mt, (0.0, -depth, z_slab),
              (crown_rot_x, 0.0, 0.0), {}, show=boards)
        place(CL, depth - proj, slope_len, mt, (0.0, 0.0, z_slab),
              (crown_rot_x, 0.0, math.radians(-90)), {},
              show=boards and fl)
        place(CR, depth - proj, slope_len, mt, (width, -depth + proj, z_slab),
              (crown_rot_x, 0.0, math.radians(90)), {},
              show=boards and fr)

        self._rebuild_surround(mp, width, depth, z0, mt, fl, fr)

    # =====================================================================
    # Surround (legs & header) - catalog Mantle Surrounds
    # =====================================================================
    _SURROUND_PART_SPEC = (
        (PART_ROLE_MANTLE_LEG_FRONT_L, 'Mantle Leg Front Left'),
        (PART_ROLE_MANTLE_LEG_FRONT_R, 'Mantle Leg Front Right'),
        (PART_ROLE_MANTLE_LEG_OUT_L, 'Mantle Leg Side Left'),
        (PART_ROLE_MANTLE_LEG_OUT_R, 'Mantle Leg Side Right'),
        (PART_ROLE_MANTLE_LEG_IN_L, 'Mantle Leg Inner Left'),
        (PART_ROLE_MANTLE_LEG_IN_R, 'Mantle Leg Inner Right'),
        (PART_ROLE_MANTLE_HEADER_FRONT, 'Mantle Header'),
        (PART_ROLE_MANTLE_HEADER_BOTTOM, 'Mantle Header Bottom'),
    )

    def _ensure_surround_parts(self):
        return {role: self._ensure_mantle_part(role, name)
                for role, name in self._SURROUND_PART_SPEC}

    def _mantle_panel(self, role):
        for child in self.obj.children:
            if child.get(TAG_MANTLE_PANEL) == role:
                return child
        return None

    def _ensure_surround_panel(self, role, name, w, h, loc, mt):
        """A paneled leg / header front: a standalone face frame panel
        (rails / stiles / inset panels, raised or recessed per the
        cabinet style) filling the front footprint, front face flush
        with the plain build's front plane. The header panel keeps the
        auto width ladder, so a wide header splits into multiple
        openings like the catalog drawings."""
        existing = self._mantle_panel(role)
        if existing is None:
            panel = PanelFaceFrameCabinet()
            panel.create(name, bay_qty=1)
            existing = panel.obj
            existing.parent = self.obj
            existing[TAG_MANTLE_PANEL] = role
        style = self.obj.get('STYLE_NAME')
        if style:
            existing['STYLE_NAME'] = style
        existing.location = loc
        existing.rotation_euler = (0.0, 0.0, 0.0)
        pp = existing.face_frame_cabinet
        pp.depth = mt
        pp.width = w
        pp.height = h
        return existing

    def _remove_surround_panels(self):
        for child in list(self.obj.children):
            if child.get(TAG_MANTLE_PANEL):
                _remove_root_with_children(child)

    def _rebuild_surround(self, mp, width, depth, z0, mt, fl, fr):
        """Build (or clear) the legs and header below the shelf zone.
        Two hollow legs stand floor to the shelf underside with the
        header spanning between them; fronts are plain boards or
        applied panel assemblies, and a base moulding profile wraps
        each leg's foot."""
        surround_on = mp.include_surround and z0 > mt
        if not surround_on:
            for role, _name in self._SURROUND_PART_SPEC:
                for child in self.obj.children:
                    if (child.get('hb_part_role') == role
                            and not child.get('IS_MANUAL_PART')):
                        child.hide_viewport = True
                        child.hide_render = True
            self._remove_surround_panels()
            self._rebuild_base_sweep(None, width, 0.0, 0.0, fl, fr)
            return

        leg_w = min(max(mp.leg_width, mt * 2), width / 2 - inch(1.0))
        leg_d = min(max(mp.leg_depth, mt * 2), depth)
        header_h = min(max(mp.header_height, mt), z0)
        # The header is a shallower band than the legs (6" standard).
        header_d = min(max(mp.header_depth, mt * 2), leg_d)
        build = mp.surround_build
        if build == 'DEFAULT':
            build = ('PLAIN' if mp.mantle_style == 'CONTEMPORARY'
                     else 'PANELED')
        paneled = build == 'PANELED'

        parts = self._ensure_surround_parts()
        LF = parts[PART_ROLE_MANTLE_LEG_FRONT_L]
        RF = parts[PART_ROLE_MANTLE_LEG_FRONT_R]
        LO = parts[PART_ROLE_MANTLE_LEG_OUT_L]
        RO = parts[PART_ROLE_MANTLE_LEG_OUT_R]
        LI = parts[PART_ROLE_MANTLE_LEG_IN_L]
        RI = parts[PART_ROLE_MANTLE_LEG_IN_R]
        HF = parts[PART_ROLE_MANTLE_HEADER_FRONT]
        HB = parts[PART_ROLE_MANTLE_HEADER_BOTTOM]

        place = self._place
        inner_w = max(width - leg_w * 2, mt)
        z_head = max(z0 - header_h, 0.0)

        # Fronts: plain boards, hidden when panels replace them.
        place(LF, leg_w, z0, mt, (0.0, -leg_d, 0.0),
              (math.radians(-90), 0.0, 0.0), {'Mirror Y': True},
              show=not paneled)
        place(RF, leg_w, z0, mt, (width - leg_w, -leg_d, 0.0),
              (math.radians(-90), 0.0, 0.0), {'Mirror Y': True},
              show=not paneled)
        place(HF, inner_w, header_h, mt, (leg_w, -header_d, z_head),
              (math.radians(-90), 0.0, 0.0), {'Mirror Y': True},
              show=not paneled)

        # Leg sides: outer faces on finished ends, inner faces always
        # (they line the fireplace opening).
        side_len = max(leg_d - mt, mt)
        place(LO, side_len, z0, mt, (0.0, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True, 'Mirror Z': True},
              show=fl)
        place(RO, side_len, z0, mt, (width, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True}, show=fr)
        place(LI, side_len, z0, mt, (leg_w, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True})
        place(RI, side_len, z0, mt, (width - leg_w, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True, 'Mirror Z': True})

        # Header soffit: closes the underside back to the wall.
        place(HB, inner_w, max(header_d - mt, mt), mt,
              (leg_w, -header_d + mt, z_head), (0.0, 0.0, 0.0), {})

        if paneled:
            self._ensure_surround_panel(
                'LEG_L', 'Mantle Leg Panel Left', leg_w, z0,
                (0.0, -leg_d + mt, 0.0), mt)
            self._ensure_surround_panel(
                'LEG_R', 'Mantle Leg Panel Right', leg_w, z0,
                (width - leg_w, -leg_d + mt, 0.0), mt)
            self._ensure_surround_panel(
                'HEADER', 'Mantle Header Panel', inner_w, header_h,
                (leg_w, -header_d + mt, z_head), mt)
        else:
            self._remove_surround_panels()

        ref = None
        if mp.include_base_moulding:
            ref = mp.base_profile
            if not ref or ref == 'DEFAULT':
                ref = MANTLE_SURROUND_BASE.get(
                    mp.mantle_style, MANTLE_SURROUND_BASE_FALLBACK)
        self._rebuild_base_sweep(ref, width, leg_w, leg_d, fl, fr)

    def _base_sweep_obj(self):
        for child in self.obj.children:
            if child.get('hb_part_role') == PART_ROLE_MANTLE_BASE_SWEEP:
                return child
        return None

    def _rebuild_base_sweep(self, ref, width, leg_w, leg_d, fl, fr):
        """Extrude the base moulding profile around each leg's foot:
        up the outer side (finished ends only), across the front and
        back to the wall on the opening side. One curve, one spline
        per leg, same bevel-sweep construction as the crown."""
        from ...molding import packages
        sweep = self._base_sweep_obj()

        def _hide():
            if sweep is not None:
                old = sweep.data.bevel_object
                if old is not None:
                    sweep.data.bevel_object = None
                    bpy.data.objects.remove(old, do_unlink=True)
                sweep.hide_viewport = True
                sweep.hide_render = True
            return None

        if not ref:
            return _hide()
        if packages.profile_top_height(ref, None) <= 1e-5:
            return _hide()

        if sweep is None:
            curve_data = bpy.data.curves.new('Mantle Base', 'CURVE')
            sweep = hb_utils.new_object('Mantle Base', curve_data)
            for coll in self.obj.users_collection:
                coll.objects.link(sweep)
            sweep.parent = self.obj
            sweep['hb_part_role'] = PART_ROLE_MANTLE_BASE_SWEEP
            sweep['IS_MANTLE_BASE'] = True
        curve = sweep.data
        curve.dimensions = '2D'
        curve.fill_mode = 'NONE'
        curve.bevel_mode = 'OBJECT'
        curve.use_fill_caps = True

        old = curve.bevel_object
        coll = (self.obj.users_collection[0] if self.obj.users_collection
                else bpy.context.scene.collection)
        prof = packages.make_profile_object(
            ref, None, 'Mantle Base Profile', coll)
        if prof is None:
            return _hide()
        curve.bevel_object = prof
        prof.parent = sweep
        if old is not None and old is not prof:
            bpy.data.objects.remove(old, do_unlink=True)

        curve.splines.clear()
        left = ([(0.0, 0.0)] if fl else []) + [
            (0.0, -leg_d), (leg_w, -leg_d), (leg_w, 0.0)]
        right = [(width - leg_w, 0.0), (width - leg_w, -leg_d),
                 (width, -leg_d)] + ([(width, 0.0)] if fr else [])
        for pts in (left, right):
            spline = curve.splines.new('BEZIER')
            spline.use_smooth = False
            spline.bezier_points.add(count=len(pts) - 1)
            for bp, (x, y) in zip(spline.bezier_points, pts):
                bp.co = (x, y, 0.0)
                bp.handle_left_type = 'VECTOR'
                bp.handle_right_type = 'VECTOR'

        sweep.location = (0.0, 0.0, 0.0)
        sweep.rotation_euler = (0.0, 0.0, 0.0)
        sweep.hide_viewport = False
        sweep.hide_render = False
        sweep['IS_FINISHED'] = True
        return True


class ValanceFaceFrameProduct(FaceFrameCabinet):
    """Wall-mounted valance - a decorative board spanning the gap
    between two upper cabinets (e.g. over a sink or a window).

    NOT a bay/opening product: like the floating shelf it is a fixed
    parameterized assembly built directly from the cage width / depth /
    height (height = the board's vertical drop) and the
    ``valance_product`` propgroup. Parts: the valance board across the
    front, finish-gated left/right return panels back to the wall, and
    an optional top cover recessed below the top edge by a scribe
    amount (or resting at the bottom when flush_bottom).

    ``fill_no_bays`` spans the wall gap as one piece in placement;
    ``follow_cursor_z`` mounts it at the cursor's height on the wall
    (typically flush with the bottom of the adjacent uppers).
    """
    single_placement = False
    fill_no_bays = True       # span the gap, but always one piece
    follow_cursor_z = True    # mount at the cursor's height on the wall
    default_cabinet_type = 'BASE'

    def __init__(self):
        super().__init__()
        scene = getattr(bpy.context, 'scene', None)
        ff_scene = getattr(scene, 'hb_face_frame', None) if scene else None
        self.default_width = inch(30.0)
        self.default_depth = getattr(ff_scene, 'upper_cabinet_depth', inch(12.0))
        self.default_height = inch(4.0)   # board vertical drop

    def _has_toe_kick(self):
        return False

    def _has_carcass(self):
        return False

    def create(self, name="Valance", bay_qty=1):
        # bay_qty is accepted (the modal always passes it) but ignored -
        # a valance has no bays.
        self.create_cabinet_root(name)
        self.obj[VALANCE_TAG] = True
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_valance_commands'
        self.recalculate()

    def _ensure_valance_part(self, role, name):
        # MENU_ID is (re)stamped on existing parts too so valances built
        # before the parts had their own right-click menu pick it up on
        # their next recalc. The shared part menu carries Add Cutout and
        # Make Editable (an arched valance board is cut that way).
        for child in self.obj.children:
            if child.get('hb_part_role') == role:
                child['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
                return child
        part = CabinetPart()
        part.create(name)
        part.obj.parent = self.obj
        part.obj['hb_part_role'] = role
        part.obj['CABINET_PART'] = True
        part.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
        return part.obj

    @hb_utils.with_children_index
    def recalculate(self):
        cab = self.obj.face_frame_cabinet
        val = self.obj.valance_product

        width = cab.width
        height = cab.height   # Dim Z = the board's vertical drop
        depth = cab.depth
        self.set_input('Dim X', width)
        self.set_input('Dim Y', depth)
        self.set_input('Dim Z', height)

        ft = val.frame_thickness   # board + return panel stock
        ct = val.cover_thickness   # top cover stock
        fl = val.finish_left
        fr = val.finish_right

        BOARD = self._ensure_valance_part(PART_ROLE_VALANCE_BOARD, 'Valance Board')
        COVER = self._ensure_valance_part(PART_ROLE_VALANCE_COVER, 'Valance Cover')
        LP = self._ensure_valance_part(PART_ROLE_VALANCE_PANEL_LEFT, 'Valance Panel Left')
        RP = self._ensure_valance_part(PART_ROLE_VALANCE_PANEL_RIGHT, 'Valance Panel Right')

        def place(obj, length, w, th, loc, rot, mirror):
            # A Make Editable part owns its mesh and transform (its GN
            # was applied, so set_input would fail anyway) - leave it
            # alone; Revert to Parametric re-adds the GN and the next
            # recalc re-drives it here.
            if obj.get('IS_MANUAL_PART'):
                return
            gn = GeoNodeCutpart(obj)
            gn.set_input('Length', length)
            gn.set_input('Width', w)
            gn.set_input('Thickness', th)
            obj.location = loc
            obj.rotation_euler = rot
            for k, v in mirror.items():
                gn.set_input(k, v)

        inset_l = ft if fl else 0.0
        inset_r = ft if fr else 0.0
        inner_len = width - inset_l - inset_r
        inner_depth = depth - ft   # behind the board, back to the wall

        # Valance board: full width across the front, `height` tall.
        # Same transform convention as a cabinet bottom rail (+90 X,
        # Mirror Z) - identical world geometry to the old -90/Mirror Y
        # placement, but it lets _position_bottom_rail_profile_cutter
        # cut the decorative bottom profile in the board's local space
        # exactly as it does on a bottom rail. Mirror Y is written
        # False explicitly so valances placed before this change
        # migrate on their next recalc.
        place(BOARD, width, height, ft, (0.0, -depth, 0.0),
              (math.radians(90), 0.0, 0.0),
              {'Mirror Y': False, 'Mirror Z': True})
        BOARD['IS_FINISHED'] = True

        # Return panels: close each end back to the wall when finished.
        place(LP, inner_depth, height, ft, (0.0, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True, 'Mirror Z': True})
        if not LP.get('IS_MANUAL_PART'):
            LP.hide_viewport = not fl
            LP.hide_render = not fl
        LP['IS_FINISHED'] = True

        place(RP, inner_depth, height, ft, (width, 0.0, 0.0),
              (math.radians(-90), 0.0, math.radians(90)),
              {'Mirror X': True, 'Mirror Y': True})
        if not RP.get('IS_MANUAL_PART'):
            RP.hide_viewport = not fr
            RP.hide_render = not fr
        RP['IS_FINISHED'] = True

        # Top cover: Mirror Z makes the given Z the panel's TOP face -
        # recessed below the top edge by the scribe amount, or occupying
        # 0..thickness at the floor of the valance when flush_bottom.
        cover_z = ct if val.flush_bottom else height - val.top_scribe
        place(COVER, inner_len, inner_depth, ct,
              (inset_l, -depth + ft, cover_z), (0.0, 0.0, 0.0),
              {'Mirror Z': True})
        if not COVER.get('IS_MANUAL_PART'):
            COVER.hide_viewport = not val.include_cover
            COVER.hide_render = not val.include_cover
        COVER['IS_FINISHED'] = True

        # Decorative bottom profile on the front board - the cabinet
        # bottom_rail_profile option applied to the valance. Reuses the
        # bottom-rail cutter machinery verbatim (the board shares the
        # rail transform convention above). A manual board is left
        # entirely alone: its cut, if any, is baked or riding the
        # existing boolean, and the cutter can't be rebuilt from an
        # applied GN anyway.
        if not BOARD.get('IS_MANUAL_PART'):
            profile_id = getattr(cab, 'bottom_rail_profile', 'NONE')
            is_arch = profile_id in _BOTTOM_RAIL_PROCEDURAL_PROFILES
            poly = (None if (is_arch or profile_id in ('NONE', ''))
                    else _bottom_rail_profile_poly(profile_id))
            if profile_id in ('NONE', '') or (not is_arch and not poly):
                mod = BOARD.modifiers.get(BOTTOM_RAIL_PROFILE_CUT_MOD_NAME)
                if mod is not None:
                    BOARD.modifiers.remove(mod)
                self._cleanup_bottom_rail_profile_cutters()
            else:
                cutter = self._ensure_bottom_rail_profile_cutter('VALANCE_BOARD')
                ok = self._position_bottom_rail_profile_cutter(
                    cutter, BOARD, profile_id, poly)
                mod = BOARD.modifiers.get(BOTTOM_RAIL_PROFILE_CUT_MOD_NAME)
                if not ok:
                    if mod is not None:
                        BOARD.modifiers.remove(mod)
                else:
                    if mod is None:
                        mod = BOARD.modifiers.new(
                            name=BOTTOM_RAIL_PROFILE_CUT_MOD_NAME,
                            type='BOOLEAN')
                        mod.operation = 'DIFFERENCE'
                        mod.solver = 'EXACT'
                    mod.material_mode = 'TRANSFER'
                    if mod.object is not cutter:
                        mod.object = cutter


class MiscPart(CabinetPart):
    """A single freely-resizable face frame part - a lone GeoNodeCutpart
    with NO cabinet cage.

    Unlike Panel / Leg / Floating Shelf (which are FaceFrameCabinet
    subclasses carrying a cage), a Misc Part is just a board: it stays out
    of Cabinets selection mode and carries none of the carcass / bay /
    opening machinery. It rides the standard place_cabinet modal, which
    special-cases cage-less products in _finalize (see
    operators/ops_placement.py) - it has no face_frame_cabinet propgroup
    for the cabinet path to write to. The default_* attrs feed that modal's
    preview cage; single_placement keeps it one fixed-width piece.
    """
    single_placement = True
    default_cabinet_type = 'BASE'

    def __init__(self):
        super().__init__()
        # Dim X = width, Dim Y = depth, Dim Z = height (thickness). A flat
        # 24 x 12 x 3/4 board out of the box; resize after placement.
        self.default_width = inch(24.0)
        self.default_depth = inch(12.0)
        self.default_height = inch(0.75)

    def create(self, name="Misc Part", bay_qty=1):
        # bay_qty is accepted (the modal always passes it) but ignored - a
        # Misc Part has no bays. CabinetPart.create lays down the
        # GeoNodeCutpart + default inputs; we then size it, mark it a Misc
        # Part, and finish both faces.
        super().create(name)
        self.obj['IS_FACE_FRAME_MISC_PART'] = True
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_misc_part_commands'
        self.set_input('Length', self.default_width)
        self.set_input('Width', self.default_depth)
        self.set_input('Thickness', self.default_height)
        self.set_input('Mirror Y', True)
        self.obj['Finish Top'] = True
        self.obj['Finish Bottom'] = True

    # --- placement hooks (read by place_cabinet._finalize for bare parts) ---
    placement_stand_rotation = None  # Misc Part lies flat; no reorient.

    def apply_placement_width(self, width):
        """The cage width maps to the board's X span = its 'Length' input."""
        self.set_input('Length', width)
        self.rebuild()

    # Slotted-shelf construction (production spec): slats set in a
    # solid perimeter frame, slat faces flush with the frame top.
    SLOTTED_FRAME_WIDTH = inch(4.0)
    SLOTTED_SLAT_WIDTH = inch(3.0)
    SLOTTED_SLAT_THICKNESS = inch(0.625)
    SLOTTED_TARGET_GAP = inch(1.5)
    SLOTTED_MIN_GAP = inch(0.5)

    def _slotted_shelf_mesh(self, length, width, t):
        """Write a static slotted-shelf mesh: a perimeter frame of
        SLOTTED_FRAME_WIDTH members at full thickness with equally
        spaced slats spanning front-to-back, tops flush with the frame.
        Same local space as the flat cutpart: x 0..length, y 0..-width
        (Mirror Y), z 0..t. Falls back to a plain slab footprint when
        the part is too small to carry a frame."""
        import bmesh
        fw = self.SLOTTED_FRAME_WIDTH
        sw = self.SLOTTED_SLAT_WIDTH
        st = min(self.SLOTTED_SLAT_THICKNESS, t)
        boxes = []
        if length <= 2.0 * fw + sw or width <= 2.0 * fw:
            boxes.append((0.0, length, -width, 0.0, 0.0, t))
        else:
            # Perimeter frame: back, front, left, right members.
            boxes.append((0.0, length, -fw, 0.0, 0.0, t))
            boxes.append((0.0, length, -width, -width + fw, 0.0, t))
            boxes.append((0.0, fw, -width + fw, -fw, 0.0, t))
            boxes.append((length - fw, length, -width + fw, -fw, 0.0, t))
            # Slats across the interior, equal gaps both sides.
            interior = length - 2.0 * fw
            g0 = self.SLOTTED_TARGET_GAP
            n = max(1, int(round((interior + g0) / (sw + g0))))
            while n > 1 and (interior - n * sw) / (n + 1) < self.SLOTTED_MIN_GAP:
                n -= 1
            gap = (interior - n * sw) / (n + 1)
            for i in range(n):
                x0 = fw + gap + i * (sw + gap)
                boxes.append((x0, x0 + sw, -width + fw, -fw, t - st, t))
        bm = bmesh.new()
        for (x0, x1, y0, y1, z0, z1) in boxes:
            vs = [bm.verts.new((x, y, z))
                  for z in (z0, z1) for y in (y0, y1) for x in (x0, x1)]
            # verts ordered: z0(y0(x0,x1), y1(x0,x1)), z1(...)
            faces = ((0, 1, 3, 2), (4, 6, 7, 5), (0, 2, 6, 4),
                     (1, 5, 7, 3), (0, 4, 5, 1), (2, 3, 7, 6))
            for f in faces:
                bm.faces.new([vs[i] for i in f])
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(self.obj.data)
        bm.free()
        mod_name = getattr(self.obj.home_builder, 'mod_name', '')
        mod = self.obj.modifiers.get(mod_name) if mod_name else None
        if mod is not None:
            mod.show_viewport = False
            mod.show_render = False
        self.obj[TAG_STATIC_TEXTURED] = True

    def rebuild(self):
        """Sync the board's display with its panel type (stored on the
        object as HB_MISC_PANEL_TYPE). PANEL is the live GN cutpart;
        BEADBOARD / SHIPLAP carve a static textured mesh via the same
        builder the finished-end applied panels use, sized from the
        cutpart's own Length / Width / Thickness inputs so size edits
        re-carve in place. The carved (exterior) face lands on the
        board's TOP face -- the finish face of the flat-lying part.
        SLOTTED_SHELF builds a frame-and-slats static mesh instead."""
        obj = self.obj
        ptype = obj.get('HB_MISC_PANEL_TYPE', 'PANEL')
        if ptype == 'SLOTTED_SHELF':
            self._slotted_shelf_mesh(
                self.get_input('Length'),
                self.get_input('Width'),
                self.get_input('Thickness'))
            if obj.data is not None and not obj.data.materials:
                try:
                    surf = self.get_input('Top Surface')
                except Exception:
                    surf = None
                if surf is not None:
                    obj.data.materials.append(surf)
            return
        if ptype not in ('BEADBOARD', 'SHIPLAP', 'V_GROOVE'):
            mod_name = getattr(obj.home_builder, 'mod_name', '')
            mod = obj.modifiers.get(mod_name) if mod_name else None
            if obj.data is not None and obj.get(TAG_STATIC_TEXTURED):
                obj.data.clear_geometry()
            if mod is not None:
                mod.show_viewport = True
                mod.show_render = True
            if TAG_STATIC_TEXTURED in obj:
                del obj[TAG_STATIC_TEXTURED]
            return
        length = self.get_input('Length')
        width = self.get_input('Width')
        t = self.get_input('Thickness')
        # mirror_z=True carves the exterior on the z=0 plane with the
        # material extending -z; shifting the mesh up by the thickness
        # puts the body back at 0..t (matching the plain cutpart) with
        # the grooves on the top face. The builder hides the GN display
        # and stamps TAG_STATIC_TEXTURED itself.
        FaceFrameCabinet._textured_panel_mesh(
            obj, length, width, t, ptype, mirror_z=True)
        obj.data.transform(Matrix.Translation((0.0, 0.0, t)))
        obj.data.update()
        # The static mesh renders its own slots; seed them from the
        # cutpart's surface input so an applied finish carries over.
        if obj.data is not None and not obj.data.materials:
            try:
                surf = self.get_input('Top Surface')
            except Exception:
                surf = None
            if surf is not None:
                obj.data.materials.append(surf)


# Door Part: stand-up rotation so a standalone door reads vertical with
# its front face toward the room. Euler X=90 (the configured
# default), Y=-90: localX(Length=height)->world Z (up), localY(Width)->
# world X (across), and the front face (local +Z = thickness) points
# world -Y (toward the viewer). place_cabinet._finalize composes this
# onto the placement transform. Flip the X sign to face the door the
# other way.
_DOOR_PART_STAND = Euler((math.radians(90.0), math.radians(-90.0), 0.0),
                         'XYZ').to_matrix().to_4x4()


def _active_door_style():
    """The Face_Frame_Door_Style of the project's ACTIVE cabinet style, or
    None. Mirrors _apply_door_styles_to_fronts' resolution: active cabinet
    style -> its door_style name -> ff.door_styles lookup."""
    from . import props_hb_face_frame as props
    ff = props.get_style_props()
    if ff is None:
        return None
    idx = ff.active_cabinet_style_index
    if not (0 <= idx < len(ff.cabinet_styles)):
        return None
    name = ff.cabinet_styles[idx].door_style
    if not name or name == 'NONE':
        return None
    for ds in ff.door_styles:
        if ds.name == name:
            return ds
    return None


def apply_active_door_style_to_part(door_obj):
    """Apply the active cabinet style's door style to a Door Part front
    (assign_style_to_front adds / strips the CPM_5PIECEDOOR 'Door Style'
    modifier and stamps DOOR_STYLE_NAME). Also records the source cabinet
    style as STYLE_NAME so a later style-update pass can find it. No-op if
    nothing resolves."""
    from . import props_hb_face_frame as props
    ds = _active_door_style()
    if ds is None:
        return
    ds.assign_style_to_front(door_obj)
    ff = props.get_style_props()
    if ff is not None and 0 <= ff.active_cabinet_style_index < len(ff.cabinet_styles):
        door_obj['STYLE_NAME'] = ff.cabinet_styles[ff.active_cabinet_style_index].name


def apply_active_finish_to_product(product_obj):
    """Assign the project's ACTIVE cabinet style's exterior FINISH material
    to every cutpart under a non-cabinet face-frame PRODUCT (e.g. a Half
    Wall) and record the source style as STYLE_NAME.

    A product built from the frameless part primitives carries no
    hb_part_role, so the cabinet material walk (_apply_materials_to_cabinet,
    which dispatches by role and reads face_frame_cabinet side conditions)
    skips it entirely. A half wall is a single finished element, so the
    faithful behavior is the style's finish on every surface - surface =
    finish, edges = the rotated variant, mirroring the cabinet exterior-role
    branch. No-op if no style resolves or the finish is unresolved (e.g.
    CUSTOM species with no custom_material picked yet)."""
    from . import props_hb_face_frame as props
    ff = props.get_style_props()
    if ff is None:
        return
    idx = ff.active_cabinet_style_index
    if not (0 <= idx < len(ff.cabinet_styles)):
        return
    cs = ff.cabinet_styles[idx]
    finish_mat, finish_mat_rotated = cs.get_finish_material()
    if finish_mat is None:
        return
    for child in product_obj.children_recursive:
        if child.type != 'MESH':
            continue
        # _set_part_surfaces wraps the obj as a GeoNodeCutpart and plugs the
        # Top/Bottom Surface + edge inputs; it silently no-ops on any object
        # that isn't a cutpart, so the MESH guard is enough.
        cs._set_part_surfaces(child, finish_mat, finish_mat_rotated)
        # A static turning (turned support-frame leg) carries the
        # material on its own mesh; keep it following the cutpart input.
        if child.get(turned_leg.STATIC_TAG):
            turned_leg.sync_static_material(child)
    product_obj['STYLE_NAME'] = cs.name


def position_door_part_pull(door_obj):
    """Create or reposition a scene-settings door pull on a Door Part.

    Mirrors _create_pull_for_front's DOOR / BASE / left-hinged branch but
    reads the part's own GeoNode dims (not a cabinet leaf) so it works
    standalone. The pull is parented to the door in front-local space
    (X = Length up, -Y = Width across, +Z = front face). Reused on resize
    so the pull tracks the door. Returns the pull Object or None."""
    scene_props = bpy.context.scene.hb_face_frame
    existing = next((c for c in door_obj.children if c.get('IS_CABINET_PULL')), None)

    # Per-door toggles stored as ID props (default on / left-hinged):
    # DOOR_PART_SHOW_PULL and DOOR_PART_PULL_SIDE ('LEFT' / 'RIGHT'),
    # driven by the right-click menu. Pull hidden -> drop any existing
    # instance and bail.
    if not door_obj.get('DOOR_PART_SHOW_PULL', True):
        if existing is not None:
            bpy.data.objects.remove(existing, do_unlink=True)
        return None
    # Front kind ('DOOR' default / 'DRAWER') picks the pull asset +
    # placement convention. A DRAWER front borrows the drawer-pull asset
    # and the in-cabinet drawer formula (horizontal bar, centered).
    front_kind = door_obj.get('DOOR_PART_FRONT_KIND', 'DOOR')
    pull_kind = 'drawer' if front_kind == 'DRAWER' else 'door'
    pull_obj = pulls.resolve_pull_object(scene_props, pull_kind)
    if pull_obj is None:
        if existing is not None:
            bpy.data.objects.remove(existing, do_unlink=True)
        return None
    part = GeoNodeCutpart(door_obj)
    length = part.get_input('Length')      # front height
    width = part.get_input('Width')        # front width
    thickness = part.get_input('Thickness')
    half = pulls.pull_length(pull_obj) / 2.0
    z = thickness                                                 # front face

    if pull_kind == 'drawer':
        # Drawer convention: horizontal bar centered across the width;
        # vertically centered or near the top per center_pulls_on_drawer_
        # front. Mirrors _create_pull_for_front's drawer branch (rot_z=90
        # runs the bar horizontal). PULL_SIDE is ignored (centered).
        if scene_props.center_pulls_on_drawer_front:
            x = length / 2.0
        else:
            x = length - scene_props.pull_vertical_location_base - half
        y = -width / 2.0
        rot = (math.radians(-90.0), 0.0, math.radians(90.0))
    else:
        # Door convention: vertical bar near the top, on the edge opposite
        # the hinge (DOOR_PART_PULL_SIDE).
        x = length - scene_props.pull_vertical_location_base - half
        if door_obj.get('DOOR_PART_PULL_SIDE', 'LEFT') == 'RIGHT':
            y = -scene_props.pull_horizontal_offset
        else:
            y = -(width - scene_props.pull_horizontal_offset)
        rot = (math.radians(-90.0), 0.0, 0.0)

    if existing is not None:
        inst = existing
        if inst.data is not pull_obj.data:
            inst.data = pull_obj.data
    else:
        inst = hb_utils.new_object(f"Pull - {door_obj.name}", pull_obj.data)
        bpy.context.scene.collection.objects.link(inst)
        inst.parent = door_obj
        inst['hb_part_role'] = 'PULL'
        inst['IS_CABINET_PULL'] = True
    inst.location = (x, y, z)
    inst.rotation_euler = rot
    return inst


class DoorPart(CabinetPart):
    """A standalone door: the same bare GeoNodeCutpart as a Misc Part, but
    carrying a door style + pull.

    It is a DOOR-role front (so Face_Frame_Door_Style.assign_style_to_front
    renders it slab / 5-piece) plus a scene-settings pull, with NO cabinet
    cage / opening. On create it picks up the project's ACTIVE cabinet
    style's door style and the scene's current pull settings; both are
    re-applicable from the right-click menu. Rides the place_cabinet modal
    like the Misc Part; _finalize composes placement_stand_rotation so the
    door stands vertical wherever it lands. The 'Length' input is the door
    HEIGHT and 'Width' the door WIDTH (assign_style_to_front's convention).
    """
    single_placement = True
    default_cabinet_type = 'BASE'
    placement_stand_rotation = _DOOR_PART_STAND

    def __init__(self):
        super().__init__()
        # Preview cage: Dim X = width, Dim Y = depth (door thickness),
        # Dim Z = height -> a thin tall slab that reads as a door.
        self.default_width = inch(18.0)
        self.default_depth = inch(0.75)
        self.default_height = inch(30.0)

    def apply_placement_width(self, width):
        """The cage width is the door's WIDTH = its 'Width' input (its
        'Length' input is the door HEIGHT - see assign_style_to_front)."""
        self.set_input('Width', width)

    def create(self, name="Door", bay_qty=1):
        # bay_qty accepted but ignored. CabinetPart.create lays the cutpart;
        # we set it up as a DOOR front, stand it up, then apply the active
        # door style + a scene pull.
        super().create(name)
        self.obj['IS_FACE_FRAME_DOOR_PART'] = True
        self.obj['hb_part_role'] = PART_ROLE_DOOR
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_door_part_commands'
        self.set_input('Length', self.default_height)    # door height
        self.set_input('Width', self.default_width)      # door width
        self.set_input('Thickness', self.default_depth)  # door thickness
        self.set_input('Mirror Y', True)
        self.obj['Finish Top'] = True
        self.obj['Finish Bottom'] = True
        # Stand vertical for direct creation; _finalize re-composes this
        # onto the placement transform when placed via the modal.
        self.obj.matrix_basis = self.obj.matrix_basis @ _DOOR_PART_STAND
        apply_active_door_style_to_part(self.obj)
        position_door_part_pull(self.obj)


class HalfWallFaceFrameProduct(_FramelessHalfWall):
    """Half wall (pony / knee wall) for the Face Frame catalog's Misc
    section. Migrated by REUSING the frameless HalfWall geometry verbatim
    (studs + skins + finished end caps) - the face frame library already
    depends on the frameless part primitives (see the CabinetPart import
    above), so this thin subclass only routes the product through the face
    frame placement modal.

    It is NOT a face frame cabinet (no bays / openings / face frame), so it
    rides place_cabinet's bare-product branch in _finalize - the same path
    Misc Part / Door use. The frameless IS_FRAMELESS_PRODUCT_CAGE tag and
    PART_TYPE='HALF_WALL' set by the inherited create() are deliberately
    KEPT: the existing frameless right-click prompts (stud spacing, end
    caps, size) and delete key off those, so editing works unchanged.
    """
    single_placement = True          # one fixed-size piece, like Misc Part
    placement_stand_rotation = None  # built standing (Dim Z = height); no reorient

    def __init__(self):
        super().__init__()
        # Feed the placement modal's preview cage. The frameless HalfWall
        # seeds width / height / depth as instance attrs in its __init__;
        # mirror them onto the default_* names the face frame modal reads.
        self.default_width = self.width
        self.default_height = self.height
        self.default_depth = self.depth

    def create(self, name="Half Wall", bay_qty=1):
        # bay_qty is accepted (place_cabinet._finalize always passes it) but
        # ignored - a half wall has no bays. The inherited create builds the
        # full stud / skin geometry and tags the product cage.
        super().create(name)
        # Mark it a face-frame product cage so the Cabinets selection mode
        # shows its cage + makes it the selection target (see TAG_PRODUCT_CAGE
        # and hb_face_frame_OT_toggle_mode). NOT a cabinet cage by design.
        self.obj[TAG_PRODUCT_CAGE] = True
        # Pick up the project's active face-frame cabinet style's finish
        # material (the frameless geometry otherwise carries no face-frame
        # finish). Stamps STYLE_NAME so the source style is recorded.
        apply_active_finish_to_product(self.obj)

    def apply_placement_width(self, width):
        """The cage width maps to the product's X span = its 'Dim X' input.
        The studs / skins / top / bottom are solved from that input, so
        re-solve after writing it."""
        from ..frameless import types_products
        self.set_input('Dim X', width)
        types_products.recalculate_product(self.obj)


class SupportFrameFaceFrameProduct(_FramelessSupportFrame):
    """Support frame (open rectangular frame + corner legs) for the Face
    Frame catalog's Misc section. Same migration shape as the Half Wall:
    REUSE the frameless SupportFrame geometry verbatim and add only the
    face frame placement + integration hooks.

    Not a face frame cabinet (no bays / openings), so it rides
    place_cabinet's bare-product branch in _finalize. The frameless
    IS_FRAMELESS_PRODUCT_CAGE tag + PART_TYPE='SUPPORT_FRAME' set by the
    inherited create() are KEPT so the existing frameless right-click
    prompts (support spacing, per-corner legs + types, leg sizes) and
    delete operate on it unchanged. TAG_PRODUCT_CAGE is added so it shows
    its cage / is the selection target in Cabinets selection mode, and the
    active style's finish material is applied to its parts.
    """
    single_placement = True          # one fixed-size piece, like the Half Wall
    placement_stand_rotation = None  # built in real orientation; no reorient
    # The frame band spans local Z 0..4" with the corner legs hanging 34.5"
    # DOWN from the band top -- the product is built to hang under a
    # countertop. Placed at floor Z the legs punched 30.5" through the
    # floor and the band sat at ankle height, so mount it like an upper at
    # leg-height minus band-height: legs land on the floor and the band
    # top meets the 34.5" counter underside.
    mounts_as_upper = True
    default_z_location = inch(34.5) - inch(4.0)

    def __init__(self):
        super().__init__()
        # Feed the placement modal's preview cage. The frameless SupportFrame
        # seeds width / height / depth in its __init__; mirror them onto the
        # default_* names the face frame modal reads.
        self.default_width = self.width
        self.default_height = self.height
        self.default_depth = self.depth

    def create(self, name="Support Frame", bay_qty=1):
        # bay_qty accepted (the modal always passes it) but ignored. The
        # inherited create builds the full frame + legs and tags the cage.
        super().create(name)
        # Face frame product cage -> shows in Cabinets selection mode.
        self.obj[TAG_PRODUCT_CAGE] = True
        # Active cabinet style's finish material (+ STYLE_NAME stamp).
        apply_active_finish_to_product(self.obj)

    def apply_placement_width(self, width):
        """The cage width maps to the product's X span = its 'Dim X' input.
        The frame's panels / supports / legs are solved from that input, so
        re-solve after writing it."""
        from ..frameless import types_products
        self.set_input('Dim X', width)
        types_products.recalculate_support_frame(self.obj)


class WoodTopPart(CabinetPart):
    """Wood top (countertop part): ONE lone finished board, like Misc
    Part -- a single GeoNodeCutpart object with NO cabinet cage.

    Sizing lives on the ``wood_top`` propgroup (width / depth /
    thickness / overhangs / nosing); rebuild() syncs the board from it.
    Placement snaps the board onto the cabinet under the cursor
    (parenting it there), sized to that cabinet plus the overhangs;
    editing the overhangs refits a seated top in place. A nosing style
    (the shelf-nosing profile set) mills the front edge: the board
    shortens by the nosing stock depth and the profiled edge takes its
    place, all inside this one object's mesh (GN display hands off to a
    static mesh, same pattern as the textured panels). Construction
    (veneer vs solid) is a label for downstream consumers.
    """
    single_placement = True
    snap_cabinet_top = True   # placement seats it on the cabinet under the cursor
    default_cabinet_type = 'BASE'
    placement_stand_rotation = None  # lies flat

    def __init__(self):
        super().__init__()
        self.default_width = inch(36.0)
        self.default_depth = inch(25.5)
        self.default_height = inch(1.5)   # slab thickness

    def create(self, name="Wood Top", bay_qty=1):
        # bay_qty accepted (the modal always passes it) but ignored.
        super().create(name)
        self.obj[WOOD_TOP_TAG] = True
        self.obj['hb_part_role'] = PART_ROLE_WOOD_TOP
        self.obj['CABINET_PART'] = True
        self.obj['IS_FINISHED'] = True
        self.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_wood_top_commands'
        self.set_input('Mirror Y', True)
        self.obj['Finish Top'] = True
        self.obj['Finish Bottom'] = True
        self.rebuild()

    # --- placement hooks (read by place_cabinet._finalize for bare parts) ---
    def apply_placement_width(self, width):
        self.obj.wood_top.width = width   # update callback rebuilds

    def rebuild(self):
        """Sync the board from the wood_top propgroup: anchored tops
        (parented to a cabinet) size from the anchor plus the
        overhangs; free tops use the propgroup width / depth. Then
        build the nosed front edge when a nosing style is set."""
        obj = self.obj
        wt = obj.wood_top
        # An applied edge takes the outer band of the top: the board
        # this object drives becomes the core, the band builds as its
        # own part, and the overhangs still measure to the outside of
        # the edge. The milled nosing owns the same edges, so the two
        # are mutually exclusive.
        edge_t = getattr(wt, 'edge_thickness', 0.0)
        edged = [s for s in ('front', 'back', 'left', 'right')
                 if getattr(wt, 'edge_' + s, False)]
        if (getattr(wt, 'edge_type', 'NONE') == 'NONE'
                or wt.nosing_style not in (None, '', 'NONE')
                or edge_t <= 0.0):
            edged = []
        anchor = (obj.parent
                  if obj.parent is not None
                  and obj.parent.get(TAG_CABINET_CAGE) else None)
        if anchor is not None:
            ap = anchor.face_frame_cabinet
            width = ap.width + wt.overhang_left + wt.overhang_right
            depth = ap.depth + wt.overhang_front + wt.overhang_back
            # Origin walks in to the core's back-left corner so the
            # band's outer face lands on the overhang line.
            obj.location = (
                -wt.overhang_left + (edge_t if 'left' in edged else 0.0),
                wt.overhang_back - (edge_t if 'back' in edged else 0.0),
                ap.height)
            obj.rotation_euler = (0.0, 0.0, 0.0)
        else:
            width = wt.width
            depth = wt.depth
        t = wt.thickness
        core_w = width - edge_t * (('left' in edged) + ('right' in edged))
        core_d = depth - edge_t * (('front' in edged) + ('back' in edged))
        # A band wider than the top itself would invert the core.
        if core_w < inch(1.0) or core_d < inch(1.0):
            edged = []
            core_w, core_d = width, depth
        self.set_input('Length', core_w)
        self.set_input('Width', core_d)
        self.set_input('Thickness', t)
        self._sync_edge_bands(obj, core_w, core_d, t, wt, edged)

        mod_name = getattr(obj.home_builder, 'mod_name', '')
        mod = obj.modifiers.get(mod_name) if mod_name else None
        nosed_sides = [s for s in ('front', 'back', 'left', 'right')
                       if getattr(wt, 'nosing_' + s, s == 'front')]
        if wt.nosing_style in (None, '', 'NONE') or not nosed_sides:
            # Plain board: the driven cutpart is the geometry.
            if obj.data is not None and obj.get(TAG_STATIC_TEXTURED):
                obj.data.clear_geometry()
            if mod is not None:
                mod.show_viewport = True
                mod.show_render = True
            if TAG_STATIC_TEXTURED in obj:
                del obj[TAG_STATIC_TEXTURED]
            return
        self._write_nosed_mesh(obj, core_w, core_d, t, wt, nosed_sides)
        if mod is not None:
            mod.show_viewport = False
            mod.show_render = False
        obj[TAG_STATIC_TEXTURED] = True
        # The static mesh renders its own slots; seed them from the
        # cutpart's surface input so a finish applied while the top was
        # a plain board carries over to the nosed display.
        if obj.data is not None and not obj.data.materials:
            try:
                surf = self.get_input('Top Surface')
            except Exception:
                surf = None
            if surf is not None:
                obj.data.materials.append(surf)

    @staticmethod
    def _sync_edge_bands(obj, core_w, core_d, t, wt, edged):
        """Build / refresh one edge band part per edged side, parented to
        the core board. Front and back bands run the full outer length;
        the end bands butt between them. Bands are sized in the core's
        local frame (X right, Y back-to-front through 0..-core_d, Z up
        from the core bottom). Sides that were turned off lose their
        part.
        """
        existing = {}
        for child in list(obj.children):
            if child.get('hb_part_role') != PART_ROLE_WOOD_TOP_EDGE:
                continue
            existing[child.get('hb_wood_top_edge_side')] = child
        for side, part in existing.items():
            if side in edged:
                continue
            bpy.data.objects.remove(part, do_unlink=True)
        if not edged:
            return

        edge_t = wt.edge_thickness
        out_l = edge_t if 'left' in edged else 0.0
        out_r = edge_t if 'right' in edged else 0.0
        # (length, width, location) per side.
        layout = {
            'front': (core_w + out_l + out_r, edge_t,
                      (-out_l, -core_d, 0.0)),
            'back':  (core_w + out_l + out_r, edge_t,
                      (-out_l, edge_t, 0.0)),
            'left':  (edge_t, core_d, (-edge_t, 0.0, 0.0)),
            'right': (edge_t, core_d, (core_w, 0.0, 0.0)),
        }
        for side in edged:
            part = existing.get(side)
            band = CabinetPart()
            if part is None:
                band.create(f'Wood Top Edge {side.capitalize()}')
                part = band.obj
                part.parent = obj
                part['hb_part_role'] = PART_ROLE_WOOD_TOP_EDGE
                part['hb_wood_top_edge_side'] = side
                part['CABINET_PART'] = True
                part['IS_FINISHED'] = True
                part['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
                band.set_input('Mirror Y', True)
            else:
                band.obj = part
            # Carried for downstream consumers (drawings, part lists):
            # the band is a distinct piece with its own edge spec.
            part['hb_wood_top_edge_type'] = wt.edge_type
            length, band_w, loc = layout[side]
            band.set_input('Length', length)
            band.set_input('Width', band_w)
            band.set_input('Thickness', t)
            part.location = loc
            part.rotation_euler = (0.0, 0.0, 0.0)
            # Eased reads as a softened arris on the exposed corners;
            # square leaves them sharp.
            bev = part.modifiers.get('Eased Edge')
            if wt.edge_type == 'EASED':
                if bev is None:
                    bev = part.modifiers.new('Eased Edge', 'BEVEL')
                bev.width = inch(0.0625)
                bev.segments = 3
                bev.limit_method = 'ANGLE'
            elif bev is not None:
                part.modifiers.remove(bev)

    @staticmethod
    def _write_nosed_mesh(obj, width, depth, t, wt, nosed_sides):
        """Static mesh: a core board shortened by the nosing stock depth
        on each nosed side, plus one profiled prism per nosed edge.
        Prism ends miter at 45 degrees where two nosed edges meet at a
        corner, and cut square at the board edge otherwise. Local space
        matches the driven cutpart: X 0..width, Y 0..-depth (Mirror Y),
        Z 0..thickness with the nosing top flush to the board top
        (extra-height styles drop below).
        """
        h = (max(t, wt.nosing_height)
             if wt.nosing_style in shelf_nosing.EXTRA_HEIGHT_STYLES
             else t)
        outline = wood_top_edge.edge_outline(wt.nosing_style, t, h)
        if not outline:
            return
        # Band depth follows the profile: a shallow one keeps the stock
        # depth and leaves a flat behind it, a deep one grows the band
        # instead of poking out past the top's outer face.
        nose_d = wood_top_edge.stock_depth(outline)
        nosed = set(nosed_sides)
        # Prism cross-section in (d, z): d grows outward from the core
        # face (0) to the board's outer face (nose_d) -- the outline's
        # forward distance maps to d DIRECTLY (mirroring it through the
        # stock renders every profile inside-out). From the core top
        # around the nosing free boundary, closing at the core face at
        # the outline's final height (below z=0 for hang-down styles).
        sec = [(0.0, t)]
        for d_pt, z_pt in outline:
            sec.append((d_pt, t + z_pt))
        sec.append((0.0, min(0.0, t + outline[-1][1])))
        if sec[-1][1] < -1e-9:
            sec.append((0.0, 0.0))

        # Core box, shrunk on each nosed side (clamped to stay a solid).
        x0 = min(nose_d if 'left' in nosed else 0.0, width * 0.5 - 1e-4)
        x1 = max(width - (nose_d if 'right' in nosed else 0.0),
                 width * 0.5 + 1e-4)
        yf = min(-depth + (nose_d if 'front' in nosed else 0.0),
                 -depth * 0.5 - 1e-4)
        yb = max(-(nose_d if 'back' in nosed else 0.0), -depth * 0.5 + 1e-4)

        bm = bmesh.new()
        corners = [(x, y, z) for z in (0.0, t) for y in (yf, yb)
                   for x in (x0, x1)]
        cv = [bm.verts.new(c) for c in corners]
        for quad in ((0, 1, 3, 2), (4, 6, 7, 5), (0, 2, 6, 4),
                     (1, 5, 7, 3), (0, 4, 5, 1), (2, 3, 7, 6)):
            bm.faces.new([cv[i] for i in quad])

        # (a, d, z) -> local xyz per side; ends list the adjacent side
        # at (a0, a1) for the miter decision.
        def _point(side, a, d, z):
            if side == 'front':
                return (a, -depth + (nose_d - d), z)
            if side == 'back':
                return (a, -(nose_d - d), z)
            if side == 'left':
                return (nose_d - d, a, z)
            return (width - (nose_d - d), a, z)

        spans = {
            'front': (0.0, width, 'left', 'right'),
            'back':  (0.0, width, 'left', 'right'),
            'left':  (-depth, 0.0, 'front', 'back'),
            'right': (-depth, 0.0, 'front', 'back'),
        }
        for side in nosed_sides:
            a0, a1, adj0, adj1 = spans[side]
            ring0, ring1 = [], []
            for d, z in sec:
                s0 = a0 + (nose_d - d) if adj0 in nosed else a0
                s1 = a1 - (nose_d - d) if adj1 in nosed else a1
                ring0.append(bm.verts.new(_point(side, s0, d, z)))
                ring1.append(bm.verts.new(_point(side, s1, d, z)))
            bm.faces.new(ring0)
            bm.faces.new(list(reversed(ring1)))
            n = len(sec)
            for i in range(n):
                j = (i + 1) % n
                bm.faces.new((ring0[i], ring0[j], ring1[j], ring1[i]))
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()


CABINET_NAME_DISPATCH = {
    "Base Door": BaseFaceFrameCabinet,
    "Base Door Drw": BaseFaceFrameCabinet,
    "Base Drawer": BaseFaceFrameCabinet,
    "Floating Base Cabinet": FloatingBaseFaceFrameCabinet,
    "Floating Vanity": FloatingVanityCabinet,
    "5 Drawer Dresser": FiveDrawerDresserCabinet,
    "6 Drawer Dresser": SixDrawerDresserCabinet,
    "Night Stand": NightStandFaceFrameCabinet,
    "3 Drawer Night Stand": ThreeDrawerNightStandCabinet,
    "Window Seat": WindowSeatFaceFrameCabinet,
    "Sink": SinkFaceFrameCabinet,
    "Cooktop Base": CooktopFaceFrameCabinet,
    "Galley IWS 2": GalleyIWS2Cabinet,
    "Galley IWS 3": GalleyIWS3Cabinet,
    "Galley IWS 4": GalleyIWS4Cabinet,
    "Galley IWS 5": GalleyIWS5Cabinet,
    "Galley IWS 6": GalleyIWS6Cabinet,
    "Galley IWS 7": GalleyIWS7Cabinet,
    "ADA Sink": ADASinkCabinet,
    "Lap Drawer": LapDrawerFaceFrameCabinet,
    "Upper": UpperFaceFrameCabinet,
    "Upper Stacked": UpperFaceFrameCabinet,
    "Bookcase Upper": BookcaseUpperFaceFrameCabinet,
    "Hutch Upper": HutchUpperFaceFrameCabinet,
    "Standard Recessed Medicine Cabinet": StandardRecessedMedicineCabinet,
    "Medicine Cabinet": MedicineCabinetFaceFrameCabinet,
    "Overstool Cabinet": OverstoolCabinetFaceFrameCabinet,
    "Mirror Frame": MirrorFrameFaceFrameCabinet,
    "Tri-View Medicine Cabinet": TriViewMedicineCabinetFaceFrameCabinet,
    "Tub Skirt": TubSkirtFaceFrameCabinet,
    "Tall": TallFaceFrameCabinet,
    "Tall Stacked": TallFaceFrameCabinet,
    "Refrigerator Cabinet": RefrigeratorCabinet,
    "Built in Tall": BuiltInTallFaceFrameCabinet,
    "Panel": PanelFaceFrameCabinet,
    "Face Frame and Doors": FaceFrameAndDoorsCabinet,
    "Bookcase": BookcaseFaceFrameCabinet,
    "Bookcase Storage Unit": BookcaseStorageUnitFaceFrameCabinet,
    "Leg Product": LegProductFaceFrameCabinet,
    "Floating Shelves": FloatingShelfFaceFrameCabinet,
    "Mantle": MantleFaceFrameProduct,
    "Valance": ValanceFaceFrameProduct,
    "Wood Top": WoodTopPart,
    "Misc Part": MiscPart,
    "Door": DoorPart,
    "Half Wall": HalfWallFaceFrameProduct,
    "Support Frame": SupportFrameFaceFrameProduct,
}


# Catalog names in the Appliance Products section map to classes in
# the shared common.types_appliances module. These produce a wireframe
# cage with a text label and no carcass / bays / face frame; the
# draw_cabinet operator drops them at the 3D cursor rather than
# routing through the cabinet placement modal.
APPLIANCE_NAME_DISPATCH = {
    "Dishwasher": types_appliances.Dishwasher,
    "Range": types_appliances.Range,
    "Range Hood": types_appliances.Hood,
    "Standalone Refrigerator": types_appliances.Refrigerator,
    "Under Counter Appliance": types_appliances.UnderCounterAppliance,
}


def get_cabinet_class(cabinet_name):
    """Return the FaceFrameCabinet subclass for the given library name."""
    if cabinet_name in CABINET_NAME_DISPATCH:
        return CABINET_NAME_DISPATCH[cabinet_name]
    if not cabinet_name:
        return None
    if 'Upper' in cabinet_name:
        return UpperFaceFrameCabinet
    if 'Tall' in cabinet_name or 'Refrigerator Cabinet' in cabinet_name:
        return TallFaceFrameCabinet
    return BaseFaceFrameCabinet


def refresh_round_top_frames(obj):
    """Re-cut the frame members above a cabinet's round-top doors after
    a door's shape changed. Setting the shape restyles just that door,
    which is not a cabinet recalc, so the member above it would keep its
    square opening until the next unrelated edit. No-op off a cabinet."""
    root = find_cabinet_root(obj)
    if root is None or not root.get(TAG_CABINET_CAGE):
        return
    try:
        FaceFrameCabinet(root)._apply_round_top_frames()
    except Exception:
        pass


def find_cabinet_root(obj):
    """Walk up parents from obj to find the face frame cabinet root.

    Returns the cage Object (the one with IS_FACE_FRAME_CABINET_CAGE) or
    None if obj is not part of a face frame cabinet.
    """
    if obj is None:
        return None
    cur = obj
    while cur is not None:
        if cur.get(TAG_CABINET_CAGE):
            return cur
        cur = cur.parent
    return None


def default_front_type_for_root(root):
    """Default front_type for a freshly created opening under `root`.

    Panels default to INSET_PANEL so a new panel reads as a paneled
    door out of the box - the user can change individual openings
    afterward via the Change Opening menu or the Selection sub-panel.
    Cabinets stay NONE (open shelving) and let the user pick.
    """
    if root is None:
        return 'NONE'
    # A product class can override the default via default_opening_front_type
    # (e.g. FF & Doors defaults its openings to DOOR). Resolve the wrapper
    # class by CLASS_NAME the same way recalc does.
    cls = WRAP_CLASS_REGISTRY.get(root.get('CLASS_NAME'), FaceFrameCabinet)
    override = getattr(cls, 'default_opening_front_type', None)
    if override:
        return override
    if root.face_frame_cabinet.cabinet_type == 'PANEL':
        return 'INSET_PANEL'
    return 'NONE'


def applied_panel_geometry(layout, side):
    """Transform + dimensions for an applied panel covering one side of
    a cabinet. Returns (location, rotation_z, width, height, depth).

    Cabinet conventions: X=0 is the left exterior face, X=dim_x is the
    right exterior face; Y=0 is the back, Y=-dim_y is the front; Z=0
    is the floor, Z=dim_z is the cabinet top.

    LEFT and RIGHT panels sit in the scribe gap between the cabinet's
    exterior face and the side panel's outer face. The panel's outer
    (visible) face is flush with the face frame's outer face; its inner
    face touches the side panel. Z range is the FULL cabinet height -
    floor to cabinet top - so the panel covers the toe-kick band at
    the bottom and ignores top_scribe at the top. The panel's bottom
    rail width grows by toe_kick_height (handled in
    applied_panel_sizing) to keep that bottom band reading as frame
    rather than opening.

    BACK uses simple full-extent positioning for now; refining is
    deferred until applied-back behavior is settled.

    The standalone panel's local axes are: +X = width, +Y points INTO
    the panel (back face Y=0, front Y=-depth), +Z = up. Each side's
    rotation around Z aims the front face outward from the cabinet.
    """
    if side == 'LEFT':
        scribe = solver.left_scribe_offset(layout)
        # Rz(-pi/2): panel +X -> cabinet -Y, panel +Y -> cabinet +X.
        # Origin x = scribe (panel back face touches side outer face);
        # panel front face lands at cabinet x = 0 (flush with FF outer
        # face) when depth = scribe.
        # Angled-front cabinets carry per-side depths: the panel runs
        # to that side's own front edge (where the angled FF meets it).
        depth_l = (solver.effective_left_depth(layout)
                   if layout.is_angled else layout.dim_y)
        # A side toe-kick inset recesses the kick from this face, so the
        # panel is held up at the bay bottom (like the carcass side is)
        # and the inset kick stays visible beneath it.
        z0 = (solver.bay_bottom_z(layout, 0)
              if layout.kick_inset_left > 0 else 0.0)
        location = (scribe, 0.0, z0)
        rotation_z = -math.pi / 2.0
        width = depth_l - layout.fft
        height = layout.dim_z - z0
        return (location, rotation_z, width, height, scribe)
    if side == 'RIGHT':
        scribe = solver.right_scribe_offset(layout)
        # Rz(+pi/2): panel +X -> cabinet +Y, panel +Y -> cabinet -X.
        # Origin x = dim_x - scribe; front face lands at dim_x (flush
        # with FF outer face) when depth = scribe.
        depth_r = (solver.effective_right_depth(layout)
                   if layout.is_angled else layout.dim_y)
        z0 = (solver.bay_bottom_z(layout, len(layout.bays) - 1)
              if layout.kick_inset_right > 0 else 0.0)
        location = (layout.dim_x - scribe,
                    -depth_r + layout.fft, z0)
        rotation_z = math.pi / 2.0
        width = depth_r - layout.fft
        height = layout.dim_z - z0
        return (location, rotation_z, width, height, scribe)
    # BACK: rotate +pi around Z. Front face -> +Y. Origin at
    # back-right-bottom; width spans cabinet x from dim_x down to 0.
    # Full cabinet height for now - refine when applied-back behavior
    # is settled.
    return ((layout.dim_x, 0.0, 0.0), math.pi,
            layout.dim_x, layout.dim_z, inch(0.75))


# Registry of CLASS_NAME -> FaceFrameCabinet subclass for _wrap_cabinet.
# Modules that introduce new cabinet subclasses (e.g. corner cabinets)
# register their classes into this dict at import time so the prop
# update callback dispatches to the right recalculate() override.
WRAP_CLASS_REGISTRY = {}


def _wrap_cabinet(obj):
    """Wrap a cabinet root Object as the appropriate FaceFrameCabinet subclass."""
    class_name = obj.get('CLASS_NAME', 'FaceFrameCabinet')
    cls = WRAP_CLASS_REGISTRY.get(class_name, FaceFrameCabinet)
    instance = cls.__new__(cls)
    GeoNodeCage.__init__(instance, obj)
    return instance


WRAP_CLASS_REGISTRY.update({
    'BaseFaceFrameCabinet': BaseFaceFrameCabinet,
    'FloatingBaseFaceFrameCabinet': FloatingBaseFaceFrameCabinet,
    'FloatingVanityCabinet': FloatingVanityCabinet,
    'SinkFaceFrameCabinet': SinkFaceFrameCabinet,
    'CooktopFaceFrameCabinet': CooktopFaceFrameCabinet,
    'GalleyWorkstationFaceFrameCabinet': GalleyWorkstationFaceFrameCabinet,
    'GalleyIWS2Cabinet': GalleyIWS2Cabinet,
    'GalleyIWS3Cabinet': GalleyIWS3Cabinet,
    'GalleyIWS4Cabinet': GalleyIWS4Cabinet,
    'GalleyIWS5Cabinet': GalleyIWS5Cabinet,
    'GalleyIWS6Cabinet': GalleyIWS6Cabinet,
    'GalleyIWS7Cabinet': GalleyIWS7Cabinet,
    'ADASinkCabinet': ADASinkCabinet,
    'UpperFaceFrameCabinet': UpperFaceFrameCabinet,
    'TallFaceFrameCabinet': TallFaceFrameCabinet,
    'RefrigeratorCabinet': RefrigeratorCabinet,
    'BuiltInTallFaceFrameCabinet': BuiltInTallFaceFrameCabinet,
    'BookcaseFaceFrameCabinet': BookcaseFaceFrameCabinet,
    'LapDrawerFaceFrameCabinet': LapDrawerFaceFrameCabinet,
    'PanelFaceFrameCabinet': PanelFaceFrameCabinet,
    'FaceFrameAndDoorsCabinet': FaceFrameAndDoorsCabinet,
    'LegProductFaceFrameCabinet': LegProductFaceFrameCabinet,
    'FloatingShelfFaceFrameCabinet': FloatingShelfFaceFrameCabinet,
    'MantleFaceFrameProduct': MantleFaceFrameProduct,
    'ValanceFaceFrameProduct': ValanceFaceFrameProduct,
})


# Specialty Bath leaf classes. _wrap_cabinet() (run on every recalc) falls back
# to the base FaceFrameCabinet for any CLASS_NAME not registered here, and the
# base reports _has_carcass() == True - so an unregistered PANEL-derived class
# (Mirror Frame) wrongly rebuilds carcass / blind / top / bottom parts at
# recalc. Registering it makes recalc wrap it as a Panel (no carcass). The
# upper-derived bath products wrap to a carcass either way (and resolve
# _has_toe_kick to Upper's False == the base-wrap value), so listing them here
# is behavior-neutral - it just makes recalc use their real class.
# Furniture and bookcase leaf classes. These sit on a toe kick -- they
# descend from BASE or TALL -- but an unregistered class wraps as the
# plain FaceFrameCabinet, whose _has_toe_kick() is False. So the first
# recalc after placement dropped the carcass bottom, back and bay by the
# kick height and stretched the back to suit: a dresser or window seat
# fell into its own kick as soon as it was resized. The two upper-derived
# entries resolve the same either way, and are listed so the set is the
# whole family rather than the half of it that misbehaved.
WRAP_CLASS_REGISTRY.update({
    'FurnitureFaceFrameCabinet': FurnitureFaceFrameCabinet,
    'FiveDrawerDresserCabinet': FiveDrawerDresserCabinet,
    'SixDrawerDresserCabinet': SixDrawerDresserCabinet,
    'NightStandFaceFrameCabinet': NightStandFaceFrameCabinet,
    'ThreeDrawerNightStandCabinet': ThreeDrawerNightStandCabinet,
    'WindowSeatFaceFrameCabinet': WindowSeatFaceFrameCabinet,
    'BookcaseStorageUnitFaceFrameCabinet': BookcaseStorageUnitFaceFrameCabinet,
    'BookcaseUpperFaceFrameCabinet': BookcaseUpperFaceFrameCabinet,
    'HutchUpperFaceFrameCabinet': HutchUpperFaceFrameCabinet,
})


WRAP_CLASS_REGISTRY.update({
    'StandardRecessedMedicineCabinet': StandardRecessedMedicineCabinet,
    'MedicineCabinetFaceFrameCabinet': MedicineCabinetFaceFrameCabinet,
    'OverstoolCabinetFaceFrameCabinet': OverstoolCabinetFaceFrameCabinet,
    'MirrorFrameFaceFrameCabinet': MirrorFrameFaceFrameCabinet,
    'TubSkirtFaceFrameCabinet': TubSkirtFaceFrameCabinet,
    'TriViewMedicineCabinetFaceFrameCabinet': TriViewMedicineCabinetFaceFrameCabinet,
})


def _remove_root_with_children(root_obj):
    """Delete a cabinet/panel root and every descendant. Iterates the
    descendant list in reverse so deeper objects unparent before their
    ancestors, avoiding "StructRNA has been removed" errors when a
    later iteration would try to read a freed Object.
    """
    for desc in reversed(list(root_obj.children_recursive)):
        if desc.name in bpy.data.objects:
            bpy.data.objects.remove(desc, do_unlink=True)
    bpy.data.objects.remove(root_obj, do_unlink=True)


# Standalone panel products (placed from the library) that should get the
# applied-back-panel behaviour: auto face frame sizes, the mid-stile width
# ladder, and auto openings. Applied panels are PanelFaceFrameCabinet too but
# carry TAG_APPLIED_PANEL_SIDE and are reconciled by their host, so excluded.
PANEL_PRODUCT_CLASS_NAMES = frozenset({
    'PanelFaceFrameCabinet', 'FaceFrameAndDoorsCabinet',
})


def _is_standalone_panel(root):
    return (root is not None
            and root.get('CLASS_NAME') in PANEL_PRODUCT_CLASS_NAMES
            and not root.get(TAG_APPLIED_PANEL_SIDE))


# Guard so the bay insert/delete inside the standalone-panel reconcile (each of
# which recalcs the panel) doesn't recurse back into the reconcile.
_RECONCILING_STANDALONE = set()


def _reconcile_standalone_panel(root):
    """Give a standalone Panel the same treatment an applied back panel gets:
    auto face frame sizes, the mid-stile width ladder, and auto openings - with
    the panel acting as its own host. Runs OUTSIDE the recalc reentrance guard
    (so the bay insert/delete it performs can recalc the panel) but under its
    own guard (so that recalc doesn't recurse here)."""
    if id(root) in _RECONCILING_STANDALONE:
        return
    if not _is_standalone_panel(root):
        return
    _RECONCILING_STANDALONE.add(id(root))
    try:
        from . import applied_panel_sizing as aps
        # NOTE: do NOT call apply_panel_sizing here. Its 5-piece path
        # reconstructs the rail as `cab.top_rail_width - overlay + door_rail`,
        # reading and writing the SAME field when the panel is its own host -
        # so the rail grows without bound every recalc. A standalone panel
        # keeps its own style-driven face-frame widths; only the split
        # structure (ladder + auto openings + mid-stile widths) is applied.
        aps.apply_panel_split_structure(root, root, 'BACK')
        # X-Frame braces (the catalog's matching X-Frame Back).
        aps.apply_panel_x_frame(root, root, 'BACK')
        # Surface the panel's properties from any of its parts: stamp the
        # part-commands menu onto menu-less parts (inset panels / pivots).
        for part in root.children_recursive:
            if part.get('hb_part_role') and not part.get('MENU_ID'):
                part['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'
    finally:
        _RECONCILING_STANDALONE.discard(id(root))


def recalculate_face_frame_cabinet(obj):
    """Push current property values to all carcass parts. Safe entry point
    for property update callbacks. Walks up to find the cabinet root if obj
    is a child or descendant.

    Guarded against reentrance: if a recalc is already in progress for this
    cabinet (because a bay/cabinet prop write inside recalculate fired its
    update callback), this call exits immediately. The outer recalc will
    pick up the new value when it reads from props.

    Also honors suspend_recalc(): when active, the request is queued by name
    and drained once at the outermost resume.
    """
    root = find_cabinet_root(obj)
    if root is None:
        return
    if _RECALC_SUSPEND_DEPTH > 0:
        _PENDING_RECALC_NAMES.add(root.name)
        return
    if id(root) in _RECALCULATING:
        return
    _RECALCULATING.add(id(root))
    try:
        with hb_utils.children_index():
            # Combined back-to-back island ends: re-derive how far the
            # end panel runs back from the other run's live depth before
            # the parts are sized, so resizing either run keeps the
            # shared panel the right length. Only this root's own props
            # are written, and the reentrance guard above is already
            # armed, so the writes' update callbacks fall straight back
            # out.
            island_pair.sync(root)
            cabinet = _wrap_cabinet(root)
            cabinet.recalculate()
            _resize_seated_wood_tops(root)
            _reapply_cabinet_style(root)
            # Round-top doors: carry a quarter / half circle door's
            # curve into the frame member above it, so the opening
            # follows the door instead of showing square above the arc.
            # After the style pass, which is what gives each door the
            # frame its curve is measured from. No-op + cleanup when no
            # door is round.
            refresh_round_top_frames(root)
            _reapply_selection_mode_highlights(root)
    finally:
        _RECALCULATING.discard(id(root))

    # Standalone panels get the applied-back behaviour after the core
    # recalc (own guard prevents recursion via its bay insert/delete).
    with hb_utils.children_index():
        _reconcile_standalone_panel(root)


def _resize_seated_wood_tops(root):
    """Refit wood tops seated on this cabinet after its size changed.

    A seated top sizes from its anchor cabinet plus the overhangs, but
    that math only runs inside WoodTopPart.rebuild() -- which nothing
    fired when the cabinet underneath was resized, so the board kept the
    width / depth / height it was placed at. Style re-apply happens after
    this so a rebuilt board still picks up its materials.
    """
    # Collect first: rebuild() adds / removes the top's own edge band
    # parts, which are themselves in children_recursive.
    tops = [child for child in root.children_recursive
            if child.get(WOOD_TOP_TAG)]
    for child in tops:
        # rebuild() re-reads the board's OWN parent, so a top seated on a
        # nested cage still fits the cabinet it actually sits on.
        top = WoodTopPart()
        top.obj = child
        top.rebuild()


def _reapply_selection_mode_highlights(root):
    """Re-apply face frame selection mode highlight to root and all its
    descendants. Called at the end of every recalc so newly created
    parts pick up the highlight without forcing the user to toggle the
    mode off and on.

    Mirrors HB_FACE_FRAME_OT_toggle_mode's per-object dispatch but does
    NOT clear scene selection - recalc fires from prop update callbacks
    during live-bound popup edits, not from an explicit user action, so
    messing with selection would close popups and break drag flow.
    """
    # Lazy import: toggle_cabinet_color lives in a sibling product library
    # and pulling it at module top would couple type-level recalc to the
    # frameless package import order during addon load.
    from ..frameless.operators.ops_placement import toggle_cabinet_color
    from . import quiet_cages

    scene_props = getattr(bpy.context.scene, 'hb_face_frame', None)
    if scene_props is None:
        return

    mode = scene_props.face_frame_selection_mode
    # Master toggle off and Parts mode both route through the "not
    # highlighted" path - matches the operator's behavior at execute().
    if not scene_props.face_frame_selection_mode_enabled or mode == 'Parts':
        mode = '__off__'

    # Same tag dict as HB_FACE_FRAME_OT_toggle_mode.MODE_TAGS. Kept in
    # sync by convention; if the operator's MODE_TAGS gain entries, add
    # them here too.
    mode_tags = {
        'Cabinets':       TAG_CABINET_CAGE,
        'Bays':           TAG_BAY_CAGE,
        'Openings':       'IS_FACE_FRAME_OPENING_CAGE',
        'Interiors':      'IS_FACE_FRAME_INTERIOR_PART',
        'Applied Panels': TAG_APPLIED_PANEL_SIDE,
    }

    skip_markers = ('IS_WALL_BP', 'IS_ENTRY_DOOR_BP',
                    'IS_WINDOW_BP', 'IS_CUTTING_OBJ')

    def matches(obj):
        if mode == 'Face Frame':
            return obj.get('hb_part_role') in FACE_FRAME_PART_ROLES
        # Drawer boxes join Interiors mode by role - deliberately NOT
        # tagged IS_FACE_FRAME_INTERIOR_PART, which would also send
        # them to the dashed hidden-line pass on 2D layout views.
        if (mode == 'Interiors'
                and obj.get('hb_part_role') == PART_ROLE_DRAWER_BOX):
            return True
        if mode == 'Cabinets':
            if obj.get('IS_APPLIANCE'):
                return True
            if obj.get(TAG_APPLIED_PANEL_SIDE):
                return False
        tag = mode_tags.get(mode)
        if tag is None:
            return False
        return tag in obj

    def apply(obj):
        if any(t in obj for t in skip_markers):
            return
        if matches(obj):
            # Material Preview / Rendered: an unselected cage stays
            # hidden (see quiet_cages). prev_selected is the snapshot
            # taken below, before this pass touches anything.
            if quiet_cages.keep_hidden(obj, mode,
                                       selected_names=prev_selected):
                toggle_cabinet_color(
                    obj, False,
                    type_name=mode_tags.get(mode, ''),
                )
                return
            toggle_cabinet_color(
                obj, True,
                type_name=mode_tags.get(mode, ''),
                dont_show_parent=False,
            )
            # Unlocked (overridden) parts read a distinct colour so the
            # user can see what they've changed from default. Same rule as
            # the toggle_mode operator; this path runs after every recalc.
            if mode == 'Face Frame' and part_width_is_unlocked(obj):
                obj.color = FACE_FRAME_UNLOCKED_COLOR
        else:
            toggle_cabinet_color(
                obj, False,
                type_name=mode_tags.get(mode, ''),
            )

    # toggle_cabinet_color select_set()s as a side effect -- wanted when
    # the user explicitly toggles a selection mode, but this path runs
    # after EVERY recalc (accessory adds, width edits, prop callbacks),
    # and silently selecting every matching cage in the cabinet destroys
    # the user's one-opening selection. Snapshot and restore around the
    # highlight pass so a recalc never changes what is selected.
    view_layer = bpy.context.view_layer
    prev_selected = {o.name for o in bpy.context.selected_objects}
    prev_active = view_layer.objects.active

    subtree = [root, *root.children_recursive]
    for obj in subtree:
        apply(obj)

    for obj in subtree:
        try:
            obj.select_set(obj.name in prev_selected)
        except RuntimeError:
            pass  # not in the view layer / hidden by the highlight pass
    if prev_active is not None \
            and view_layer.objects.active is not prev_active:
        try:
            view_layer.objects.active = prev_active
        except Exception:
            pass


def _reapply_cabinet_style(root):
    """Re-attach door / drawer-front styles AND materials to a cabinet's
    parts after a recalc. The face frame solver wipes and rebuilds all
    bays, carcass parts, and fronts on every recalc, so per-part
    material slots and the per-front CPM_5PIECEDOOR modifier vanish
    each cycle. STYLE_NAME on the cabinet root survives (it lives on
    the root, not on parts), so we look up the cabinet style and re-
    run both walks. No-op if the cabinet has no STYLE_NAME or the
    named style is missing from the scene's collection.

    Order matters: door styles add the 5-piece modifier (which has its
    own material slots), and the material walk then wires those slots
    along with the cutpart surface inputs.
    """
    style_name = root.get('STYLE_NAME')
    if not style_name:
        return
    from .props_hb_face_frame import get_style_props
    ff = get_style_props()
    for cs in ff.cabinet_styles:
        if cs.name == style_name:
            cs._apply_door_styles_to_fronts(root)
            cs._apply_materials_to_cabinet(root)
            # FF sizes intentionally NOT re-applied here - widths are
            # cabinet props the user can edit between recalcs; pushing
            # them every recalc would clobber per-cabinet adjustments.
            # The Assign Style op runs the push explicitly.
            return


# ---------------------------------------------------------------------------
# Cabinet merge
# ---------------------------------------------------------------------------

_SIDE_PROP_NAMES_LEFT = (
    'left_finished_end_condition', 'left_exposure',
    'left_dishwasher_adjacent', 'left_finish_end_auto', 'left_scribe',
    'left_flush_x_amount', 'blind_left', 'blind_amount_left',
    'extend_left', 'left_offset', 'inset_toe_kick_left',
    'left_stile_width', 'left_stile_type', 'unlock_left_stile',
    'turn_off_left_stile', 'extend_left_stile_to_floor',
    'extend_left_stile_up', 'extend_left_stile_down',
    'extend_left_stile_up_amount', 'extend_left_stile_down_amount',
    'left_depth', 'unlock_left_depth',
)
_SIDE_PROP_NAMES_RIGHT = (
    'right_finished_end_condition', 'right_exposure',
    'right_dishwasher_adjacent', 'right_finish_end_auto', 'right_scribe',
    'right_flush_x_amount', 'blind_right', 'blind_amount_right',
    'extend_right', 'right_offset', 'inset_toe_kick_right',
    'right_stile_width', 'right_stile_type', 'unlock_right_stile',
    'turn_off_right_stile', 'extend_right_stile_to_floor',
    'extend_right_stile_up', 'extend_right_stile_down',
    'extend_right_stile_up_amount', 'extend_right_stile_down_amount',
    'right_depth', 'unlock_right_depth',
)


def _side_prop_names(side):
    return _SIDE_PROP_NAMES_RIGHT if side == 'RIGHT' else _SIDE_PROP_NAMES_LEFT


def _capture_side_props(props, side):
    """Snapshot all side-specific cabinet props for the given side."""
    return {name: getattr(props, name) for name in _side_prop_names(side)}


def _apply_side_props(props, side, captured):
    """Write a captured side-prop snapshot onto props. The dict's keys
    are expected to match the prop names for that side.

    The auto-finish flag is written LAST. The finish-condition and
    scribe props both flip it off from their update callbacks, so
    writing it in list order would leave the side pinned regardless of
    what was captured.
    """
    auto_name = f'{side.lower()}_finish_end_auto'
    for name in _side_prop_names(side):
        if name != auto_name and name in captured:
            setattr(props, name, captured[name])
    if auto_name in captured:
        setattr(props, auto_name, captured[auto_name])


def _default_side_props(side, stile_width, depth):
    """Return a dict of side-specific cabinet prop values representing
    a freshly-exterior side - what a new cabinet edge looks like at
    creation time. Used during break to reset both halves' new
    boundary edges to a clean default state.
    """
    pre = 'right_' if side == 'RIGHT' else 'left_'
    suf = '_right' if side == 'RIGHT' else '_left'
    return {
        f'{pre}finished_end_condition': 'UNFINISHED',
        f'{pre}exposed': True,
        f'{pre}scribe': 0.0,
        f'{pre}flush_x_amount': inch(4.0),
        f'blind{suf}': False,
        f'blind_amount{suf}': inch(24.0),
        f'extend{suf}': 0.0,
        f'{pre}offset': 0.0,
        f'inset_toe_kick{suf}': 0.0,
        f'{pre}stile_width': stile_width,
        f'{pre}stile_type': 'STANDARD',
        f'unlock_{pre}stile': False,
        f'turn_off_{pre}stile': False,
        f'extend_{pre}stile_to_floor': False,
        f'extend_{pre}stile_up': False,
        f'extend_{pre}stile_down': False,
        f'extend_{pre}stile_up_amount': 0.0,
        f'extend_{pre}stile_down_amount': 0.0,
        f'{pre}depth': depth,
        f'unlock_{pre}depth': False,
    }


def _propagate_far_side_props(absorbed_props, anchor_props, side):
    """When `absorbed` is merged onto `anchor` on the given `side`,
    `absorbed`'s far-side exterior props (the side opposite the merge
    boundary) become `anchor`'s same-side exterior props. The anchor's
    OTHER side stays untouched. The merge boundary itself - what was
    anchor's <side> exterior and absorbed's <opposite> exterior - just
    disappears (becomes interior bay structure), so neither gets read
    after the merge.
    """
    if side == 'RIGHT':
        anchor_props.right_finished_end_condition = absorbed_props.right_finished_end_condition
        anchor_props.right_exposure             = absorbed_props.right_exposure
        anchor_props.right_dishwasher_adjacent  = absorbed_props.right_dishwasher_adjacent
        anchor_props.right_scribe                 = absorbed_props.right_scribe
        anchor_props.right_flush_x_amount         = absorbed_props.right_flush_x_amount
        anchor_props.blind_right                  = absorbed_props.blind_right
        anchor_props.blind_amount_right           = absorbed_props.blind_amount_right
        anchor_props.extend_right                 = absorbed_props.extend_right
        anchor_props.right_offset                 = absorbed_props.right_offset
        anchor_props.inset_toe_kick_right         = absorbed_props.inset_toe_kick_right
        anchor_props.right_stile_width            = absorbed_props.right_stile_width
        anchor_props.right_stile_type             = absorbed_props.right_stile_type
        anchor_props.unlock_right_stile           = absorbed_props.unlock_right_stile
        anchor_props.turn_off_right_stile         = absorbed_props.turn_off_right_stile
        anchor_props.extend_right_stile_to_floor  = absorbed_props.extend_right_stile_to_floor
        anchor_props.extend_right_stile_up        = absorbed_props.extend_right_stile_up
        anchor_props.extend_right_stile_down      = absorbed_props.extend_right_stile_down
        anchor_props.extend_right_stile_up_amount   = absorbed_props.extend_right_stile_up_amount
        anchor_props.extend_right_stile_down_amount = absorbed_props.extend_right_stile_down_amount
        # Per-side depth / unlock - pre-flight requires square cabinets so
        # these are defensive copies (would matter only if angled-cabinet
        # merge support is added later).
        anchor_props.right_depth                  = absorbed_props.right_depth
        anchor_props.unlock_right_depth           = absorbed_props.unlock_right_depth
        # Auto flag last: the finish-condition and scribe writes above
        # each turn it off through their update callbacks. Written in
        # place it would leave the merged side pinned, so the exposure
        # pass that runs right after the merge could not finish an end
        # that is now exposed - the absorbed cabinet was carrying the
        # default Unfinished, detection never having run on it.
        anchor_props.right_finish_end_auto        = absorbed_props.right_finish_end_auto
    else:  # LEFT
        anchor_props.left_finished_end_condition = absorbed_props.left_finished_end_condition
        anchor_props.left_exposure              = absorbed_props.left_exposure
        anchor_props.left_dishwasher_adjacent   = absorbed_props.left_dishwasher_adjacent
        anchor_props.left_scribe                 = absorbed_props.left_scribe
        anchor_props.left_flush_x_amount         = absorbed_props.left_flush_x_amount
        anchor_props.blind_left                  = absorbed_props.blind_left
        anchor_props.blind_amount_left           = absorbed_props.blind_amount_left
        anchor_props.extend_left                 = absorbed_props.extend_left
        anchor_props.left_offset                 = absorbed_props.left_offset
        anchor_props.inset_toe_kick_left         = absorbed_props.inset_toe_kick_left
        anchor_props.left_stile_width            = absorbed_props.left_stile_width
        anchor_props.left_stile_type             = absorbed_props.left_stile_type
        anchor_props.unlock_left_stile           = absorbed_props.unlock_left_stile
        anchor_props.turn_off_left_stile         = absorbed_props.turn_off_left_stile
        anchor_props.extend_left_stile_to_floor  = absorbed_props.extend_left_stile_to_floor
        anchor_props.extend_left_stile_up        = absorbed_props.extend_left_stile_up
        anchor_props.extend_left_stile_down      = absorbed_props.extend_left_stile_down
        anchor_props.extend_left_stile_up_amount   = absorbed_props.extend_left_stile_up_amount
        anchor_props.extend_left_stile_down_amount = absorbed_props.extend_left_stile_down_amount
        anchor_props.left_depth                  = absorbed_props.left_depth
        anchor_props.unlock_left_depth           = absorbed_props.unlock_left_depth
        # Auto flag last: the finish-condition and scribe writes above
        # each turn it off through their update callbacks. Written in
        # place it would leave the merged side pinned, so the exposure
        # pass that runs right after the merge could not finish an end
        # that is now exposed - the absorbed cabinet was carrying the
        # default Unfinished, detection never having run on it.
        anchor_props.left_finish_end_auto        = absorbed_props.left_finish_end_auto


def merge_cabinets(anchor, absorbed, side):
    """Merge `absorbed` cabinet into `anchor` on the given `side`
    ('LEFT' or 'RIGHT' relative to anchor).

    Reparents absorbed's bays under anchor (preserving opening cage
    object identity, which the solver matches by obj.name across
    recalcs), copies absorbed's far-side exterior props onto anchor's
    same-side exterior, deletes absorbed, then triggers a single recalc
    of anchor.

    Pre-flight requires matching height, depth, world Z, and parent;
    abutting within 1 inch in parent-local X; and both cabinets square
    (no corner / angled merge in this pass).

    Returns True on success, False on failed pre-flight.
    """
    if side not in ('LEFT', 'RIGHT'):
        return False
    if anchor is None or absorbed is None or anchor is absorbed:
        return False
    if not anchor.get(TAG_CABINET_CAGE) or not absorbed.get(TAG_CABINET_CAGE):
        return False

    a_props = anchor.face_frame_cabinet
    b_props = absorbed.face_frame_cabinet

    eps = 1e-4
    if abs(a_props.height - b_props.height) > eps:
        return False
    if abs(a_props.depth - b_props.depth) > eps:
        return False
    if abs(hb_utils.world_matrix(anchor).translation.z - hb_utils.world_matrix(absorbed).translation.z) > eps:
        return False
    if anchor.parent is not absorbed.parent:
        return False
    if a_props.corner_type != 'NONE' or b_props.corner_type != 'NONE':
        return False

    tolerance = inch(1.0)
    a_w = a_props.width
    b_w = b_props.width

    # Abutment is checked along the anchor's run direction, defined as
    # its local +X axis projected into the world XY plane. For wall-
    # parented cabinets both anchor and absorbed sit with no local Z
    # rotation, so the run axis equals the wall's length direction and
    # the projected gap collapses to (absorbed.location.x -
    # anchor.location.x) - same number the old code computed. For
    # island / off-wall placement the cabinets can sit at any Z
    # rotation; the projection handles both cases.
    a_run = hb_utils.world_matrix(anchor).to_3x3() @ Vector((1.0, 0.0, 0.0))
    a_run.z = 0.0
    b_run = hb_utils.world_matrix(absorbed).to_3x3() @ Vector((1.0, 0.0, 0.0))
    b_run.z = 0.0
    if a_run.length < 1e-8 or b_run.length < 1e-8:
        return False
    a_run.normalize()
    b_run.normalize()
    # Cabinets in the same run must share orientation. Half-degree
    # tolerance keeps two parallel island runs offset depth-wise from
    # ever being treated as a single run.
    if a_run.dot(b_run) < math.cos(math.radians(0.5)):
        return False

    disp = hb_utils.world_matrix(absorbed).translation - hb_utils.world_matrix(anchor).translation
    signed = disp.x * a_run.x + disp.y * a_run.y
    perp_x = disp.x - signed * a_run.x
    perp_y = disp.y - signed * a_run.y
    perp = math.sqrt(perp_x * perp_x + perp_y * perp_y)
    if perp > tolerance:
        return False
    if side == 'RIGHT':
        gap = signed - a_w
    else:
        gap = -signed - b_w
    if abs(gap) > tolerance:
        return False

    with suspend_recalc():
        anchor_bays = sorted(
            [c for c in anchor.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )
        absorbed_bays = sorted(
            [c for c in absorbed.children if c.get(TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        )
        M = len(anchor_bays)
        N = len(absorbed_bays)

        # Snapshot original unlock_width on every bay. After merge each
        # bay's lock state is one of: original (multi-bay source) or
        # forced-True (single-bay source - the sink / appliance case
        # where the bay must hold its captured width).
        original_unlock = {
            bay.name: bay.face_frame_bay.unlock_width
            for bay in (anchor_bays + absorbed_bays)
        }

        # Capture mid_stile_widths from both cabinets as plain data
        # before mutating anything. Boundary width is the sum of the
        # two end stiles meeting at the merge - the wood that was
        # anchor's right end stile + absorbed's left end stile becomes
        # the boundary mid stile, preserving bay positions exactly.
        # Captured BEFORE _propagate_far_side_props because propagation
        # overwrites anchor's end stile widths.
        def _snapshot_mids(props):
            return [(e.width, e.unlock, e.extend_up_amount, e.extend_down_amount)
                    for e in props.mid_stile_widths]
        anchor_mids = _snapshot_mids(a_props)
        absorbed_mids = _snapshot_mids(b_props)

        # Boundary mid stile uses the cabinet's default mid-stile
        # width (typically narrower than the two abutting end stiles).
        # Total cabinet width is held at (a_w + b_w); the bay
        # redistributor absorbs the saved-stile-width delta into
        # whichever bays remain unlocked at recalc time.
        boundary_width = a_props.bay_mid_stile_width
        boundary_gap_index = M - 1 if side == 'RIGHT' else N - 1

        # Capture mid-stile / mid-div parts. Absorbed's move to anchor
        # with new indices; anchor's existing parts shift only on LEFT
        # merges (when absorbed prepends).
        mid_part_roles = (PART_ROLE_MID_STILE, PART_ROLE_MID_DIVISION)
        anchor_mid_parts = [c for c in anchor.children
                            if c.get('hb_part_role') in mid_part_roles]
        absorbed_mid_parts = [c for c in absorbed.children
                              if c.get('hb_part_role') in mid_part_roles]

        # Reparent absorbed's bays under anchor.
        for bay in absorbed_bays:
            bay.parent = anchor
            bay.matrix_parent_inverse.identity()
        hb_utils.note_parent_change()

        if side == 'RIGHT':
            final_bays = anchor_bays + absorbed_bays
        else:
            final_bays = absorbed_bays + anchor_bays
        for new_idx, bay in enumerate(final_bays):
            bay['hb_bay_index'] = new_idx
            bay.face_frame_bay.bay_index = new_idx

        # A single-bay source's bay gets force-locked when it merges
        # into a multi-bay cabinet - the lock keeps a sink / appliance
        # bay from being resized by the neighbor's redistribution.
        # Multi-bay sources always keep their original unlock_width so
        # their auto-calculated bays absorb the boundary-stile
        # consolidation delta at recalc time.
        #
        # When two single-bay cabinets merge, the anchor is the cabinet
        # already in place and holds its width; only the absorbed bay -
        # the one just placed - stays unlocked, so _distribute_bay_widths
        # grows it to fill the merged run (the two abutting end stiles
        # collapse to one narrower boundary mid stile, freeing width
        # that needs an unlocked bay to land in).
        anchor_was_single = (M == 1)
        absorbed_was_single = (N == 1)
        both_single = anchor_was_single and absorbed_was_single
        for bay in anchor_bays:
            bay.face_frame_bay.unlock_width = (
                True if anchor_was_single else original_unlock[bay.name]
            )
        for bay in absorbed_bays:
            if both_single:
                bay.face_frame_bay.unlock_width = False
            else:
                bay.face_frame_bay.unlock_width = (
                    True if absorbed_was_single else original_unlock[bay.name]
                )

        # Toe-kick construction reconciliation. toe_kick_type and
        # toe_kick_height are cabinet-level, so the merge - which keeps
        # the anchor's cabinet props and deletes absorbed - would render
        # absorbed's bays with the anchor's kick. Express any difference
        # per bay instead: a bay built FLOATING (lap drawer, floating
        # base) carries floating_bay so the solver lifts it regardless
        # of the merged cabinet type, and any bay whose recess differs
        # from the merged default is unlocked so _distribute_bay_kick_
        # heights leaves it alone (e.g. a 27\" lap-drawer lift would
        # otherwise snap to the anchor's 4\").
        a_tk, b_tk = a_props.toe_kick_type, b_props.toe_kick_type
        if a_tk != b_tk:
            # Grounded type wins as the cabinet-level default for
            # unflagged bays: NOTCH over FLUSH over FLOATING.
            if 'NOTCH' in (a_tk, b_tk):
                merged_tk = 'NOTCH'
            elif 'FLUSH' in (a_tk, b_tk):
                merged_tk = 'FLUSH'
            else:
                merged_tk = 'FLOATING'
            if merged_tk != 'FLOATING':
                if a_tk == 'FLOATING':
                    for bay in anchor_bays:
                        bay.face_frame_bay.floating_bay = True
                if b_tk == 'FLOATING':
                    for bay in absorbed_bays:
                        bay.face_frame_bay.floating_bay = True
            a_props.toe_kick_type = merged_tk

        # Bays seed kick_height from their origin cabinet's
        # toe_kick_height; after the merge the cabinet-level default is
        # the anchor's. Unlock any bay that differs so it holds its own
        # recess / lift rather than being resynced to that default.
        merged_kh = a_props.toe_kick_height
        for bay in final_bays:
            bp = bay.face_frame_bay
            if abs(bp.kick_height - merged_kh) > eps:
                bp.unlock_kick_height = True

        _propagate_far_side_props(b_props, a_props, side)

        # Reparent absorbed's mid parts under anchor with new indices.
        # Anchor's existing mid parts shift only on LEFT merges.
        if side == 'RIGHT':
            for part in absorbed_mid_parts:
                old_idx = part.get('hb_mid_stile_index', 0)
                part['hb_mid_stile_index'] = old_idx + M
                part.parent = anchor
                part.matrix_parent_inverse.identity()
        else:
            for part in anchor_mid_parts:
                old_idx = part.get('hb_mid_stile_index', 0)
                part['hb_mid_stile_index'] = old_idx + N
            for part in absorbed_mid_parts:
                part.parent = anchor
                part.matrix_parent_inverse.identity()
        hb_utils.note_parent_change()

        # Build the boundary mid stile + slot-0 / slot-1 mid div pair.
        # _create_mid_parts_at parents to anchor and sets defaults; the
        # recalc positions and sizes everything from layout.
        _wrap_cabinet(anchor)._create_mid_parts_at(boundary_gap_index)

        # Rebuild anchor's mid_stile_widths in merged order.
        if side == 'RIGHT':
            merged_mids = (anchor_mids
                           + [(boundary_width, False, 0.0, 0.0)]
                           + absorbed_mids)
        else:
            merged_mids = (absorbed_mids
                           + [(boundary_width, False, 0.0, 0.0)]
                           + anchor_mids)
        a_props.mid_stile_widths.clear()
        for w, ulk, ext_up, ext_dn in merged_mids:
            entry = a_props.mid_stile_widths.add()
            # The merge keeps the anchor's cabinet props, so the merged
            # cabinet has ONE mid-stile default. A width carried over
            # from the absorbed cabinet can predate its own sizing pass
            # (a cabinet merged on the drop is consumed before anything
            # writes its style widths, so its bays still hold the
            # property default) and would read as an unexplained wider
            # stile on the merged front. Only a width the user unlocked
            # is a real override and survives verbatim.
            entry.width = w if ulk else a_props.bay_mid_stile_width
            entry.unlock = ulk
            entry.extend_up_amount = ext_up
            entry.extend_down_amount = ext_dn

        # LEFT merge: anchor's origin moves to absorbed's old location.
        # The merged cabinet then spans exactly the same range as the
        # two originals combined; the bay redistributor handles the
        # (anchor.right + absorbed.left - boundary_default) delta by
        # growing whichever bays are still unlocked. Shifting via the
        # rotation-applied run vector lets this work for island
        # placement at any orientation, while collapsing to a plain
        # location.x assignment when rotation_euler is zero.
        if side == 'LEFT':
            run_in_parent = (
                anchor.rotation_euler.to_matrix() @ Vector((1.0, 0.0, 0.0))
            )
            anchor.location -= b_w * run_in_parent

        # Total cabinet width preserved at sum of original widths.
        a_props.width = a_w + b_w

        # Bays and mid parts have been reparented; what's left under
        # absorbed is its carcass + end stiles + rails + pulls.
        _remove_root_with_children(absorbed)

    return True


def _resolve_style_overlay(root):
    """door_overlay_type of the cabinet's assigned style, or None."""
    style_name = root.get('STYLE_NAME')
    if not style_name:
        return None
    try:
        from .props_hb_face_frame import get_style_props
        ff = get_style_props()
        style = next((cs for cs in ff.cabinet_styles if cs.name == style_name), None)
        return style.door_overlay_type if style is not None else None
    except Exception:
        return None


def _resolve_style_stile_width(root, cab_props, row):
    """Style's ff_<row>_width_<col> for this cabinet (column from
    cabinet_type), or None if it can't be resolved. Lets the break op size
    new butt-stile edges from the assigned style."""
    style_name = root.get('STYLE_NAME')
    if not style_name:
        return None
    try:
        from .props_hb_face_frame import get_style_props
        ff = get_style_props()
        style = next((cs for cs in ff.cabinet_styles if cs.name == style_name), None)
        if style is None:
            return None
        col = style._CABINET_TYPE_COLUMN.get(cab_props.cabinet_type, 'base')
        return getattr(style, f"ff_{row}_width_{col}", None)
    except Exception:
        return None


def break_cabinet_at_gap(cabinet, gap_index, shrink_side='AUTO'):
    """Break `cabinet` into two cabinets at the gap between bays
    `gap_index` and `gap_index+1`. Returns the new (right-half)
    cabinet root, or None on invalid input.

    `shrink_side` directs which half absorbs the extra width the break
    creates (replacing the boundary mid stile with two butt end stiles
    widens the pair; see the width math below): 'AUTO' splits it between
    halves that have unlocked bays; 'LEFT' / 'RIGHT' force it onto one
    half (Break Both uses this so each outer cabinet absorbs exactly one
    boundary's worth and the outer halves come out equal). A forced side
    with no unlocked bays falls back to AUTO.

    The original keeps bays [0..gap_index]; the new cabinet receives
    bays [gap_index+1..end] reindexed from 0. The boundary mid stile
    + mid div pair is deleted. New end stiles at the break edge use
    the cabinet's bay_mid_stile_width default; side props on the
    break edges reset to default-exterior state. The original's
    far-side (right) props propagate onto the new cabinet's right
    side, since that's the new cabinet's exterior on that side.

    Caller sets unlock_width on bays it wants preserved before
    calling.
    """
    if cabinet is None or not cabinet.get(TAG_CABINET_CAGE):
        return None
    cab_props = cabinet.face_frame_cabinet
    if cab_props.corner_type != 'NONE':
        return None
    bays = sorted(
        [c for c in cabinet.children if c.get(TAG_BAY_CAGE)],
        key=lambda c: c.get('hb_bay_index', 0),
    )
    if not (0 <= gap_index < len(bays) - 1):
        return None

    class_name = cabinet.get('CLASS_NAME', 'FaceFrameCabinet')
    cls = WRAP_CLASS_REGISTRY.get(class_name, FaceFrameCabinet)

    with suspend_recalc():
        captured_right = _capture_side_props(cab_props, 'RIGHT')
        mids_data = [(e.width, e.unlock, e.extend_up_amount, e.extend_down_amount)
                     for e in cab_props.mid_stile_widths]
        right_mids = mids_data[gap_index + 1:]

        mid_part_roles = (PART_ROLE_MID_STILE, PART_ROLE_MID_DIVISION)
        all_mid_parts = [c for c in cabinet.children
                         if c.get('hb_part_role') in mid_part_roles]
        boundary_parts = [p for p in all_mid_parts
                          if p.get('hb_mid_stile_index', 0) == gap_index]
        right_mid_parts = [p for p in all_mid_parts
                           if p.get('hb_mid_stile_index', 0) > gap_index]
        right_bays = bays[gap_index + 1:]
        # Break edges become an interior butt joint -> size them from the
        # style's butt-stile width (keeps the width-conservation math below
        # consistent); fall back to the mid-stile default if no style.
        butt_w = _resolve_style_stile_width(cabinet, cab_props, 'butt_stile')
        boundary_default = butt_w if butt_w else cab_props.bay_mid_stile_width

        # Create new cabinet (1 default bay; we replace it below)
        new_inst = cls()
        new_inst.create(cabinet.name.split('.')[0], bay_qty=1)
        new_root = new_inst.obj
        new_props = new_root.face_frame_cabinet

        # Carry over root-level custom prop tags. STYLE_NAME drives
        # _reapply_cabinet_style at recalc end (door style + materials);
        # without it, the new cabinet's fronts render slab.
        for key in ('STYLE_NAME',):
            val = cabinet.get(key)
            if val is not None:
                new_root[key] = val

        if cabinet.parent is not None:
            new_root.parent = cabinet.parent
            new_root.matrix_parent_inverse.identity()
        new_root.rotation_euler = cabinet.rotation_euler.copy()
        new_root.location.y = cabinet.location.y
        new_root.location.z = cabinet.location.z

        # Copy cabinet-wide (non-side) props from original to new
        for name in (
            'cabinet_type', 'height', 'depth',
            'is_sink', 'is_built_in_appliance', 'is_double',
            'top_scribe', 'top_rail_width', 'bottom_rail_width',
            'unlock_top_rail', 'unlock_bottom_rail',
            'bay_mid_rail_width', 'bay_mid_stile_width',
            'panel_frame_auto', 'panel_top_rail_width',
            'panel_bottom_rail_width', 'panel_stile_width',
            'default_top_overlay', 'default_bottom_overlay',
            'default_left_overlay', 'default_right_overlay',
            'material_thickness', 'face_frame_thickness',
            'door_thickness', 'back_thickness', 'division_thickness',
            'finish_toe_kick_thickness',
            'toe_kick_type', 'toe_kick_height', 'toe_kick_setback',
            'toe_kick_thickness', 'back_bottom_inset',
            'include_finish_toe_kick',
            'include_external_nailer', 'include_internal_nailer',
            'include_thin_finished_bottom',
            'include_thick_finished_bottom', 'include_blocking',
            'back_finished_end_condition', 'back_exposure', 'back_finish_end_auto',
            'corner_type', 'exterior_option', 'interior_option',
            'tray_compartment',
        ):
            try:
                setattr(new_props, name, getattr(cab_props, name))
            except (AttributeError, TypeError):
                pass

        # Side props
        _apply_side_props(new_props, 'RIGHT', captured_right)
        _apply_side_props(new_props, 'LEFT',
                          _default_side_props('LEFT', boundary_default, cab_props.depth))
        _apply_side_props(cab_props, 'RIGHT',
                          _default_side_props('RIGHT', boundary_default, cab_props.depth))

        # The two edges the break just created are an interior butt joint.
        # Setting the type re-derives the stile width from the style's butt
        # row (== boundary_default), before the width math reads it below.
        new_props.left_stile_type = 'BUTT'
        cab_props.right_stile_type = 'BUTT'

        # Delete the new cabinet's default bay (created by cls.create())
        for child in list(new_root.children):
            if child.get(TAG_BAY_CAGE):
                _remove_root_with_children(child)

        # Reparent right bays from original to new, reindex from 0
        for new_idx, bay in enumerate(right_bays):
            bay.parent = new_root
            bay.matrix_parent_inverse.identity()
            bay['hb_bay_index'] = new_idx
            bay.face_frame_bay.bay_index = new_idx
        hb_utils.note_parent_change()

        # Delete boundary mid stile + mid div pair
        for p in boundary_parts:
            if p.name in bpy.data.objects:
                bpy.data.objects.remove(p, do_unlink=True)

        # Reparent right mid parts; subtract (gap_index + 1) from index
        for p in right_mid_parts:
            old_idx = p.get('hb_mid_stile_index', 0)
            p['hb_mid_stile_index'] = old_idx - (gap_index + 1)
            p.parent = new_root
            p.matrix_parent_inverse.identity()
        hb_utils.note_parent_change()

        # Strip original's mid_stile_widths down to first gap_index entries
        coll_a = cab_props.mid_stile_widths
        while len(coll_a) > gap_index:
            coll_a.remove(len(coll_a) - 1)

        # Build new cabinet's mid_stile_widths
        coll_b = new_props.mid_stile_widths
        coll_b.clear()
        for w, ulk, ext_up, ext_dn in right_mids:
            entry = coll_b.add()
            entry.width = w
            entry.unlock = ulk
            entry.extend_up_amount = ext_up
            entry.extend_down_amount = ext_dn

        # Set widths so combined width preserves the original cabinet's
        # total. Replacing the boundary mid stile (width B) with two
        # new end stiles (each at default D) adds (2D - B) of extra
        # width. That extra has to be absorbed by shrinking unlocked
        # bays - same redistribution principle as merge but in
        # reverse. Locked bays (including the active one the operator
        # just locked) hold; unlocked bays in each half receive a
        # share of the shrinkage.
        left_bay_total = sum(b.face_frame_bay.width for b in bays[:gap_index + 1])
        left_mid_total = sum(w for (w, _, _, _) in mids_data[:gap_index])
        right_bay_total = sum(b.face_frame_bay.width for b in right_bays)
        right_mid_total = sum(w for (w, _, _, _) in right_mids)

        boundary_actual = mids_data[gap_index][0]
        extra = 2 * boundary_default - boundary_actual

        left_has_unlocked = any(not b.face_frame_bay.unlock_width
                                for b in bays[:gap_index + 1])
        right_has_unlocked = any(not b.face_frame_bay.unlock_width
                                 for b in right_bays)
        if shrink_side == 'LEFT' and left_has_unlocked:
            left_shrink, right_shrink = extra, 0.0
        elif shrink_side == 'RIGHT' and right_has_unlocked:
            left_shrink, right_shrink = 0.0, extra
        elif left_has_unlocked and right_has_unlocked:
            left_shrink, right_shrink = extra / 2.0, extra / 2.0
        elif left_has_unlocked:
            left_shrink, right_shrink = extra, 0.0
        elif right_has_unlocked:
            left_shrink, right_shrink = 0.0, extra
        else:
            # No unlocked bays anywhere. Distribute symmetrically; the
            # halves will be slightly oversized but the user can
            # adjust manually.
            left_shrink, right_shrink = extra / 2.0, extra / 2.0

        cab_props.width = (cab_props.left_stile_width
                           + left_bay_total + left_mid_total
                           + cab_props.right_stile_width
                           - left_shrink)
        new_props.width = (new_props.left_stile_width
                           + right_bay_total + right_mid_total
                           + new_props.right_stile_width
                           - right_shrink)

        # Position new cabinet abutting original (using the now-final
        # original width).
        new_root.location.x = cabinet.location.x + cab_props.width

    return new_root

"""Layout solver for face frame cabinets.

Pure-Python; no drivers. The cabinet's recalculate() method builds a
FaceFrameLayout snapshot from PropertyGroups, asks this module for
segments and per-part geometry, then writes resolved values to the
existing part objects.

Coordinate convention (matches frameless and the carcass):
- Cabinet origin at back-left, floor level
- +X is right, -Y is forward (cabinet front at y = -dim_y)
- Face frame outside face flush with cabinet front (at y = -dim_y)
- Carcass front edge sits behind the face frame (at y = -dim_y + fft)

Multi-bay strategy (option B - lazy per-segment rails):
A "segment" is a run of consecutive bays whose top (or bottom) rail can
be a single physical part - same height, no extended mid stile breaking
the run, etc. The solver returns one segment record per physical rail
needed; the cabinet's recalculate() reconciles those segments against
existing rail objects, creating/destroying as needed. No hidden parts.

Mid stiles are always one-per-gap and never destroyed. Their length and Z
position adapt based on whether adjacent rails pass through the gap.
"""
import math
import bpy

from ...units import inch
from . import island_pair
from . import shelf_nosing
from . import bar_storage


# ---------------------------------------------------------------------------
# Layout snapshot
# ---------------------------------------------------------------------------
def blind_insets(cab):
    """(left, right) amount a BLIND end pulls the face frame plane in
    from the cabinet's ends. Zero on a side that isn't a live blind."""
    left = (cab.blind_amount_left
            if (cab.left_stile_type == 'BLIND' and cab.blind_left
                and cab.blind_amount_left > 0) else 0.0)
    right = (cab.blind_amount_right
             if (cab.right_stile_type == 'BLIND' and cab.blind_right
                 and cab.blind_amount_right > 0) else 0.0)
    return left, right


def decorative_corner_insets(cab):
    """(left, right) amount a decorative corner post on a FRONT corner
    pulls the face frame plane in from that end.

    The post is let into the cabinet's front corner and the frame stays
    whole and butts into it: the frame's left endpoint moves right by
    the post size for a front-left post (mirror on the right). Only
    the carcass is notched around the post. Angled fronts and corner
    cabinets don't take posts, so they read zero here.
    """
    if getattr(cab, 'decorative_corner_style', 'NONE') == 'NONE':
        return 0.0, 0.0
    if cab.cabinet_type == 'PANEL' or cab.corner_type != 'NONE':
        return 0.0, 0.0
    if cab.unlock_left_depth or cab.unlock_right_depth:
        return 0.0, 0.0
    from . import decorative_corner
    size = decorative_corner.post_size(cab, cab.width, cab.depth)
    if size <= 0.0:
        return 0.0, 0.0
    left = size if getattr(cab, 'decorative_corner_front_left', False) else 0.0
    right = size if getattr(cab, 'decorative_corner_front_right', False) else 0.0
    return left, right


def face_frame_insets(cab):
    """(left, right) total inset of the face frame plane from the
    cabinet's ends: blind offset plus decorative corner post. Both the
    layout snapshot and the bay-width distribution read this so the
    bays share exactly the frame length the solver builds."""
    bl, br = blind_insets(cab)
    dl, dr = decorative_corner_insets(cab)
    return bl + dl, br + dr


class FaceFrameLayout:
    """Snapshot of a cabinet's solved state.

    Reads cabinet props, walks bay child objects (sorted by hb_bay_index),
    reads the cabinet's mid_stile_widths collection. Used by every solver
    function so positions and lengths come from one consistent input.
    """

    def __init__(self, cabinet_obj):
        # Lazy import avoids any circular at module load
        from . import types_face_frame
        self._cabinet_tag = types_face_frame.TAG_BAY_CAGE

        cab = cabinet_obj.face_frame_cabinet
        self.cabinet_type = cab.cabinet_type
        self.corner_type = cab.corner_type

        # Cabinet dimensions
        self.dim_x = cab.width
        self.dim_y = cab.depth
        self.dim_z = cab.height

        # Angled standard cabinet (single-bay only): per-side depths drive
        # the front face frame plane, leaving the back at dim_y. Captured
        # here so the side / face frame solvers branch on a single flag
        # without re-reading cab props. is_angled gates the branch and is
        # finalized below once bay_count is known.
        self.unlock_left_depth = cab.unlock_left_depth
        self.unlock_right_depth = cab.unlock_right_depth
        self.cab_left_depth = cab.left_depth
        self.cab_right_depth = cab.right_depth

        # Material thicknesses
        self.mt = cab.material_thickness
        self.bt = cab.back_thickness
        self.fft = cab.face_frame_thickness

        # Cabinet default overlays. Retained for the removed-mid-rail gap
        # math (collapse a dropped rail to a 3/32" front reveal); also the
        # fallback when an adjacent neighbor isn't a leaf opening. _cab_props
        # is kept so _read_tree_node can resolve each leaf's per-side overlay.
        self._cab_props = cab
        self.default_top_overlay = cab.default_top_overlay
        self.default_bottom_overlay = cab.default_bottom_overlay

        # Toe kick (cabinet baseline; bay kick_height adds on top)
        self.has_toe_kick = self.cabinet_type in ('BASE', 'TALL', 'LAP_DRAWER')
        # Top construction style: bases and lap drawers use front + rear
        # stretchers; uppers and talls use a solid top panel.
        self.uses_stretchers = self.cabinet_type in ('BASE', 'LAP_DRAWER')
        self.tkh = cab.toe_kick_height if self.has_toe_kick else 0.0
        self.tks = cab.toe_kick_setback if self.has_toe_kick else 0.0
        self.tkt = cab.toe_kick_thickness if self.has_toe_kick else 0.0
        self.toe_kick_type = (cab.toe_kick_type
                              if self.has_toe_kick else 'FLOATING')
        # Floating vanity: a floating base whose top closes with a panel
        # rather than stretchers, because a sink sits on it. The rest of
        # its construction (the 1/2 top over the 3/4 back, the basin
        # cutout) rides the same flag - see is_floating_vanity.
        self.floating_vanity = is_floating_vanity(cab)
        if self.floating_vanity:
            self.uses_stretchers = False
        self.extend_left_stile_to_floor = cab.extend_left_stile_to_floor
        self.extend_right_stile_to_floor = cab.extend_right_stile_to_floor
        # Combined island end: where the run behind lays a board across
        # this end, this cabinet builds no side of its own and its
        # cavity stops at that board. None on every other end, including
        # a covered end under an applied panel - a panel goes OVER a
        # side, so this run keeps its own. See island_pair.
        self.l_covered_thickness = island_pair.covered_end_side_thickness(
            cabinet_obj, 'LEFT')
        self.r_covered_thickness = island_pair.covered_end_side_thickness(
            cabinet_obj, 'RIGHT')
        # Refrigerator cabinet: per-side raise of the carcass side + end
        # stile up to the top of the fridge opening, plus the per-cabinet
        # opening height that datum is built from.
        self.raise_left_to_refrigerator_height = getattr(
            cab, 'raise_left_to_refrigerator_height', False)
        self.raise_right_to_refrigerator_height = getattr(
            cab, 'raise_right_to_refrigerator_height', False)
        self.refrigerator_opening_height = getattr(
            cab, 'refrigerator_opening_height', 0.0)
        # 'Stile in lieu of leg' toggles: mirrored onto the layout so
        # has_refrig_stile / raise_side_to_refrigerator can read them.
        self.refrigerator_stile_left = getattr(
            cab, 'refrigerator_stile_left', False)
        self.refrigerator_stile_right = getattr(
            cab, 'refrigerator_stile_right', False)
        # Hutch option (uppers): left/right sides + end stiles drop below
        # the box bottom by this amount (see ends_down_drop / side_bottom_z).
        self.extend_left_end_down = getattr(cab, 'extend_left_end_down', False)
        self.extend_left_end_down_amount = getattr(cab, 'extend_left_end_down_amount', 0.0)
        self.extend_right_end_down = getattr(cab, 'extend_right_end_down', False)
        self.extend_right_end_down_amount = getattr(cab, 'extend_right_end_down_amount', 0.0)
        # Over-stool: drop BOTH sides (not the stiles) - see side_extend_down.
        self.extend_sides_down = getattr(cab, 'extend_sides_down', False)
        self.extend_sides_down_amount = getattr(cab, 'extend_sides_down_amount', 0.0)
        self.side_front_profile = getattr(cab, 'side_front_profile', False)
        self.overstool_accessory = getattr(cab, 'overstool_accessory', 'SHELF')
        self.kick_inset_left = (cab.inset_toe_kick_left
                                if self.has_toe_kick else 0.0)
        self.kick_inset_right = (cab.inset_toe_kick_right
                                 if self.has_toe_kick else 0.0)
        self.back_bottom_inset = cab.back_bottom_inset
        # Tip-up wedge inputs (refrigerator / tall). Computed dims are
        # derived live in wedge_geometry(); only the inputs persist.
        self.wedge_enabled = getattr(cab, 'wedge_enabled', False)
        self.wedge_ceiling_height = getattr(cab, 'wedge_ceiling_height', 0.0)
        self.wedge_fudge = getattr(cab, 'wedge_fudge', 0.0)
        self.wedge_max_height = getattr(cab, 'wedge_max_height', 0.0)
        self.top_thickness_override = getattr(
            cab, 'top_thickness_override', 0.0)
        self.top_over_back = getattr(cab, 'top_over_back', False)
        self.wedge_override = getattr(cab, 'wedge_override', False)
        self.wedge_length = getattr(cab, 'wedge_length', 0.0)
        self.wedge_height = getattr(cab, 'wedge_height', 0.0)
        self.finish_kick_thickness = cab.finish_toe_kick_thickness
        self.include_finish_kick = cab.include_finish_toe_kick

        # End stile widths
        self.lsw = cab.left_stile_width
        self.rsw = cab.right_stile_width

        # Blind corner offsets - amount the FF plane is shrunk on each
        # side when the corresponding end is configured as blind. Zero
        # otherwise. Used by face_frame_length and ff_outer_world_pos
        # so end stiles, rails, and bays all naturally fit inside the
        # remaining FF area; the blind panels themselves still anchor
        # to the cabinet's outer edges (x=0 / x=dim_x).
        self.blind_offset_left, self.blind_offset_right = blind_insets(cab)
        # Total FF-plane inset per side: the blind offset plus a
        # decorative corner post the frame butts into (see
        # decorative_corner_insets). Every FF-local <-> world X
        # conversion goes through these; blind_offset_* stay for the
        # blind-specific parts (blind panels, corner FO stiles).
        self.ff_inset_left, self.ff_inset_right = face_frame_insets(cab)

        # FULL-overlay blind corner sides: the corner stile carries an
        # applied overlay stile in front (mitered with the partner
        # cabinet's - see _reconcile_full_overlay_stiles) and the door
        # pulls back to a 1/4" overlay on that side so a 1/4" reveal
        # fits between it and the applied stile. Captured here so the
        # front builders and the FO-stile reconcile agree.
        self.left_stile_type = cab.left_stile_type
        self.right_stile_type = cab.right_stile_type
        is_full_overlay = (
            types_face_frame._resolve_style_overlay(cabinet_obj) == 'FULL')
        # Kept on the layout: the mid-stile step notches (and the flush
        # finished division that goes with them) are FULL-overlay
        # construction only -- standard overlays keep the plain stile +
        # partition-skin build.
        self.full_overlay = is_full_overlay
        self.corner_overlay_left = (
            is_full_overlay and cab.left_stile_type == 'BLIND')
        self.corner_overlay_right = (
            is_full_overlay and cab.right_stile_type == 'BLIND')

        # Side scribe + finish end condition. The pair determines how
        # far the side panel sits inboard of the face frame outer face
        # via left_scribe_offset / right_scribe_offset.
        self.l_scribe = cab.left_scribe
        self.r_scribe = cab.right_scribe
        self.l_fin_end = cab.left_finished_end_condition
        self.r_fin_end = cab.right_finished_end_condition
        self.b_fin_end = cab.back_finished_end_condition
        self.top_scribe = cab.top_scribe
        self.division_thickness = cab.division_thickness

        # Rail width defaults (used when populating a fresh bay)
        self.default_top_rail_width = cab.top_rail_width
        self.default_bottom_rail_width = cab.bottom_rail_width
        # Stretcher dimensions for stretcher-based top construction
        self.stretcher_w = getattr(cab, 'stretcher_width', None) or 0.0889
        self.stretcher_t = getattr(cab, 'stretcher_thickness', None) or 0.01905

        # Bay-level mid rail / mid stile widths (face frame members
        # created by H/V splits inside a bay). Cabinet-level defaults
        # used as starting values; per-member overrides come later.
        self.bay_mid_rail_width = cab.bay_mid_rail_width
        self.bay_mid_stile_width = cab.bay_mid_stile_width

        # Walk bay children
        bay_children = sorted(
            [c for c in cabinet_obj.children if c.get(self._cabinet_tag)],
            key=lambda c: c.get('hb_bay_index', 0),
        )
        if bay_children:
            self.bay_count = len(bay_children)
            self.bays = [self._read_bay(c) for c in bay_children]
        else:
            # Fallback - cabinet hasn't built its bay objects yet (during
            # the initial create_carcass call before bays are added).
            self.bay_count = 1
            self.bays = [self._make_default_bay()]

        # Angled mode is exclusive with corner cabinets. Single-bay:
        # one FF plane spanning both depths (the original behavior).
        # Multi-bay (angled_multi): ONLY the first bay angles for the
        # left depth and ONLY the last bay for the right depth; middle
        # bays stay square. Bend points land on the mid stiles at full
        # cabinet depth (see bay_front_angle + the piecewise ff_*
        # mapping helpers).
        self.is_angled = (
            self.corner_type == 'NONE'
            and (self.unlock_left_depth or self.unlock_right_depth)
        )
        self.angled_multi = self.is_angled and self.bay_count > 1

        # Angled cabinets always use a solid top regardless of cabinet
        # type. The boolean cutter that produces the trapezoidal top /
        # bottom / shelves operates on full panels; stretchers would
        # need separate per-strip trimming and would defeat the point
        # of a single uniform cutter.
        if self.is_angled:
            self.uses_stretchers = False

        # Mid stile widths from the cabinet's collection (one per gap)
        ms_coll = cab.mid_stile_widths
        n_gaps = max(0, self.bay_count - 1)
        # A gap with no entry of its own falls back to the cabinet's
        # own mid-stile default, which the style apply keeps in sync.
        # A hardcoded 2in here put un-overridden 2in mid stiles on
        # cabinets whose style runs a different width -- the style
        # cascade only ever touches entries that exist, so a gap the
        # collection never grew an entry for stayed at the constant no
        # matter what style was assigned.
        default_ms = cab.bay_mid_stile_width
        self.mid_stiles = []
        for i in range(n_gaps):
            if i < len(ms_coll):
                ms = ms_coll[i]
                self.mid_stiles.append({
                    'width': ms.width,
                    'extend_up_amount': ms.extend_up_amount,
                    'extend_down_amount': ms.extend_down_amount,
                    'to_floor': bool(getattr(ms, 'to_floor', False)),
                    'division_location': getattr(ms, 'division_location', 'CENTERED'),
                    'division_offset': getattr(ms, 'division_offset', 0.0),
                })
            else:
                self.mid_stiles.append({
                    'width': default_ms,
                    'extend_up_amount': 0.0,
                    'extend_down_amount': 0.0,
                    'to_floor': False,
                    'division_location': 'CENTERED',
                    'division_offset': 0.0,
                })

    def _read_bay(self, bay_obj):
        bp = bay_obj.face_frame_bay
        tree = self._read_tree_root(bay_obj)
        return {
            'width':              bp.width,
            'height':             bp.height,
            'depth':              bp.depth,
            'kick_height':        bp.kick_height,
            'top_offset':         bp.top_offset,
            'front_drop':         bp.front_drop,
            'front_drop_include_fillers':    bp.front_drop_include_fillers,
            'front_drop_set_appliance_width': bp.front_drop_set_appliance_width,
            'front_drop_appliance_width':    bp.front_drop_appliance_width,
            'front_drop_left_filler':        bp.front_drop_left_filler,
            'front_drop_right_filler':       bp.front_drop_right_filler,
            'top_rail_width':     bp.top_rail_width,
            'bottom_rail_width':  bp.bottom_rail_width,
            'remove_bottom':      bp.remove_bottom,
            'remove_carcass':     bp.remove_carcass,
            'floating_bay':       bp.floating_bay,
            'finish_bay':         bp.finish_bay,
            'finish_bay_flush':   bp.finish_bay_flush,
            'finish_bay_flush_depth': bp.finish_bay_flush_depth,
            # The carcass panels behind this bay (back / bottom) are cut
            # from finish stock rather than being lined with an applied
            # 1/4 panel - see _bay_finish_carcass.
            'finish_carcass':     _bay_finish_carcass(bp, tree),
            'back_condition':     getattr(bp, 'back_condition', 'DEFAULT'),
            'tree':               tree,
        }

    def _read_tree_root(self, bay_obj):
        """Find the bay's root tree node (single direct opening or split
        child) and recursively snapshot it. Returns None if the bay has
        no tree yet (during initial creation, before _build_carcass_parts
        adds the first opening)."""
        from . import types_face_frame
        candidates = [
            c for c in bay_obj.children
            if c.get(types_face_frame.TAG_OPENING_CAGE)
            or c.get(types_face_frame.TAG_SPLIT_NODE)
        ]
        if not candidates:
            return None
        # Prefer a child explicitly tagged as the bay's root if there's
        # ever ambiguity. With the current model there's exactly one
        # tree-node child of a bay; we just take the first.
        return self._read_tree_node(candidates[0])

    def _read_tree_node(self, obj):
        """Recursively snapshot a tree node. Leaves carry opening props;
        internal nodes carry axis + a list of child snapshots (sorted
        by hb_split_child_index for stable ordering)."""
        from . import types_face_frame
        if obj.get(types_face_frame.TAG_SPLIT_NODE):
            sp = obj.face_frame_split
            children = sorted(
                [c for c in obj.children
                 if c.get(types_face_frame.TAG_OPENING_CAGE)
                 or c.get(types_face_frame.TAG_SPLIT_NODE)],
                key=lambda c: c.get('hb_split_child_index', 0),
            )
            # Per-splitter width snapshot. A split with N children has
            # N-1 splitter members; member i uses its active per-index
            # override if present, else the scalar splitter_width. The
            # solver consumes this list so one mid rail can hold its own
            # width without dragging its siblings (see Face_Frame_Splitter_Width).
            n_split = max(0, len(children) - 1)
            ov = sp.splitter_widths
            splitter_widths = [
                (ov[i].width if i < len(ov) and ov[i].active else sp.splitter_width)
                for i in range(n_split)
            ]
            # Per-splitter member removal (mid rails only). A removed member
            # is dropped (no FF part, no backing) and its gap collapsed in
            # _walk_tree. Default False = normal member.
            splitter_removes = [
                (ov[i].remove_member if i < len(ov) else False)
                for i in range(n_split)
            ]
            # Per-splitter backing removal. Unlike remove_member this
            # keeps the face-frame member and drops only the carcass
            # backing behind it (the shelf behind a mid rail / the
            # division behind a mid stile), which is how a drawer bank
            # is built - rails, no floors between the boxes.
            splitter_backing_removes = [
                (ov[i].remove_backing if i < len(ov) else False)
                for i in range(n_split)
            ]
            return {
                'kind':            'split',
                'obj_name':        obj.name,
                'axis':            sp.axis,
                'size':            sp.size,
                'unlock_size':     sp.unlock_size,
                'size_role':       obj.get('SIZE_ROLE'),
                'splitter_width':  sp.splitter_width,
                'splitter_widths': splitter_widths,
                'splitter_removes': splitter_removes,
                'splitter_backing_removes': splitter_backing_removes,
                'add_backing':     sp.add_backing,
                'children':        [self._read_tree_node(c) for c in children],
            }
        # Leaf opening
        op = obj.face_frame_opening
        return {
            'kind':         'leaf',
            'obj_name':     obj.name,
            'size':         op.size,
            'unlock_size':  op.unlock_size,
            'size_role':    obj.get('SIZE_ROLE'),
            'opening_index': op.opening_index,
            # Per-opening finish, read here so the carcass segment builders
            # can tell whether the panels behind a bay are finished stock
            # (see _bay_finish_carcass).
            'finish_opening':          op.finish_opening,
            'finish_opening_material': op.finish_opening_material,
            # Whether the bottom-most leaf has a front decides if a
            # remove_bottom bay's capping splitter is a real bottom rail
            # (frontless: appliance / open shelving) or a true mid rail
            # (a door/drawer/pullout below). See _walk_tree.
            'front_type':   op.front_type,
            # Resolved per-side overlays, used by the removed-mid-rail gap
            # math so the collapse accounts for a per-opening overlay override.
            'overlay_top':    resolved_overlay(self._cab_props, op, 'top'),
            'overlay_bottom': resolved_overlay(self._cab_props, op, 'bottom'),
        }

    def _make_default_bay(self):
        return {
            'width':              self.dim_x - self.lsw - self.rsw,
            'height':             self.dim_z,
            'depth':              self.dim_y,
            'kick_height':        self.tkh,
            'top_offset':         0.0,
            'front_drop':         0.0,
            'front_drop_include_fillers':    False,
            'front_drop_set_appliance_width': True,
            'front_drop_appliance_width':    0.0,
            'front_drop_left_filler':        0.0,
            'front_drop_right_filler':       0.0,
            'top_rail_width':     self.default_top_rail_width,
            'bottom_rail_width':  self.default_bottom_rail_width,
            'remove_bottom':      False,
            'remove_carcass':     False,
            'floating_bay':       False,
            'finish_bay':         False,
            'finish_bay_flush':   False,
            'finish_bay_flush_depth': 0.0,
            'finish_carcass':     False,
            'back_condition':     'DEFAULT',
            'tree':               None,
        }


def _tree_all_openings_finished(node):
    """True when every opening leaf under `node` is a finished opening
    showing the exterior finish (and there is at least one leaf).

    A bay whose openings are ALL finished reads the same as finish_bay
    for the carcass panels behind them - the whole back / bottom is
    finish stock. A bay with a mix keeps interior carcass panels; only
    the finished opening's applied side liners show the finish (the
    back / bottom are not split horizontally within a bay).
    """
    if node is None:
        return False
    if node.get('kind') == 'leaf':
        return (bool(node.get('finish_opening'))
                and node.get('finish_opening_material') == 'FINISH')
    children = node.get('children') or []
    return bool(children) and all(
        _tree_all_openings_finished(c) for c in children)


def _bay_finish_carcass(bay_props, tree):
    """True when the bay's carcass back / bottom panels are cut from
    finish stock instead of interior stock.

    That happens when the whole bay is finished (finish_bay) or when
    every opening in it is (see _tree_all_openings_finished), and the
    region asks for the FINISH material rather than the style's
    INTERIOR one (with INTERIOR the panels are already what's wanted,
    so there's nothing to split for).
    """
    if bay_props.finish_bay:
        return bay_props.finish_bay_material == 'FINISH'
    return _tree_all_openings_finished(tree)


# ---------------------------------------------------------------------------
# Carcass dimensions
# ---------------------------------------------------------------------------
def carcass_inner_depth(layout):
    """Available depth from cabinet front to back, behind the face frame."""
    return layout.dim_y - layout.fft


# ---------------------------------------------------------------------------
# Side X offset (scribe / finish end condition)
# ---------------------------------------------------------------------------
# Face frame outer face stays at X=0 (left) and X=dim_x (right). Side
# panels can sit inboard of the face frame outer face by left/right
# scribe offsets. The offset comes from finish end condition first, then
# the user's typed scribe:
#   - FINISHED: side IS the outer face -> offset = 0
#   - PANELED / FALSE_FF / WORKING_FF: reserve 3/4" outboard for the
#     applied face-frame panel (all three spawn one)
#   - everything else: use the typed scribe value (default 0)
def left_scribe_offset(layout):
    if layout.l_fin_end == 'FINISHED':
        return 0.0
    if layout.l_fin_end in ('PANELED', 'FALSE_FF', 'WORKING_FF'):
        return inch(0.75)
    # 1/4 applied panels (FLUSH_X strip + textured beadboard / shiplap)
    # all sit in a 1/4 scribe gap so they tuck flush against the side.
    if layout.l_fin_end in ('FLUSH_X', 'BEADBOARD', 'SHIPLAP', 'V_GROOVE'):
        return inch(0.25)
    return layout.l_scribe


def left_side_thickness(layout):
    """Left side panel thickness. FINISHED sides are 3/4 stock (the
    side IS the visible outer face); FALSE_FF / WORKING_FF have NO
    carcass side at all - the applied face frame replaces it, so the
    cavity runs to the panel's back face (thickness 0 keeps
    carcass_inner_* honest and the recalc hides the side part). Other
    conditions use the cabinet's material_thickness (typically 1/2).
    Tops, bottoms, and dividers stay at material_thickness in all
    cases.

    A combined island end is the same story told from the other side:
    the run behind carries a board across this end, so this cabinet
    builds none and its cavity stops at that board's inner face.
    Reporting the covering's thickness is what keeps every part that
    lands on this side - stretchers, bottoms, kick beams - off it.
    """
    if layout.l_covered_thickness is not None:
        return layout.l_covered_thickness
    if layout.l_fin_end == 'FINISHED':
        return inch(0.75)
    if layout.l_fin_end in ('FALSE_FF', 'WORKING_FF'):
        return 0.0
    return layout.mt


def right_scribe_offset(layout):
    if layout.r_fin_end == 'FINISHED':
        return 0.0
    if layout.r_fin_end in ('PANELED', 'FALSE_FF', 'WORKING_FF'):
        return inch(0.75)
    if layout.r_fin_end in ('FLUSH_X', 'BEADBOARD', 'SHIPLAP', 'V_GROOVE'):
        return inch(0.25)
    return layout.r_scribe


def right_side_thickness(layout):
    """See left_side_thickness."""
    if layout.r_covered_thickness is not None:
        return layout.r_covered_thickness
    if layout.r_fin_end == 'FINISHED':
        return inch(0.75)
    if layout.r_fin_end in ('FALSE_FF', 'WORKING_FF'):
        return 0.0
    return layout.mt


def back_thickness(layout):
    """Carcass back panel thickness. The cabinet's back_thickness prop
    (typically 1/4) regardless of finish condition - the FINISHED back
    is rendered as a SEPARATE 3/4 applied panel layered on top of the
    carcass back, not by thickening the carcass back itself. See
    _reconcile_finished_back for the applied piece.

    A floating vanity is the exception: its back is 3/4 by construction,
    so a cabinet still carrying the 1/4 default gets the vanity's.
    """
    if (getattr(layout, 'floating_vanity', False)
            and layout.bt <= FLOATING_VANITY_BACK_THICKNESS - 1e-6):
        return FLOATING_VANITY_BACK_THICKNESS
    return layout.bt


def is_floating_vanity(cab):
    """True for a base cabinet built as a floating vanity: the option
    is on AND its toe kick is the floating one, since the kick height
    is what lifts it off the floor."""
    return (getattr(cab, 'floating_vanity', False)
            and getattr(cab, 'toe_kick_type', '') == 'FLOATING')


# What the floating vanity construction is, where it differs from a
# plain floating base. Sizes stay editable per cabinet; these are what
# ticking the box gives you.
FLOATING_VANITY_TOP_THICKNESS = inch(0.5)
FLOATING_VANITY_BACK_THICKNESS = inch(0.75)


def bottom_thickness(layout):
    """Carcass bottom panel thickness: the cabinet's material, except on
    a floating vanity, whose bottom is 3/4 by construction - it carries
    the cabinet where a floor-standing one is carried by its base."""
    if (getattr(layout, 'floating_vanity', False)
            and layout.mt <= FLOATING_VANITY_BACK_THICKNESS - 1e-6):
        return FLOATING_VANITY_BACK_THICKNESS
    return layout.mt


def top_thickness(layout):
    """Carcass top panel thickness: the cabinet's own override where it
    has one, the vanity's 1/2 top on a floating vanity, else the
    material thickness."""
    override = getattr(layout, 'top_thickness_override', 0.0)
    if override > 0.0:
        return override
    if getattr(layout, 'floating_vanity', False):
        return FLOATING_VANITY_TOP_THICKNESS
    return layout.mt


def back_notch_depth(layout, side):
    """Depth of the rabbet run down a FINISHED side's back edge for the
    carcass back to land in.

    A finished end is the visible outer face, so the back is not butted
    against it - the back sits in a notch cut halfway through the side,
    and the back panel widens to reach into the notch on each end. Only
    FINISHED sides get it: thinner unfinished sides butt the back as
    before, FALSE_FF / WORKING_FF have no carcass side at all, and a
    WORKING_FF back means there is no carcass back to land.
    """
    if layout.b_fin_end == 'WORKING_FF':
        return 0.0
    if side == 'LEFT':
        if layout.l_fin_end != 'FINISHED':
            return 0.0
        thickness = left_side_thickness(layout)
    else:
        if layout.r_fin_end != 'FINISHED':
            return 0.0
        thickness = right_side_thickness(layout)
    if thickness <= 0.0:
        return 0.0
    return thickness / 2.0


def carcass_inner_left_x(layout):
    """X of the left side panel's inner face - the left bound of the
    cabinet's interior cavity. Outer face sits at left_scribe_offset;
    thickness depends on the finish condition (3/4 for FINISHED,
    material_thickness otherwise)."""
    return left_scribe_offset(layout) + left_side_thickness(layout)


def carcass_inner_right_x(layout):
    """X of the right side panel's inner face."""
    return layout.dim_x - right_scribe_offset(layout) - right_side_thickness(layout)


# ---------------------------------------------------------------------------
# Top Z: carcass top vs side top
# ---------------------------------------------------------------------------
# bay_top_z is the bay opening top (= bottom of top rail = top of side
# in the no-scribe case). With top_scribe, the carcass top (top panel
# for Upper/Tall, stretchers for Base/LapDrawer) drops by top_scribe.
# Sides that aren't the visible finished face drop with it; THREE_QUARTER
# finished sides stay at bay_top_z to keep their visible face full-height.
# Face frame members (stiles, top rail) are unaffected.
def carcass_top_z(layout, bay_index):
    """Z of the carcass top's top face. Held down by top_scribe."""
    return bay_top_z(layout, bay_index) - layout.top_scribe


def left_side_top_z(layout):
    if layout.l_fin_end == 'FINISHED':
        return bay_top_z(layout, 0)
    return carcass_top_z(layout, 0)


def right_side_top_z(layout):
    last = layout.bay_count - 1
    if layout.r_fin_end == 'FINISHED':
        return bay_top_z(layout, last)
    return carcass_top_z(layout, last)


# ---------------------------------------------------------------------------
# Bay X position (cumulative across stiles + previous bays)
# ---------------------------------------------------------------------------
def bay_x_position(layout, bay_index):
    """X coordinate of the left edge of bay N's opening."""
    x = layout.lsw
    for i in range(bay_index):
        x += layout.bays[i]['width']
        if i < len(layout.mid_stiles):
            x += layout.mid_stiles[i]['width']
    return x


# ---------------------------------------------------------------------------
# Per-bay vertical anchors - the key abstraction for base vs upper cabinets
# ---------------------------------------------------------------------------
# Bases / talls anchor at the floor. bay.height is floor to top of top rail;
# bay.kick_height is floor to bottom of bottom rail (the toe kick recess
# height). bay_bottom_z / bay_top_z map directly to these.
# Uppers anchor at the cabinet top: bay_top_z is fixed by dim_z - top_offset,
# and bay_height extends downward from there. Uppers carry kick_height = 0.
#
# All Z positions for bottom rails, bay cages, mid stile bottoms, and the
# bottom-rail passthrough check go through these helpers.
def bay_bottom_z(layout, bay_index):
    """Z of the bay's bottom edge (bottom of the bottom rail / top of
    toe kick recess for base / tall)."""
    bay = layout.bays[bay_index]
    if layout.cabinet_type == 'UPPER':
        return layout.dim_z - bay['top_offset'] - bay['height']
    return bay['kick_height']


def bay_top_z(layout, bay_index):
    """Z of the bay's top edge (top of the top rail)."""
    bay = layout.bays[bay_index]
    if layout.cabinet_type == 'UPPER':
        return layout.dim_z - bay['top_offset']
    return bay['height']


def front_drop(layout, bay_index):
    """Amount this bay's FRONT construction (top rail + front stretcher)
    is lowered below the bay top - the sink / cooktop bay drop. Only the
    front drops: the back panel, rear stretcher, carcass sides, and the
    end / mid stiles all stay at the bay's full height (the countertop
    hides the open band above the dropped rail)."""
    return max(0.0, layout.bays[bay_index].get('front_drop', 0.0))


def front_drop_filler_widths(layout, bay_index):
    """(left, right) widths of the filler stiles inside a bay's dropped
    band - the open region above the dropped top rail, between the bay's
    bounding stiles - so the clear width fits a farm sink or cooktop.

    Mirrors appliance_filler_widths' two input modes:
      * front_drop_set_appliance_width ON  -> the user gives the appliance
        width; the remainder ``bay width - appliance width`` splits evenly.
      * OFF -> the user gives each filler width directly; the appliance
        occupies whatever clear width remains.
    (0, 0) when the bay has no front_drop or front_drop_include_fillers is
    off. Widths are clamped >= 0 and scaled down together if they would
    exceed the band.
    """
    bay = layout.bays[bay_index]
    fd = front_drop(layout, bay_index)
    if fd <= 0.0 or not bay.get('front_drop_include_fillers'):
        return (0.0, 0.0)
    clear = bay['width']
    if clear <= 0.0:
        return (0.0, 0.0)
    if bay.get('front_drop_set_appliance_width', True):
        appl = max(0.0, min(bay.get('front_drop_appliance_width', 0.0), clear))
        each = max(0.0, (clear - appl) / 2.0)
        return (each, each)
    left = max(0.0, bay.get('front_drop_left_filler', 0.0))
    right = max(0.0, bay.get('front_drop_right_filler', 0.0))
    total = left + right
    if total > clear and total > 0.0:
        scale = clear / total
        left *= scale
        right *= scale
    return (left, right)


def front_drop_filler_segments(layout):
    """One record per filler stile in a dropped band, across all bays.

    Each filler spans the drop vertically (from the dropped rail's top to
    the bay top) and sits at the band's left or right edge against the
    bounding stile. Oriented like an end stile: the LEFT filler anchors at
    the band's left edge and extends +X (Mirror Y True); the RIGHT filler
    anchors at the band's right edge and extends -X (Mirror Y False).

    Keys: bay, side ('LEFT'/'RIGHT'), pos (world origin at the band
    bottom, on the FF outer plane), length (vertical = the drop), width,
    thickness (fft).
    """
    segments = []
    for i in range(layout.bay_count):
        fd = front_drop(layout, i)
        if fd <= 0.0:
            continue
        left_w, right_w = front_drop_filler_widths(layout, i)
        band_left = bay_x_position(layout, i)
        z0 = bay_top_z(layout, i) - fd
        if left_w > 0.0:
            segments.append({
                'bay':       i,
                'side':      'LEFT',
                'pos':       ff_outer_world_pos(layout, band_left, z0),
                'length':    fd,
                'width':     left_w,
                'thickness': layout.fft,
            })
        if right_w > 0.0:
            band_right = band_left + layout.bays[i]['width']
            segments.append({
                'bay':       i,
                'side':      'RIGHT',
                'pos':       ff_outer_world_pos(layout, band_right, z0),
                'length':    fd,
                'width':     right_w,
                'thickness': layout.fft,
            })
    return segments


def effective_bottom_rail_width(layout, bay_index):
    """Bottom-rail width the FACE FRAME OPENING should reserve at the
    bottom of the bay.

    Normally this is the bay's bottom_rail_width: the opening starts one
    rail-width up from the bay bottom. When the bay's bottom rail is
    removed (remove_bottom), there is no rail to leave room for, so the
    opening / bay cage grows DOWN into that band to take up the freed
    space - this returns 0 in that case. Drives the cage position, cage
    height, and root reveals so the opening, its cage, and any
    bay-internal splitters all extend to the bay bottom together."""
    bay = layout.bays[bay_index]
    if bay.get('remove_bottom'):
        return 0.0
    return bay['bottom_rail_width']


def ends_down_drop(layout, side='LEFT'):
    """Distance the given end's carcass side + end stile extends BELOW the
    box bottom for an upper with the hutch 'extend ends down' option on.
    Left and right are independent. Zero for non-uppers or when that side's
    option is off. Drops the end to the countertop while the box / doors
    stay at standard upper height.
    """
    if layout.cabinet_type != 'UPPER':
        return 0.0
    if side == 'RIGHT':
        on = getattr(layout, 'extend_right_end_down', False)
        amount = getattr(layout, 'extend_right_end_down_amount', 0.0)
    else:
        on = getattr(layout, 'extend_left_end_down', False)
        amount = getattr(layout, 'extend_left_end_down_amount', 0.0)
    return max(0.0, amount) if on else 0.0


def side_extend_down(layout, side='LEFT'):
    """Distance BOTH carcass side panels extend BELOW the box bottom for the
    over-stool / furniture-leg option. Unlike ends_down_drop this moves ONLY
    the side panels - the end stiles and face frame stay at the box bottom.
    Both sides share one amount. Zero for non-uppers or when the option is off.
    """
    if layout.cabinet_type != 'UPPER':
        return 0.0
    on = getattr(layout, 'extend_sides_down', False)
    amount = getattr(layout, 'extend_sides_down_amount', 0.0)
    return max(0.0, amount) if on else 0.0


def raise_side_to_refrigerator(layout, side='LEFT'):
    """True when this end's carcass side + end stile should lift off the
    floor to the top of the refrigerator opening (refrigerator cabinets).
    Left and right are independent; supersedes that side's stile-to-floor.
    Turning on that side's 'stile in lieu of leg' also raises the end stile:
    the separate lower stile fills the floor-to-opening zone below it."""
    if side == 'RIGHT':
        base = getattr(layout, 'raise_right_to_refrigerator_height', False)
    else:
        base = getattr(layout, 'raise_left_to_refrigerator_height', False)
    return base or has_refrig_stile(layout, side)


def has_refrig_stile(layout, side='LEFT'):
    """True when this end builds a separate face-frame stile from the floor to
    the top of the refrigerator opening, in lieu of a leg (refrigerator
    cabinets). Independent per side; also raises that side's end stile via
    raise_side_to_refrigerator so the two stack into the door-zone stile above
    and the floor-to-opening stile below."""
    if side == 'RIGHT':
        return getattr(layout, 'refrigerator_stile_right', False)
    return getattr(layout, 'refrigerator_stile_left', False)


def refrigerator_raise_z(layout, bay_index):
    """Z (from floor) of the top of the refrigerator opening - where a raised
    side / end stile bottoms out so it lines up with the bottom of the mid
    rail above the opening (spanning only the door zone).

    effective_bottom_rail_width is 0 when the bay's bottom rail is removed
    (the refrigerator cabinet's default), so the opening runs from the top
    of the kick; with a bottom rail present the opening starts one rail up.
    Either way this lands the raised end at the underside of the mid rail."""
    return (bay_bottom_z(layout, bay_index)
            + effective_bottom_rail_width(layout, bay_index)
            + getattr(layout, 'refrigerator_opening_height', 0.0))


def _upper_side_captured(layout, side, bay_index):
    """True when this UNFINISHED upper side should be captured by (sit on
    top of) the carcass bottom panel instead of running the full box
    height. The bottom panel is extended outward under the side to match
    (see carcass_bottom_segments). False for non-uppers, FINISHED / other
    finish conditions, sides extended downward (hutch / over-stool), or
    bays with no bottom panel (remove_bottom / remove_carcass)."""
    if layout.cabinet_type != 'UPPER':
        return False
    side_fin = layout.l_fin_end if side == 'LEFT' else layout.r_fin_end
    if side_fin != 'UNFINISHED':
        return False
    if ends_down_drop(layout, side) + side_extend_down(layout, side) > 0.0:
        return False
    bay = layout.bays[bay_index]
    return not (bay.get('remove_bottom') or bay.get('remove_carcass'))


def side_bottom_z(layout, bay_index, side='LEFT'):
    """Z of the carcass side panel's bottom edge.

    NOTCH and FLUSH run sides to the floor (a corner notch handles the
    recess for NOTCH; the wide bottom rail handles it for FLUSH).
    FLOATING and uppers anchor the side at the bay bottom.

    Per-bay override: floating_bay forces this bay's side to anchor at
    the bay bottom regardless of cabinet toe_kick_type.

    Inset exception: kick_inset_left / kick_inset_right > 0 means a
    return part is wrapping the kick at that end and the side floats
    by kick_height on that side, so the inset region is open from
    the floor up to the cabinet bottom panel.
    """
    # Refrigerator per-side raise wins over every other anchor: the
    # side lifts to the top of the fridge opening (door zone only).
    if raise_side_to_refrigerator(layout, side):
        return refrigerator_raise_z(layout, bay_index)
    if not layout.has_toe_kick:
        # Uppers: anchor at the box bottom, dropped by the hutch amount
        # (side + stile) and the over-stool amount (sides only).
        # An UNFINISHED upper side is captured by the carcass bottom
        # panel: the panel runs out under the side and the side sits on
        # top of it, so the side's bottom edge rises to the top face of
        # this bay's bottom panel (bay bottom + bottom rail width). A
        # FINISHED side stays full-height - the side IS the visible face
        # and wraps the bottom. carcass_bottom_segments widens the panel
        # outward to match.
        if _upper_side_captured(layout, side, bay_index):
            bay = layout.bays[bay_index]
            return bay_bottom_z(layout, bay_index) + bay['bottom_rail_width']
        return (bay_bottom_z(layout, bay_index)
                - ends_down_drop(layout, side)
                - side_extend_down(layout, side))
    # LOOSE / LOOSE_FLUSH float the carcass exactly like FLOATING - the
    # difference is they also build a ladder sub-base under the cabinet
    # (LOOSE_FLUSH's ladder sits flush to the front, LOOSE's is recessed).
    # Floating carcass (cabinet-level FLOATING / LOOSE / LOOSE_FLUSH, or a
    # per-bay floating_bay on this end bay) normally anchors the side at the
    # bay bottom. But when the end stile on this side is run to the floor
    # (a "leg"), the finished side drops with it so the leg reads solid down
    # to the floor. The side belongs to an end bay (LEFT = bay 0, RIGHT =
    # last bay), so the matching end-stile-to-floor flag governs the drop.
    floating = (layout.toe_kick_type in ('FLOATING', 'LOOSE', 'LOOSE_FLUSH')
                or layout.bays[bay_index].get('floating_bay'))
    if floating:
        side_stile_to_floor = (left_stile_to_floor(layout) if side == 'LEFT'
                               else right_stile_to_floor(layout))
        if side_stile_to_floor:
            return 0.0
        return bay_bottom_z(layout, bay_index)
    # NOTCH / FLUSH default to floor unless this side has a kick inset.
    if side == 'LEFT' and layout.kick_inset_left > 0:
        return bay_bottom_z(layout, bay_index)
    if side == 'RIGHT' and layout.kick_inset_right > 0:
        return bay_bottom_z(layout, bay_index)
    return 0.0


def left_stile_to_floor(layout):
    """End stile extends past the bay bottom down to the floor when the
    user enables it explicitly, or when FLUSH is on (a wide bottom rail
    butts into a full-height stile rather than the other way around).
    Uppers don't have a kick to fill, so the option no-ops there.
    """
    if not layout.has_toe_kick:
        return False
    if layout.toe_kick_type == 'FLUSH':
        return True
    return layout.extend_left_stile_to_floor


def right_stile_to_floor(layout):
    if not layout.has_toe_kick:
        return False
    if layout.toe_kick_type == 'FLUSH':
        return True
    return layout.extend_right_stile_to_floor


# ---------------------------------------------------------------------------
# Toe kick subfront - the visible front face of the recess
# ---------------------------------------------------------------------------
def has_kick_subfront(layout):
    """Subfront only exists for NOTCH (recessed kick). FLUSH replaces
    it with the wide bottom rail; FLOATING leaves the kick to a separate
    base assembly; uppers have no kick.
    """
    return layout.has_toe_kick and layout.toe_kick_type == 'NOTCH'


# Clear space held between the cabinet back and the back face of the
# rear kick beam, so plumbing and wiring can come up through the floor
# of the cabinet behind it.
KICK_REAR_BEAM_CLEARANCE = inch(5.0)
# Cabinets shallower than this have no room for that clearance, so the
# beam pulls back tight against the back panel instead, landing in line
# with the carcass bottom and the stretchers above it.
KICK_REAR_BEAM_SHALLOW_DEPTH = inch(15.0)


def kick_rear_beam_clearance(layout):
    """Gap between the cabinet back and the rear beam's back face."""
    if layout.dim_y < KICK_REAR_BEAM_SHALLOW_DEPTH - inch(0.01):
        return back_thickness(layout)
    return KICK_REAR_BEAM_CLEARANCE


def kick_beam_width(layout, bay_index):
    """Height of a sub-base beam (kick subfront / rear beam).

    The beams carry the carcass bottom, so they run from the floor up
    to that panel's UNDERSIDE - not just to the top of the kick recess.
    The bay floor sits a bottom rail width above the bay bottom (which
    is itself the kick height) and the panel hangs its own thickness
    below that, so the beam stands kick_height + bottom_rail_width - mt
    tall. Cutting them off at kick_height leaves the panel unsupported
    over a gap the width of the bottom rail.
    """
    bay = layout.bays[bay_index]
    width = bay['kick_height'] + bay['bottom_rail_width'] - layout.mt
    return max(width, 0.0)


def kick_subrear_segments(layout):
    """Rear kick beam segments - the second beam of the sub-base, run
    parallel to the subfront near the back of the cabinet to carry the
    back edge of the carcass bottom.

    Same stock, height and segmentation as the subfront, but positioned
    off the BACK (which stays square even when the front is angled) and
    held clear of it by kick_rear_beam_clearance. The front-only setback
    doesn't apply, but the end insets do - the beam is captured between
    the kick returns just like the subfront is. Skipped on cabinets too
    shallow for the beam to clear the subfront.
    """
    if not has_kick_subfront(layout):
        return []
    beam_back_y = -kick_rear_beam_clearance(layout)
    beam_front_y = beam_back_y - layout.tkt
    subfront_back_y = -layout.dim_y + layout.tks + layout.tkt
    if beam_front_y <= subfront_back_y:
        return []
    segments = []
    last_bay = layout.bay_count - 1
    for start, end in _compute_segments(layout, _kick_subfront_passthrough):
        first_bay = layout.bays[start]
        if first_bay.get('remove_bottom') or first_bay.get('remove_carcass'):
            continue
        if first_bay.get('floating_bay'):
            continue
        left_x, right_x = _segment_x_bounds(layout, start, end)
        # Same end treatment as the subfront: an inset end grows a
        # return that runs the full depth of the sub-base, so the beam
        # butts against the return's inboard face rather than the side.
        if start == 0 and layout.kick_inset_left > 0:
            left_x = layout.kick_inset_left + layout.tkt
        if end == last_bay and layout.kick_inset_right > 0:
            right_x = layout.dim_x - layout.kick_inset_right - layout.tkt
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          left_x,
            'y':          beam_back_y,
            'z':          0.0,
            'length':     right_x - left_x,
            'width':      kick_beam_width(layout, start),
            'thickness':  layout.tkt,
        })
    return segments


def _kick_subfront_passthrough(layout, gap_index):
    """True if a single kick subfront spans gap_index uninterrupted.
    Breaks where adjacent bays have different kick_heights, where
    either bay has remove_bottom or remove_carcass set, or where either
    bay is flagged floating_bay (no kick parts emitted at that bay).
    """
    if gap_index >= len(layout.mid_stiles):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    # A to-floor mid stile's division runs to the floor through the kick
    # zone, so the toe kick (subfront + finish) breaks here too.
    if layout.mid_stiles[gap_index].get('to_floor'):
        return False
    if not _epsilon_eq(bay_a['kick_height'], bay_b['kick_height']):
        return False
    # The sub-base beams rise to the carcass bottom, so a change in
    # bottom rail width moves their top edge and breaks the run too.
    # (The finish kick shares this passthrough and doesn't care - it
    # only ever spans one kick height - but a matching break there is
    # harmless and keeps it lined up with the subfront behind it.)
    if not _epsilon_eq(bay_a['bottom_rail_width'], bay_b['bottom_rail_width']):
        return False
    if (bay_a.get('remove_bottom') or bay_b.get('remove_bottom')
            or bay_a.get('remove_carcass') or bay_b.get('remove_carcass')):
        return False
    if bay_a.get('floating_bay') or bay_b.get('floating_bay'):
        return False
    return True


def kick_subfront_segments(layout):
    """Toe kick subfront segments. Captured between the carcass sides
    (and between mid divisions at interior breaks via _segment_x_bounds).
    Breaks where adjacent bays have different kick_heights so each
    segment can take its bay's kick_height as its Width. Insets are
    only honored at the cabinet ends - interior breaks butt against
    the meeting plane.
    """
    if not has_kick_subfront(layout):
        return []
    segments = []
    last_bay = layout.bay_count - 1
    for start, end in _compute_segments(layout, _kick_subfront_passthrough):
        first_bay = layout.bays[start]
        if first_bay.get('remove_bottom') or first_bay.get('remove_carcass'):
            continue
        if first_bay.get('floating_bay'):
            continue
        left_x, right_x = _segment_x_bounds(layout, start, end)
        if start == 0:
            if layout.kick_inset_left > 0:
                # Inset with return: main kick butts against the return's
                # inboard face at (inset + tkt).
                left_x = layout.kick_inset_left + layout.tkt
            # else: kick captured between sides at carcass_inner_left_x
        if end == last_bay:
            if layout.kick_inset_right > 0:
                right_x = (layout.dim_x - layout.kick_inset_right
                           - layout.tkt)
        if layout.angled_multi:
            # Split where the kick planes themselves intersect (bend
            # shifted by the perpendicular offset); each piece anchors
            # on its own region of the piecewise kick plane and
            # stretches by 1/cos.
            for s, e, a, b, theta in _split_ff_x_spans(
                    layout, start, end, left_x, right_x,
                    perp=layout.tks):
                wx, wy, wz = ff_perpendicular_offset_at_world_x(
                    layout, a, layout.tks, 0.0
                )
                segments.append({
                    'start_bay':  s,
                    'end_bay':    e,
                    'x':          wx,
                    'y':          wy,
                    'z':          wz,
                    'length':     (b - a) / math.cos(theta),
                    'width':      kick_beam_width(layout, start),
                    'thickness':  layout.tkt,
                })
            continue
        wx, wy, wz = ff_perpendicular_offset_at_world_x(
            layout, left_x, layout.tks, 0.0
        )
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          wx,
            # Y sits at the notch's back wall: the setback back from
            # the face frame's outer face, which is where the side
            # notch now stops too, so the kick's FRONT face is flush
            # with it. The kick is captured between the side panels
            # at world X = left_x and right_x, so we anchor at world X
            # (not FF-x). Length is along the kick's own +X axis (FF-
            # aligned after rotation), which spans 1/cos farther than
            # the world X delta in angled mode.
            'y':          wy,
            'z':          wz,
            'length':     ff_world_x_span_to_length(layout, right_x - left_x),
            'width':      kick_beam_width(layout, start),
            'thickness':  layout.tkt,
        })
    return segments


def kick_notch_depth(layout):
    """Depth of the front-bottom toe-kick notch cut into a carcass side,
    a mid division, a partition skin or a finished-end band.

    ``toe_kick_setback`` is measured from the face frame's outer face -
    the same datum the leg product, the loose kick ladder and the
    applied panels already set their kick back from - but every part
    this notch is cut into starts one face-frame thickness behind that
    plane, so the cut it takes is that much shallower. A setback inside
    the face-frame band leaves nothing to notch and returns 0.
    """
    return max(0.0, layout.tks - layout.fft)


def has_finish_kick(layout):
    """Finish toe kick is the visible 1/4 face board applied to the
    front of the kick subfront. Requires include_finish_kick on
    cab_props plus a subfront to apply to.
    """
    return has_kick_subfront(layout) and layout.include_finish_kick


def finish_kick_segments(layout):
    """Finish toe kick segments. Same passthrough as the subfront so a
    segmented subfront gets a matching segmented finish, but X spans
    the FULL cabinet width at the ends (not captured between sides) -
    interior breaks still meet at the carcass meeting plane to line up
    with the subfront break behind them. Y sits in front of the
    subfront so its back face is flush with the subfront's front.

    Stile-to-floor exception: that side's carcass panel has no notch
    and is solid through the kick Y range, so a full-width finish kick
    would intersect it. Inset the cabinet-end X by the side's thickness
    on that side; the corner finish kick part fills the X stretch
    behind the stile separately.
    """
    if not has_finish_kick(layout):
        return []
    segments = []
    last_bay = layout.bay_count - 1
    finish_t = layout.finish_kick_thickness
    for start, end in _compute_segments(layout, _kick_subfront_passthrough):
        first_bay = layout.bays[start]
        if first_bay.get('remove_bottom') or first_bay.get('remove_carcass'):
            continue
        if first_bay.get('floating_bay'):
            continue
        if start == 0:
            if layout.kick_inset_left > 0:
                # Inset with return: finish kick covers the return's
                # front face, so it starts at the return's outer X.
                left_x = layout.kick_inset_left
            elif left_stile_to_floor(layout):
                left_x = carcass_inner_left_x(layout)
            else:
                left_x = 0.0
        else:
            if _void_gap(layout, start - 1):
                # The to-floor division finishing the void blocks the
                # pass-under; the finish kick butts its near face.
                left_x = _mid_div_right_outer_x(layout, start - 1)
            else:
                left_x = _carcass_meeting_x(layout, start - 1)
        if end == last_bay:
            if layout.kick_inset_right > 0:
                right_x = layout.dim_x - layout.kick_inset_right
            elif right_stile_to_floor(layout):
                right_x = carcass_inner_right_x(layout)
            else:
                right_x = layout.dim_x
        else:
            if _void_gap(layout, end):
                right_x = _mid_div_left_outer_x(layout, end)
            else:
                right_x = _carcass_meeting_x(layout, end)
        # Finish kick lives just IN FRONT of the subfront (its back face
        # flush with the subfront's front face), so its perpendicular
        # offset from the FF outer plane is (tks + tkt - finish_t).
        # Like the subfront, it spans world-X between the side panels,
        # so we use the world-X helper and convert to FF-aligned length.
        if layout.angled_multi:
            # Same plane-intersection splitting as the subfront behind
            # it, at the finish kick's own perpendicular offset.
            for s, e, a, b, theta in _split_ff_x_spans(
                    layout, start, end, left_x, right_x,
                    perp=layout.tks - finish_t):
                wx, wy, wz = ff_perpendicular_offset_at_world_x(
                    layout, a,
                    layout.tks - finish_t,
                    0.0,
                )
                segments.append({
                    'start_bay':  s,
                    'end_bay':    e,
                    'x':          wx,
                    'y':          wy,
                    'z':          wz,
                    'length':     (b - a) / math.cos(theta),
                    'width':      first_bay['kick_height'],
                    'thickness':  finish_t,
                })
            continue
        wx, wy, wz = ff_perpendicular_offset_at_world_x(
            layout, left_x,
            layout.tks - finish_t,
            0.0,
        )
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          wx,
            'y':          wy,
            'z':          wz,
            'length':     ff_world_x_span_to_length(layout, right_x - left_x),
            'width':      first_bay['kick_height'],
            'thickness':  finish_t,
        })
    return segments


def _end_bay_drops_kick(layout, bay_index):
    """End-bay convenience: True if that bay omits its kick parts via
    remove_bottom, remove_carcass, or floating_bay. Used to suppress
    corner finish kicks and kick returns at a cabinet end whose bay
    has no kick.
    """
    bay = layout.bays[bay_index]
    return bool(bay.get('remove_bottom')
                or bay.get('remove_carcass')
                or bay.get('floating_bay'))


def has_left_corner_finish_kick(layout):
    """Filler at the left corner behind the stile - only when stile-to-
    floor is on for that side AND the user hasn't disabled the finish.
    Suppressed when bay 0 omits its kick parts.
    """
    if _end_bay_drops_kick(layout, 0):
        return False
    return has_finish_kick(layout) and left_stile_to_floor(layout)


def has_right_corner_finish_kick(layout):
    if _end_bay_drops_kick(layout, layout.bay_count - 1):
        return False
    return has_finish_kick(layout) and right_stile_to_floor(layout)


def left_corner_finish_kick_position(layout):
    """Origin at the inside face of the left side panel (carcass_inner_
    left_x already folds in scribe + side_thickness), at the back of
    the stile, on the floor. Starting here keeps the corner kick from
    intersecting the side and from overlapping the main finish kick,
    which begins at the same X.
    """
    return (carcass_inner_left_x(layout),
            -layout.dim_y + layout.fft, 0.0)


def left_corner_finish_kick_dims(layout):
    """Length spans from inside-of-side to inside-of-stile, so it adjusts
    automatically with scribe and side_thickness (both folded into
    carcass_inner_left_x). Width is bay 0's kick height. Thickness fills
    the gap from stile back to main finish kick front.
    """
    length = layout.lsw - carcass_inner_left_x(layout)
    width = layout.bays[0]['kick_height']
    thickness = (layout.tks - layout.finish_kick_thickness
                 - layout.fft)
    return (length, width, thickness)


def right_corner_finish_kick_position(layout):
    """Origin at the inside face of the right stile (X = dim_x - rsw),
    extending +X toward the side's inner face.
    """
    return (layout.dim_x - layout.rsw,
            -layout.dim_y + layout.fft, 0.0)


def right_corner_finish_kick_dims(layout):
    """Mirror of the left corner: length runs from inside-of-stile to
    inside-of-side. Uses the LAST bay's kick height since this corner
    abuts the rightmost main-finish segment.
    """
    length = carcass_inner_right_x(layout) - (layout.dim_x - layout.rsw)
    width = layout.bays[layout.bay_count - 1]['kick_height']
    thickness = (layout.tks - layout.finish_kick_thickness
                 - layout.fft)
    return (length, width, thickness)


# ---------------------------------------------------------------------------
# Kick returns - vertical closeout panels at the inset ends
# ---------------------------------------------------------------------------
# When kick_inset_left / right > 0, the side floats up by kick_height
# and the kick is "wrapped" at that end by a return panel running the
# full carcass depth, sitting tkt-thick at the inset X position. The
# ---------------------------------------------------------------------------
# Mid-stile finish toe kick fillers (two per to-floor mid stile)
# ---------------------------------------------------------------------------
# When a MID stile is dropped to the floor its carcass division also drops
# through the kick zone, so the toe kick breaks at the gap. The mid stile board
# overhangs the division by (msw - dt)/2 on each side; these fillers bridge that
# overhang from the stile back to the main finish kick front so the face frame
# reads flush in the kick band - the mid-stile analog of the end-stile corner
# finish kick. One filler per side (LEFT / RIGHT of the division), each at its
# adjacent bay's kick height.
def has_mid_finish_kick(layout, gap_index):
    """True when gap_index's mid stile is to-floor AND the cabinet has a
    finish kick. Suppressed if either adjacent bay omits its kick parts
    (remove_bottom / remove_carcass / floating)."""
    if gap_index >= len(layout.mid_stiles):
        return False
    if not has_finish_kick(layout):
        return False
    if not layout.mid_stiles[gap_index].get('to_floor'):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    if (bay_a.get('remove_bottom') or bay_b.get('remove_bottom')
            or bay_a.get('remove_carcass') or bay_b.get('remove_carcass')
            or bay_a.get('floating_bay') or bay_b.get('floating_bay')):
        return False
    return True


def mid_finish_kick_position(layout, gap_index, side):
    """Origin for the LEFT / RIGHT mid finish kick filler: at the FF back,
    on the floor, at the outer edge of its half of the mid-stile overhang
    (LEFT = mid-stile left edge; RIGHT = division right face). Length then
    runs +X to the division (LEFT) or to the mid-stile right edge (RIGHT).
    Returns None when no filler is needed here."""
    if not has_mid_finish_kick(layout, gap_index):
        return None
    center = _mid_stile_center_x(layout, gap_index)
    msw = layout.mid_stiles[gap_index]['width']
    if side == 'LEFT':
        x = center - msw / 2.0
    else:
        x = _mid_div_right_outer_x(layout, gap_index)
    return (x, -layout.dim_y + layout.fft, 0.0)


def mid_finish_kick_dims(layout, gap_index, side):
    """Length (X) = the FF overhang beyond the division on this side
    (asymmetric when the division is offset; a flush side needs no
    filler and returns None). Width (Z) = the adjacent bay's kick
    height. Thickness (Y) = stile back to main finish kick front (same
    gap the end-stile corner kick fills). Returns None when no filler
    is needed."""
    if not has_mid_finish_kick(layout, gap_index):
        return None
    center = _mid_stile_center_x(layout, gap_index)
    msw = layout.mid_stiles[gap_index]['width']
    if side == 'LEFT':
        length = (_mid_div_left_outer_x(layout, gap_index)
                  - (center - msw / 2.0))
    else:
        length = ((center + msw / 2.0)
                  - _mid_div_right_outer_x(layout, gap_index))
    if length <= 1e-6:
        return None
    bay_idx = gap_index if side == 'LEFT' else gap_index + 1
    width = layout.bays[bay_idx]['kick_height']
    thickness = (layout.tks - layout.finish_kick_thickness
                 - layout.fft)
    return (length, width, thickness)


# ---------------------------------------------------------------------------
# main kick subfront butts against the return's inboard face.
# ---------------------------------------------------------------------------
def has_left_kick_return(layout):
    if _end_bay_drops_kick(layout, 0):
        return False
    return (has_kick_subfront(layout)
            and layout.kick_inset_left > 0)


def has_right_kick_return(layout):
    if _end_bay_drops_kick(layout, layout.bay_count - 1):
        return False
    return (has_kick_subfront(layout)
            and layout.kick_inset_right > 0)


def left_kick_return_position(layout):
    """Origin at the cabinet back, X at the inset distance from the
    cabinet outer, on the floor. Length runs -Y toward the front,
    Thickness extends +X toward the cabinet interior.
    """
    return (layout.kick_inset_left, 0.0, 0.0)


def left_kick_return_dims(layout):
    """Length spans from cabinet back to main kick front. Width is bay
    0's kick height. Thickness is the toe kick board thickness.
    """
    length = layout.dim_y - layout.tks
    width = layout.bays[0]['kick_height']
    thickness = layout.tkt
    return (length, width, thickness)


def right_kick_return_position(layout):
    """Origin at the right end at X = dim_x - kick_inset_right; Thickness
    extends -X toward the cabinet interior (Mirror Z = False on the
    part flips the Thickness direction relative to the left return).
    """
    return (layout.dim_x - layout.kick_inset_right, 0.0, 0.0)


def right_kick_return_dims(layout):
    """Mirror of left_kick_return_dims; uses the LAST bay's kick height."""
    length = layout.dim_y - layout.tks
    width = layout.bays[layout.bay_count - 1]['kick_height']
    thickness = layout.tkt
    return (length, width, thickness)


# ---------------------------------------------------------------------------
# Loose toe kick - a freestanding ladder sub-base
# ---------------------------------------------------------------------------
# LOOSE floats the carcass (side_bottom_z) and builds a separate ladder on
# the floor for the cabinet to sit on: a full-width front rail + rear rail
# spanning between two front-to-back end boards. One ladder per cabinet
# (mid divisions don't break it). All four boards are tkt thick, tkh tall,
# set back from the cabinet front by the setback. Straight cabinets only
# for v1 - angled / corner ladders are deferred.
def has_loose_kick(layout):
    """True when this cabinet should build a loose ladder sub-base.
    Both LOOSE and LOOSE_FLUSH build the ladder; they differ only in the
    ladder's front setback (see loose_kick_setback)."""
    return (layout.has_toe_kick
            and layout.toe_kick_type in ('LOOSE', 'LOOSE_FLUSH'))


def loose_kick_setback(layout):
    """Front setback for the loose ladder. LOOSE recesses the ladder
    front by the cabinet's toe_kick_setback (tks); LOOSE_FLUSH sets it to
    0 so the ladder front sits flush with the cabinet front face. Used by
    loose_kick_end (board length) and loose_kick_front_rail (front Y)."""
    if layout.toe_kick_type == 'LOOSE_FLUSH':
        return 0.0
    return layout.tks


def loose_kick_x_bounds(layout):
    """Outer X span of the ladder. End boards sit flush at the cabinet
    ends by default; kick_inset_left / kick_inset_right push each end
    inboard."""
    return (layout.kick_inset_left, layout.dim_x - layout.kick_inset_right)


def loose_kick_end(layout, side):
    """One end board, running front-to-back. Kick-return orientation
    (rot X=90 + Z=-90): Length runs -Y from the cabinet back to the
    ladder front face, Width is the kick height (vertical), Thickness is
    the board thickness mirrored +X (LEFT) / -X (RIGHT via Mirror Z on
    the part). Spans the full ladder depth so the front + rear rails
    butt between the two end boards."""
    x_left, x_right = loose_kick_x_bounds(layout)
    x = x_left if side == 'LEFT' else x_right
    return {
        'x': x, 'y': 0.0, 'z': 0.0,
        # Length spans from the cabinet back to the ladder front face;
        # LOOSE_FLUSH (setback 0) runs the full depth so the ladder is
        # flush with the cabinet front.
        'length': layout.dim_y - loose_kick_setback(layout),
        'width':  layout.tkh,
        'thickness': layout.tkt,
    }


def _loose_kick_rail_x_length(layout):
    """X origin + length for the front / rear rails. They fit BETWEEN
    the two end boards, so the origin starts one board thickness inboard
    of the left end and the span drops two thicknesses."""
    x_left, x_right = loose_kick_x_bounds(layout)
    return x_left + layout.tkt, (x_right - x_left) - 2.0 * layout.tkt


def loose_kick_front_rail(layout):
    """Front rail. Subfront orientation (rot X=90 + Mirror Z): Length
    along X between the end boards, Width = kick height (up from the
    floor), Thickness extends +Y into the cabinet. Front face set back
    from the cabinet front by the setback."""
    x0, length = _loose_kick_rail_x_length(layout)
    return {
        'x': x0,
        # Front face set back by the ladder setback (0 for LOOSE_FLUSH ->
        # flush with the cabinet front).
        'y': -layout.dim_y + loose_kick_setback(layout),
        'z': 0.0,
        'length': length,
        'width':  layout.tkh,
        'thickness': layout.tkt,
    }


def loose_kick_rear_rail(layout):
    """Rear rail. Same orientation and X span as the front rail; sits at
    the cabinet back with its outer face flush to y=0 (Thickness extends
    +Y, so the origin is one thickness forward)."""
    x0, length = _loose_kick_rail_x_length(layout)
    return {
        'x': x0,
        'y': -layout.tkt,
        'z': 0.0,
        'length': length,
        'width':  layout.tkh,
        'thickness': layout.tkt,
    }


# ---------------------------------------------------------------------------
# Tip-up wedge - back-bottom chamfer so a tall cabinet clears the ceiling
# ---------------------------------------------------------------------------
# When a tall cabinet is stood upright by pivoting on its front-bottom edge,
# the back-bottom corner sweeps an arc of radius = the cabinet's diagonal
# (sqrt(depth^2 + height^2)). If that diagonal exceeds the available ceiling
# (minus a fudge allowance) the corner won't clear, so we chamfer it. The
# wedge height is capped by the base molding that later covers it.
def compute_wedge(leg_depth, leg_height, ceiling, fudge, max_wedge_height):
    """Wedge dimensions, ported from the catalog wedge calculator. All lengths in meters.

    Returns (wedge_length, wedge_height, clamped, needed). ``needed`` is False
    when the diagonal already fits the effective ceiling (both dims 0).
    ``clamped`` is True when the raw height was capped by max_wedge_height.
    """
    effective_ceiling = ceiling - fudge
    diagonal = math.sqrt(leg_depth * leg_depth + leg_height * leg_height)

    if diagonal <= effective_ceiling:
        return 0.0, 0.0, False, False

    wedge_height = diagonal - effective_ceiling
    clamped = False
    if max_wedge_height > 0.0 and wedge_height > max_wedge_height:
        wedge_height = max_wedge_height
        clamped = True

    if effective_ceiling > leg_height:
        inner = effective_ceiling * effective_ceiling - leg_height * leg_height
        wedge_length = leg_depth - math.sqrt(inner)
    else:
        wedge_length = leg_depth

    if wedge_length < 0.0:
        wedge_length = 0.0

    return wedge_length, wedge_height, clamped, True


def wedge_geometry(layout):
    """Resolve the cabinet's live wedge from its persisted inputs.

    Reads leg depth / height straight off the layout so the wedge tracks
    cabinet resizes. Returns (length, height, clamped) when a wedge is
    enabled AND needed, else None (recalc then cleans up any cutter)."""
    if not layout.wedge_enabled:
        return None
    # Typed sizes win outright: another calculator reading the same
    # cabinet differently is the reason the field exists, so this one
    # does not get to second-guess the number.
    if layout.wedge_override:
        length = layout.wedge_length
        height = layout.wedge_height
        if length <= 0.0 and height <= 0.0:
            return None
        return length, height, False
    length, height, clamped, needed = compute_wedge(
        layout.dim_y, layout.dim_z,
        layout.wedge_ceiling_height, layout.wedge_fudge,
        layout.wedge_max_height,
    )
    if not needed:
        return None
    return length, height, clamped


# ---------------------------------------------------------------------------
# Pass-through predicates - "does the rail/something cross gap N?"
# ---------------------------------------------------------------------------
def _epsilon_eq(a, b, places=4):
    return round(a, places) == round(b, places)


def top_rail_passthrough(layout, gap_index):
    """True if a single top rail spans uninterrupted across gap_index.

    Break conditions:
    - extend_up_amount > 0 on the mid stile (it pokes through the rail)
    - bay top Z's differ (top_offset for uppers; kick/height for bases)
    - bay top rail widths differ
    - either bay has a front_drop (a dropped sink / cooktop rail sits
      below the bay top; the mid stile runs full height past it, so the
      rail can't continue through the gap)
    """
    if gap_index >= len(layout.mid_stiles):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    ms = layout.mid_stiles[gap_index]
    if ms['extend_up_amount'] > 0:
        return False
    if not _epsilon_eq(bay_top_z(layout, gap_index),
                       bay_top_z(layout, gap_index + 1)):
        return False
    if not _epsilon_eq(bay_a['top_rail_width'], bay_b['top_rail_width']):
        return False
    if (not _epsilon_eq(front_drop(layout, gap_index), 0.0)
            or not _epsilon_eq(front_drop(layout, gap_index + 1), 0.0)):
        return False
    return True


def bottom_rail_passthrough(layout, gap_index):
    """True if a single bottom rail spans uninterrupted across gap_index.

    Break conditions:
    - extend_down_amount > 0 on the mid stile
    - bay bottom Z's differ (caused by kick height differences for bases,
      or bay height differences for uppers)
    - bay bottom rail widths differ
    - either bay has remove_bottom set (the flagged bay omits its rail)
    """
    if gap_index >= len(layout.mid_stiles):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    ms = layout.mid_stiles[gap_index]
    if ms['extend_down_amount'] > 0 or ms.get('to_floor'):
        return False
    if not _epsilon_eq(bay_bottom_z(layout, gap_index),
                       bay_bottom_z(layout, gap_index + 1)):
        return False
    if not _epsilon_eq(bay_a['bottom_rail_width'], bay_b['bottom_rail_width']):
        return False
    if bay_a.get('remove_bottom') or bay_b.get('remove_bottom'):
        return False
    return True


# ---------------------------------------------------------------------------
# Segment computation
# ---------------------------------------------------------------------------
def _compute_segments(layout, passthrough_fn):
    """Generic segment builder. passthrough_fn(layout, gap_index) -> bool.

    Returns list of (start_bay, end_bay) tuples (inclusive on both ends).
    """
    n = layout.bay_count
    if n == 0:
        return []

    segments = []
    seg_start = 0
    for gap in range(n - 1):
        if not passthrough_fn(layout, gap):
            segments.append((seg_start, gap))
            seg_start = gap + 1
    segments.append((seg_start, n - 1))
    return segments


def top_rail_segments(layout):
    """Compute top rail segments. Each segment becomes one rail object.

    Returns list of dicts with keys: start_bay, end_bay, x, y, z,
    length, width, thickness.
    """
    segments = []
    for start, end in _compute_segments(layout, top_rail_passthrough):
        first_bay = layout.bays[start]
        ff_x = bay_x_position(layout, start)
        # Length: sum of bay widths within segment + intermediate mid stile widths
        length = first_bay['width']
        for k in range(start, end):
            length += layout.mid_stiles[k]['width']
            length += layout.bays[k + 1]['width']
        # A front-dropped bay (sink / cooktop) lowers its rail below the
        # bay top; passthrough breaks at any drop change so `start` speaks
        # for the whole segment.
        z = bay_top_z(layout, start) - front_drop(layout, start)
        if layout.angled_multi:
            # Split at the bend points so no rail crosses a bend; each
            # angled piece is longer than its world span by 1/cos.
            for s, e, a, b, theta in _split_ff_x_spans(
                    layout, start, end, ff_x, ff_x + length):
                wx, wy, wz = ff_outer_world_pos(layout, a, z)
                segments.append({
                    'start_bay':  s,
                    'end_bay':    e,
                    'x':          wx,
                    'y':          wy,
                    'z':          wz,
                    'length':     (b - a) / math.cos(theta),
                    'width':      first_bay['top_rail_width'],
                    'thickness':  layout.fft,
                })
            continue
        wx, wy, wz = ff_outer_world_pos(layout, ff_x, z)
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          wx,
            'y':          wy,
            'z':          wz,
            'length':     length,
            'width':      first_bay['top_rail_width'],
            'thickness':  layout.fft,
        })
    return segments


def bottom_rail_segments(layout):
    """Compute bottom rail segments. FLUSH extends the rail down to the
    floor and grows its width by kick_height so a single wide rail fills
    the space the recess would otherwise occupy.
    """
    segments = []
    flush = (layout.has_toe_kick and layout.toe_kick_type == 'FLUSH')
    for start, end in _compute_segments(layout, bottom_rail_passthrough):
        first_bay = layout.bays[start]
        # Passthrough breaks at bays with remove_bottom, so any flagged
        # bay arrives here as a (i, i) segment we drop. remove_carcass
        # is intentionally not gated here - the face frame stays.
        if first_bay.get('remove_bottom'):
            continue
        ff_x = bay_x_position(layout, start)
        length = first_bay['width']
        for k in range(start, end):
            length += layout.mid_stiles[k]['width']
            length += layout.bays[k + 1]['width']
        if flush:
            z = 0.0
            width = first_bay['kick_height'] + first_bay['bottom_rail_width']
        else:
            z = bay_bottom_z(layout, start)
            width = first_bay['bottom_rail_width']
        if layout.angled_multi:
            # Same bend-point splitting as top_rail_segments.
            for s, e, a, b, theta in _split_ff_x_spans(
                    layout, start, end, ff_x, ff_x + length):
                wx, wy, wz = ff_outer_world_pos(layout, a, z)
                segments.append({
                    'start_bay':  s,
                    'end_bay':    e,
                    'x':          wx,
                    'y':          wy,
                    'z':          wz,
                    'length':     (b - a) / math.cos(theta),
                    'width':      width,
                    'thickness':  layout.fft,
                })
            continue
        wx, wy, wz = ff_outer_world_pos(layout, ff_x, z)
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          wx,
            'y':          wy,
            'z':          wz,
            'length':     length,
            'width':      width,
            'thickness':  layout.fft,
        })
    return segments


# ---------------------------------------------------------------------------
# End stiles (left and right) - always exist
# ---------------------------------------------------------------------------
def left_end_stile_position(layout):
    """Left end stile follows bay 0's vertical extent unless the user
    has asked for a stile-to-floor or FLUSH forces it - in those cases
    the stile drops to Z = 0 and gets longer. Anchored at the LEFT
    endpoint of the FF outer plane (FF-x = 0); in angled mode that
    sits at world (0, -effective_left_depth) instead of (0, -dim_y).
    """
    if raise_side_to_refrigerator(layout, 'LEFT'):
        bottom_z = refrigerator_raise_z(layout, 0)
    elif left_stile_to_floor(layout):
        bottom_z = 0.0
    else:
        bottom_z = bay_bottom_z(layout, 0) - ends_down_drop(layout, 'LEFT')
    return ff_outer_world_pos(layout, 0.0, bottom_z)


def left_end_stile_dims(layout):
    if raise_side_to_refrigerator(layout, 'LEFT'):
        bottom_z = refrigerator_raise_z(layout, 0)
    elif left_stile_to_floor(layout):
        bottom_z = 0.0
    else:
        bottom_z = bay_bottom_z(layout, 0) - ends_down_drop(layout, 'LEFT')
    top_z = bay_top_z(layout, 0)
    return (top_z - bottom_z, layout.lsw, layout.fft)


def right_end_stile_position(layout):
    """Right end stile follows the LAST bay's vertical extent unless the
    user has asked for a stile-to-floor or FLUSH forces it. Anchored
    at the RIGHT endpoint of the FF outer plane (FF-x = ff_length);
    in angled mode that sits at world (dim_x, -effective_right_depth).
    """
    last = layout.bay_count - 1
    if raise_side_to_refrigerator(layout, 'RIGHT'):
        bottom_z = refrigerator_raise_z(layout, last)
    elif right_stile_to_floor(layout):
        bottom_z = 0.0
    else:
        bottom_z = bay_bottom_z(layout, last) - ends_down_drop(layout, 'RIGHT')
    return ff_outer_world_pos(layout, face_frame_length(layout), bottom_z)


def right_end_stile_dims(layout):
    last = layout.bay_count - 1
    if raise_side_to_refrigerator(layout, 'RIGHT'):
        bottom_z = refrigerator_raise_z(layout, last)
    elif right_stile_to_floor(layout):
        bottom_z = 0.0
    else:
        bottom_z = bay_bottom_z(layout, last) - ends_down_drop(layout, 'RIGHT')
    top_z = bay_top_z(layout, last)
    return (top_z - bottom_z, layout.rsw, layout.fft)


def left_refrig_stile_position(layout):
    """'Stile in lieu of leg': floor-anchored lower stile on the LEFT, sharing
    the left end stile's X. Bottoms at Z = 0; tops at the refrigerator opening
    (where the raised end stile begins), so the two abut into one continuous
    stile split at the opening top."""
    return ff_outer_world_pos(layout, 0.0, 0.0)


def left_refrig_stile_dims(layout):
    top_z = refrigerator_raise_z(layout, 0)
    return (top_z, layout.lsw, layout.fft)


def right_refrig_stile_position(layout):
    """Mirror of left_refrig_stile_position on the RIGHT end."""
    return ff_outer_world_pos(layout, face_frame_length(layout), 0.0)


def right_refrig_stile_dims(layout):
    last = layout.bay_count - 1
    top_z = refrigerator_raise_z(layout, last)
    return (top_z, layout.rsw, layout.fft)


# ---------------------------------------------------------------------------
# Carcass side panels - extend with first/last bay's vertical range
# ---------------------------------------------------------------------------
def effective_left_depth(layout):
    """Left side's front-to-back length budget. In angled mode the
    unlocked side reads cab.left_depth; otherwise it falls back to the
    first bay's depth (which equals dim_y on single-bay carcasses)."""
    if layout.is_angled and layout.unlock_left_depth:
        return layout.cab_left_depth
    return layout.bays[0]['depth']


def effective_right_depth(layout):
    """Mirror of effective_left_depth for the right side."""
    if layout.is_angled and layout.unlock_right_depth:
        return layout.cab_right_depth
    last = layout.bay_count - 1
    return layout.bays[last]['depth']


def multi_bend_points(layout):
    """(bend_left_x, bend_right_x) world X of the piecewise front's
    bend points for angled_multi - the centers of the first and last
    mid stiles. The angled left plane runs (0, -left_depth) ->
    (bend_left, -dim_y); the right plane (bend_right, -dim_y) ->
    (dim_x, -right_depth); between them the front is square. On a
    2-bay cabinet both bends are the same stile center."""
    last = layout.bay_count - 1
    # mid stile between bay i and i+1 spans [bay_x_position(i+1) - ms,
    # bay_x_position(i+1)]; ms recovered from the position arithmetic
    # so no extra layout fields are needed.
    x1 = bay_x_position(layout, 1)
    ms0 = x1 - (bay_x_position(layout, 0) + layout.bays[0]['width'])
    bend_l = x1 - ms0 / 2.0
    xl = bay_x_position(layout, last)
    msl = xl - (bay_x_position(layout, last - 1)
                + layout.bays[last - 1]['width'])
    bend_r = xl - msl / 2.0
    return bend_l, bend_r


def bay_front_angle(layout, bay_index):
    """Per-bay front angle. Single-bay angled -> the whole-cabinet
    face_frame_angle (original behavior). Multi-bay: only bay 0 angles
    for the left depth and only the last bay for the right depth;
    everything else is square. Sign convention matches
    face_frame_angle (dy = shallower-left => positive slope)."""
    if not layout.is_angled:
        return 0.0
    if not layout.angled_multi:
        return face_frame_angle(layout)
    last = layout.bay_count - 1
    bend_l, bend_r = multi_bend_points(layout)
    if bay_index == 0 and layout.unlock_left_depth and bend_l > 1e-6:
        return math.atan2(
            effective_left_depth(layout) - layout.dim_y, bend_l)
    if (bay_index == last and layout.unlock_right_depth
            and layout.dim_x - bend_r > 1e-6):
        return math.atan2(
            layout.dim_y - effective_right_depth(layout),
            layout.dim_x - bend_r)
    return 0.0


def _multi_front_at(layout, x):
    """(y, theta) of the piecewise FF outer line at world X for
    angled_multi."""
    bend_l, bend_r = multi_bend_points(layout)
    last = layout.bay_count - 1
    if layout.unlock_left_depth and x < bend_l:
        theta = bay_front_angle(layout, 0)
        ld = effective_left_depth(layout)
        return -ld + x * math.tan(theta), theta
    if layout.unlock_right_depth and x > bend_r:
        theta = bay_front_angle(layout, last)
        rd = effective_right_depth(layout)
        return (-rd - (layout.dim_x - x) * math.tan(theta)), theta
    return -layout.dim_y, 0.0


def _angled_multi_cuts(layout, start, end, perp=0.0):
    """(cut_x, gap_index) breaks an angled_multi FF member spanning bays
    start..end must take so no piece crosses a bend point. A left cut
    only exists when the segment includes bay 0 AND extends past it (the
    bend sits mid-stile-0); mirror for the right. On a 2-bay cabinet
    both bends share gap 0, so the right cut is skipped once the left
    one is taken.

    `perp` is the member's perpendicular offset from the FF outer plane
    (0 for rails, tks for the kick subfront). Offset planes
    meeting at an angle intersect NOT at the outer-plane bend X, so
    each cut is computed as the intersection of the two ADJACENT
    regions' offset lines (y = m*x + b): angled-left vs square, square
    vs angled-right - or angled-left vs angled-right directly on a
    2-bay cabinet where both bends share the one mid stile and no
    square region exists between them. perp = 0 collapses every cut to
    the bend points."""
    cuts = []
    if not layout.angled_multi:
        return cuts
    last = layout.bay_count - 1
    bend_l, bend_r = multi_bend_points(layout)
    theta_l = bay_front_angle(layout, 0)
    theta_r = bay_front_angle(layout, last)
    has_l = (start == 0 and end > 0 and layout.unlock_left_depth
             and abs(theta_l) > 1e-9)
    has_r = (end == last and start < last and layout.unlock_right_depth
             and abs(theta_r) > 1e-9)
    m_l = math.tan(theta_l)
    b_l = -effective_left_depth(layout) + perp / math.cos(theta_l)
    m_r = math.tan(theta_r)
    b_r = (-effective_right_depth(layout) - m_r * layout.dim_x
           + perp / math.cos(theta_r))
    b_sq = -layout.dim_y + perp
    if has_l and has_r and bend_r - bend_l < 1e-9:
        if abs(m_l - m_r) > 1e-9:
            cuts.append(((b_r - b_l) / (m_l - m_r), 0))
        return cuts
    if has_l:
        cuts.append(((b_sq - b_l) / m_l, 0))
    if has_r:
        cuts.append(((b_sq - b_r) / m_r, last - 1))
    return cuts


def _split_ff_x_spans(layout, start, end, x0, x1, perp=0.0):
    """Split a FF member covering bays start..end and world X [x0, x1]
    at the angled_multi bend points (shifted to the member's own plane
    intersections via `perp` - see _angled_multi_cuts). Returns a list
    of (sub_start_bay, sub_end_bay, a, b, theta) pieces where [a, b] is
    the piece's world X range and theta its front angle (0 on square
    pieces). A single piece with theta from bay_front_angle(start) when
    no cut applies - callers only use this on the angled_multi path, so
    single-bay hypotenuse math stays untouched."""
    cuts = [(x, g)
            for (x, g) in _angled_multi_cuts(layout, start, end, perp)
            if x0 + 1e-9 < x < x1 - 1e-9]
    cuts.sort()
    pieces = []
    a, s = x0, start
    for (x, g) in cuts:
        pieces.append((s, g, a, x))
        a, s = x, g + 1
    pieces.append((s, end, a, x1))
    return [(s, e, a, b, bay_front_angle(layout, s))
            for (s, e, a, b) in pieces]


def face_frame_angle(layout):
    """Z rotation (radians) that maps the original square face frame
    direction (+X) to the angled FF plane's direction, going from the
    left endpoint to the right endpoint of the FF inner plane.

    Negative when the left side is shallower than the right: the right
    endpoint sits at more-negative Y, so rotating +X clockwise (negative
    Z in right-handed coords) is needed to align with the FF line.
    Returns 0.0 when not angled.

    Used directly as rotation_euler.z on FF parts that lie in the FF
    plane (stiles, rails, kick subfront, opening front pivots) and on
    the angled cutter.
    """
    if not layout.is_angled:
        return 0.0
    dy = effective_left_depth(layout) - effective_right_depth(layout)
    return math.atan2(dy, layout.dim_x)


def face_frame_length(layout):
    """Length of the face frame plane along its own X axis. In the
    square case the FF plane shrinks by any active blind offsets so
    end stiles, rails, and bays all fit within the non-blind portion
    of the cabinet width. The angled case keeps the hypotenuse math
    untouched - blind plus angled isn't supported yet.
    """
    if not layout.is_angled:
        return (layout.dim_x
                - layout.ff_inset_left
                - layout.ff_inset_right)
    if layout.angled_multi:
        # Multi-bay angled parameterizes the piecewise front by WORLD
        # X (bay widths stay world-x; members on angled segments scale
        # their own lengths by 1/cos). Blind+angled unsupported.
        return layout.dim_x
    dy = effective_right_depth(layout) - effective_left_depth(layout)
    return math.hypot(layout.dim_x, dy)


def ff_outer_world_pos(layout, ff_x, world_z):
    """World (x, y, z) on the FF outer plane at FF-distance ff_x from
    the left endpoint of the (potentially shrunken) face frame, at
    height world_z.

    For non-angled cabinets ff_x maps to world X via the FF inset
    (blind offset + decorative corner post): the FF plane's left
    endpoint sits at world x = ff_inset_left, so the function returns
    (ff_x + ff_inset_left, -dim_y, z).
    Callers pass FF-local coordinates from bay_x_position /
    face_frame_length so the offset is added once at the world
    boundary.

    For angled cabinets the FF outer plane is rotated around Z by
    face_frame_angle, with its left endpoint at (0, -effective_left_
    depth) and its right endpoint at (dim_x, -effective_right_depth).
    Blind+angled isn't supported, so the angled branch ignores the
    blind offsets.
    """
    if not layout.is_angled:
        return (ff_x + layout.ff_inset_left, -layout.dim_y, world_z)
    if layout.angled_multi:
        y, _theta = _multi_front_at(layout, ff_x)
        return (ff_x, y, world_z)
    theta = face_frame_angle(layout)
    return (
        ff_x * math.cos(theta),
        -effective_left_depth(layout) + ff_x * math.sin(theta),
        world_z,
    )


def ff_inner_world_pos(layout, ff_x, world_z):
    """World (x, y, z) on the FF inner plane (the back face of the
    face frame, where carcass tops / bottoms / sides butt) at FF-
    distance ff_x from the left endpoint, at height world_z.

    Equivalent to ff_outer_world_pos shifted by fft in the
    perpendicular-into-cabinet direction.
    """
    return ff_perpendicular_offset(layout, ff_x, layout.fft, world_z)


def ff_perpendicular_offset(layout, ff_x, perp_offset, world_z):
    """World (x, y, z) on a FF-parallel plane shifted inward from the
    FF outer plane by perp_offset along the perpendicular-into-cabinet
    direction, parameterized by FF-distance ff_x from the left FF
    endpoint. For parts whose endpoints are already in FF coordinates
    (rails, stiles).
    """
    if not layout.is_angled:
        return (ff_x, -layout.dim_y + perp_offset, world_z)
    if layout.angled_multi:
        y, theta = _multi_front_at(layout, ff_x)
        return (
            ff_x - perp_offset * math.sin(theta),
            y + perp_offset * math.cos(theta),
            world_z,
        )
    theta = face_frame_angle(layout)
    cos_t = math.cos(theta)
    sin_t = math.sin(theta)
    return (
        ff_x * cos_t - perp_offset * sin_t,
        -effective_left_depth(layout) + ff_x * sin_t + perp_offset * cos_t,
        world_z,
    )


def ff_perpendicular_offset_at_world_x(layout, world_x, perp_offset, world_z):
    """World (x, y, z) on the same FF-parallel plane as
    ff_perpendicular_offset, but parameterized by WORLD X instead of
    FF-distance. For the toe kick subfront and finish kick whose
    endpoints must align with the side panels' world-X-aligned inner
    faces (so the kick is captured between the sides), not with the
    FF stile inboard edges.
    """
    if not layout.is_angled:
        return (world_x, -layout.dim_y + perp_offset, world_z)
    if layout.angled_multi:
        y, theta = _multi_front_at(layout, world_x)
        return (world_x, y + perp_offset / math.cos(theta), world_z)
    theta = face_frame_angle(layout)
    sin_t = math.sin(theta)
    cos_t = math.cos(theta)
    # Kick plane equation: y(x) = -ld + tan*x + perp/cos. Derived from
    # parameterizing the plane by FF-x (y = -ld + ff_x*sin + perp*cos,
    # x = ff_x*cos - perp*sin) and eliminating ff_x.
    return (
        world_x,
        (-effective_left_depth(layout)
         + (sin_t / cos_t) * world_x
         + perp_offset / cos_t),
        world_z,
    )


def ff_world_x_span_to_length(layout, world_x_span):
    """Given a span between two world X coordinates that lie on a FF-
    parallel plane (e.g. the subfront kick stretching between the side
    panels' inner faces), return the length the part should be along
    its own +X axis (which after rotation is FF-aligned). For square
    cabinets this is the same number; for angled it's longer by 1/cos.
    """
    if not layout.is_angled:
        return world_x_span
    if layout.angled_multi:
        # Multi-bay: the caller's span midpoint decides which segment's
        # angle applies (segments are split at the bends, see
        # kick/rail segmentation).
        return world_x_span
    return world_x_span / math.cos(face_frame_angle(layout))


def left_side_position(layout):
    """Left carcass side. Two anchoring modes:

      Square (default): side back edge sits at -dim_y + bay 0 depth,
        so a shallower bay shifts BOTH ends forward equally and the
        back panel moves with it.
      Angled (unlock on): side back edge anchors at the cabinet back
        (Y = 0). Only the front edge moves, producing the asymmetric
        front geometry that drives the angled face frame plane while
        the back stays put. Multi-bay cabinets anchor per side: only
        the side whose end bay actually angles switches modes; the
        other keeps the square anchoring.

    X reflects the scribe offset so the side can sit inboard of the
    stile. Z anchor depends on toe_kick_type via side_bottom_z.
    """
    if layout.is_angled and (not layout.angled_multi
                             or layout.unlock_left_depth):
        y = 0.0
    else:
        y = -layout.dim_y + layout.bays[0]['depth']
    return (left_scribe_offset(layout), y,
            side_bottom_z(layout, 0, 'LEFT'))


def left_side_dims(layout):
    bottom_z = side_bottom_z(layout, 0, 'LEFT')
    top_z = left_side_top_z(layout)
    return (top_z - bottom_z,
            effective_left_depth(layout) - layout.fft,
            left_side_thickness(layout))


def right_side_position(layout):
    """Mirror of left_side_position. See its docstring for the two
    anchoring modes."""
    if layout.is_angled and (not layout.angled_multi
                             or layout.unlock_right_depth):
        y = 0.0
    else:
        last = layout.bay_count - 1
        y = -layout.dim_y + layout.bays[last]['depth']
    last = layout.bay_count - 1
    return (layout.dim_x - right_scribe_offset(layout), y,
            side_bottom_z(layout, last, 'RIGHT'))


def right_side_dims(layout):
    last = layout.bay_count - 1
    bottom_z = side_bottom_z(layout, last, 'RIGHT')
    top_z = right_side_top_z(layout)
    return (top_z - bottom_z,
            effective_right_depth(layout) - layout.fft,
            right_side_thickness(layout))


# ---------------------------------------------------------------------------
# Mid stile (one per gap) - position and length depend on adjacent rails
# ---------------------------------------------------------------------------
def mid_stile_position(layout, gap_index):
    """X, Y, Z position for the mid stile at gap_index (between bay
    gap_index and bay gap_index + 1).

    Z = lower of the two adjacent bay bottoms (so the stile reaches down
    to the deeper bay), plus the bottom rail width if a rail passes
    through this gap, minus the mid stile's extend_down_amount.
    """
    if gap_index >= len(layout.mid_stiles):
        return (0.0, 0.0, 0.0)

    bay_a = layout.bays[gap_index]
    ms = layout.mid_stiles[gap_index]

    base_z = min(bay_bottom_z(layout, gap_index),
                 bay_bottom_z(layout, gap_index + 1))
    if bottom_rail_passthrough(layout, gap_index):
        base_z += bay_a['bottom_rail_width']
    base_z -= ms['extend_down_amount']
    if ms.get('to_floor'):
        base_z = 0.0

    x = (bay_x_position(layout, gap_index)
         + bay_a['width']
         + layout.ff_inset_left)
    y = -layout.dim_y
    return (x, y, base_z)


def mid_stile_dims(layout, gap_index):
    """Length, Width, Thickness for the mid stile at gap_index.

    Length runs from the mid stile's bottom Z up to the bottom edge of
    the top rail covering this gap (or cabinet ceiling if rails are split).
    extend_up_amount adds to the length.
    """
    if gap_index >= len(layout.mid_stiles):
        return (0.0, 0.0, layout.fft)

    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    ms = layout.mid_stiles[gap_index]

    # Bottom Z (matches mid_stile_position)
    bottom_z = min(bay_bottom_z(layout, gap_index),
                   bay_bottom_z(layout, gap_index + 1))
    if bottom_rail_passthrough(layout, gap_index):
        bottom_z += bay_a['bottom_rail_width']
    bottom_z -= ms['extend_down_amount']
    # Stile-to-floor pins the mid stile's bottom to the floor (Z=0),
    # overriding the bay-bottom + extend-down computation (like an end stile).
    if ms.get('to_floor'):
        bottom_z = 0.0

    # Top Z: higher of the two adjacent bay tops, minus top rail width
    # if a rail passes through, plus extend_up_amount.
    top_z = max(bay_top_z(layout, gap_index),
                bay_top_z(layout, gap_index + 1))
    if top_rail_passthrough(layout, gap_index):
        top_z -= bay_a['top_rail_width']
    top_z += ms['extend_up_amount']

    length = top_z - bottom_z
    return (length, ms['width'], layout.fft)


def mid_stile_notches(layout, gap_index):
    """Step notches for a mid stile whose adjacent bays differ in
    vertical extent (the full-overlay height-change case).

    The stile spans the UNION of both bays; where only ONE bay runs
    beside it, the stile keeps just that bay's HALF of its width --
    the absent bay's half is notched away from the stile's end up (or
    down) to the absent bay's edge, so e.g. a 2-1/4" shared stile
    reads 1-1/8" beside the single full-height door below a shortened
    middle bay.

    Returns a list of notch dicts: end ('BOTTOM' / 'TOP'), side
    ('LEFT' / 'RIGHT' -- which adjacent bay's half is removed), span
    (extent along the stile from that end) and width (the removed
    width). Empty for standard overlays (FULL-overlay construction
    only -- others keep the plain stile + partition skins), when the
    bays align, or when the gap sits on a bend (the mitered halves
    handle their own geometry).
    """
    if not getattr(layout, 'full_overlay', False):
        return []
    if gap_index >= len(layout.mid_stiles):
        return []
    if layout.angled_multi and mid_stile_bend_thetas(layout, gap_index):
        return []
    ms = layout.mid_stiles[gap_index]
    a_bot = bay_bottom_z(layout, gap_index)
    b_bot = bay_bottom_z(layout, gap_index + 1)
    a_top = bay_top_z(layout, gap_index)
    b_top = bay_top_z(layout, gap_index + 1)
    # Physical stile extent -- mirrors mid_stile_position / _dims.
    bottom_z = min(a_bot, b_bot)
    if bottom_rail_passthrough(layout, gap_index):
        bottom_z += layout.bays[gap_index]['bottom_rail_width']
    bottom_z -= ms['extend_down_amount']
    if ms.get('to_floor'):
        bottom_z = 0.0
    top_z = max(a_top, b_top)
    if top_rail_passthrough(layout, gap_index):
        top_z -= layout.bays[gap_index]['top_rail_width']
    top_z += ms['extend_up_amount']

    half = ms['width'] / 2.0
    eps = inch(1.0 / 32.0)
    out = []
    hi_bot = max(a_bot, b_bot)      # the shallower-reaching bay's bottom
    if hi_bot - bottom_z > eps:
        out.append({
            'end': 'BOTTOM',
            'side': 'LEFT' if a_bot > b_bot else 'RIGHT',
            'span': hi_bot - bottom_z,
            'width': half,
        })
    lo_top = min(a_top, b_top)      # the shorter bay's top
    if top_z - lo_top > eps:
        out.append({
            'end': 'TOP',
            'side': 'LEFT' if a_top < b_top else 'RIGHT',
            'span': top_z - lo_top,
            'width': half,
        })
    return out


def mid_stile_bend_thetas(layout, gap_index):
    """(theta_left_region, theta_right_region) of the front planes
    meeting at this gap's mid stile, or None when the gap is flat (no
    bend here). Only gap 0 can carry the left angle and only the last
    gap the right; on a 2-bay cabinet the one gap can carry both."""
    if not layout.angled_multi:
        return None
    last = layout.bay_count - 1
    th_l = (bay_front_angle(layout, 0)
            if (gap_index == 0 and layout.unlock_left_depth) else 0.0)
    th_r = (bay_front_angle(layout, last)
            if (gap_index == last - 1 and layout.unlock_right_depth)
            else 0.0)
    if abs(th_l) < 1e-9 and abs(th_r) < 1e-9:
        return None
    return th_l, th_r


def mid_stile_bend_halves(layout, gap_index):
    """Split geometry for a mid stile sitting ON a bend: the stile
    splits lengthwise into two half-width boards, each lying in its
    side's front plane, mitered together on the vertical plane through
    the bend line along the planes' angular bisector.

    None on flat gaps. Otherwise a dict:
      bend       - (x, y) of the bend line on the FF outer plane
      base_z / length / thickness - shared vertical extent (identical
                   to the flat stile's, so extend up/down / to-floor
                   still apply)
      miter_dir  - (x, y) unit bisector pointing into the cabinet;
                   the miter plane contains the bend line + this dir
      left/right - per half: theta, width (half the stile width
                   measured along that plane, so world-X footprint
                   stays ms/2), pos (anchor at the half's LEFT edge on
                   its plane - the right half anchors at the bend),
                   open_dir (direction on the OTHER side of the miter
                   plane, toward the material this half must shed)
    """
    thetas = mid_stile_bend_thetas(layout, gap_index)
    if thetas is None:
        return None
    th_l, th_r = thetas
    ms = layout.mid_stiles[gap_index]
    half_w = ms['width'] / 2.0
    bend_x = _mid_stile_center_x(layout, gap_index)
    pos = mid_stile_position(layout, gap_index)
    length, _w, fft = mid_stile_dims(layout, gap_index)
    base_z = pos[2]
    n_l = (-math.sin(th_l), math.cos(th_l))
    n_r = (-math.sin(th_r), math.cos(th_r))
    mx, my = n_l[0] + n_r[0], n_l[1] + n_r[1]
    ln = math.hypot(mx, my)
    return {
        'bend':      (bend_x, -layout.dim_y),
        'base_z':    base_z,
        'length':    length,
        'thickness': fft,
        'miter_dir': (mx / ln, my / ln),
        'left': {
            'theta':    th_l,
            'width':    half_w / math.cos(th_l),
            'pos':      ff_outer_world_pos(layout, bend_x - half_w, base_z),
            'open_dir': (math.cos(th_r), math.sin(th_r)),
        },
        'right': {
            'theta':    th_r,
            'width':    half_w / math.cos(th_r),
            'pos':      ff_outer_world_pos(layout, bend_x, base_z),
            'open_dir': (-math.cos(th_l), -math.sin(th_l)),
        },
    }


# ---------------------------------------------------------------------------
# Per-segment carcass bottom panels - the bay floors
# ---------------------------------------------------------------------------
def bay_finish_bottom(layout, bay_index):
    """True when the bay's carcass BOTTOM is cut from finish stock.

    Either the whole bay reads finished (finish_carcass), or the
    bottom-most opening in it is finished - a finished region's floor is
    never lined, so the panel it sits on IS the finish, and for the
    bottom-most opening that panel is the bay floor. Cached on the
    layout: the passthrough asks per gap and the segment builder asks
    again per run.
    """
    bay = layout.bays[bay_index]
    if bay.get('finish_carcass'):
        return True
    cache = layout.__dict__.setdefault('_finish_bottom_cache', {})
    if bay_index not in cache:
        found = False
        for leaf in bay_openings(layout, bay_index)['leaves']:
            if abs(leaf['cage_z']) > 1e-6:
                continue
            op_obj = bpy.data.objects.get(leaf['obj_name'])
            if op_obj is None:
                continue
            op = op_obj.face_frame_opening
            if op.finish_opening and op.finish_opening_material == 'FINISH':
                found = True
                break
        cache[bay_index] = found
    return cache[bay_index]


def _carcass_bottom_passthrough(layout, gap_index):
    """True if the bay-floor (carcass bottom) panel spans gap_index uninterrupted.

    Break conditions:
    - bay bottom Z's differ (different floor heights)
    - bay depths differ (each panel sized to its bay's depth)
    - bottom rail widths differ (panel Z computed from bay_bottom_z + brw)
    - either bay has remove_bottom or remove_carcass set
    - bay_finish_bottom differs (a finished floor is finish stock, so it
      splits off to leave its neighbours interior)
    """
    if gap_index >= len(layout.mid_stiles):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    # A to-floor mid stile drops its carcass division to the floor, so the
    # bay-floor panel must break here to let the division pass through.
    if layout.mid_stiles[gap_index].get('to_floor'):
        return False
    if not _epsilon_eq(bay_bottom_z(layout, gap_index),
                       bay_bottom_z(layout, gap_index + 1)):
        return False
    if not _epsilon_eq(bay_a['depth'], bay_b['depth']):
        return False
    if not _epsilon_eq(bay_a['bottom_rail_width'], bay_b['bottom_rail_width']):
        return False
    if (bay_a.get('remove_bottom') or bay_b.get('remove_bottom')
            or bay_a.get('remove_carcass') or bay_b.get('remove_carcass')):
        return False
    if bay_finish_bottom(layout, gap_index) != bay_finish_bottom(layout,
                                                                 gap_index + 1):
        return False
    return True


def _mid_stile_center_x(layout, gap_index):
    """World-X of the FACE FRAME mid-stile centerline at this gap. The
    frame keys off this line; the carcass mid-div setup keys off
    _mid_div_center_x, which folds in the user's division offset (so
    the division can sit off-center under the stile, scribe-style).

    bay_x_position returns FF-local; add ff_inset_left so this
    function honors its world-X contract regardless of blind state.
    """
    bay_a = layout.bays[gap_index]
    ms = layout.mid_stiles[gap_index]
    msw = ms['width']
    base_x = (bay_x_position(layout, gap_index)
              + bay_a['width']
              + layout.ff_inset_left)
    return base_x + msw / 2.0


def _mid_div_offset(layout, gap_index):
    """Signed X shift of the carcass mid-division setup off the stile
    centerline - the interior analog of the side scribe amount.
    CENTERED = 0 (historical behavior). FLUSH_LEFT / FLUSH_RIGHT pin
    the setup's outer face to that stile edge, computed live so flush
    re-tracks stile width / division thickness changes. OFFSET is the
    user's typed value (+X = toward the right bay). Only the carcass
    division and geometry keyed to its faces move; the face frame does
    not.
    """
    ms = layout.mid_stiles[gap_index]
    # Bay-height STEP (full overlay): the whole division setup shifts
    # so its void-side face lands on the stile's notch plane (the
    # stile centerline) -- and every face-keyed consumer (carcass
    # bottom / back segments, kick, skins) follows through the shared
    # _mid_div_* helpers instead of poking through the moved panel.
    step = mid_stile_notches(layout, gap_index)
    if step and _epsilon_eq(layout.bays[gap_index]['depth'],
                            layout.bays[gap_index + 1]['depth']):
        dt = layout.division_thickness
        return (-dt / 2.0 if step[0]['side'] == 'RIGHT' else dt / 2.0)
    loc = ms.get('division_location', 'CENTERED')
    if loc == 'CENTERED':
        return 0.0
    if loc == 'OFFSET':
        return ms.get('division_offset', 0.0)
    # Flush: the setup's half-width is dt/2 for the single centered
    # panel (same-depth) or dt for the two-panel face-to-face setup.
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    dt = layout.division_thickness
    half = dt / 2.0 if _epsilon_eq(bay_a['depth'], bay_b['depth']) else dt
    extreme = max(0.0, ms['width'] / 2.0 - half)
    return -extreme if loc == 'FLUSH_LEFT' else extreme


def _mid_div_center_x(layout, gap_index):
    """World-X centerline of the mid-division SETUP: stile centerline
    plus the division offset. All carcass division geometry (panels,
    outer faces, meeting points) derives from this."""
    return (_mid_stile_center_x(layout, gap_index)
            + _mid_div_offset(layout, gap_index))


def _mid_div_left_outer_x(layout, gap_index):
    """X of the LEFT-facing outer face of the mid-div setup. For
    matching bay depths this is the single centered panel's left face;
    for differing depths this is panel A's (bay A's right wall) left
    face.
    """
    center = _mid_div_center_x(layout, gap_index)
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    dt = layout.division_thickness
    if _epsilon_eq(bay_a['depth'], bay_b['depth']):
        return center - dt / 2.0
    return center - dt


def _mid_div_right_outer_x(layout, gap_index):
    """X of the RIGHT-facing outer face of the mid-div setup. Mirror
    of _mid_div_left_outer_x."""
    center = _mid_div_center_x(layout, gap_index)
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    dt = layout.division_thickness
    if _epsilon_eq(bay_a['depth'], bay_b['depth']):
        return center + dt / 2.0
    return center + dt


def _carcass_meeting_x(layout, gap_index):
    """X coordinate where two adjacent carcass bottom (or back)
    segments meet at gap_index.

    Same-depth gap (one panel): the HIGHER bay's panel abuts the mid div
    at its near face; the LOWER bay's panel passes UNDER the mid div to
    the far face. Both segments meet at that single X.

    Diff-depth gap (two panels): segments cannot pass under since each
    bay has its own wall at its own depth. Both terminate at the
    touching face between panel A and panel B (= mid-stile center).
    """
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    if not _epsilon_eq(bay_a['depth'], bay_b['depth']):
        return _mid_div_center_x(layout, gap_index)
    if bay_bottom_z(layout, gap_index) > bay_bottom_z(layout, gap_index + 1):
        return _mid_div_left_outer_x(layout, gap_index)
    return _mid_div_right_outer_x(layout, gap_index)


def _step_gap(layout, gap_index):
    """True when gap_index carries a same-depth bay-height STEP (the
    full-overlay notched-stile + flush-division construction). The
    dropped full-height division blocks the usual pass-under, so
    carcass segments must stop at THEIR side's division face."""
    return bool(
        _epsilon_eq(layout.bays[gap_index]['depth'],
                    layout.bays[gap_index + 1]['depth'])
        and mid_stile_notches(layout, gap_index))


def _void_gap(layout, gap_index):
    """True when the bay on either side of gap_index is open to the floor.

    That happens with remove_carcass, and equally with remove_bottom:
    taking a bay's bottom out is how an appliance bay is made, and the
    appliance stands on the floor, so the space below runs right down
    through the kick. Either way the mid division becomes that void's
    side wall and drops to the floor, and nothing passes under it -
    segments stop at their own side's division face, the same rule as a
    step gap.

    remove_bottom used to be left out, so a bay opened for a freezer or
    a refrigerator was walled only to the top of the kick and stood open
    at the bottom for the kick's height.
    """
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    return bool(bay_a.get('remove_carcass') or bay_b.get('remove_carcass')
                or bay_a.get('remove_bottom') or bay_b.get('remove_bottom'))


def _segment_x_bounds(layout, start, end):
    """Left and right X for a segment that should fill from cabinet inner
    side wall to cabinet inner side wall, meeting adjacent segments at
    the mid division on internal gaps. On a step gap the division runs
    the full height flush with the stile notch plane, so nothing passes
    under it -- each segment stops at its own side's division face.
    """
    if start == 0:
        left_x = carcass_inner_left_x(layout)
    elif _step_gap(layout, start - 1) or _void_gap(layout, start - 1):
        left_x = _mid_div_right_outer_x(layout, start - 1)
    else:
        left_x = _carcass_meeting_x(layout, start - 1)
    if end == layout.bay_count - 1:
        right_x = carcass_inner_right_x(layout)
    elif _step_gap(layout, end) or _void_gap(layout, end):
        right_x = _mid_div_left_outer_x(layout, end)
    else:
        right_x = _carcass_meeting_x(layout, end)
    return left_x, right_x


def _stretcher_x_bounds(layout, start, end):
    """X bounds for stretchers (and any panel that meets adjacent
    segments SYMMETRICALLY at the mid division's inside faces, rather
    than asymmetrically like carcass bottoms which have a higher/lower
    bay relationship).

    For an internal boundary at gap_index:
      - segment on the LEFT  (right edge): meets at mid_div left face = mid_div_x
      - segment on the RIGHT (left edge):  meets at mid_div right face = mid_div_x + mt
    """
    if start == 0:
        left_x = carcass_inner_left_x(layout)
    else:
        left_x = _mid_div_right_outer_x(layout, start - 1)
    if end == layout.bay_count - 1:
        right_x = carcass_inner_right_x(layout)
    else:
        right_x = _mid_div_left_outer_x(layout, end)
    return left_x, right_x


def carcass_bottom_segments(layout):
    """Per-segment bay floor panels.

    Length spans from carcass inner side (or previous mid division) to
    next mid division (or carcass inner side). The HIGHER neighbor's
    panel abuts the mid division; the LOWER neighbor passes underneath
    so the mid division can rest on top of it.
    """
    segments = []
    for start, end in _compute_segments(layout, _carcass_bottom_passthrough):
        first_bay = layout.bays[start]
        # Passthrough breaks at bays with remove_bottom or remove_carcass,
        # so any flagged bay arrives here as a (i, i) segment we drop.
        if first_bay.get('remove_bottom') or first_bay.get('remove_carcass'):
            continue
        left_x, right_x = _segment_x_bounds(layout, start, end)
        # Captured UNFINISHED upper sides sit on top of this panel, so
        # extend it outward to the side's outer face (end bays only) to
        # give the raised side something to land on. Mirrors side_bottom_z.
        if start == 0 and _upper_side_captured(layout, 'LEFT', 0):
            left_x -= left_side_thickness(layout)
        if end == layout.bay_count - 1 and _upper_side_captured(layout, 'RIGHT', end):
            right_x += right_side_thickness(layout)
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          left_x,
            'y':          -layout.dim_y + first_bay['depth'] - back_thickness(layout),
            'z':          (bay_bottom_z(layout, start)
                           + first_bay['bottom_rail_width']
                           - bottom_thickness(layout)),
            'length':     right_x - left_x,
            'panel_dim_y': first_bay['depth'] - back_thickness(layout) - layout.fft,
            'thickness':  bottom_thickness(layout),
            # Segments break at finish boundaries, so the start bay
            # speaks for the whole panel.
            'finished':   bay_finish_bottom(layout, start),
        })
    return segments


def _carcass_back_passthrough(layout, gap_index):
    """Back panel breaks when bay floors, ceilings, or depths differ,
    when either bay has remove_carcass set, when either bay has
    remove_bottom set (the flagged bay's back drops to the cabinet
    floor and so can't share a Z origin with its neighbours), or when
    finish_carcass differs (a finished bay's back is finish stock, so
    it splits off to leave its neighbours interior)."""
    if gap_index >= len(layout.mid_stiles):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    if not _epsilon_eq(bay_bottom_z(layout, gap_index),
                       bay_bottom_z(layout, gap_index + 1)):
        return False
    if not _epsilon_eq(bay_top_z(layout, gap_index),
                       bay_top_z(layout, gap_index + 1)):
        return False
    if not _epsilon_eq(bay_a['depth'], bay_b['depth']):
        return False
    if not _epsilon_eq(bay_a['bottom_rail_width'], bay_b['bottom_rail_width']):
        return False
    if bay_a.get('remove_carcass') or bay_b.get('remove_carcass'):
        return False
    if bay_a.get('remove_bottom') or bay_b.get('remove_bottom'):
        return False
    if bool(bay_a.get('finish_carcass')) != bool(bay_b.get('finish_carcass')):
        return False
    # A bay carrying its own back type gets its own panel: the applied
    # back is built one per segment, and a working front behind a bay
    # takes the carcass back away from that bay alone.
    if bay_back_condition(layout, gap_index) != bay_back_condition(
            layout, gap_index + 1):
        return False
    return True


def bay_back_condition(layout, bay_index):
    """The back type in force for one bay: its own if it carries one,
    otherwise the cabinet's."""
    bay = layout.bays[bay_index]
    own = bay.get('back_condition', 'DEFAULT')
    if own and own != 'DEFAULT':
        return own
    return layout.b_fin_end


def carcass_back_segments(layout):
    """Per-segment back panels.

    Same X span as the bottom segments (from mid division to mid division
    or carcass side). Z origin matches the bay's floor (top of bottom
    panel); vertical extent reaches up to the cabinet ceiling.
    """
    segments = []
    for start, end in _compute_segments(layout, _carcass_back_passthrough):
        first_bay = layout.bays[start]
        # Passthrough breaks at bays with remove_carcass, so flagged bays
        # arrive as (i, i) segments we drop.
        if first_bay.get('remove_carcass'):
            continue
        # A working face frame on this bay's back is a real front you
        # open, so the bay cannot be closed off behind it.
        if bay_back_condition(layout, start) == 'WORKING_FF':
            continue
        left_x, right_x = _segment_x_bounds(layout, start, end)
        # A FINISHED end is notched for the back (back_notch_depth), so
        # the outermost segments run PAST the side's inner face into the
        # notch instead of stopping at it. Only the segment that reaches
        # a cabinet end widens, and only on that end.
        if start == 0:
            left_x -= back_notch_depth(layout, 'LEFT')
        if end == layout.bay_count - 1:
            right_x += back_notch_depth(layout, 'RIGHT')
        if first_bay.get('remove_bottom'):
            # No bottom panel here. On a floor-standing carcass (NOTCH /
            # FLUSH base) the back wraps the missing bottom and toe-kick
            # area by dropping to the cabinet floor. But on a FLOATING
            # carcass (FLOATING / LOOSE / LOOSE_FLUSH base, or a per-bay
            # floating_bay - e.g. a lap drawer floated up on a tall kick)
            # the bay bottom IS the carcass underside, so the back must
            # follow the sides down to the bay bottom, NOT the room floor.
            # Mirrors the floating branch in side_bottom_z(). Gated on
            # has_toe_kick so uppers (toe_kick_type forced to FLOATING)
            # keep their box-bottom 0.0 origin.
            floating_carcass = layout.has_toe_kick and (
                layout.toe_kick_type in ('FLOATING', 'LOOSE', 'LOOSE_FLUSH')
                or first_bay.get('floating_bay'))
            if floating_carcass:
                z_origin = bay_bottom_z(layout, start)
            else:
                z_origin = 0.0
        else:
            z_origin = bay_bottom_z(layout, start) + first_bay['bottom_rail_width'] - layout.mt
        # Over-stool: the back runs FULL HEIGHT, following the extended
        # sides down to the leg bottoms so the open area below the box
        # is closed at the back.
        overstool_drop = side_extend_down(layout)
        if overstool_drop > 0.0:
            z_origin = bay_bottom_z(layout, start) - overstool_drop
        # Cabinet-level override: raise the back's bottom edge above
        # the default origin (refrigerator cabinet, etc.). Honored
        # only when it raises the panel - never lowers it. The > 0.0
        # guard matters: the default 0.0 means "no override", so it
        # must NOT clamp a legitimately negative z_origin up to the
        # cabinet floor. An upper bay taller than the cabinet box has
        # bottom_z < 0; its back has to drop with the bottom panel and
        # sides (which already do), otherwise the lower part of the
        # bay is left open at the back.
        if layout.back_bottom_inset > 0.0 and layout.back_bottom_inset > z_origin:
            z_origin = layout.back_bottom_inset
        # Per-bay back: segments break at depth changes (passthrough returns
        # False), so each segment's bays share a single depth -> use start
        # bay's depth to position the back at this bay group's back edge.
        back_y = -layout.dim_y + first_bay['depth']
        segments.append({
            'start_bay':       start,
            'end_bay':         end,
            'x':               left_x,
            'y':               back_y,
            'z':               z_origin,
            'horizontal_length': right_x - left_x,
            # A top that runs over the back stops the back below it.
            'vertical_length':   (carcass_top_z(layout, start) - z_origin
                                  - (top_thickness(layout)
                                     if (getattr(layout, 'top_over_back', False)
                                         or getattr(layout, 'floating_vanity',
                                                    False))
                                     and not layout.uses_stretchers else 0.0)),
            'thickness':       back_thickness(layout),
            # Segments break at finish boundaries, so the start bay
            # speaks for the whole panel.
            'finished':        bool(first_bay.get('finish_carcass')),
            'back_condition':  bay_back_condition(layout, start),
        })
    return segments


def applied_back_segments(layout):
    """Where the applied back panels go, one per stretch of bays that
    share a back type and a depth.

    The carcass back segments already break on everything that matters
    here - depth, floor and ceiling heights, and now the back type - so
    they are the spans the applied panels follow. A bay whose back is a
    working face frame has no carcass back at all, so its span is
    rebuilt from the bay bounds instead.

    Each entry carries the plane the panel sits on (``y``, the outer
    face of that stretch's back), its X span, its Z range and the
    condition to build. Only conditions that produce an applied panel
    are returned; the caller decides what to do with each.
    """
    # A bay-less product (a leg post) passes a minimal layout snapshot: it
    # has no carcass back for a panel to hang on, and every field below is
    # bay-derived. Nothing to build, so answer that directly rather than
    # raising partway through the caller's applied-panel pass.
    if not getattr(layout, "bays", None):
        return []
    out = []
    for start, end in _compute_segments(layout, _carcass_back_passthrough):
        first_bay = layout.bays[start]
        if first_bay.get('remove_carcass'):
            continue
        condition = bay_back_condition(layout, start)
        left_x, right_x = _segment_x_bounds(layout, start, end)
        # An applied back covers the cabinet's outer face, so a segment
        # reaching a cabinet end runs out to it rather than stopping at
        # the carcass side. With one segment this is the full-width span
        # the cabinet-wide panel has always used.
        if start == 0:
            left_x = 0.0
        if end == layout.bay_count - 1:
            right_x = layout.dim_x
        out.append({
            'start_bay':  start,
            'end_bay':    end,
            'condition':  condition,
            'x':          left_x,
            'right_x':    right_x,
            # Outer face of this stretch's back: the panel hangs on it.
            'y':          -layout.dim_y + first_bay['depth'],
            # Floor to cabinet top, as the cabinet-wide applied back has
            # always run - it covers the toe-kick band at the bottom.
            'z':          0.0,
            'top_z':      layout.dim_z,
            'width':      right_x - left_x,
        })
    return out


def _top_stretcher_passthrough(layout, gap_index):
    """True if a top stretcher spans uninterrupted across gap_index.

    Stretchers (front and rear) are placed per-bay at each bay's top
    edge. They merge across adjacent bays only when nothing about the
    geometry differs between the two bays.

    Break conditions:
    - bay top Z's differ (top_offset for uppers; kick + height for bases)
    - bay depths differ (front stretcher Y position depends on depth)
    - either bay has remove_carcass set
    """
    if gap_index >= len(layout.mid_stiles):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    if not _epsilon_eq(bay_top_z(layout, gap_index),
                       bay_top_z(layout, gap_index + 1)):
        return False
    if not _epsilon_eq(bay_a['depth'], bay_b['depth']):
        return False
    if bay_a.get('remove_carcass') or bay_b.get('remove_carcass'):
        return False
    return True


def carcass_top_segments(layout):
    """Per-segment SOLID carcass top panels for Upper / Tall cabinets.

    Bases and lap drawers use front + rear stretchers instead — see
    front_stretcher_segments / rear_stretcher_segments. This function
    produces a closed top panel sitting between the carcass sides /
    mid divisions, dropping with each bay's carcass_top_z.

    Geometry:
      - origin x: segment left_x (symmetric meeting at mid div inside faces)
      - origin y: -dim_y + bay.depth - bt  (front face of this bay's back panel)
      - origin z: carcass_top_z(start)  (= bay_top_z - top_scribe)
      - Length:  segment X span
      - Width:   bay.depth - bt - fft   (back-panel front face to
        face-frame back face; Mirror Y = True so width extends in -Y)
      - Thickness: mt   (Mirror Z = True so panel extends down by mt)
    """
    segments = []
    for start, end in _compute_segments(layout, _top_stretcher_passthrough):
        first_bay = layout.bays[start]
        if first_bay.get('remove_carcass'):
            continue
        left_x, right_x = _stretcher_x_bounds(layout, start, end)
        # Over the back, the top runs the full depth and lands on the
        # back panel's top edge; otherwise it butts its front face.
        if (getattr(layout, 'top_over_back', False)
                or getattr(layout, 'floating_vanity', False)):
            y = -layout.dim_y + first_bay['depth']
            panel_dim_y = first_bay['depth'] - layout.fft
        else:
            y = -layout.dim_y + first_bay['depth'] - back_thickness(layout)
            panel_dim_y = (first_bay['depth'] - back_thickness(layout)
                           - layout.fft)
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          left_x,
            'y':          y,
            'z':          carcass_top_z(layout, start),
            'length':     right_x - left_x,
            'panel_dim_y': panel_dim_y,
            'thickness':  top_thickness(layout),
        })
    return segments


def _front_stretcher_passthrough(layout, gap_index):
    """True if a FRONT top stretcher spans uninterrupted across gap_index.

    Everything that breaks the shared stretcher passthrough breaks the
    front one too, plus: either bay carrying a front_drop (sink /
    cooktop). A dropped front stretcher sits below the carcass top, so
    it terminates at the mid division's face (like the diff-depth case)
    instead of crossing through the division's top-front notch. The rear
    stretcher keeps the shared passthrough - it never drops.
    """
    if not _top_stretcher_passthrough(layout, gap_index):
        return False
    if (not _epsilon_eq(front_drop(layout, gap_index), 0.0)
            or not _epsilon_eq(front_drop(layout, gap_index + 1), 0.0)):
        return False
    return True


def front_stretcher_segments(layout):
    """Per-segment front-of-cabinet top stretchers.

    Sits just behind the face frame at each bay's top edge. Replaces
    the older solid carcass top with stretcher-based face frame
    construction (no closed top panel, just front + rear stretchers).
    A front-dropped bay (sink / cooktop) lowers its stretcher by the
    drop, tracking its dropped top rail.

    Geometry:
      - rotation: none (Cutpart with default axes)
      - origin x: segment left_x (= mt for the leftmost bay segment)
      - origin y: -dim_y + fft  (just behind the face frame)
      - origin z: carcass_top_z(start) - front_drop(start)
      - Length:  segment X span (right_x - left_x)
      - Width:   stretcher depth (Y axis, extends in +Y; Mirror Y = False)
      - Thickness: stretcher thickness (Z axis, extends in -Z; Mirror Z = True)
    """
    segments = []
    for start, end in _compute_segments(layout, _front_stretcher_passthrough):
        if layout.bays[start].get('remove_carcass'):
            continue
        left_x, right_x = _stretcher_x_bounds(layout, start, end)
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          left_x,
            'y':          -layout.dim_y + layout.fft,
            'z':          carcass_top_z(layout, start) - front_drop(layout, start),
            'length':     right_x - left_x,
            'width':      layout.stretcher_w,
            'thickness':  layout.stretcher_t,
        })
    return segments


def rear_stretcher_segments(layout):
    """Per-segment back-of-cabinet top stretchers.

    Sits just inside the carcass back panel, mirrored from the front
    stretcher. Same X bounds and Z origin as the front; differs only
    in Y position and Mirror Y direction.

    Geometry:
      - rotation: none
      - origin x: segment left_x
      - origin y: -bt  (just inside back panel)
      - origin z: carcass_top_z(start)  (held down by top_scribe)
      - Length:  segment X span
      - Width:   stretcher depth (Mirror Y = True so it extends in -Y)
      - Thickness: stretcher thickness (Mirror Z = True)
    """
    segments = []
    for start, end in _compute_segments(layout, _top_stretcher_passthrough):
        first_bay = layout.bays[start]
        if first_bay.get('remove_carcass'):
            continue
        left_x, right_x = _stretcher_x_bounds(layout, start, end)
        # Rear stretcher sits just inside the bay's back panel, so its Y
        # tracks the bay's back panel front face: -dim_y + bay_depth - bt.
        # Segment passthrough already breaks on depth change, so all bays
        # in a segment share a depth and the start bay drives Y.
        rear_y = -layout.dim_y + first_bay['depth'] - back_thickness(layout)
        segments.append({
            'start_bay':  start,
            'end_bay':    end,
            'x':          left_x,
            'y':          rear_y,
            'z':          carcass_top_z(layout, start),
            'length':     right_x - left_x,
            'width':      layout.stretcher_w,
            'thickness':  layout.stretcher_t,
        })
    return segments


# ---------------------------------------------------------------------------
# Mid division - the carcass partition behind each mid stile
# ---------------------------------------------------------------------------
def mid_division_notch_active(layout, gap_index):
    """Whether the slot-0 mid-div panel at this gap needs stretcher
    notches at its top-front and top-back corners. Only the same-depth
    single panel ever gets notches: differing depths produce two panels
    each ending under its own bay's stretcher segment, so nothing
    crosses the panel.

    True iff:
      - cabinet uses stretchers (Base / LapDrawer), and
      - bay depths match (single panel at this gap), and
      - the stretcher segment actually passes through this gap
        (matching heights, depths, rail widths)

    Gates the top-BACK notch (rear stretcher). The top-FRONT notch is
    gated separately (mid_division_front_notch_active): a front-dropped
    bay's stretcher terminates at the division face instead of crossing,
    so the front corner must stay uncut.
    """
    if not layout.uses_stretchers:
        return False
    if gap_index >= len(layout.mid_stiles):
        return False
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    if not _epsilon_eq(bay_a['depth'], bay_b['depth']):
        return False
    return _top_stretcher_passthrough(layout, gap_index)


def mid_division_front_notch_active(layout, gap_index):
    """Whether the slot-0 mid-div panel's top-FRONT stretcher notch is
    cut: the shared notch conditions PLUS the front stretcher actually
    crossing this gap (it stops at the division face when either bay
    has a front_drop)."""
    if not mid_division_notch_active(layout, gap_index):
        return False
    return _front_stretcher_passthrough(layout, gap_index)


def mid_division_floor_notch(layout, gap_index):
    """``(active, kick_height)`` for the front-bottom toe-kick notch on a
    mid division that runs to the floor.

    A division flanking a bay with its carcass removed becomes that
    void's side wall and drops to the floor, where it stands proud of
    the recessed kick beside it unless it is notched - the same cut a
    carcass side gets. A gap whose mid stile is itself dropped to the
    floor stays uncut: the stile already encloses the kick corner from
    the front (same reasoning as the side notch).

    The kick height comes from the neighbour that still builds a kick -
    the removed bay carries none. Inactive when neither does.
    """
    if not (layout.has_toe_kick and layout.toe_kick_type == 'NOTCH'):
        return (False, 0.0)
    if gap_index >= len(layout.mid_stiles):
        return (False, 0.0)
    if not _void_gap(layout, gap_index):
        return (False, 0.0)
    if layout.mid_stiles[gap_index].get('to_floor'):
        return (False, 0.0)
    for idx in (gap_index, gap_index + 1):
        if not _end_bay_drops_kick(layout, idx):
            return (True, layout.bays[idx]['kick_height'])
    return (False, 0.0)


def mid_division_panels(layout, gap_index):
    """Per-gap mid-division panel data.

    Returns a list of one or two panel dicts. Bay depths matching ->
    a single panel centered on the mid-stile. Bay depths differing ->
    two panels face-to-face at the mid-stile center, each sized to
    its own bay's depth.

    Each dict has:
      slot      - 0 (always present) or 1 (only when depths differ)
      bay_side  - 'CENTER', 'A' (bay_a's right wall), 'B' (bay_b's left wall)
      x, y, z   - origin position
      length    - vertical extent (top_z - bottom_z)
      width     - depth into cabinet (front-to-back), per its bay
      thickness - panel thickness (= layout.mt)
    """
    if gap_index >= len(layout.mid_stiles):
        return []
    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    ms = layout.mid_stiles[gap_index]

    # A neighbor bay with remove_carcass leaves an open void to the
    # floor; the surviving division becomes the void's side wall and
    # runs to the floor (kick and floor segments stop at its faces via
    # _void_gap).
    void_gap = _void_gap(layout, gap_index)

    center_x = _mid_div_center_x(layout, gap_index)
    dt = layout.division_thickness
    # When adjacent bay tops differ (top_offset change at this gap),
    # the partition extends an extra mt past the carcass top so it
    # sits flush with the top panel's top face instead of stopping at
    # its underside. Mirrors how the partition skin reaches the top
    # face of the shallower bay's top panel.
    tops_differ = not _epsilon_eq(
        bay_top_z(layout, gap_index),
        bay_top_z(layout, gap_index + 1),
    )

    def _panel_y(depth):
        # Mirror Y=True extends width in -Y; origin sits at the panel's
        # back face (= front face of carcass back panel). Width spans
        # forward to the face frame's back face.
        return -layout.dim_y + depth - back_thickness(layout)

    def _panel_width(depth):
        return depth - back_thickness(layout) - layout.fft

    def _bay_z_range(bay_idx):
        """Bottom and top Z of a single-bay mid-div panel: from this
        bay's bottom rail top to this bay's carcass top (with the
        construction-style adjustment + per-mid-stile extend amounts).

        remove_bottom on this bay drops the brw term so the panel's
        bottom matches the mid-stile's bottom (which itself drops by
        brw via bottom_rail_passthrough returning False)."""
        bay = layout.bays[bay_idx]
        brw_term = 0.0 if bay.get('remove_bottom') else bay['bottom_rail_width']
        bottom_z = (bay_bottom_z(layout, bay_idx)
                    + brw_term
                    - ms['extend_down_amount'])
        if ms.get('to_floor') or void_gap:
            bottom_z = 0.0
        top = carcass_top_z(layout, bay_idx)
        # Stretchers: division flush with stretcher tops for structural
        # attachment. Solid top: division stops mt below carcass top to
        # butt against the underside of the top panel.
        if layout.uses_stretchers or tops_differ:
            top_z = top + ms['extend_up_amount']
        else:
            top_z = top - layout.mt + ms['extend_up_amount']
        return bottom_z, top_z

    if _epsilon_eq(bay_a['depth'], bay_b['depth']):
        # One shared panel. Spans the union of the two bays' vertical
        # ranges - bottom = lower bay's floor (rail top), top = higher
        # carcass top - so the single wall covers both bays whatever
        # their heights.
        if bay_bottom_z(layout, gap_index) <= bay_bottom_z(layout, gap_index + 1):
            lower_idx = gap_index
        else:
            lower_idx = gap_index + 1
        # If either adjacent bay has remove_bottom, the mid-stile drops
        # by brw (rail-passthrough returns False); the shared division
        # panel follows so its bottom aligns with the mid-stile.
        either_remove_bottom = (bay_a.get('remove_bottom')
                                or bay_b.get('remove_bottom'))
        if either_remove_bottom:
            lower_brw = 0.0
        else:
            lower_brw = layout.bays[lower_idx]['bottom_rail_width']
        bottom_z = (bay_bottom_z(layout, lower_idx) + lower_brw
                    - ms['extend_down_amount'])
        if ms.get('to_floor') or void_gap:
            bottom_z = 0.0
        higher_top_z = max(carcass_top_z(layout, gap_index),
                           carcass_top_z(layout, gap_index + 1))
        if layout.uses_stretchers or tops_differ:
            top_z = higher_top_z + ms['extend_up_amount']
        else:
            top_z = higher_top_z - layout.mt + ms['extend_up_amount']
        # Mirror Z=True extends in +X from origin, so origin x = panel's
        # left face = center - dt/2.
        #
        # Bay-height STEP at this gap (mid_stile_notches, full overlay
        # only): the division becomes the void's finished surface. It
        # extends to the face frame's own extent on the stepped end (no
        # bottom-rail inset; the stile and panel bottoms align). The
        # flush-with-the-notch-plane shift lives in _mid_div_offset so
        # every face-keyed consumer follows; center_x already carries it.
        step_flush = None
        step_notches = mid_stile_notches(layout, gap_index)
        if step_notches:
            step_flush = step_notches[0]['side']
            for n in step_notches:
                if n['end'] == 'BOTTOM':
                    bottom_z = (bay_bottom_z(layout, lower_idx)
                                - ms['extend_down_amount'])
                    if ms.get('to_floor') or void_gap:
                        bottom_z = 0.0
                else:
                    top_z = (max(bay_top_z(layout, gap_index),
                                 bay_top_z(layout, gap_index + 1))
                             + ms['extend_up_amount'])
        return [{
            'slot':      0,
            'bay_side':  'CENTER',
            'x':         center_x - dt / 2.0,
            'y':         _panel_y(bay_a['depth']),
            'z':         bottom_z,
            'length':    top_z - bottom_z,
            'width':     _panel_width(bay_a['depth']),
            'thickness': dt,
            'step_flush': step_flush,
            # Stretcher notches at top-front + top-back of the panel.
            # Active when stretchers actually cross this gap; sized to
            # the stretcher's own width and thickness for a flush fit.
            # The front notch gates separately: a front-dropped bay's
            # stretcher ends at the panel face instead of crossing.
            'notch_active':       mid_division_notch_active(layout, gap_index),
            'notch_front_active': mid_division_front_notch_active(layout, gap_index),
            'notch_x':            layout.stretcher_t,
            'notch_y':            layout.stretcher_w,
            'notch_route_depth':  dt,
        }]

    # Two panels, face-to-face at center_x. Each is its own bay's
    # interior wall - sized to its own bay's depth AND height. Panel A
    # is bay A's right wall (left face at center_x - dt, right face at
    # center_x). Panel B is bay B's left wall (left face at center_x,
    # right face at center_x + dt).
    a_bottom_z, a_top_z = _bay_z_range(gap_index)
    b_bottom_z, b_top_z = _bay_z_range(gap_index + 1)
    if void_gap:
        # The removed bay contributes no wall of its own; the neighbor's
        # wall runs to the floor to finish the void's side.
        if bay_b.get('remove_carcass'):
            a_bottom_z = 0.0
        if bay_a.get('remove_carcass'):
            b_bottom_z = 0.0
    panels = [
        {
            'slot':      0,
            'bay_side':  'A',
            'x':         center_x - dt,
            'y':         _panel_y(bay_a['depth']),
            'z':         a_bottom_z,
            'length':    a_top_z - a_bottom_z,
            'width':     _panel_width(bay_a['depth']),
            'thickness': dt,
            # Diff-depth: each bay's stretcher segment terminates at its
            # own panel face, so nothing crosses - notches never apply.
            'notch_active':       False,
            'notch_x':            layout.stretcher_t,
            'notch_y':            layout.stretcher_w,
            'notch_route_depth':  dt,
        },
        {
            'slot':      1,
            'bay_side':  'B',
            'x':         center_x,
            'y':         _panel_y(bay_b['depth']),
            'z':         b_bottom_z,
            'length':    b_top_z - b_bottom_z,
            'width':     _panel_width(bay_b['depth']),
            'thickness': dt,
            'notch_active':       False,
            'notch_x':            layout.stretcher_t,
            'notch_y':            layout.stretcher_w,
            'notch_route_depth':  dt,
        },
    ]
    if bay_a.get('remove_carcass'):
        panels = [p for p in panels if p['bay_side'] != 'A']
    if bay_b.get('remove_carcass'):
        panels = [p for p in panels if p['bay_side'] != 'B']
    return panels


# ---------------------------------------------------------------------------
# Partition skin - filler at the bottom of the mid-division covering the
# mid-stile back-face overhang on the shallower bay's side when adjacent
# bays have different floors.
# ---------------------------------------------------------------------------
def partition_skin_panels(layout, gap_index):
    """Per-gap partition skins. Returns 0, 1, or 2 panel dicts.

    A skin is a filler attached to the partition on the shallower
    bay's side, covering the mid-stile back-face overhang where one
    bay's interior doesn't extend as far as the other's. Up to two
    skins emit per gap:

      slot 0 - bottom step: floors differ. Skin fills the X overhang
        in Z range from the deeper bay's floor up to the shallower
        bay's bottom panel underside (= floor + brw - mt).

      slot 1 - top step: tops differ. Only meaningful for cabinets
        with a solid top panel (Upper / Tall). Skin fills the X
        overhang in Z range from the shallower bay's top panel top
        face (= bay_top_z - top_scribe) up to the deeper bay's top.

    Thickness is the per-side overhang between the stile edge and the
    division's outer face (asymmetric when the division is offset; a
    flush side has zero overhang and drops its skins). Y wraps
    the back panel so origin sits at the bay's back-panel back face
    and width spans forward to the face frame's back face.
    """
    skins = []
    if gap_index >= len(layout.mid_stiles):
        return skins
    # A same-depth bay-height STEP is handled by the notched stile +
    # the flush finished division (mid_stile_notches / the step_flush
    # panel) -- the void surface IS the division, so no skin.
    if (_epsilon_eq(layout.bays[gap_index]['depth'],
                    layout.bays[gap_index + 1]['depth'])
            and mid_stile_notches(layout, gap_index)):
        return skins

    bay_a = layout.bays[gap_index]
    bay_b = layout.bays[gap_index + 1]
    msw = layout.mid_stiles[gap_index]['width']
    # Per-side FF overhang beyond the division's outer faces. Asymmetric
    # when the division is offset off the stile centerline; a side with
    # no overhang (flush) drops its skins via the filter at the return.
    stile_center = _mid_stile_center_x(layout, gap_index)
    left_thickness = (_mid_div_left_outer_x(layout, gap_index)
                      - (stile_center - msw / 2.0))
    right_thickness = ((stile_center + msw / 2.0)
                       - _mid_div_right_outer_x(layout, gap_index))
    if left_thickness <= 0.0 and right_thickness <= 0.0:
        return skins

    def _x_origin(side):
        if side == 'LEFT':
            return stile_center - msw / 2.0
        return _mid_div_right_outer_x(layout, gap_index)

    def _side_thickness(side):
        return left_thickness if side == 'LEFT' else right_thickness

    def _y_and_width(skin_bay):
        d = skin_bay['depth']
        return (-layout.dim_y + d, d - layout.fft)

    # A bay flagged floating raises its floor (kick_height holds the lift), so
    # the floors-differ step below would ALSO fire on the floating side and
    # overlap the slot-2 floating finish. When exactly one adjacent bay floats
    # (base / tall), slot 2 covers that side to the floor, so slot 0 is
    # suppressed for the gap.
    float_a = bool(bay_a.get('floating_bay'))
    float_b = bool(bay_b.get('floating_bay'))
    floating_finish = layout.has_toe_kick and (float_a != float_b)

    # ----- Slot 0: bottom step -----
    floor_a = bay_bottom_z(layout, gap_index)
    floor_b = bay_bottom_z(layout, gap_index + 1)
    if not _epsilon_eq(floor_a, floor_b) and not floating_finish:
        if floor_a > floor_b:
            side = 'LEFT'
            skin_bay_idx = gap_index
            bottom_z, top_z = floor_b, floor_a
        else:
            side = 'RIGHT'
            skin_bay_idx = gap_index + 1
            bottom_z, top_z = floor_a, floor_b
        skin_bay = layout.bays[skin_bay_idx]
        top_z += skin_bay['bottom_rail_width'] - layout.mt
        y, width = _y_and_width(skin_bay)
        skins.append({
            'slot':      0,
            'side':      side,
            'x':         _x_origin(side),
            'y':         y,
            'z':         bottom_z,
            'length':    top_z - bottom_z,
            'width':     width,
            'thickness': _side_thickness(side),
        })

    # ----- Slot 1: top step (Upper / Tall only - solid top panel) -----
    if layout.cabinet_type in {'UPPER', 'TALL'}:
        top_a = bay_top_z(layout, gap_index)
        top_b = bay_top_z(layout, gap_index + 1)
        if not _epsilon_eq(top_a, top_b):
            # Bay with the LOWER top is the shallower-at-top one.
            if top_a < top_b:
                side = 'LEFT'
                skin_bay_idx = gap_index
                lower_top, upper_top = top_a, top_b
            else:
                side = 'RIGHT'
                skin_bay_idx = gap_index + 1
                lower_top, upper_top = top_b, top_a
            skin_bay = layout.bays[skin_bay_idx]
            bottom_z = lower_top - layout.top_scribe
            top_z = upper_top
            y, width = _y_and_width(skin_bay)
            skins.append({
                'slot':      1,
                'side':      side,
                'x':         _x_origin(side),
                'y':         y,
                'z':         bottom_z,
                'length':    top_z - bottom_z,
                'width':     width,
                'thickness': _side_thickness(side),
            })

    # ----- Slot 2: floating-bay finish (base / tall) -----
    # A floating bay has no toe kick, so below its carcass bottom the mid-stile
    # back-face overhang is exposed to the floor on that bay's side. Drop a skin
    # to the floor to finish it; slot 0 is suppressed above so the two don't
    # overlap. (float_a / float_b / floating_finish are computed by the slot-0
    # block.) No skin when both bays float or on uppers (no kick zone).
    if floating_finish:
        if float_a:
            side = 'LEFT'
            skin_bay_idx = gap_index
        else:
            side = 'RIGHT'
            skin_bay_idx = gap_index + 1
        skin_bay = layout.bays[skin_bay_idx]
        top_z = (bay_bottom_z(layout, skin_bay_idx)
                 + skin_bay['bottom_rail_width'] - layout.mt)
        y, width = _y_and_width(skin_bay)
        skins.append({
            'slot':      2,
            'side':      side,
            'x':         _x_origin(side),
            'y':         y,
            'z':         0.0,
            'length':    top_z,
            'width':     width,
            'thickness': _side_thickness(side),
        })

    # A flush side has zero overhang - drop its skins.
    return [s for s in skins if s['thickness'] > 1e-6]


# ---------------------------------------------------------------------------
# Bay cage (the opening behind the face frame)
# ---------------------------------------------------------------------------
def _cage_x_bounds(layout, bay_index):
    """Carcass interior X bounds for a single bay - left face to right
    face of the cavity between sides / mid divisions.

    Differs from _segment_x_bounds in the stepped-cabinet case: the
    cage always stops at the mid division's near face from this bay's
    perspective, regardless of which neighbor's bottom panel passes
    under or over the division.
    """
    if bay_index == 0:
        left_x = carcass_inner_left_x(layout)
    else:
        left_x = _mid_div_right_outer_x(layout, bay_index - 1)
    if bay_index == layout.bay_count - 1:
        right_x = carcass_inner_right_x(layout)
    else:
        right_x = _mid_div_left_outer_x(layout, bay_index)
    return left_x, right_x


def bay_cage_position(layout, bay_index):
    """Origin of the bay cage in cabinet-local space.

    Cabinet mode: back-left-bottom corner of the carcass column for
    this bay - top of bottom panel, back face of face frame, inner
    face of left side / mid division.

    Panel mode: back-left-bottom corner of the face frame opening for
    this bay. X = bay's left FF edge. Y = back face of panel. Z = top
    of bottom rail.
    """
    bay = layout.bays[bay_index]
    if layout.cabinet_type == 'PANEL':
        x = bay_x_position(layout, bay_index)
        y = -layout.dim_y
        z = bay_bottom_z(layout, bay_index) + effective_bottom_rail_width(layout, bay_index)
        return (x, y, z)

    left_x, _ = _cage_x_bounds(layout, bay_index)
    z = bay_bottom_z(layout, bay_index) + effective_bottom_rail_width(layout, bay_index)
    # In angled mode the cage rotates around Z by face_frame_angle so
    # bay-local +X aligns with the FF direction. The anchor sits at
    # FF-distance left_x from the left endpoint on the FF inner plane;
    # opening cages stay at bay-local Y=0 and inherit the rotation, so
    # they land on the FF inner plane in world. ff_inner_world_pos
    # collapses to (left_x, -dim_y + fft, z) when not angled.
    return ff_inner_world_pos(layout, left_x, z)


def bay_cage_dims(layout, bay_index):
    """Dim X (width), Dim Y (depth back-to-front), Dim Z (height).

    Cabinet mode: cage spans the full carcass column behind the face
    frame for this bay - interior cavity, wider than the face frame
    opening on every axis to capture overlay door/drawer extents.

    Panel mode (cabinet_type == 'PANEL'): cage exactly matches the
    face frame opening rectangle. No carcass behind the frame, so no
    interior cavity to enclose. Y collapses to the panel's own depth.

    - X: between cabinet sides / adjacent mid divisions (cabinet) or
      between this bay's stiles (panel)
    - Y: bay depth minus fft minus bt (cabinet) or full panel depth
      (panel)
    - Z: top of bottom panel to underside of top construction
      (cabinet) or face frame opening height (panel)
    """
    bay = layout.bays[bay_index]
    if layout.cabinet_type == 'PANEL':
        ff_opening_height = (
            bay['height'] - bay['top_rail_width']
            - effective_bottom_rail_width(layout, bay_index)
        )
        return (bay['width'], layout.dim_y, ff_opening_height)

    left_x, right_x = _cage_x_bounds(layout, bay_index)
    cage_dim_x = right_x - left_x
    cage_dim_y = bay['depth'] - layout.fft - back_thickness(layout)
    if layout.angled_multi:
        # An angled end bay's cage is rotated by its front angle, so its
        # X span along the rotated axis must be the PLANE length of the
        # world-X cavity span (1/cos longer) to still reach the mid
        # division. Square (middle) bays get theta = 0 -> unchanged.
        theta = bay_front_angle(layout, bay_index)
        if abs(theta) > 1e-9:
            cos_t = math.cos(theta)
            cage_dim_x /= cos_t
            # Depth: the rotated cage extends its local +Y from the
            # angled FF inner plane; keep every back corner at (or in
            # front of) the bay's carcass back plane so the interior
            # (drawer boxes, shelves, opening cages) doesn't poke out
            # of the cabinet. The binding corner is the SHALLOW end of
            # the angled plane.
            y_front_l = ff_perpendicular_offset_at_world_x(
                layout, left_x, layout.fft, 0.0)[1]
            y_front_r = ff_perpendicular_offset_at_world_x(
                layout, right_x, layout.fft, 0.0)[1]
            back_y = -layout.dim_y + bay['depth'] - back_thickness(layout)
            cage_dim_y = max(
                0.0, (back_y - max(y_front_l, y_front_r)) / cos_t)
    top_thickness = layout.stretcher_t if layout.uses_stretchers else layout.mt
    cage_top_z = carcass_top_z(layout, bay_index) - top_thickness
    cage_bottom_z = bay_bottom_z(layout, bay_index) + effective_bottom_rail_width(layout, bay_index)
    cage_dim_z = cage_top_z - cage_bottom_z
    return (cage_dim_x, cage_dim_y, cage_dim_z)


def bay_opening_center_x(layout, bay_index):
    """Cabinet-local X of a bay's FACE FRAME OPENING center - midway
    between the inner edges of the bay's bounding stiles (the end stiles
    for the outer bays, mid stiles between).

    This differs from the bay cage center (``bay_cage_position`` +
    ``bay_cage_dims`` / 2), which tracks the carcass interior and so
    shifts with scribe / finished-end / side-thickness conditions. A
    symmetric face frame yields the cabinet midpoint here regardless of
    an asymmetric end condition, so a sink centerline dimensioned to this
    reads the opening the basin actually sits in, not the scribe-shifted
    cavity midpoint.
    """
    ff_len = face_frame_length(layout)
    last = layout.bay_count - 1
    # Left bounding stile inner (right-facing) edge, FF-local X.
    if bay_index <= 0:
        left_inner = layout.lsw
    else:
        gap = bay_index - 1
        left_inner = ((_mid_stile_center_x(layout, gap) - layout.ff_inset_left)
                      + layout.mid_stiles[gap]['width'] / 2.0)
    # Right bounding stile inner (left-facing) edge, FF-local X.
    if bay_index >= last:
        right_inner = ff_len - layout.rsw
    else:
        gap = bay_index
        right_inner = ((_mid_stile_center_x(layout, gap) - layout.ff_inset_left)
                       - layout.mid_stiles[gap]['width'] / 2.0)
    # Back to cabinet-local X (the FF plane starts at ff_inset_left).
    return (left_inner + right_inner) / 2.0 + layout.ff_inset_left


# ---------------------------------------------------------------------------
# Opening cage (the face frame opening; child of a bay cage)
# ---------------------------------------------------------------------------
# Each bay starts with a single opening filling its face frame opening.
# Splitter operations subdivide a bay by adding more openings.
# ---------------------------------------------------------------------------
# Bay opening tree walk
#
# bay_openings(layout, bay_index) is the entry point: it walks the
# bay's tree of openings and split nodes (snapshotted into
# layout.bays[i]['tree']) and returns one rect per LEAF opening.
#
# Each rect carries the cage geometry (position + dimensions in
# bay-local coords), the four reveals (distance from cage edge to face
# frame opening edge on each side), and the leaf's identity
# (obj_name, opening_index) so the type-side reconciliation can match
# leaves back to live Blender objects.
#
# A reveal of 0 on a side means the cage edge is flush with the face
# frame opening edge on that side - which happens whenever a face
# frame member sits flush against a panel boundary (top of bottom rail
# = top of bottom panel; mid rail edges = sub-opening cage edges).
# Non-zero reveals come from members whose width exceeds the adjacent
# panel thickness (top rail wider than the carcass top thickness) or
# from stiles wider than the side panel thickness.
# ---------------------------------------------------------------------------
def _bay_root_reveals(layout, bay_index):
    """Reveals on each side of the bay's full cage rect, from the bay's
    perimeter face frame (top rail, bottom rail, end stile, mid div).
    These are inherited downward through the tree on edges that touch
    the bay's perimeter; internal split boundaries reset reveals to 0
    on the perpendicular side because a mid rail / mid stile edge is
    flush with its neighboring sub-cage's edge.

    Panel mode: cage already matches the face frame opening, so all
    perimeter reveals are zero.
    """
    if layout.cabinet_type == 'PANEL':
        return {'top': 0.0, 'bottom': 0.0, 'left': 0.0, 'right': 0.0}

    bay = layout.bays[bay_index]
    cage_left_x, cage_right_x = _cage_x_bounds(layout, bay_index)
    # Cage bounds are world; bay_x_position is FF-local. Convert to
    # world so the reveal subtractions don't mix coordinate systems.
    ff_opening_left_x = (bay_x_position(layout, bay_index)
                         + layout.ff_inset_left)
    ff_opening_right_x = ff_opening_left_x + bay['width']

    _, _, cage_dim_z = bay_cage_dims(layout, bay_index)
    # bay.height now spans floor to top of top rail, so subtracting just
    # the rails leaves both the FF opening AND the kick recess. Subtract
    # kick_height too so the result is the FF opening only. Uppers carry
    # kick_height = 0 so this is a no-op there. A front_drop (sink /
    # cooktop) lowers the top rail, so the opening below it shrinks by
    # the same amount.
    ff_opening_height = (
        bay['height']
        - bay['top_rail_width']
        - effective_bottom_rail_width(layout, bay_index)
        - bay['kick_height']
        - front_drop(layout, bay_index)
    )

    reveal_left = ff_opening_left_x - cage_left_x
    reveal_right = cage_right_x - ff_opening_right_x
    if layout.angled_multi:
        # The angled end bay's cage X axis runs along the bay's front
        # plane (see bay_cage_dims), so the X reveals - world-X spans -
        # convert to plane lengths too. Opening width then comes out to
        # bay_width / cos(theta): the FF opening measured along the
        # angled plane. Square bays: theta = 0, no-op.
        theta = bay_front_angle(layout, bay_index)
        if abs(theta) > 1e-9:
            reveal_left /= math.cos(theta)
            reveal_right /= math.cos(theta)
    return {
        'top':    cage_dim_z - ff_opening_height,
        'bottom': 0.0,
        'left':   reveal_left,
        'right':  reveal_right,
    }


# A vanity door zone (SIZE_ROLE 'VANITY_DOOR') always lands this much
# wider than the sibling it shares its split with: the extra is taken
# out of the pool before shares are computed, so with one door beside
# one drawer stack the door ends up share + 2" and the stack share - 2".
# Must match the rule in types_face_frame._redistribute_split_node.
VANITY_DOOR_EXTRA_WIDTH = inch(4.0)


def _redistribute_sizes(children, available, splitter_total):
    """Distribute `available` along children; siblings with unlock_size
    hold their stored value, the rest evenly share the remainder. This
    is the same algorithm as _distribute_bay_widths, just running over
    a tree node's children instead of the cabinet's bays.

    `splitter_total` is the SUM of all splitter member widths in this
    node (members may differ now that each can hold its own width), so
    the caller passes the total rather than count * uniform width.

    An unlocked child carrying size_role 'VANITY_DOOR' takes its share
    plus VANITY_DOOR_EXTRA_WIDTH, the extra deducted from the pool, so
    the door stays that much wider than its siblings through resizes.
    A locked vanity door holds its stored value like any locked child.
    """
    consumed_by_splitters = splitter_total
    locked_total = sum(
        c['size'] for c in children if c['unlock_size']
    )
    unlocked = [c for c in children if not c['unlock_size']]
    extra_total = sum(
        VANITY_DOOR_EXTRA_WIDTH for c in unlocked
        if c.get('size_role') == 'VANITY_DOOR'
    )
    remainder = available - consumed_by_splitters - locked_total
    share = ((remainder - extra_total) / len(unlocked)) if unlocked else 0.0
    sizes = []
    for c in children:
        if c['unlock_size']:
            sizes.append(c['size'])
        elif c.get('size_role') == 'VANITY_DOOR':
            sizes.append(share + VANITY_DOOR_EXTRA_WIDTH)
        else:
            sizes.append(share)
    return sizes


# Backing kind is implied by the split's axis: H-splits (mid rails)
# always get a shelf, V-splits (mid stiles) always get a division.
_AXIS_TO_BACKING_ROLE = {
    'H': 'BAY_SHELF',
    'V': 'BAY_DIVISION',
}


def _backing_removed(node, splitter_index):
    """True when this one splitter's carcass backing was dropped from
    the right-click menu. Per-member, so a single shelf can come out of
    a stack without disturbing its siblings."""
    flags = node.get('splitter_backing_removes') or ()
    return 0 <= splitter_index < len(flags) and bool(flags[splitter_index])


def _backing_thickness_for_role(layout, role):
    """Material thickness for a carcass backing. Divisions match the
    cabinet's standard carcass material thickness; shelves are fixed at
    3/4" per HB5 carcass conventions."""
    if role == 'BAY_DIVISION':
        return layout.mt
    if role == 'BAY_SHELF':
        return inch(0.75)
    return 0.0


def _emit_h_splitter(node, cage_x, cage_z, cage_dim_x, cage_dim_y, cage_dim_z,
                     reveals, splitter_top_z, splitter_bottom_z,
                     splitter_index, splitter_w, layout, splitters, backings,
                     as_bottom_rail=False):
    """Append the mid rail rect for an H-split between two consecutive
    children, plus the matching backing rect if backing_kind isn't
    NONE. All coords are BAY-local. `splitter_w` is this member's own
    width (per-index; the caller resolves the override / scalar).

    `as_bottom_rail` flags the lowest framed rail of a remove_bottom bay
    (see _walk_tree); the rect still routes through the mid-rail builder,
    which tags the part BOTTOM_RAIL instead of BAY_MID_RAIL."""
    ff_left_x = cage_x + reveals['left']
    ff_width = cage_dim_x - reveals['left'] - reveals['right']
    # Cabinet: bay cage origin sits at the back of the face frame, so a
    # mid splitter (a face-frame member) lives one fft in -Y from the
    # origin to land in the FF plane. Panel: bay cage origin sits at
    # the panel's front face and the cage spans the full panel depth,
    # so the splitter sits at bay-local y=0 to land flush with the
    # panel's front face.
    splitter_y = _ff_front_y_bay_local(layout)
    splitters.append({
        'role':            'BAY_MID_RAIL',
        'as_bottom_rail':  as_bottom_rail,
        'split_node_name': node['obj_name'],
        'splitter_index':  splitter_index,
        'x':               ff_left_x,
        'y':               splitter_y,
        'z':               splitter_bottom_z,
        'length':          ff_width,
        'splitter_width':  splitter_w,
        'thickness':       layout.fft,
    })
    if not node.get('add_backing', False):
        return
    if _backing_removed(node, splitter_index):
        return
    role = _AXIS_TO_BACKING_ROLE['H']
    bt_thickness = _backing_thickness_for_role(layout, role)
    # cage_dim_y comes in as a parameter (bay-uniform); was previously
    # recomputed from layout.dim_y, which broke for varying bay depths.
    # Backing's TOP face flush with mid rail's TOP edge; backing
    # thickness extends downward from there. Length spans the full
    # carcass interior X (parent cage_dim_x), Width spans full carcass
    # depth, Thickness = backing_thickness on Z.
    backings.append({
        'role':            role,
        'split_node_name': node['obj_name'],
        'splitter_index':  splitter_index,
        'axis':            'H',
        'x':               cage_x,
        'y':               0.0,
        'z':               splitter_top_z - bt_thickness,
        'length':          cage_dim_x,
        'width':           cage_dim_y,
        'thickness':       bt_thickness,
    })


def _emit_v_splitter(node, cage_x, cage_z, cage_dim_x, cage_dim_y, cage_dim_z,
                     reveals, splitter_left_x, splitter_index, splitter_w,
                     layout, splitters, backings):
    """Append the mid stile rect for a V-split between two consecutive
    children, plus the matching backing rect if backing_kind isn't
    NONE. All coords are BAY-local. `splitter_w` is this member's own
    width (per-index; the caller resolves the override / scalar)."""
    ff_bottom_z = cage_z + reveals['bottom']
    ff_height = cage_dim_z - reveals['top'] - reveals['bottom']
    # See _emit_h_splitter for the cabinet vs panel y rationale.
    splitter_y = _ff_front_y_bay_local(layout)
    splitters.append({
        'role':            'BAY_MID_STILE',
        'split_node_name': node['obj_name'],
        'splitter_index':  splitter_index,
        'x':               splitter_left_x,
        'y':               splitter_y,
        'z':               ff_bottom_z,
        'length':          ff_height,
        'splitter_width':  splitter_w,
        'thickness':       layout.fft,
    })
    if not node.get('add_backing', False):
        return
    if _backing_removed(node, splitter_index):
        return
    role = _AXIS_TO_BACKING_ROLE['V']
    bt_thickness = _backing_thickness_for_role(layout, role)
    # cage_dim_y comes in as a parameter (bay-uniform); was previously
    # recomputed from layout.dim_y, which broke for varying bay depths.
    # Vertical division centered on the mid stile (X-wise). Spans full
    # carcass interior Z (parent cage_dim_z) and full depth.
    stile_center_x = splitter_left_x + splitter_w / 2.0
    backing_left_x = stile_center_x - bt_thickness / 2.0
    backings.append({
        'role':            role,
        'split_node_name': node['obj_name'],
        'splitter_index':  splitter_index,
        'axis':            'V',
        'x':               backing_left_x,
        'y':               0.0,
        'z':               cage_z,
        'length':          cage_dim_z,
        'width':           cage_dim_y,
        'thickness':       bt_thickness,
    })


def _child_overlay(child, side, default):
    """Resolved overlay on one side of a child node. Leaves carry their
    own snapshotted overlays; a nested split node has none, so the
    cabinet default is used. Feeds the removed-mid-rail gap collapse."""
    if child.get('kind') == 'leaf':
        return child.get('overlay_' + side, default)
    return default


# Frontless bottom-opening front types: openings that carry no door/drawer
# front and run open to the kick (the front-leaf builder emits no leaf for
# either). When such an opening is the bottom-most child of a remove_bottom
# bay, the splitter capping it is the lowest framed rail and is built as a
# real BOTTOM_RAIL. APPLIANCE (e.g. a refrigerator opening) is frontless
# alongside NONE -- it just adds its own filler stiles.
_FRONTLESS_FRONT_TYPES = frozenset({'NONE', 'APPLIANCE'})


def _walk_tree(node, layout, bay_index,
               cage_x, cage_z, cage_dim_x, cage_dim_y, cage_dim_z,
               reveals, leaves, splitters, backings,
               is_bay_root=False):
    """Recursively descend a tree node. Emits leaf rects, splitter
    rects (mid rails / mid stiles), and backing rects (divisions /
    shelves) into the three lists provided by the caller.

    ``is_bay_root`` is True only for the bay's top-level node. When the
    bay drops its bottom rail (remove_bottom) AND its bottom-most child is
    a frontless opening (front_type in _FRONTLESS_FRONT_TYPES -- NONE or
    APPLIANCE, an appliance / open-shelf zone that runs open to the kick,
    e.g. a refrigerator cabinet), the splitter
    capping it is the lowest framed rail, so it is emitted as a real
    BOTTOM_RAIL (sized to the bay's bottom_rail_width) rather than a mid
    rail. A bottom opening WITH a front (stacked doors, drawers, pullout)
    keeps a true mid rail between the two fronts -- otherwise the rail
    width/role shift would collide the two fronts. Only fires at the bay
    root H-split, where the bottom-most child reaches the bay bottom."""
    if node['kind'] == 'leaf':
        leaves.append({
            'obj_name':       node['obj_name'],
            'opening_index':  node.get('opening_index', 0),
            'cage_x':         cage_x,
            'cage_z':         cage_z,
            'cage_dim_x':     cage_dim_x,
            # cage_dim_y is bay-uniform; threaded down from bay_openings
            # so interior items size to the bay's depth, not the
            # cabinet's overall dim_y.
            'cage_dim_y':     cage_dim_y,
            'cage_dim_z':     cage_dim_z,
            'reveal_top':     reveals['top'],
            'reveal_bottom':  reveals['bottom'],
            'reveal_left':    reveals['left'],
            'reveal_right':   reveals['right'],
        })
        return

    children = node['children']
    if not children:
        return
    n_children = len(children)
    n_splitters = n_children - 1
    splitter_w = node['splitter_width']
    # Per-splitter widths (member i uses eff_widths[i]); fall back to a
    # uniform list for snapshots predating the per-index field. Each
    # member can differ now, so consumption is the sum, not count * w.
    widths = node.get('splitter_widths')
    if not widths or len(widths) != n_splitters:
        widths = [splitter_w] * n_splitters
    removes = node.get('splitter_removes')
    if not removes or len(removes) != n_splitters:
        removes = [False] * n_splitters

    # A removed mid rail (H-split member) emits NO face-frame member and
    # NO backing; its splitter space collapses so the two overlay fronts
    # sit MID_RAIL_REMOVED_GAP apart. front_gap = space - ov_above -
    # ov_below, so space = gap + ov_above + ov_below. Removal is H-only
    # (mid rails); a V-split mid stile ignores the flag (members stay).
    eff_widths = list(widths)
    # When the bay drops its bottom rail and the bottom-most child runs
    # open to the kick, the LAST root H-split splitter is the lowest
    # framed rail -> build it as a BOTTOM_RAIL (sized to the bay's
    # bottom_rail_width) instead of a mid rail. Set the width here, before
    # splitter_total, so the layout math and the emitted rail agree.
    bottom_rail_splitter_index = None
    if node['axis'] == 'H':
        for i in range(n_splitters):
            if removes[i]:
                ov_above = _child_overlay(children[i], 'bottom',
                                          layout.default_bottom_overlay)
                ov_below = _child_overlay(children[i + 1], 'top',
                                          layout.default_top_overlay)
                eff_widths[i] = MID_RAIL_REMOVED_GAP + ov_above + ov_below
        bay = layout.bays[bay_index]
        if (is_bay_root and n_splitters >= 1
                and bay.get('remove_bottom')
                and children[-1].get('kind') == 'leaf'
                and children[-1].get('front_type') in _FRONTLESS_FRONT_TYPES
                and not removes[n_splitters - 1]):
            bottom_rail_splitter_index = n_splitters - 1
            brw = bay.get('bottom_rail_width') or 0.0
            if brw > 0:
                eff_widths[bottom_rail_splitter_index] = brw
    # For size distribution a removed rail still consumes its FULL width
    # from the pool; the freed space (full width minus the collapsed gap)
    # is handed to the two adjacent openings below, half each. Without
    # this the freed space went to whichever siblings were unlocked --
    # and silently vanished when every sibling held a typed size, so the
    # opening dims never summed back to the cabinet height.
    dist_widths = list(eff_widths)
    if node['axis'] == 'H':
        for i in range(n_splitters):
            if removes[i]:
                dist_widths[i] = widths[i]
    splitter_total = sum(dist_widths)

    if node['axis'] == 'H':
        ff_avail_z = cage_dim_z - reveals['top'] - reveals['bottom']
        sizes = _redistribute_sizes(
            children, ff_avail_z, splitter_total
        )
        for i in range(n_splitters):
            if removes[i]:
                freed = dist_widths[i] - eff_widths[i]
                if freed > 0:
                    sizes[i] += freed / 2.0
                    sizes[i + 1] += freed / 2.0
        ff_opening_top_z = cage_z + cage_dim_z - reveals['top']
        cur_z_top = ff_opening_top_z
        for i, child in enumerate(children):
            child_size = sizes[i]
            child_ff_bottom_z = cur_z_top - child_size
            child_reveal_top = reveals['top'] if i == 0 else 0.0
            child_reveal_bottom = reveals['bottom'] if i == n_children - 1 else 0.0
            child_cage_top_z = cur_z_top + child_reveal_top
            child_cage_bottom_z = child_ff_bottom_z - child_reveal_bottom
            child_cage_dim_z = child_cage_top_z - child_cage_bottom_z

            child_reveals = {
                'top':    child_reveal_top,
                'bottom': child_reveal_bottom,
                'left':   reveals['left'],
                'right':  reveals['right'],
            }
            _walk_tree(
                child, layout, bay_index,
                cage_x=cage_x,
                cage_z=child_cage_bottom_z,
                cage_dim_x=cage_dim_x,
                cage_dim_y=cage_dim_y,
                cage_dim_z=child_cage_dim_z,
                reveals=child_reveals,
                leaves=leaves, splitters=splitters, backings=backings,
            )
            if i < n_children - 1:
                # Mid rail sits below this child's FF bottom edge. A removed
                # member emits nothing (no rail, no backing) - only the
                # collapsed gap is consumed so the fronts land 3/32" apart.
                w_i = eff_widths[i]
                if not removes[i]:
                    splitter_top_z = child_ff_bottom_z
                    splitter_bottom_z = splitter_top_z - w_i
                    _emit_h_splitter(
                        node, cage_x, cage_z, cage_dim_x, cage_dim_y, cage_dim_z,
                        reveals, splitter_top_z, splitter_bottom_z,
                        splitter_index=i, splitter_w=w_i, layout=layout,
                        splitters=splitters, backings=backings,
                        as_bottom_rail=(i == bottom_rail_splitter_index),
                    )
                cur_z_top = child_ff_bottom_z - w_i
    else:
        ff_avail_x = cage_dim_x - reveals['left'] - reveals['right']
        sizes = _redistribute_sizes(
            children, ff_avail_x, splitter_total
        )
        ff_opening_left_x = cage_x + reveals['left']
        cur_x_left = ff_opening_left_x
        for i, child in enumerate(children):
            child_size = sizes[i]
            child_ff_right_x = cur_x_left + child_size
            child_reveal_left = reveals['left'] if i == 0 else 0.0
            child_reveal_right = reveals['right'] if i == n_children - 1 else 0.0
            child_cage_left_x = cur_x_left - child_reveal_left
            child_cage_right_x = child_ff_right_x + child_reveal_right
            child_cage_dim_x = child_cage_right_x - child_cage_left_x

            child_reveals = {
                'top':    reveals['top'],
                'bottom': reveals['bottom'],
                'left':   child_reveal_left,
                'right':  child_reveal_right,
            }
            _walk_tree(
                child, layout, bay_index,
                cage_x=child_cage_left_x,
                cage_z=cage_z,
                cage_dim_x=child_cage_dim_x,
                cage_dim_y=cage_dim_y,
                cage_dim_z=cage_dim_z,
                reveals=child_reveals,
                leaves=leaves, splitters=splitters, backings=backings,
            )
            if i < n_children - 1:
                w_i = eff_widths[i]
                splitter_left_x = child_ff_right_x
                _emit_v_splitter(
                    node, cage_x, cage_z, cage_dim_x, cage_dim_y, cage_dim_z,
                    reveals, splitter_left_x,
                    splitter_index=i, splitter_w=w_i, layout=layout,
                    splitters=splitters, backings=backings,
                )
                cur_x_left = child_ff_right_x + w_i


def bay_openings(layout, bay_index):
    """Walk one bay's tree and return its parts.

    Returns a dict with three lists in BAY-local coords:
      - 'leaves':    opening rects (cage geometry + reveals + identity)
      - 'splitters': mid rail / mid stile rects (face frame members
                     between consecutive children of each split node)
      - 'backings':  division / shelf rects (carcass-deep panels behind
                     each splitter, only present when the split's
                     backing_kind is SHELF or DIVISION)

    With no splits in the bay's tree the result is a single leaf and
    empty splitter / backing lists - same as the pre-tree behavior.
    """
    bay = layout.bays[bay_index]
    tree = bay.get('tree')
    empty = {'leaves': [], 'splitters': [], 'backings': []}
    if tree is None:
        return empty
    cage_dim_x_, cage_dim_y_, cage_dim_z_ = bay_cage_dims(layout, bay_index)
    leaves, splitters, backings = [], [], []
    _walk_tree(
        tree, layout, bay_index,
        cage_x=0.0, cage_z=0.0,
        cage_dim_x=cage_dim_x_, cage_dim_y=cage_dim_y_, cage_dim_z=cage_dim_z_,
        reveals=_bay_root_reveals(layout, bay_index),
        leaves=leaves, splitters=splitters, backings=backings,
        is_bay_root=True,
    )
    # Stamp the leaves that sit against a FULL-overlay blind corner
    # stile: only the edge bay's edge leaf pulls its front back to the
    # corner overlay (interior leaves face mid stiles, not the corner).
    if layout.corner_overlay_left or layout.corner_overlay_right:
        last = layout.bay_count - 1
        for r in leaves:
            if (layout.corner_overlay_left and bay_index == 0
                    and r['cage_x'] <= 1e-6):
                r['corner_left'] = True
            if (layout.corner_overlay_right and bay_index == last
                    and r['cage_x'] + r['cage_dim_x'] >= cage_dim_x_ - 1e-6):
                r['corner_right'] = True
    return {'leaves': leaves, 'splitters': splitters, 'backings': backings}


def opening_ff_sizes(cabinet_obj):
    """{opening object name: (width, height)} of the CLEAR FACE FRAME
    opening -- what you could pass through the front of the cabinet.

    Not the same as the opening cage, which spans the carcass cavity and
    runs behind the stiles and rails: a 10" bay hands back an 11-1/2"
    cage. Anything asking whether something FITS -- an accessory against
    its minimum opening width, a report, a checker -- wants this number,
    and getting it means building the layout, which is why it is worth
    having in one place rather than in each caller.

    Builds one FaceFrameLayout for the whole cabinet, so ask once per
    cabinet and read the map, rather than calling this per opening.
    Returns {} for anything that is not a face frame cabinet.
    """
    sizes = {}
    try:
        layout = FaceFrameLayout(cabinet_obj)
    except Exception:
        return sizes
    for bay_index in range(len(layout.bays)):
        try:
            leaves = bay_openings(layout, bay_index).get('leaves', [])
        except Exception:
            continue
        for leaf in leaves:
            name = leaf.get('obj_name')
            if not name:
                continue
            sizes[name] = (
                leaf['cage_dim_x'] - leaf['reveal_left'] - leaf['reveal_right'],
                leaf['cage_dim_z'] - leaf['reveal_top'] - leaf['reveal_bottom'],
            )
    return sizes


# ---------------------------------------------------------------------------
# Compatibility wrappers - thin shims that route through bay_openings.
# Kept so existing callers (and any external tools) don't break; new
# code should consume bay_openings() directly.
# ---------------------------------------------------------------------------
def opening_count(layout, bay_index):
    return len(bay_openings(layout, bay_index)['leaves'])


def opening_position(layout, bay_index, opening_index):
    leaves = bay_openings(layout, bay_index)['leaves']
    if opening_index >= len(leaves):
        return (0.0, 0.0, 0.0)
    r = leaves[opening_index]
    return (r['cage_x'], 0.0, r['cage_z'])


def opening_dims(layout, bay_index, opening_index):
    leaves = bay_openings(layout, bay_index)['leaves']
    cage_dim_y = bay_cage_dims(layout, bay_index)[1]
    if opening_index >= len(leaves):
        return (0.0, cage_dim_y, 0.0)
    r = leaves[opening_index]
    return (r['cage_dim_x'], cage_dim_y, r['cage_dim_z'])


# ---------------------------------------------------------------------------
# Door / drawer front geometry (children of opening cage)
# ---------------------------------------------------------------------------
def resolved_overlay(cab_props, opening_props, side):
    """Return the effective overlay for one side of an opening.

    side is one of 'top', 'bottom', 'left', 'right'. If the opening
    unlocks that side, its own value wins; otherwise the cabinet-level
    default is used.
    """
    if getattr(opening_props, f'unlock_{side}_overlay'):
        return getattr(opening_props, f'{side}_overlay')
    return getattr(cab_props, f'default_{side}_overlay')


# Side overlay a front takes against a FULL-overlay blind corner stile:
# pulled back from the style's full side overlay so the applied overlay
# stile fits in front of the frame stile with a 1/4" reveal to the door
# (corner detail: 3.5" frame stiles, mitered overlay stiles, 1/4"
# reveal). See bay_openings for the corner_left/right rect stamps.
FULL_CORNER_SIDE_OVERLAY = inch(0.25)


def front_overlay(rect, cab_props, opening_props, side):
    """resolved_overlay plus the FULL-overlay corner pullback: a front
    whose rect is stamped corner_left/right takes the corner overlay on
    that side (an explicit per-opening unlock still wins)."""
    if (side in ('left', 'right') and rect.get(f'corner_{side}')
            and not getattr(opening_props, f'unlock_{side}_overlay')):
        return FULL_CORNER_SIDE_OVERLAY
    return resolved_overlay(cab_props, opening_props, side)



# Construction constants for visual open state. Cabinet-level
# customization can come later; for now the values match typical
# residential hinge / slide hardware.
#
# A door stops square. Hinges open further than that on the bench, but
# a door only reaches it with nothing beside it - and in a run there
# always is something: the next door, a return wall, an appliance. Past
# 90 degrees a door leans back across its own hinge line and into that
# neighbour, which is what made doors swing through walls and through
# each other. Square is the last angle that is true everywhere, and
# together with the hinge barrel sitting on the door's front face
# (_hinge_barrel_pivot) it guarantees no part of a door ever crosses
# the line it hangs on.
DOOR_MAX_SWING_ANGLE = math.radians(90.0)
DOUBLE_DOOR_REVEAL = inch(0.125)
# Inset doors butt closer than overlay doors where a pair meets.
INSET_DOUBLE_DOOR_REVEAL = inch(0.0625)   # 1/16"
# Front-to-front reveal left when a mid rail is removed between two
# (typically drawer) openings. The split is kept but the face-frame
# member + its backing are dropped; the solver collapses the splitter
# space to this gap plus the two adjacent overlays so the fronts sit
# this far apart. See _walk_tree.
MID_RAIL_REMOVED_GAP = inch(0.09375)   # 3/32"
TRIVIEW_DOOR_REVEAL = inch(0.125)   # gap where adjacent mirror doors meet
TRIVIEW_FRAME_WIDTH = inch(1.25)    # tri-view stile / rail width (spec default)
# Forward offset of door / drawer front from the face frame face.
# Mirrors the visible reveal between the back of an overlay door and
# the front of the frame on real cabinetry.
DOOR_TO_FRAME_GAP = inch(0.125)


def _ff_front_y_bay_local(layout):
    """Bay-local Y of the face frame's front (outer) face.

    Cabinet mode: bay cage origin sits at the BACK of the face frame,
    so the front face is one fft in -Y. Panel mode: cage origin sits
    at the panel's front face (which is the FF front), so it's 0.
    Used by every front leaf and splitter to anchor against the FF
    plane regardless of cabinet vs panel context.
    """
    return 0.0 if layout.cabinet_type == 'PANEL' else -layout.fft


def _ff_back_y_bay_local(layout):
    """Bay-local Y of the face frame's back (inner) face.

    Cabinet mode: 0 (bay cage origin = FF back). Panel mode: layout.dim_y
    (cage spans panel front -> back).
    """
    return layout.dim_y if layout.cabinet_type == 'PANEL' else 0.0


def _door_panel_size(rect, cab_props, opening_props):
    """Width and height of the door panel covering this opening's face
    frame opening plus per-side overlay. For DOUBLE this is the
    combined width across both leaves; the per-leaf width is derived
    in the leaf builder by subtracting the reveal gap and halving.

    `rect` is one entry from bay_openings() - it carries the cage
    dimensions and the four reveals for this specific opening, which
    fully determines the face frame opening size on each axis.
    """
    opening_width = (
        rect['cage_dim_x'] - rect['reveal_left'] - rect['reveal_right']
    )
    opening_height = (
        rect['cage_dim_z'] - rect['reveal_top'] - rect['reveal_bottom']
    )
    width = (
        opening_width
        + front_overlay(rect, cab_props, opening_props, 'left')
        + front_overlay(rect, cab_props, opening_props, 'right')
    )
    height = (
        opening_height
        + resolved_overlay(cab_props, opening_props, 'top')
        + resolved_overlay(cab_props, opening_props, 'bottom')
    )
    return width, height


def _drawer_max_slide(layout, rect):
    """Maximum forward translation for a drawer/pullout front. Aimed at
    "near full extension": bay depth minus face frame thickness minus
    1 inch of clearance. Sourced from the leaf rect's cage_dim_y so the
    slide tracks per-bay depth, not the cabinet's overall dim_y.
    """
    # cage_dim_y = bay_depth - fft - bt; bay_depth - fft = cage_dim_y + bt.
    return max(0.0, rect['cage_dim_y'] + back_thickness(layout) - inch(1.0))


# ---------------------------------------------------------------------------
# Front leaves: per-opening descriptor of each front panel + its pivot.
#
# Most front configurations have a single leaf. DOUBLE doors have two
# (left + right half-width leaves meeting in the middle with a small
# reveal gap). The type code iterates this list and creates one
# (pivot, part) pair per leaf.
#
# Each leaf is a dict with keys:
#   'role'           PART_ROLE_DOOR / _DRAWER_FRONT / _PULLOUT_FRONT
#   'name'           Human-readable part name ("Door", "Door (Left)", ...)
#   'pivot_position' (x, y, z) in OPENING-local coords
#   'pivot_rotation' (rx, ry, rz)
#   'part_position'  (x, y, z) in PIVOT-local coords
#   'part_dims'      (length, width, thickness)
# ---------------------------------------------------------------------------
_FRONT_TYPE_TO_ROLE_NAME = {
    'DOOR':         ('DOOR',          'Door'),
    'DRAWER_FRONT': ('DRAWER_FRONT',  'Drawer Front'),
    'PULLOUT':      ('PULLOUT_FRONT', 'Pullout Front'),
    'FALSE_FRONT':  ('FALSE_FRONT',   'False Front'),
    'TILT_OUT':     ('TILT_OUT',      'Tilt-Out'),
    'INSET_PANEL':  ('INSET_PANEL',   'Inset Panel'),
}


def _hinge_barrel_pivot(leaf, door_thickness):
    """Move a swinging leaf's turning axis from the back of the door to
    its front face, where a hinge barrel actually sits, and slide the
    door back inside the pivot by the same amount so the CLOSED
    position is untouched.

    Turning a door about its own back edge is what a drawing program
    does, not what a hinge does, and the difference shows the moment
    the door moves: the back corner on the hinge side sweeps OUT, away
    from the cabinet, straight through whatever is beside it - a return
    wall, the next door along. Hung on its front face the door rolls
    off that corner instead, the way it does on a real hinge, and every
    point on it stays on the door's own side of the hinge line for as
    far as it opens (see DOOR_MAX_SWING_ANGLE).

    Y is forward here: the pivot moves forward by a thickness, the part
    moves back by one inside the pivot. Applies to leaves that turn -
    drawers and pullouts slide instead, and an inset panel never moves.
    """
    px, py, pz = leaf['pivot_position']
    ox, oy, oz = leaf['part_position']
    leaf['pivot_position'] = (px, py - door_thickness, pz)
    leaf['part_position'] = (ox, oy + door_thickness, oz)
    return leaf


def _single_door_leaf_pivot(layout, rect, cab_props, opening_props):
    """Pivot position + rotation for a single-leaf door (LEFT / RIGHT /
    TOP / BOTTOM hinge), and the door's offset inside the pivot.
    Shared between DOOR and PULLOUT (PULLOUT in v1 uses door geometry
    but its pivot rotation is forced to identity by the caller).
    """
    door_thickness = cab_props.door_thickness
    width, height = _door_panel_size(rect, cab_props, opening_props)
    left_overlay = front_overlay(rect, cab_props, opening_props, 'left')
    bottom_overlay = resolved_overlay(cab_props, opening_props, 'bottom')

    # Door pivot lives in OPENING-local coords. The opening cage origin
    # for this leaf is at (rect['cage_x'], 0, rect['cage_z']) in bay
    # local coords; in OPENING local that's (0, 0, 0). The face frame
    # opening's left edge is at opening-local X = reveal_left, bottom
    # at Z = reveal_bottom.
    base_x = rect['reveal_left'] - left_overlay
    base_y = _ff_front_y_bay_local(layout) - DOOR_TO_FRAME_GAP + cab_props.default_door_inset_amount
    base_z = rect['reveal_bottom'] - bottom_overlay

    angle = opening_props.swing_percent * DOOR_MAX_SWING_ANGLE
    hinge = opening_props.hinge_side

    if hinge == 'RIGHT':
        return _hinge_barrel_pivot({
            'pivot_position': (base_x + width, base_y, base_z),
            'pivot_rotation': (0.0, 0.0, +angle),
            'part_position':  (-width, 0.0, 0.0),
        }, door_thickness)
    if hinge == 'TOP':
        return _hinge_barrel_pivot({
            'pivot_position': (base_x, base_y, base_z + height),
            'pivot_rotation': (-angle, 0.0, 0.0),
            'part_position':  (0.0, 0.0, -height),
        }, door_thickness)
    if hinge == 'BOTTOM':
        return _hinge_barrel_pivot({
            'pivot_position': (base_x, base_y, base_z),
            'pivot_rotation': (+angle, 0.0, 0.0),
            'part_position':  (0.0, 0.0, 0.0),
        }, door_thickness)
    # LEFT (and DOUBLE doesn't reach here - handled separately)
    return _hinge_barrel_pivot({
        'pivot_position': (base_x, base_y, base_z),
        'pivot_rotation': (0.0, 0.0, -angle),
        'part_position':  (0.0, 0.0, 0.0),
    }, door_thickness)


def _double_door_leaves(layout, rect, cab_props, opening_props, role):
    """Two leaves for a DOUBLE door: left half hinged on its outer-left
    edge, right half hinged on its outer-right edge, with a small
    reveal gap where they meet in the middle (1/16" for inset doors,
    1/8" for overlay).
    """
    door_thickness = cab_props.door_thickness
    width, height = _door_panel_size(rect, cab_props, opening_props)
    reveal = (INSET_DOUBLE_DOOR_REVEAL
              if cab_props.default_door_inset_amount > 0
              else DOUBLE_DOOR_REVEAL)
    leaf_width = (width - reveal) / 2.0
    left_overlay = front_overlay(rect, cab_props, opening_props, 'left')
    bottom_overlay = resolved_overlay(cab_props, opening_props, 'bottom')

    base_x = rect['reveal_left'] - left_overlay
    base_y = _ff_front_y_bay_local(layout) - DOOR_TO_FRAME_GAP + cab_props.default_door_inset_amount
    base_z = rect['reveal_bottom'] - bottom_overlay
    angle = opening_props.swing_percent * DOOR_MAX_SWING_ANGLE

    return [
        _hinge_barrel_pivot({
            'role': role, 'name': 'Door (Left)',
            'pivot_position': (base_x, base_y, base_z),
            'pivot_rotation': (0.0, 0.0, -angle),
            'part_position':  (0.0, 0.0, 0.0),
            'part_dims':      (height, leaf_width, door_thickness),
        }, door_thickness),
        _hinge_barrel_pivot({
            'role': role, 'name': 'Door (Right)',
            'pivot_position': (base_x + width, base_y, base_z),
            'pivot_rotation': (0.0, 0.0, +angle),
            'part_position':  (-leaf_width, 0.0, 0.0),
            'part_dims':      (height, leaf_width, door_thickness),
        }, door_thickness),
    ]


def _drawer_or_pullout_slide_leaf(layout, rect, cab_props,
                                  opening_props, role, name):
    """Single-leaf slide-out front. Pivot translates in -Y by
    swing_percent * max_slide; no rotation."""
    door_thickness = cab_props.door_thickness
    width, height = _door_panel_size(rect, cab_props, opening_props)
    left_overlay = front_overlay(rect, cab_props, opening_props, 'left')
    bottom_overlay = resolved_overlay(cab_props, opening_props, 'bottom')

    base_x = rect['reveal_left'] - left_overlay
    base_y = _ff_front_y_bay_local(layout) - DOOR_TO_FRAME_GAP + cab_props.default_door_inset_amount
    base_z = rect['reveal_bottom'] - bottom_overlay
    slide = opening_props.swing_percent * _drawer_max_slide(layout, rect)

    return {
        'role': role, 'name': name,
        'pivot_position': (base_x, base_y - slide, base_z),
        # Swing-zero pivot corner. The drawer box anchors against this so it
        # can be placed once in pivot-local space and ride the slide via the
        # pivot's animated Y - if it anchored to pivot_position instead, the
        # box would sit at a fixed world Y and stay behind while the front
        # slides out.
        'pivot_anchor_position': (base_x, base_y, base_z),
        'pivot_rotation': (0.0, 0.0, 0.0),
        'part_position':  (0.0, 0.0, 0.0),
        'part_dims':      (height, width, door_thickness),
    }


def _inset_panel_leaf(layout, rect, role, name):
    """Single-leaf inset panel that fills the face frame opening.
    Sits IN the opening (not in front of it like an overlay door),
    with its back face flush with the back of the face frame plane.
    Thickness fixed at 1/4".

    The pivot is the part's back face; the part extends -Y by
    thickness from there to its front face. To place the back face
    on the FF back plane: pivot_y = ff_back_y_bay_local. In bay-local
    Y the FF back is at 0 for cabinets (cage origin = back of FF)
    and at layout.dim_y for panels (cage spans panel front -> back).
    """
    panel_thickness = inch(0.25)
    width = (
        rect['cage_dim_x'] - rect['reveal_left'] - rect['reveal_right']
    )
    height = (
        rect['cage_dim_z'] - rect['reveal_top'] - rect['reveal_bottom']
    )
    base_x = rect['reveal_left']
    base_y = _ff_back_y_bay_local(layout)
    base_z = rect['reveal_bottom']
    return {
        'role': role,
        'name': name,
        'pivot_position': (base_x, base_y, base_z),
        'pivot_rotation': (0.0, 0.0, 0.0),
        'part_position':  (0.0, 0.0, 0.0),
        'part_dims':      (height, width, panel_thickness),
    }


class _ZeroSwingProxy:
    """Wraps an opening_props instance and reports swing_percent as 0.
    Used for FALSE_FRONT so the leaf builder can be reused without
    branching on slide behavior inside it.
    """
    __slots__ = ('_inner',)
    def __init__(self, inner):
        object.__setattr__(self, '_inner', inner)
    def __getattr__(self, name):
        if name == 'swing_percent':
            return 0.0
        return getattr(self._inner, name)


class _ForceHingeProxy:
    """Wraps an opening_props instance and reports a fixed hinge_side
    (every other field, including swing_percent, passes through). Used by
    TILT_OUT to force a BOTTOM hinge through the shared door-pivot builder
    while the user's swing_percent still drives how far it tilts open.
    """
    __slots__ = ('_inner', '_hinge')
    def __init__(self, inner, hinge):
        object.__setattr__(self, '_inner', inner)
        object.__setattr__(self, '_hinge', hinge)
    def __getattr__(self, name):
        if name == 'hinge_side':
            return self._hinge
        return getattr(self._inner, name)


def _triple_door_leaves(layout, rect, cab_props, opening_props, role):
    """Three equal leaves for a tri-view medicine cabinet front: three
    mirror doors butting across ONE opening (no mid-stiles), hinged
    R / R / L. Each door is a 5-piece frame with TRIVIEW_FRAME_WIDTH
    stiles / rails - but the two INTERIOR stiles (where mirrors meet) are
    zeroed so the mirrors run edge-to-edge: the left door drops its right
    stile, the center door both stiles, the right door its left stile.

    Each descriptor carries a `frame_override` dict (left_stile /
    right_stile / top_rail / bottom_rail, meters) that the front-creation
    loop stamps onto the door object so the door-style application sets
    these per-side widths instead of the uniform style stile_width.
    """
    door_thickness = cab_props.door_thickness
    width, height = _door_panel_size(rect, cab_props, opening_props)
    left_overlay = front_overlay(rect, cab_props, opening_props, 'left')
    bottom_overlay = resolved_overlay(cab_props, opening_props, 'bottom')

    base_x = rect['reveal_left'] - left_overlay
    base_y = _ff_front_y_bay_local(layout) - DOOR_TO_FRAME_GAP + cab_props.default_door_inset_amount
    base_z = rect['reveal_bottom'] - bottom_overlay
    angle = opening_props.swing_percent * DOOR_MAX_SWING_ANGLE

    leaf_width = (width - 2.0 * TRIVIEW_DOOR_REVEAL) / 3.0
    fw = TRIVIEW_FRAME_WIDTH

    # left edge (opening-local X) of each leaf, left to right
    x0 = base_x
    x1 = x0 + leaf_width + TRIVIEW_DOOR_REVEAL
    x2 = x1 + leaf_width + TRIVIEW_DOOR_REVEAL

    def _right_hinged(name, x_left, ovr):
        # pivot on the leaf's RIGHT edge; part extends back in -X
        return _hinge_barrel_pivot({
            'role': role, 'name': name,
            'pivot_position': (x_left + leaf_width, base_y, base_z),
            'pivot_rotation': (0.0, 0.0, +angle),
            'part_position':  (-leaf_width, 0.0, 0.0),
            'part_dims':      (height, leaf_width, door_thickness),
            'frame_override': ovr,
        }, door_thickness)

    def _left_hinged(name, x_left, ovr):
        return _hinge_barrel_pivot({
            'role': role, 'name': name,
            'pivot_position': (x_left, base_y, base_z),
            'pivot_rotation': (0.0, 0.0, -angle),
            'part_position':  (0.0, 0.0, 0.0),
            'part_dims':      (height, leaf_width, door_thickness),
            'frame_override': ovr,
        }, door_thickness)

    rails = {'top_rail': fw, 'bottom_rail': fw}
    # The overrides are visual-true (left_stile = the viewer's left):
    # assign_style_to_front renders them as named and swaps at the
    # CPM_5PIECEDOOR boundary itself when on the GN fallback (that
    # node renders its Left / Right inputs on the opposite sides).
    return [
        # Left door: keep OUTER (left) stile, drop INTERIOR (right)
        _right_hinged('Door (Left)',   x0,
                      {'left_stile': fw,  'right_stile': 0.0, **rails}),
        # Center door: no stiles (mirror runs full width)
        _right_hinged('Door (Center)', x1,
                      {'left_stile': 0.0, 'right_stile': 0.0, **rails}),
        # Right door: drop INTERIOR (left), keep OUTER (right) stile
        _left_hinged('Door (Right)',   x2,
                     {'left_stile': 0.0, 'right_stile': fw,  **rails}),
    ]


def front_leaves(layout, rect, cab_props, opening_props):
    """List of leaf descriptors for one opening's front parts.

    `rect` is the opening's entry from bay_openings() - it provides
    cage geometry and reveals so leaves don't need to be told which
    bay/opening_index they belong to.

    Empty list when front_type is NONE. Single-element for most
    configurations; two elements for DOUBLE doors (one per leaf).
    """
    front_type = opening_props.front_type
    if front_type == 'NONE':
        return []
    # APPLIANCE openings carry no door/drawer front; the left/right filler
    # stiles are built directly in _update_fronts_in_opening (see
    # appliance_filler_widths), not as front leaves.
    if front_type == 'APPLIANCE':
        return []
    role, base_name = _FRONT_TYPE_TO_ROLE_NAME[front_type]

    if front_type == 'INSET_PANEL':
        return [_inset_panel_leaf(layout, rect, role, base_name)]

    if front_type == 'TILT_OUT':
        # A drawer-styled front that tilts down on a BOTTOM hinge. The motion
        # reuses the door swing pivot (flip-down), but the leaf carries the
        # TILT_OUT role so it's styled from the drawer-front pool and gets a
        # centered drawer pull with no slide box (see types_face_frame). The
        # bottom hinge is forced regardless of hinge_side; swing_percent still
        # drives how far it tilts open.
        width, height = _door_panel_size(rect, cab_props, opening_props)
        leaf = _single_door_leaf_pivot(
            layout, rect, cab_props, _ForceHingeProxy(opening_props, 'BOTTOM'))
        leaf['role'] = role
        leaf['name'] = base_name
        leaf['part_dims'] = (height, width, cab_props.door_thickness)
        leaf['hinge'] = 'BOTTOM'
        return [leaf]

    if front_type in ('DRAWER_FRONT', 'PULLOUT', 'FALSE_FRONT'):
        # FALSE_FRONT shares drawer geometry but is fixed - we hand the
        # leaf builder a synthetic opening_props with swing_percent
        # zeroed so the panel never translates forward, regardless of
        # any stale value left on the real props.
        leaf_props = opening_props
        if front_type == 'FALSE_FRONT':
            leaf_props = _ZeroSwingProxy(opening_props)
        return [_drawer_or_pullout_slide_leaf(
            layout, rect, cab_props, leaf_props, role, base_name
        )]

    # DOOR
    if cab_props.id_data.get('HB_TRIVIEW_DOORS'):
        # Tri-view medicine cabinet: three mirror doors in one opening.
        return _triple_door_leaves(
            layout, rect, cab_props, opening_props, role
        )
    if opening_props.hinge_side == 'DOUBLE':
        return _double_door_leaves(
            layout, rect, cab_props, opening_props, role
        )

    width, height = _door_panel_size(rect, cab_props, opening_props)
    leaf = _single_door_leaf_pivot(layout, rect, cab_props, opening_props)
    leaf['role'] = role
    leaf['name'] = base_name
    leaf['part_dims'] = (height, width, cab_props.door_thickness)
    # Carry the hinge so the pull placer can special-case a flip door
    # (TOP / BOTTOM hinge) -- it can't infer a horizontal hinge from the
    # part's location.x sign the way it does for LEFT / RIGHT.
    leaf['hinge'] = opening_props.hinge_side
    return [leaf]


def appliance_filler_widths(rect, opening_props):
    """Return (left_width, right_width) for an APPLIANCE opening's filler stiles.

    ``clear`` is the face-frame opening width (cage minus side reveals). Two
    input modes, mirroring the legacy appliance opening:
      * set_appliance_width ON  -> the user gives the appliance width; the
        remainder ``clear - appliance_width`` is split evenly into two fillers.
      * set_appliance_width OFF -> the user gives each filler width directly;
        the appliance simply occupies whatever clear width remains.
    include_fillers OFF returns (0, 0) so the opening can be reserved as an
    appliance with no fillers built yet. Widths are clamped to be >= 0 and to
    never exceed the clear opening (scaled down together if they would).
    """
    if not getattr(opening_props, 'include_fillers', True):
        return (0.0, 0.0)
    clear = rect['cage_dim_x'] - rect['reveal_left'] - rect['reveal_right']
    if clear <= 0.0:
        return (0.0, 0.0)
    if getattr(opening_props, 'set_appliance_width', True):
        appl = max(0.0, min(opening_props.appliance_width, clear))
        each = max(0.0, (clear - appl) / 2.0)
        return (each, each)
    left = max(0.0, opening_props.left_filler_amount)
    right = max(0.0, opening_props.right_filler_amount)
    total = left + right
    if total > clear and total > 0.0:
        scale = clear / total
        left *= scale
        right *= scale
    return (left, right)


# ---------------------------------------------------------------------------
# Interior items (shelves, accessory labels, ...). Lives behind the face
# frame, inside the bay carcass cavity.
#
# Coordinate space for every descriptor is OPENING-LOCAL: x in [0, cage_dim_x],
# y in [0, cage_dim_y] (y = 0 at back face of face frame, growing into the
# cabinet), z in [0, cage_dim_z] (z = 0 at top of bay's bottom panel).
# ---------------------------------------------------------------------------
SHELF_THICKNESS = inch(0.75)
SHELF_X_CLEARANCE = inch(1.0 / 16.0)   # side gap for shelf-pin clearance
SHELF_FRONT_SETBACK = inch(0.25)       # tucked behind the face frame plane
SHELF_BACK_SETBACK = inch(0.25)        # finger gap to the back panel

# Interior kinds whose depth is a fraction of the cavity depth rather
# than a fixed setback, mapped to (depth fraction, part name).
PARTIAL_DEPTH_SHELF_KINDS = {
    'HALF_DEPTH_SHELF': (0.5, 'Half-Depth Shelf'),
    'QUARTER_DEPTH_SHELF': (0.25, 'Quarter-Depth Shelf'),
}

# Applied finish liner stock. Interior parts in a finished region stop
# at the liner face, not the cavity wall - see finish_liner_insets.
FINISH_LINER_THICKNESS = inch(0.25)

ACCESSORY_TEXT_SIZE = inch(1.5)
ACCESSORY_Y_OFFSET = inch(1.0)         # nudge into the cavity so it reads
                                       # cleanly against the cabinet back


def auto_shelf_qty(opening_height, depth):
    """Catalog count of adjustable shelves for an interior opening, keyed on
    the opening's interior HEIGHT and the CABINET DEPTH (per the residential catalog).

    Shallow cabinets (depth < 18") take more shelves per inch of opening
    height than deeper ones, so the bracket table is depth-dependent. An
    opening shorter than the first bracket gets 0 (e.g. the door zone above
    a refrigerator). Heights / depth are compared in inches; the count caps
    at 4 (the catalog's tallest listed opening, 66").

    Catalog (Opening Height -> Shelves):
        Depth < 18"      : <15->0  15-20->1  >20-32->2  >32-44->3  >44-66->4
        Depth 18" to 30" : <20->0  20-28->1  >28-40->2  >40-52->3  >52-66->4

    The earlier rule was a flat one-shelf-per-12" (``int(h / 12)``), which
    ignored depth -- it over-shelved deep cabinets (the "refrigerator gets
    too many shelves" report) and under-shelved shallow uppers (the "above
    the range not enough shelves" report). Used for both initial seeding
    (when an interior item is added) and live recompute (unlock_shelf_qty
    False). Openings taller than 66" are not in the catalog and clamp to 4.
    """
    in_per_m = 1.0 / inch(1.0)
    h = (opening_height or 0.0) * in_per_m
    d = (depth or 0.0) * in_per_m
    # First step is inclusive ("15 to 20" includes 15 and 20); the rest are
    # exclusive ("Over 20", "Over 28", ...). EPS absorbs float jitter so a
    # value sitting exactly on a boundary lands in the lower (catalog) bracket.
    eps = 0.01
    if d < 18.0:
        qty = 0
        if h >= 15.0 - eps:
            qty = 1
        if h > 20.0 + eps:
            qty = 2
        if h > 32.0 + eps:
            qty = 3
        if h > 44.0 + eps:
            qty = 4
    else:
        qty = 0
        if h >= 20.0 - eps:
            qty = 1
        if h > 28.0 + eps:
            qty = 2
        if h > 40.0 + eps:
            qty = 3
        if h > 52.0 + eps:
            qty = 4
    return qty


def _shelf_stack_descriptors(rect, cage_dim_y, qty, setback,
                              kind, role, name_prefix,
                              nosing_style='NONE', nosing_height=0.0,
                              z0=0.0):
    """Stacked horizontal shelves filling a region. Geometry is
    identical for adjustable and glass shelves; the kind/role tag
    drives downstream material handling and selection. setback is
    per-item (half-depth shelves pass the mid-cavity line) so
    individual items can request a deeper front gap. z0 lifts the
    whole stack: shelves distribute evenly in [z0, region top], so
    an item can sit above another insert sharing the opening.

    A nosing style other than NONE (adjustable shelves only) recesses
    the shelf board by the nosing stock depth and emits one
    SHELF_NOSING descriptor per shelf; the nosing front face lands
    where the plain shelf front would have been, so the overall depth
    is unchanged.
    """
    if qty <= 0:
        return []
    cage_dim_x = rect['cage_dim_x']
    cage_dim_z = rect['cage_dim_z']

    z0 = max(0.0, min(z0, cage_dim_z))
    interior_h = (cage_dim_z - z0) - qty * SHELF_THICKNESS
    if interior_h <= 0:
        return []
    spacing = interior_h / (qty + 1)

    nosing = nosing_style not in (None, '', 'NONE')
    nose_d = shelf_nosing.NOSE_STOCK_DEPTH if nosing else 0.0

    length = max(0.0, cage_dim_x - 2 * SHELF_X_CLEARANCE)
    width = max(0.0, cage_dim_y - setback - SHELF_BACK_SETBACK - nose_d)

    items = []
    for k in range(qty):
        # Shelf k bottom-face Z: stack from the bottom with one spacing
        # gap before the first shelf and one after the last.
        z = z0 + (k + 1) * spacing + k * SHELF_THICKNESS
        items.append({
            'kind':     kind,
            'role':     role,
            'name':     f'{name_prefix} {k + 1}',
            'orientation': 'HORIZONTAL',
            'position': (SHELF_X_CLEARANCE, setback + nose_d, z),
            'dims':     (length, width, SHELF_THICKNESS),
        })
        if nosing and length > 0.0:
            items.append({
                'kind':     'SHELF_NOSING',
                'role':     'SHELF_NOSING',
                'name':     f'{name_prefix} Nosing {k + 1}',
                # Origin: back face against the shelf front edge, top
                # flush with the shelf top.
                'position': (SHELF_X_CLEARANCE, setback + nose_d,
                             z + SHELF_THICKNESS),
                'length':   length,
                'style':    nosing_style,
                'shelf_thickness': SHELF_THICKNESS,
                'height':   nosing_height,
            })
    return items


def _adjustable_shelf_descriptors(rect, cage_dim_y, qty, setback,
                                  nosing_style='NONE', nosing_height=0.0,
                                  z0=0.0):
    return _shelf_stack_descriptors(
        rect, cage_dim_y, qty, setback,
        'ADJUSTABLE_SHELF', 'ADJUSTABLE_SHELF', 'Adjustable Shelf',
        nosing_style, nosing_height, z0,
    )


def _glass_shelf_descriptors(rect, cage_dim_y, qty, setback, z0=0.0):
    return _shelf_stack_descriptors(
        rect, cage_dim_y, qty, setback,
        'GLASS_SHELF', 'GLASS_SHELF', 'Glass Shelf',
        z0=z0,
    )


def _accessory_label_descriptor(rect, cage_dim_y, label):
    """Build a single text-label descriptor centered in the opening,
    facing -Y (readable from the front of the cabinet). Position is the
    text origin; the recalc applies rotation and font size from the
    descriptor.
    """
    cage_dim_x = rect['cage_dim_x']
    cage_dim_z = rect['cage_dim_z']
    return {
        'kind':     'ACCESSORY',
        'role':     'ACCESSORY_LABEL',
        'name':     f'Accessory Label - {label}' if label else 'Accessory Label',
        'position': (cage_dim_x / 2.0,
                     min(ACCESSORY_Y_OFFSET, max(0.0, cage_dim_y - inch(0.25))),
                     cage_dim_z / 2.0),
        # Rotation around X by +90 degrees turns a default text
        # object's front face (+Z) toward -Y so it's readable from the
        # cabinet front. Centering (align_x = CENTER, align_y = CENTER)
        # is applied in the recalc since it's font-data, not transform.
        'rotation': (math.radians(90.0), 0.0, 0.0),
        'text':     label or 'Accessory',
        'size':     ACCESSORY_TEXT_SIZE,
    }


# ---------------------------------------------------------------------------
# Pullout / rollout assemblies
# ---------------------------------------------------------------------------
# A pullout assembly is N stacked items (flat shelves for PULLOUT_SHELF, drawer
# boxes for ROLLOUT) plus 4 vertical side spacers (front-left, back-left,
# front-right, back-right). The spacers are the surface slide hardware mounts
# to; they bridge any face frame inset that would otherwise leave the slide
# unsupported.
PULLOUT_SPACER_Y_OFFSET = inch(2.5)
# Assembly clearances (shared by ROLLOUT and PULLOUT_SHELF): the item is
# inset ASSEMBLY_SIDE_GAP from each FF opening edge (so it runs 1 1/2"
# narrower than the FF clear opening), and each spacer's inner face
# stops ASSEMBLY_SLIDE_GAP short of the item side -- that gap is where
# the slide lives. Spacer thickness therefore
# = reveal + (ASSEMBLY_SIDE_GAP - ASSEMBLY_SLIDE_GAP).
ASSEMBLY_SIDE_GAP = inch(0.75)
ASSEMBLY_SLIDE_GAP = inch(0.375)
# Spacer front-to-back width (the slide mounting pad). Fixed -- not
# user-adjustable (the spacer_height prop is legacy, no longer read).
ASSEMBLY_SPACER_WIDTH = inch(0.815)


def _assembly_side_geometry(rect, cage_dim_x):
    """Shared side math for a slide-mounted assembly (rollout / pullout
    shelf): ``(item_x, item_dx, spacer_l, spacer_r)`` in region-local X.

    The item must pull through the FACE FRAME opening, not just the
    carcass opening: the stiles overhang the cage by the side reveals,
    which differ per bay with the overlay. The item sits
    ASSEMBLY_SIDE_GAP inside each FF opening edge; each spacer runs from
    the carcass side to ASSEMBLY_SLIDE_GAP short of the item side, so
    the slide drops into that gap against the spacer face. Negative
    reveals (FF opening wider than the cage) clamp to 0 -- the carcass
    side is the limit there.
    """
    rev_l = max(0.0, rect.get('reveal_left', 0.0))
    rev_r = max(0.0, rect.get('reveal_right', 0.0))
    item_x = rev_l + ASSEMBLY_SIDE_GAP
    item_dx = max(0.0, cage_dim_x - rev_l - rev_r - 2 * ASSEMBLY_SIDE_GAP)
    spacer_l = rev_l + ASSEMBLY_SIDE_GAP - ASSEMBLY_SLIDE_GAP
    spacer_r = rev_r + ASSEMBLY_SIDE_GAP - ASSEMBLY_SLIDE_GAP
    return item_x, item_dx, spacer_l, spacer_r


def _spacer_length(rect, item):
    """How tall the spacer ladders run. 0 (the default) is the full
    opening height; a typed height stops them short so whatever sits
    above them clears them instead of being notched around them."""
    cage_dim_z = rect['cage_dim_z']
    typed = getattr(item, 'rollout_spacer_height', 0.0) or 0.0
    if typed <= 0.0:
        return cage_dim_z
    return min(typed, cage_dim_z)


def _assembly_spacers(rect, spacer_height, kind, role, name_prefix,
                      left_thickness, right_thickness, length=None):
    """Four vertical spacer parts for a pullout/rollout assembly. Origin
    convention for VERTICAL parts: position.y is the back face of the
    spacer's Y extent (mirror_y at materialize time fans the width
    forward in -Y), position.z is the bottom (mirror_z fans length up
    in +Z). Per-side thicknesses fill from the carcass side to the
    slide gap off the item edge (reveal-dependent, so each side can
    differ).
    """
    cage_dim_x = rect['cage_dim_x']
    cage_dim_y = rect['cage_dim_y']
    cage_dim_z = rect['cage_dim_z']

    # Back face of front spacer = front offset + spacer_height.
    front_back_y = PULLOUT_SPACER_Y_OFFSET + spacer_height
    # Back face of back spacer = cage_dim_y - PULLOUT_SPACER_Y_OFFSET.
    back_back_y = cage_dim_y - PULLOUT_SPACER_Y_OFFSET

    out = []
    sides = [
        ('Front Left',  0.0,                            front_back_y,
         left_thickness),
        ('Back Left',   0.0,                            back_back_y,
         left_thickness),
        ('Front Right', cage_dim_x - right_thickness,   front_back_y,
         right_thickness),
        ('Back Right',  cage_dim_x - right_thickness,   back_back_y,
         right_thickness),
    ]
    for side_name, x, y, thickness in sides:
        if thickness <= 0.0:
            continue
        out.append({
            'kind':         kind,
            'role':         role,
            'name':         f'{name_prefix} {side_name}',
            'orientation':  'VERTICAL',
            'position':     (x, y, 0.0),
            'dims':         (cage_dim_z if length is None else length,
                             spacer_height, thickness),
        })
    return out


def _pullout_shelf_descriptors(rect, cage_dim_y, item):
    qty = item.qty
    if qty <= 0:
        return []
    cage_dim_x = rect['cage_dim_x']
    item_height = item.pullout_thickness
    bottom_gap = item.bottom_gap
    distance_between = item.distance_between
    setback = item.item_setback

    shelf_x, length, spacer_l, spacer_r = _assembly_side_geometry(
        rect, cage_dim_x)
    width = max(0.0, cage_dim_y - setback)

    out = []
    for k in range(qty):
        z = bottom_gap + k * (item_height + distance_between)
        out.append({
            'kind':         'PULLOUT_SHELF',
            'role':         'PULLOUT_SHELF',
            'name':         f'Pullout Shelf {k + 1}',
            'orientation':  'HORIZONTAL',
            'position':     (shelf_x, setback, z),
            'dims':         (length, width, item_height),
        })
    # Same opt-out the rollout boxes have: a shelf that mounts straight
    # to the cabinet needs no spacer assembly built for it.
    if not getattr(item, 'hide_rollout_spacers', False):
        out.extend(_assembly_spacers(
            rect, ASSEMBLY_SPACER_WIDTH, 'PULLOUT_SPACER', 'PULLOUT_SPACER',
            'Pullout Spacer',
            left_thickness=spacer_l, right_thickness=spacer_r,
            length=_spacer_length(rect, item),
        ))
    return out


GALLEY_TOP_T = inch(0.5)      # a workstation roll-out's plywood top


def _rollout_descriptors(rect, cage_dim_y, item, item_index=-1):
    # Per-box stack: each box in item.rollout_boxes carries its own height,
    # so the boxes are placed bottom to top by a running Z sum rather than a
    # uniform step. Items saved before per-box heights have an empty
    # rollout_boxes collection until the recalc migrates them; fall back to a
    # uniform stack of qty boxes at rollout_height so geometry is unchanged
    # in the meantime.
    if len(item.rollout_boxes):
        heights = [box.height for box in item.rollout_boxes]
    else:
        heights = [item.rollout_height] * item.qty
    if not heights:
        return []
    cage_dim_x = rect['cage_dim_x']
    bottom_gap = item.bottom_gap
    distance_between = item.distance_between
    setback = item.item_setback

    box_x, box_dx, spacer_l, spacer_r = _assembly_side_geometry(
        rect, cage_dim_x)
    box_dy = max(0.0, cage_dim_y - setback)
    # Explicit depth (0 = auto): shorten the boxes at the BACK so they
    # clear a pipe / vent run behind them. Clamped to the auto fit.
    typed_dy = getattr(item, 'rollout_depth', 0.0)
    if typed_dy > 0.0:
        box_dy = min(typed_dy, box_dy)

    out = []
    z = bottom_gap
    for k, item_height in enumerate(heights):
        out.append({
            'kind':         'ROLLOUT_BOX',
            'role':         'ROLLOUT_BOX',
            'name':         f'Rollout Box {k + 1}',
            'orientation':  'BOX',
            'position':     (box_x, setback, z),
            'dims':         (box_dx, box_dy, item_height),
            # Which rollout_boxes entry built this box, so the builder can
            # read its per-box options (the U-notch) and the right-click
            # command can find its way back from the object.
            'item_index':   item_index,
            'box_index':    k,
        })
        # A workstation roll-out carries a top with a bowl or bin opening,
        # which takes its own thickness out of the stack.
        box = item.rollout_boxes[k] if k < len(item.rollout_boxes) else None
        top = getattr(box, 'galley_top', 'NONE') if box is not None else 'NONE'
        if top != 'NONE':
            out.append({
                'kind':         'GALLEY_ROLLOUT_TOP',
                'role':         'GALLEY_ROLLOUT_TOP',
                'name':         f'Rollout Top {k + 1}',
                'orientation':  'HORIZONTAL',
                'position':     (box_x, setback, z + item_height),
                'dims':         (box_dx, box_dy, GALLEY_TOP_T),
                'galley_top':   top,
            })
            z += GALLEY_TOP_T
        z += item_height + distance_between
    if not getattr(item, 'hide_rollout_spacers', False):
        out.extend(_assembly_spacers(
            rect, ASSEMBLY_SPACER_WIDTH, 'ROLLOUT_SPACER', 'ROLLOUT_SPACER',
            'Rollout Spacer',
            left_thickness=spacer_l, right_thickness=spacer_r,
            length=_spacer_length(rect, item),
        ))
    return out


# ---------------------------------------------------------------------------
# Tray dividers
# ---------------------------------------------------------------------------
# Vertical thin dividers spaced evenly across the opening's X span. With
# Remove Locked Shelf off (default), the dividers stop at the underside
# of a horizontal locked shelf at tray_opening_height; with it on, the
# dividers run the full opening height. The locked shelf carries its own
# part role so the wipe set picks it up alongside the dividers.
def _tray_dividers_descriptors(rect, cage_dim_y, item):
    qty = item.tray_qty
    if qty <= 0:
        return []
    cage_dim_x = rect['cage_dim_x']
    cage_dim_z = rect['cage_dim_z']
    div_thickness = item.tray_divider_thickness
    setback = item.tray_setback
    remove_shelf = item.tray_remove_shelf
    opening_height = item.tray_opening_height
    # Vertical anchor: the whole insert (dividers + locked shelf) rides
    # up from the region bottom so it can sit above other items.
    z0 = max(0.0, min(getattr(item, 'bottom_offset', 0.0), cage_dim_z))

    if remove_shelf:
        div_length = max(0.0, cage_dim_z - z0)
    else:
        # Dividers stop just below the locked shelf's bottom face.
        div_length = max(0.0, opening_height - SHELF_THICKNESS)

    div_width = max(0.0, cage_dim_y - setback - SHELF_BACK_SETBACK)

    # Equal regions: span_x = qty * div_thickness + (qty + 1) * gap.
    span_x = cage_dim_x
    div_spacing = (span_x - qty * div_thickness) / (qty + 1)

    out = []
    for k in range(qty):
        x = (k + 1) * div_spacing + k * div_thickness
        out.append({
            'kind':         'TRAY_DIVIDER',
            'role':         'TRAY_DIVIDER',
            'name':         f'Tray Divider {k + 1}',
            'orientation':  'VERTICAL',
            'position':     (x, cage_dim_y - SHELF_BACK_SETBACK, z0),
            'dims':         (div_length, div_width, div_thickness),
        })

    if not remove_shelf:
        shelf_length = max(0.0, cage_dim_x - 2 * SHELF_X_CLEARANCE)
        shelf_width = max(0.0, cage_dim_y - setback - SHELF_BACK_SETBACK)
        out.append({
            'kind':         'TRAY_LOCKED_SHELF',
            'role':         'TRAY_LOCKED_SHELF',
            'name':         'Tray Locked Shelf',
            'orientation':  'HORIZONTAL',
            'position':     (SHELF_X_CLEARANCE, setback,
                             z0 + max(0.0, opening_height - SHELF_THICKNESS)),
            'dims':         (shelf_length, shelf_width, SHELF_THICKNESS),
        })
    return out


# ---------------------------------------------------------------------------
# Vanity shelves
# ---------------------------------------------------------------------------
# Pair of L/R side-mounted shelves around plumbing, on corbel supports.
# Single Z, mirrored L/R lengths. The corbels are vertical pieces that
# tuck under the inboard end of each shelf and run from floor to shelf
# height. Hardcoded depth/thickness/inset; the user-facing knobs are
# vanity_z (height) and vanity_length (horizontal extent of each shelf).
VANITY_SUPPORT_DEPTH = inch(1.5)
VANITY_SUPPORT_THICKNESS = inch(0.5)
VANITY_SUPPORT_INSET = inch(0.375)


def _vanity_shelves_descriptors(rect, cage_dim_y, item):
    cage_dim_x = rect['cage_dim_x']
    z = item.vanity_z
    length = item.vanity_length

    out = []
    # Left shelf: anchored at x=0
    out.append({
        'kind':         'VANITY_SHELF',
        'role':         'VANITY_SHELF',
        'name':         'Vanity Left Shelf',
        'orientation':  'HORIZONTAL',
        'position':     (0.0, 0.0, z),
        'dims':         (length, cage_dim_y, SHELF_THICKNESS),
    })
    # Right shelf: anchored at x = cage_dim_x - length
    out.append({
        'kind':         'VANITY_SHELF',
        'role':         'VANITY_SHELF',
        'name':         'Vanity Right Shelf',
        'orientation':  'HORIZONTAL',
        'position':     (max(0.0, cage_dim_x - length), 0.0, z),
        'dims':         (length, cage_dim_y, SHELF_THICKNESS),
    })

    # Vertical corbel supports below each shelf, at the inboard end.
    # VERTICAL convention: position.y = back face of part's Y extent
    # (mirror_y at materialize fans width forward in -Y), position.z = 0
    # (mirror_z fans length up). Length = vanity_z (full corbel height).
    support_dims = (z, VANITY_SUPPORT_DEPTH, VANITY_SUPPORT_THICKNESS)
    # Left corbel inboard X: shelf right edge minus inset, minus thickness
    left_x = max(0.0, length - VANITY_SUPPORT_INSET - VANITY_SUPPORT_THICKNESS)
    # Right corbel inboard X: cage_dim_x - length + inset
    right_x = min(cage_dim_x - VANITY_SUPPORT_THICKNESS,
                  cage_dim_x - length + VANITY_SUPPORT_INSET)
    out.append({
        'kind':         'VANITY_SUPPORT',
        'role':         'VANITY_SUPPORT',
        'name':         'Vanity Left Support',
        'orientation':  'VERTICAL',
        'position':     (left_x, cage_dim_y, 0.0),
        'dims':         support_dims,
    })
    out.append({
        'kind':         'VANITY_SUPPORT',
        'role':         'VANITY_SUPPORT',
        'name':         'Vanity Right Support',
        'orientation':  'VERTICAL',
        'position':     (right_x, cage_dim_y, 0.0),
        'dims':         support_dims,
    })
    return out


# ---------------------------------------------------------------------------
# Bar storage inserts (Tableware & Bar Storage Solutions)
# ---------------------------------------------------------------------------
# The insert sits at the front of the cavity behind the face frame and
# is blocked off at 12" deep in deeper cabinets (catalog rule). Sizing
# is fully automatic from the opening: bar_storage.py fits the grids /
# spacing to the catalog charts, so one descriptor carries the whole
# unit and the materialize step builds a single derived mesh.
BAR_STORAGE_FRONT_Y = inch(0.75)


def _bar_storage_descriptor(rect, cage_dim_y, item):
    depth = min(
        bar_storage.MAX_DEPTH,
        cage_dim_y - BAR_STORAGE_FRONT_Y - SHELF_BACK_SETBACK,
    )
    if depth <= 0.0:
        return None
    label = bar_storage.KIND_LABELS.get(item.kind, item.kind)
    return {
        'kind':     item.kind,
        'role':     'BAR_STORAGE',
        'name':     label,
        'position': (0.0, BAR_STORAGE_FRONT_Y, 0.0),
        # (w, depth, h) of the insert volume - consumed only by the
        # bar-storage materialize branch, which builds a mesh rather
        # than an oriented cutpart.
        'dims':     (rect['cage_dim_x'], depth, rect['cage_dim_z']),
    }


# ---------------------------------------------------------------------------
# Closet rod
# ---------------------------------------------------------------------------
# Rod sizing follows the closets library conventions: 1" profile radius,
# centerline 12" out from the cavity back (clamped for shallow cabinets),
# and a drop measured from the opening top so the hang height rides the
# top on height changes.
CLOSET_ROD_RADIUS = inch(1.0)
CLOSET_ROD_FROM_REAR = inch(12.0)


def _closet_rod_descriptor(rect, cage_dim_y, item):
    dim_z = rect['cage_dim_z']
    z = dim_z - getattr(item, 'rod_distance_from_top', inch(3.0))
    z = max(CLOSET_ROD_RADIUS, min(z, dim_z - CLOSET_ROD_RADIUS))
    # Opening-local Y runs front (0) -> back (cage_dim_y): centerline
    # 12" forward of the back, clamped inside a shallow cavity.
    y = max(CLOSET_ROD_RADIUS,
            cage_dim_y - min(CLOSET_ROD_FROM_REAR,
                             cage_dim_y - CLOSET_ROD_RADIUS))
    return {
        'kind':     'CLOSET_ROD',
        'role':     'CLOSET_ROD',
        'name':     'Closet Rod',
        'position': (0.0, y, z),
        'dims':     (rect['cage_dim_x'], 0.0, 0.0),
    }


def _retracting_clearances(opening_ff):
    """(left, right, front, top) interior clearances a retracting-door
    mechanism costs, in meters. All zero when no mechanism applies.

    Per the product spec: pocketed doors ride the side(s) they hinge
    on, shelves between them narrow by a fixed amount per pocket side
    and hold back from the front for hinge access; the top-mount door
    eats a fixed height at the top of the opening.
    """
    if opening_ff is None:
        return (0.0, 0.0, 0.0, 0.0)
    mech = getattr(opening_ff, 'door_mechanism', 'NONE')
    if mech == 'RETRACTING_TOP':
        return (0.0, 0.0, 0.0, inch(2.0))
    if mech not in ('RETRACTING', 'RETRACTING_BIFOLD'):
        return (0.0, 0.0, 0.0, 0.0)
    per_side = inch(3.25) if mech == 'RETRACTING' else inch(4.75)
    hinge = getattr(opening_ff, 'hinge_side', 'RIGHT')
    left = per_side if hinge in ('LEFT', 'DOUBLE') else 0.0
    right = per_side if hinge in ('RIGHT', 'DOUBLE') else 0.0
    return (left, right, inch(3.0), 0.0)


def interior_item_descriptors(layout, rect, cab_props, opening_props,
                              opening_ff=None):
    """Flatten one opening's interior_items collection into a list of
    geometry descriptors for the recalc to materialize. One InteriorItem
    can produce many descriptors (e.g., ADJUSTABLE_SHELF with qty=3 ->
    three shelf descriptors).

    Each descriptor carries a 'kind' field so the recalc can pick the
    right Blender object type (mesh part vs text object) without
    re-reading the source collection.

    opening_ff is the OWNING OPENING's props even when opening_props is
    an interior-region leaf - opening-level state (the door mechanism)
    applies to every region the opening contains.
    """
    # Per-bay depth - threaded onto each leaf rect by bay_openings.
    # Used to be computed here from layout.dim_y, which broke when bay
    # depths diverged from the cabinet's overall depth.
    cage_dim_y = rect['cage_dim_y']

    # Retracting-door clearances: shelf stacks narrow off the pocket
    # side(s), hold back from the front, and lose the top-mount door's
    # height. Other insert kinds are left as authored for now.
    cl_l, cl_r, cl_f, cl_t = _retracting_clearances(opening_ff)
    shelf_rect = rect
    if cl_l or cl_r or cl_t:
        shelf_rect = dict(rect)
        shelf_rect['cage_dim_x'] = max(
            0.0, rect['cage_dim_x'] - cl_l - cl_r)
        shelf_rect['cage_dim_z'] = max(0.0, rect['cage_dim_z'] - cl_t)

    def _pocket_shifted(descs):
        # shelf_rect shrinks symmetrically off 0; the stack actually
        # starts past the left pocket, so shift the emitted parts.
        if cl_l:
            for d in descs:
                x, y, z = d['position']
                d['position'] = (x + cl_l, y, z)
        return descs

    out = []
    for item_index, item in enumerate(opening_props.interior_items):
        if item.kind == 'ADJUSTABLE_SHELF':
            # getattr: tolerate item collections created before the
            # nosing props existed (e.g. a live session spanning an
            # addon update).
            out.extend(_pocket_shifted(_adjustable_shelf_descriptors(
                shelf_rect, cage_dim_y, item.shelf_qty,
                max(item.shelf_setback, cl_f),
                getattr(item, 'shelf_nosing_style', 'NONE'),
                getattr(item, 'shelf_nosing_height', 0.0),
                getattr(item, 'bottom_offset', 0.0),
            )))
        elif item.kind in PARTIAL_DEPTH_SHELF_KINDS:
            # Partial-depth shelves: the front edge always sits at a
            # set fraction of the cavity depth, so the look holds
            # across wall, base, and tall cabinet depths (a static
            # setback would not). Parts emit as ADJUSTABLE_SHELF so
            # downstream consumers treat them like any other
            # adjustable shelf.
            depth_frac, depth_name = PARTIAL_DEPTH_SHELF_KINDS[item.kind]
            out.extend(_pocket_shifted(_shelf_stack_descriptors(
                shelf_rect, cage_dim_y, item.shelf_qty,
                max(cage_dim_y * (1.0 - depth_frac), cl_f),
                'ADJUSTABLE_SHELF', 'ADJUSTABLE_SHELF', depth_name,
                getattr(item, 'shelf_nosing_style', 'NONE'),
                getattr(item, 'shelf_nosing_height', 0.0),
                z0=getattr(item, 'bottom_offset', 0.0),
            )))
        elif item.kind == 'GLASS_SHELF':
            out.extend(_pocket_shifted(_glass_shelf_descriptors(
                shelf_rect, cage_dim_y, item.shelf_qty,
                max(item.shelf_setback, cl_f),
                z0=getattr(item, 'bottom_offset', 0.0),
            )))
        elif item.kind == 'PULLOUT_SHELF':
            out.extend(_pullout_shelf_descriptors(rect, cage_dim_y, item))
        elif item.kind == 'ROLLOUT':
            out.extend(_rollout_descriptors(rect, cage_dim_y, item,
                                            item_index))
        elif item.kind == 'TRAY_DIVIDERS':
            out.extend(_tray_dividers_descriptors(rect, cage_dim_y, item))
        elif item.kind == 'VANITY_SHELVES':
            out.extend(_vanity_shelves_descriptors(rect, cage_dim_y, item))
        elif item.kind == 'ACCESSORY':
            out.append(_accessory_label_descriptor(
                rect, cage_dim_y, item.accessory_label
            ))
        elif item.kind == 'CLOSET_ROD':
            out.append(_closet_rod_descriptor(rect, cage_dim_y, item))
        elif item.kind in bar_storage.KINDS:
            desc = _bar_storage_descriptor(rect, cage_dim_y, item)
            if desc is not None:
                out.append(desc)
    return out


# ---------------------------------------------------------------------------
# Interior split tree
# ---------------------------------------------------------------------------
# An opening can either carry a flat interior_items collection (no splits) or
# a tree of cage children that recursively subdivide it. Tree nodes are:
#   - split nodes: empties with TAG_INTERIOR_SPLIT_NODE; carry axis +
#     divider_thickness, with two children sorted by hb_interior_child_index.
#     'H' axis = horizontal divider (fixed shelf, children stacked in Z);
#     'V' axis = vertical divider (division, children side by side in X).
#   - leaves: cages with TAG_INTERIOR_REGION; carry their own interior_items
#     collection (same item type as the opening's flat collection).
#
# When walking a tree, descriptors emitted by the per-leaf builders are in
# region-local coords and get translated by the leaf's origin offset before
# joining the opening-level descriptor list. Divider descriptors are emitted
# directly in opening-local coords from the split-node level.


def _interior_tree_root(opening_obj):
    """Return the opening's tree root node (Empty or cage with one of the
    interior tags) if a tree exists, else None. The flat path uses the
    opening's own interior_items when this returns None.
    """
    from . import types_face_frame
    for c in opening_obj.children:
        if (c.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE)
                or c.get(types_face_frame.TAG_INTERIOR_REGION)):
            return c
    return None


def _read_interior_node_size(node):
    """Return (size, unlock_size) for any interior tree node."""
    from . import types_face_frame
    if node.get(types_face_frame.TAG_INTERIOR_REGION):
        rp = node.face_frame_interior_region
        return rp.size, rp.unlock_size
    if node.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE):
        sp = node.face_frame_interior_split
        return sp.size, sp.unlock_size
    return 0.0, False


def _shifted_descriptor(desc, offset):
    """Return a copy of desc with position translated by offset. Used to
    lift region-local descriptors from a leaf walk into opening-local
    coords. Rotation-relative dims are unaffected.
    """
    ox, oy, oz = offset
    px, py, pz = desc['position']
    out = dict(desc)
    out['position'] = (px + ox, py + oy, pz + oz)
    return out


def _walk_interior_node(node, rect, origin_offset,
                        layout, cab_props, out, opening_ff=None):
    """Recurse the interior tree. rect is the region's local cage_dim_*;
    origin_offset is the (x, y, z) of this region's front-left-bottom
    corner in OPENING-local coords. Leaves emit interior items
    (translated by origin_offset); split nodes emit one divider
    descriptor and recurse into children. opening_ff carries the owning
    opening's props down to every leaf (see interior_item_descriptors).
    """
    from . import types_face_frame

    if node.get(types_face_frame.TAG_INTERIOR_REGION):
        rp = node.face_frame_interior_region
        leaf_descs = interior_item_descriptors(
            layout, rect, cab_props, rp, opening_ff,
        )
        for d in leaf_descs:
            out.append(_shifted_descriptor(d, origin_offset))
        return

    if not node.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE):
        return

    sp = node.face_frame_interior_split
    children = sorted(
        [c for c in node.children
         if c.get(types_face_frame.TAG_INTERIOR_REGION)
         or c.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE)],
        key=lambda c: c.get('hb_interior_child_index', 0),
    )
    if len(children) != 2:
        # Malformed tree (split with != 2 children) - treat as empty;
        # the operator that created the split is responsible for keeping
        # the structure well-formed.
        return

    div_t = sp.divider_thickness
    cage_x = rect['cage_dim_x']
    cage_y = rect['cage_dim_y']
    cage_z = rect['cage_dim_z']

    # Face frame reveals for this region. The opening rect carries
    # all four; nested child rects built below inherit a reveal
    # only on edges coinciding with the opening boundary (0 on
    # edges shared with a sibling region). Optional FF parts inset
    # by these so they fit the FF opening, not the interior rect.
    rev_l = rect.get('reveal_left', 0.0)
    rev_r = rect.get('reveal_right', 0.0)
    rev_t = rect.get('reveal_top', 0.0)
    rev_b = rect.get('reveal_bottom', 0.0)

    # Both children's sizes are honored directly. The recalc-time
    # redistribution pass guarantees that for any unlocked sibling
    # the stored size already equals the remainder, so the walker
    # never has to compute it.
    size_a, _ = _read_interior_node_size(children[0])
    size_b, _ = _read_interior_node_size(children[1])

    if sp.axis == 'H':
        # Horizontal divider (fixed shelf). Children stack in Z.
        ox, oy, oz = origin_offset
        # Divider: HORIZONTAL part flush in X and Y, at z = size_a
        out.append({
            'kind':         'INTERIOR_FIXED_SHELF',
            'role':         'INTERIOR_FIXED_SHELF',
            'name':         f'Fixed Shelf {len(out) + 1}',
            'orientation':  'HORIZONTAL',
            'position':     (ox, oy, oz + size_a),
            'dims':         (cage_x, cage_y, div_t),
        })
        if sp.add_face_frame and sp.face_frame_width > 0.0:
            ffw = sp.face_frame_width
            # Rail inline with the FF plane; its top face is flush
            # with the shelf board's top, so it extends down by
            # ffw. Length inset by the left/right reveals so it
            # fits the FF opening.
            out.append({
                'kind':         'INTERIOR_FF_RAIL',
                'role':         'INTERIOR_FF_RAIL',
                'name':         f'Shelf Rail {len(out) + 1}',
                'orientation':  'HORIZONTAL',
                'position':     (ox + rev_l,
                                 _ff_front_y_bay_local(layout),
                                 oz + size_a + div_t - ffw),
                'dims':         (cage_x - rev_l - rev_r, ffw,
                                 layout.fft),
            })
        # Children stack in Z: left/right reveals pass through to
        # both; the bottom child keeps the bottom reveal (0 on
        # top, shared with the divider), the top child the top.
        lower_rect = {'cage_dim_x': cage_x, 'cage_dim_y': cage_y,
                      'cage_dim_z': size_a,
                      'reveal_left': rev_l, 'reveal_right': rev_r,
                      'reveal_top': 0.0, 'reveal_bottom': rev_b}
        upper_rect = {'cage_dim_x': cage_x, 'cage_dim_y': cage_y,
                      'cage_dim_z': size_b,
                      'reveal_left': rev_l, 'reveal_right': rev_r,
                      'reveal_top': rev_t, 'reveal_bottom': 0.0}
        _walk_interior_node(children[0], lower_rect, origin_offset,
                            layout, cab_props, out, opening_ff)
        upper_origin = (ox, oy, oz + size_a + div_t)
        _walk_interior_node(children[1], upper_rect, upper_origin,
                            layout, cab_props, out, opening_ff)
    else:
        # Vertical divider (division). Children stack in X.
        ox, oy, oz = origin_offset
        # Divider: VERTICAL part. Origin = back face Y, bottom Z; length
        # runs +Z, width runs -Y (mirror_y at materialize), thickness
        # extends in +X from the origin so left face = origin.x.
        out.append({
            'kind':         'INTERIOR_DIVISION',
            'role':         'INTERIOR_DIVISION',
            'name':         f'Division {len(out) + 1}',
            'orientation':  'VERTICAL',
            'position':     (ox + size_a, oy + cage_y, oz),
            'dims':         (cage_z, cage_y, div_t),
        })
        if sp.add_face_frame and sp.face_frame_width > 0.0:
            ffw = sp.face_frame_width
            # Stile inline with the FF plane, centered on the
            # division board's thickness centerline. Length inset
            # by the top/bottom reveals so it fits the FF opening.
            stile_x = ox + size_a + div_t / 2.0 - ffw / 2.0
            out.append({
                'kind':         'INTERIOR_FF_STILE',
                'role':         'INTERIOR_FF_STILE',
                'name':         f'Division Stile {len(out) + 1}',
                'orientation':  'VERTICAL',
                'position':     (stile_x,
                                 _ff_front_y_bay_local(layout),
                                 oz + rev_b),
                'dims':         (cage_z - rev_t - rev_b, ffw,
                                 layout.fft),
            })
        # Children stack in X: top/bottom reveals pass through to
        # both; the left child keeps the left reveal (0 on right,
        # shared with the divider), the right child the right.
        left_rect = {'cage_dim_x': size_a, 'cage_dim_y': cage_y,
                     'cage_dim_z': cage_z,
                     'reveal_left': rev_l, 'reveal_right': 0.0,
                     'reveal_top': rev_t, 'reveal_bottom': rev_b}
        right_rect = {'cage_dim_x': size_b, 'cage_dim_y': cage_y,
                      'cage_dim_z': cage_z,
                      'reveal_left': 0.0, 'reveal_right': rev_r,
                      'reveal_top': rev_t, 'reveal_bottom': rev_b}
        _walk_interior_node(children[0], left_rect, origin_offset,
                            layout, cab_props, out, opening_ff)
        right_origin = (ox + size_a + div_t, oy, oz)
        _walk_interior_node(children[1], right_rect, right_origin,
                            layout, cab_props, out, opening_ff)


def finish_liner_insets(opening_obj, layout, rect):
    """(left, right, top) clearance an opening's interior parts owe to
    the applied finish liners around it, in opening-local X / Z.

    A finished region carries 1/4 liner panels on its LEFT / RIGHT faces
    (see types._finish_region_specs), so anything living inside it -
    shelves, dividers, rollouts, interior frames - has to stop at the
    liner face rather than the bare cavity wall. There is no bottom or
    back inset: those faces get no liner (the carcass panels are cut
    from finish stock instead), so interior parts keep their normal
    clearance to them.

    The TOP is a bay-only inset. A finished OPENING applies no ceiling
    part unless it is FLUSH, so its interior parts keep their normal
    clearance to the panel above.

    A liner only borders an opening on the sides where the opening
    actually reaches the finished region's edge. A bay-level finish
    lines the BAY cage, so a middle opening in a side-by-side split owes
    nothing on the sides its neighbours cover; a per-opening finish
    lines that opening, so it owes all three.

    All zero when the region isn't finished, when the finish is FLUSH (a
    band around the FF opening, not a cavity lining), or on an angled
    cabinet (no liners are built there).
    """
    zero = (0.0, 0.0, 0.0)
    if layout.is_angled:
        return zero
    t = FINISH_LINER_THICKNESS
    eps = 1e-6

    # A bay-level finish supersedes any per-opening one (the bay liner
    # already covers everything), matching _reconcile_bay_finish_panels.
    bay_cage = opening_obj.parent
    while bay_cage is not None and not bay_cage.get('IS_FACE_FRAME_BAY_CAGE'):
        bay_cage = bay_cage.parent
    if bay_cage is not None and bay_cage.face_frame_bay.finish_bay:
        if bay_cage.face_frame_bay.finish_bay_flush:
            return zero
        bi = bay_cage.get('hb_bay_index')
        if bi is None or not (0 <= bi < len(layout.bays)):
            return zero
        bay_dim_x, _, bay_dim_z = bay_cage_dims(layout, bi)
        left = t if rect['cage_x'] <= eps else 0.0
        right = (t if abs(rect['cage_x'] + rect['cage_dim_x'] - bay_dim_x) <= eps
                 else 0.0)
        top = (t if abs(rect['cage_z'] + rect['cage_dim_z'] - bay_dim_z) <= eps
               else 0.0)
        return (left, right, top)

    op = opening_obj.face_frame_opening
    if op.finish_opening and not op.finish_opening_flush:
        return (t, t, 0.0)
    return zero


def interior_descriptors_for_opening(opening_obj, layout, rect, cab_props):
    """Top-level entry point for the recalc. Routes through the tree if
    one exists on `opening_obj`, else falls through to the flat path.

    Interior parts are laid out inside the finish liners when the
    opening sits in a finished region - see finish_liner_insets. The
    rect shrinks by the bordering liner thicknesses and every descriptor
    shifts back by the left inset, so the whole tree (splits included)
    lands in the lined cavity without each item kind knowing about it.
    """
    left_in, right_in, top_in = finish_liner_insets(opening_obj, layout, rect)
    if left_in or right_in or top_in:
        rect = dict(rect)
        rect['cage_dim_x'] = max(0.0, rect['cage_dim_x'] - left_in - right_in)
        rect['cage_dim_z'] = max(0.0, rect['cage_dim_z'] - top_in)

    root = _interior_tree_root(opening_obj)
    op_props = opening_obj.face_frame_opening
    if root is None:
        out = interior_item_descriptors(layout, rect, cab_props,
                                        op_props, op_props)
    else:
        out = []
        _walk_interior_node(root, rect, (0.0, 0.0, 0.0),
                            layout, cab_props, out, op_props)
    if left_in:
        out = [_shifted_descriptor(d, (left_in, 0.0, 0.0)) for d in out]
    return out


# ---------------------------------------------------------------------------
# Modify-cabinet support: world-space FF basis + boundary enumeration
# ---------------------------------------------------------------------------
# These helpers exist for the modify_cabinet modal operator. They convert
# between the FF-local (ff_x, ff_z) coordinate system used by every other
# solver function and Blender world space, accounting for the cabinet's
# location, Z rotation, and (for angled cabinets) face_frame_angle.

def face_frame_world_basis(cabinet_obj, layout):
    """Return (origin_w, x_axis_w, z_axis_w, normal_w) for the cabinet's
    FF outer plane, all in world space.

    - origin_w: world position of (ff_x=0, ff_z=0). This is the FF outer
      face's left endpoint at floor level.
    - x_axis_w: unit vector along the FF, in the direction of increasing
      ff_x (left endpoint to right endpoint).
    - z_axis_w: world +Z (cabinets stand vertical; FF is always plumb).
    - normal_w: unit vector pointing outward (away from the cabinet
      interior, into the room).

    Used by the modify-cabinet operator both to project mouse rays onto
    the FF plane and to project FF-local boundary positions back to
    screen space for GPU drawing.
    """
    from mathutils import Vector
    # ff_outer_world_pos returns cabinet-local coords. Two endpoints
    # define the FF line: ff_x=0 (left) and ff_x=face_frame_length (right),
    # both at world_z=0. Transform through the cabinet's matrix_world to
    # get world-space anchors.
    ff_len = face_frame_length(layout)
    p_left_local = Vector(ff_outer_world_pos(layout, 0.0, 0.0))
    p_right_local = Vector(ff_outer_world_pos(layout, ff_len, 0.0))
    mw = cabinet_obj.matrix_world
    origin_w = mw @ p_left_local
    p_right_w = mw @ p_right_local
    x_axis_w = (p_right_w - origin_w)
    if x_axis_w.length < 1e-8:
        x_axis_w = Vector((1.0, 0.0, 0.0))
    else:
        x_axis_w.normalize()
    z_axis_w = Vector((0.0, 0.0, 1.0))
    # Outward normal: cross of x_axis and z_axis, pointing away from
    # cabinet interior. The FF inner plane sits at +Y in cabinet-local
    # (carcass side); outer plane is at -Y. So outward in cabinet-local
    # is -Y, which under matrix_world rotation becomes -mw.col[1].xyz.
    # Easier: take the cross of x_axis_w and z_axis_w, then flip if it
    # points the wrong way (toward cabinet interior).
    normal_w = x_axis_w.cross(z_axis_w)
    if normal_w.length < 1e-8:
        normal_w = Vector((0.0, -1.0, 0.0))
    else:
        normal_w.normalize()
    # Test orientation: the cabinet's local +Y points into the carcass
    # interior. Outward should be opposite. mw.col[1].xyz is local +Y in
    # world space; if normal_w dots positive with it, flip.
    local_y_in_world = Vector((mw[0][1], mw[1][1], mw[2][1]))
    if normal_w.dot(local_y_in_world) > 0.0:
        normal_w = -normal_w
    return origin_w, x_axis_w, z_axis_w, normal_w


def ff_local_to_world(cabinet_obj, layout, ff_x, ff_z):
    """Map (ff_x, ff_z) on the FF outer plane to a world-space Vector.

    Wraps face_frame_world_basis for callers that just want a point.
    """
    origin_w, x_axis_w, z_axis_w, _normal_w = face_frame_world_basis(
        cabinet_obj, layout)
    return origin_w + x_axis_w * ff_x + z_axis_w * ff_z


def mouse_to_ff_local_with_basis(region, rv3d, mouse_xy, basis):
    """Project a mouse position onto a FF outer plane defined by a
    precomputed world-space basis; return (ff_x, ff_z) plus the
    world-space hit point.

    basis is the (origin_w, x_axis_w, z_axis_w, normal_w) tuple from
    face_frame_world_basis. Use this instead of mouse_to_ff_local when
    the cabinet's matrix_world is mid-update (e.g. translate-style drags),
    so the projection reference frame stays frozen for the whole drag.

    Returns (ff_x, ff_z, world_hit) on success, None on failure (parallel
    ray, projection failed, or behind viewer).

    ff_x is along the FF (0 at left endpoint, face_frame_length at right);
    ff_z is vertical (matches world Z relative to cabinet's floor).
    """
    from bpy_extras import view3d_utils
    from mathutils.geometry import intersect_line_plane
    if region is None or rv3d is None:
        return None
    co2d = (mouse_xy[0], mouse_xy[1])
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co2d)
    ray_dir = view3d_utils.region_2d_to_vector_3d(region, rv3d, co2d)
    if ray_origin is None or ray_dir is None:
        return None
    origin_w, x_axis_w, z_axis_w, normal_w = basis
    hit = intersect_line_plane(
        ray_origin, ray_origin + ray_dir, origin_w, normal_w,
    )
    if hit is None:
        return None
    rel = hit - origin_w
    ff_x = rel.dot(x_axis_w)
    ff_z = rel.dot(z_axis_w)
    return (ff_x, ff_z, hit)


def mouse_to_ff_local(cabinet_obj, layout, region, rv3d, mouse_xy):
    """Project a mouse position onto the cabinet's FF outer plane and
    return (ff_x, ff_z) plus the world-space hit point.

    Derives the FF basis from the cabinet's current matrix_world. For
    drags that move the cabinet underneath the cursor, freeze the basis
    once and use mouse_to_ff_local_with_basis instead.

    Returns (ff_x, ff_z, world_hit) on success, None on failure (parallel
    ray, projection failed, or behind viewer).

    ff_x is along the FF (0 at left endpoint, face_frame_length at right);
    ff_z is vertical (matches world Z relative to cabinet's floor).
    """
    basis = face_frame_world_basis(cabinet_obj, layout)
    return mouse_to_ff_local_with_basis(region, rv3d, mouse_xy, basis)


def bay_edge_ff_x(layout, edge_index):
    """FF-local X of the centerline of the mid-stile separating bays
    edge_index and edge_index+1.

    Valid edge_index range: 0 .. bay_count - 2. The drag handle for
    resizing two adjacent bays sits on this centerline.
    """
    if edge_index < 0 or edge_index >= layout.bay_count - 1:
        raise IndexError(f"bay edge {edge_index} out of range")
    x = layout.lsw
    for i in range(edge_index):
        x += layout.bays[i]['width']
        x += layout.mid_stiles[i]['width']
    x += layout.bays[edge_index]['width']
    x += layout.mid_stiles[edge_index]['width'] * 0.5
    return x


def editable_boundaries_v1(cabinet_obj, layout):
    """Yield boundary records for the modify-cabinet operator.

    Three kinds, all carrying axis = 'X' or 'Z' so the operator can
    branch on drag direction without re-inspecting kind:
      BAY_EDGE   - axis 'X', vertical line, drag horizontal,
                   commits via Face_Frame_Bay_Props.width
      MID_STILE  - axis 'X', vertical line, drag horizontal,
                   commits via the two child nodes' size + unlock_size
      MID_RAIL   - axis 'Z', horizontal line, drag vertical,
                   commits via the two child nodes' size + unlock_size
    """
    from . import types_face_frame
    bay_objs = sorted(
        [c for c in cabinet_obj.children if c.get(types_face_frame.TAG_BAY_CAGE)],
        key=lambda c: c.get('hb_bay_index', 0),
    )
    # BAY_EDGE pass
    if layout.bay_count >= 2:
        for i in range(layout.bay_count - 1):
            ff_x = bay_edge_ff_x(layout, i)
            zl_left = bay_bottom_z(layout, i)
            zh_left = bay_top_z(layout, i)
            zl_right = bay_bottom_z(layout, i + 1)
            zh_right = bay_top_z(layout, i + 1)
            ff_z_low = min(zl_left, zl_right)
            ff_z_high = max(zh_left, zh_right)
            locked_left = False
            locked_right = False
            if i < len(bay_objs):
                locked_left = bool(bay_objs[i].face_frame_bay.unlock_width)
            if i + 1 < len(bay_objs):
                locked_right = bool(bay_objs[i + 1].face_frame_bay.unlock_width)
            yield {
                'kind': 'BAY_EDGE',
                'axis': 'X',
                'primary_sign': 1.0,
                'cabinet_obj': cabinet_obj,
                'edge_index': i,
                'ff_x': ff_x,
                'ff_z_low': ff_z_low,
                'ff_z_high': ff_z_high,
                'left_bay_idx': i,
                'right_bay_idx': i + 1,
                'locked_left': locked_left,
                'locked_right': locked_right,
            }
    # Per-bay vertical-anchor handles. Top edge and bottom edge of each
    # bay map to different bay properties depending on cabinet type:
    #   base / tall: top -> bay.height            (drag up => grow)
    #                bottom -> bay.kick_height    (drag up => grow)
    #   upper:       top -> bay.top_offset        (drag up => shrink)
    #                bottom -> bay.height         (drag up => shrink)
    # Live in Grab Face Frame; outer cabinet edges live in Grab Cabinet.
    is_upper = (layout.cabinet_type == 'UPPER')
    for bi, bay_obj in enumerate(bay_objs):
        bp = bay_obj.face_frame_bay
        x0 = bay_x_position(layout, bi)
        x1 = x0 + layout.bays[bi]['width']
        z_top = bay_top_z(layout, bi)
        z_bottom = bay_bottom_z(layout, bi)
        if is_upper:
            # Top edge drives top_offset AND height: dragging up shrinks
            # top_offset (bay top rises) while growing height by the
            # same amount (bay bottom stays put). bay_bottom_z =
            # dim_z - top_offset - height; preserving it requires
            # d(top_offset) + d(height) = 0, i.e. compensate_sign is
            # the negative of primary's effect on top_offset.
            yield {
                'kind': 'BAY_HANDLE',
                'axis': 'Z',
                'primary_sign': -1.0,
                'cabinet_obj': cabinet_obj,
                'bay_obj_name': bay_obj.name,
                'attr': 'top_offset',
                'unlock_attr': 'unlock_top_offset',
                # top_offset is signed: positive drops the bay below
                # the cabinet ceiling, negative pushes it above. No
                # lower bound — the user's design intent rules.
                'min_value': float('-inf'),
                'compensate_attr': 'height',
                'compensate_unlock_attr': 'unlock_height',
                'compensate_sign': 1.0,
                'compensate_min_value': inch(2.0),
                'locked': bool(bp.unlock_top_offset),
                'ff_z': z_top,
                'ff_x_low': x0,
                'ff_x_high': x1,
            }
            # Bottom edge drives height (drag up shrinks height).
            # No compensate: dragging the bottom moves only the bottom
            # edge; top stays put because top_offset isn't touched.
            yield {
                'kind': 'BAY_HANDLE',
                'axis': 'Z',
                'primary_sign': -1.0,
                'cabinet_obj': cabinet_obj,
                'bay_obj_name': bay_obj.name,
                'attr': 'height',
                'unlock_attr': 'unlock_height',
                'min_value': inch(2.0),
                'locked': bool(bp.unlock_height),
                'ff_z': z_bottom,
                'ff_x_low': x0,
                'ff_x_high': x1,
            }
        else:
            # Top edge drives height (drag up grows height)
            yield {
                'kind': 'BAY_HANDLE',
                'axis': 'Z',
                'primary_sign': 1.0,
                'cabinet_obj': cabinet_obj,
                'bay_obj_name': bay_obj.name,
                'attr': 'height',
                'unlock_attr': 'unlock_height',
                'locked': bool(bp.unlock_height),
                'ff_z': z_top,
                'ff_x_low': x0,
                'ff_x_high': x1,
            }
            # Kick top drives kick_height (drag up grows kick_height).
            # Only emit when the cabinet has a toe kick at all.
            if layout.has_toe_kick:
                yield {
                    'kind': 'BAY_HANDLE',
                    'axis': 'Z',
                    'primary_sign': 1.0,
                    'cabinet_obj': cabinet_obj,
                    'bay_obj_name': bay_obj.name,
                    'attr': 'kick_height',
                    'unlock_attr': 'unlock_kick_height',
                    'min_value': 0.0,
                    'locked': bool(bp.unlock_kick_height),
                    'ff_z': z_bottom,
                    'ff_x_low': x0,
                    'ff_x_high': x1,
                }
    # MID_STILE / MID_RAIL pass per bay
    for bi in range(layout.bay_count):
        for b in intra_bay_boundaries(cabinet_obj, layout, bi):
            yield b

def intra_bay_boundaries(cabinet_obj, layout, bay_index):
    """Yield MID_STILE and MID_RAIL boundary records for one bay.

    Walks the splitter rects emitted by bay_openings() and converts them
    from bay-local coords to FF-local coords. For non-angled cabinets the
    bay's cage X origin in cabinet-local equals its FF-local X origin, so
    the conversion is an additive offset. Angled cabinets use the same
    relation since bay-local X aligns with the FF direction (see
    bay_cage_position).

    Each yielded record carries enough context for the modify-cabinet
    operator to commit a drag without re-deriving geometry: the parent
    split node's name, the splitter's gap index, and the two adjacent
    children's object names plus current lock state.
    """
    from . import types_face_frame
    bo = bay_openings(layout, bay_index)
    splitters = bo.get('splitters', [])
    if not splitters:
        return
    bay = layout.bays[bay_index]
    cage_left_x, _ = _cage_x_bounds(layout, bay_index)
    cage_bottom_z = bay_bottom_z(layout, bay_index) + effective_bottom_rail_width(layout, bay_index)

    for s in splitters:
        node_name = s.get('split_node_name')
        node_obj = bpy.data.objects.get(node_name) if node_name else None
        if node_obj is None:
            continue
        # Children of the split node, sorted to match the tree's
        # iteration order so splitter_index lines up with the gap.
        kids = sorted(
            [c for c in node_obj.children
             if c.get(types_face_frame.TAG_OPENING_CAGE)
             or c.get(types_face_frame.TAG_SPLIT_NODE)],
            key=lambda c: c.get('hb_split_child_index', 0),
        )
        gi = s['splitter_index']
        if gi < 0 or gi + 1 >= len(kids):
            continue
        left_kid = kids[gi]
        right_kid = kids[gi + 1]
        locked_left = _kid_unlock_size(left_kid)
        locked_right = _kid_unlock_size(right_kid)
        if s['role'] == 'BAY_MID_STILE':
            # Vertical line on the FF outer plane. Drag axis: FF-X.
            ff_x = cage_left_x + s['x'] + s['splitter_width'] * 0.5
            ff_z_low = cage_bottom_z + s['z']
            ff_z_high = ff_z_low + s['length']
            yield {
                'kind': 'MID_STILE',
                'axis': 'X',
                'primary_sign': 1.0,
                'cabinet_obj': cabinet_obj,
                'bay_index': bay_index,
                'split_node_name': node_name,
                'splitter_index': gi,
                'left_child_name': left_kid.name,
                'right_child_name': right_kid.name,
                'ff_x': ff_x,
                'ff_z_low': ff_z_low,
                'ff_z_high': ff_z_high,
                'locked_left': locked_left,
                'locked_right': locked_right,
            }
        elif s['role'] == 'BAY_MID_RAIL':
            # Horizontal line on the FF outer plane. Drag axis: FF-Z.
            # 'top' / 'bottom' wording mirrors how the user sees them:
            # left_kid (lower hb_split_child_index) sits at the TOP of
            # the rail because _walk_tree allocates H-split children
            # top-down (cur_z_top decreases each iteration).
            ff_z = cage_bottom_z + s['z'] + s['splitter_width'] * 0.5
            ff_x_low = cage_left_x + s['x']
            ff_x_high = ff_x_low + s['length']
            yield {
                'kind': 'MID_RAIL',
                'axis': 'Z',
                'primary_sign': -1.0,
                'cabinet_obj': cabinet_obj,
                'bay_index': bay_index,
                'split_node_name': node_name,
                'splitter_index': gi,
                'top_child_name': left_kid.name,
                'bottom_child_name': right_kid.name,
                'ff_z': ff_z,
                'ff_x_low': ff_x_low,
                'ff_x_high': ff_x_high,
                'locked_top': locked_left,
                'locked_bottom': locked_right,
            }


def _kid_unlock_size(kid_obj):
    """Read unlock_size from a tree-child object (opening leaf or split
    node). Both PropertyGroups expose unlock_size with the same name."""
    if hasattr(kid_obj, 'face_frame_opening') and kid_obj.face_frame_opening is not None:
        try:
            return bool(kid_obj.face_frame_opening.unlock_size)
        except AttributeError:
            pass
    if hasattr(kid_obj, 'face_frame_split') and kid_obj.face_frame_split is not None:
        try:
            return bool(kid_obj.face_frame_split.unlock_size)
        except AttributeError:
            pass
    return False


def editable_boundaries_cabinet(cabinet_obj, layout):
    """Boundary records for the cabinet-level grab operator.

    Exposes only the four outer edges of the cabinet — left, right,
    top, bottom. Bay-level and intra-bay edits live in
    editable_boundaries_v1 (Grab Face Frame). This separation keeps
    each operator's overlay unambiguous: at any FF position there's
    exactly one drag handle per Grab variant, no flicker between
    overlapping per-bay and cabinet-level lines.

    LEFT and BOTTOM dragging translate the cabinet's location (so the
    opposite edge stays put) in addition to writing the dimension.
    Depth is omitted; face-on UX doesn't render a depth handle cleanly.
    """
    ff_len = face_frame_length(layout)
    # OUTER_RIGHT — vertical line at the FF's right end
    yield {
        'kind': 'OUTER_RIGHT',
        'axis': 'X',
        'primary_sign': 1.0,
        'cabinet_obj': cabinet_obj,
        'dim_attr': 'width',
        'ff_x': ff_len,
        'ff_z_low': 0.0,
        'ff_z_high': layout.dim_z,
    }
    # OUTER_LEFT — vertical line at the FF's left end. Translates the
    # cabinet location along +ff_x_world so the right edge stays put.
    yield {
        'kind': 'OUTER_LEFT',
        'axis': 'X',
        'primary_sign': -1.0,
        'translate': True,
        'translate_axis': 'X',
        'cabinet_obj': cabinet_obj,
        'dim_attr': 'width',
        'ff_x': 0.0,
        'ff_z_low': 0.0,
        'ff_z_high': layout.dim_z,
    }
    # OUTER_TOP — horizontal line at the cabinet's top
    yield {
        'kind': 'OUTER_TOP',
        'axis': 'Z',
        'primary_sign': 1.0,
        'cabinet_obj': cabinet_obj,
        'dim_attr': 'height',
        'ff_z': layout.dim_z,
        'ff_x_low': 0.0,
        'ff_x_high': ff_len,
    }
    # OUTER_BOTTOM — horizontal line at the cabinet's bottom, UPPER
    # cabinets only. Translates the cabinet location along ff Z so the
    # TOP edge stays put: dragging the bottom down grows the height and
    # lowers the mount in one gesture (the wall-cabinet bottom adjust).
    # Floor-standing types keep their bottom pinned to the floor / toe
    # kick, so no handle there.
    if getattr(cabinet_obj.face_frame_cabinet, 'cabinet_type', '') == 'UPPER':
        yield {
            'kind': 'OUTER_BOTTOM',
            'axis': 'Z',
            'primary_sign': -1.0,
            'translate': True,
            'translate_axis': 'Z',
            'cabinet_obj': cabinet_obj,
            'dim_attr': 'height',
            'ff_z': 0.0,
            'ff_x_low': 0.0,
            'ff_x_high': ff_len,
        }
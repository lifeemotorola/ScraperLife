"""Face Frame product library - scene properties and library UI.

Phase 2 scaffolding: scene-level PropertyGroup, library presentation, and
section toggles. Construction logic and per-cabinet PropertyGroups land in
Phase 3 (types_face_frame.py).
"""
import bpy
import os
import re
from contextlib import contextmanager
from bpy.types import (
    PropertyGroup,
    UIList,
)
from bpy.props import (
    BoolProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
    CollectionProperty,
    EnumProperty,
)
from ... import units
from ... import hb_utils
from . import finish_colors, wood_materials, style_options, shelf_nosing
from . import wood_top_edge
from . import decorative_corner
from . import cabinet_column


# Finish-end / back conditions. Module-level so both Cabinet_Props and
# Scene_Props can reference the same enum items list.
FIN_END_ITEMS = [
    ('UNFINISHED', "Unfinished", "Side is unfinished (against a wall or hidden)"),
    ('FINISHED', "Finished", "Side IS the outer face (3/4 stock)"),
    ('PANELED', "Paneled", "Applied panel with rails and stiles"),
    ('FALSE_FF', "False Face Frame", "Applied frame with non-working fronts"),
    ('WORKING_FF', "Working Face Frame", "Applied frame with working fronts"),
    ('BEADBOARD', "Beadboard", "Beadboard finished end"),
    ('SHIPLAP', "Shiplap", "Shiplap finished end"),
    ('V_GROOVE', "V-Groove", "V-groove finished end"),
    ('FLUSH_X', "Finished Flush X Inches", "Finished strip running the front X inches of the side"),
]

# Construction of a finished-side RETURN member (the return panel or its
# rear stile). FINISHED = a flat 3/4 part; PANELED = an applied panel with
# rails / stiles + inset panel (same PanelFaceFrameCabinet machinery as a
# PANELED side); BEADBOARD / SHIPLAP = a 3/4 part carved with the same
# texture the textured side/back fields use. Per-member, per-side;
# default FINISHED.
# Texture a finished interior can carry. The same three treatments the
# finished ends and backs offer, on the liner panels that line a
# finished bay or opening - an open cabinet lined in v-groove is the
# ordinary case. FLAT is the plain liner, and the default, so a finish
# that was set before this existed is unchanged.
INTERIOR_TEXTURE_ITEMS = [
    ('NONE', "Flat", "Plain finished liner panels"),
    ('BEADBOARD', "Beadboard", "Liners carved with vertical quirk-bead grooves"),
    ('SHIPLAP', "Shiplap", "Liners carved with nickel-gap plank reveals"),
    ('V_GROOVE', "V-Groove", "Liners carved with vertical v-groove cuts"),
]

RETURN_MEMBER_TYPE_ITEMS = [
    ('FINISHED', "Finished", "Flat 3/4 finished part"),
    ('PANELED', "Paneled", "Applied panel with rails / stiles and an inset panel"),
    ('BEADBOARD', "Beadboard", "3/4 part with vertical quirk-bead grooves"),
    ('SHIPLAP', "Shiplap", "3/4 part with nickel-gap plank reveals"),
    ('V_GROOVE', "V-Groove", "3/4 part with vertical v-groove cuts"),
]


# Exposure states per side. UNEXPOSED = covered by wall or neighbor over
# the full cabinet height. PARTIAL = neighbor abuts but only covers part
# of the height (tall vs. base/upper). EXPOSED = no abutting neighbor.
# Drives the auto-pick of finished_end_condition in exposure.py.
EXPOSURE_ITEMS = [
    ('UNEXPOSED', "Unexposed", "Side is fully covered by a wall or neighbor"),
    ('PARTIAL', "Partial", "Side is partially covered by a shorter neighbor"),
    ('EXPOSED', "Exposed", "Side has no abutting neighbor"),
]


# ---------------------------------------------------------------------------
# Preview collection management - mirrors frameless lifecycle
# ---------------------------------------------------------------------------
preview_collections = {}


def get_library_previews():
    """Get or create the library preview collection (user library, moldings)."""
    if "library_previews" not in preview_collections:
        preview_collections["library_previews"] = bpy.utils.previews.new()
    return preview_collections["library_previews"]


def get_cabinet_previews():
    """Get or create the cabinet preview collection (button thumbnails)."""
    if "cabinet_previews" not in preview_collections:
        preview_collections["cabinet_previews"] = bpy.utils.previews.new()
    return preview_collections["cabinet_previews"]


def get_cabinet_thumbnail_path():
    """Path to the bundled face_frame_thumbnails folder."""
    return os.path.join(os.path.dirname(__file__), "face_frame_thumbnails")


def get_frameless_thumbnail_fallback_path():
    """Fallback to the frameless thumbnails folder while face_frame ones are
    being created. A face_frame thumbnail of the same name takes precedence."""
    return os.path.join(
        os.path.dirname(os.path.dirname(__file__)),
        "frameless",
        "frameless_thumbnails",
    )


def load_library_thumbnail(filepath, name):
    """Load a thumbnail image into the user library preview collection."""
    pcoll = get_library_previews()
    if name in pcoll:
        return pcoll[name].icon_id
    if os.path.exists(filepath):
        thumb = pcoll.load(name, filepath, 'IMAGE')
        return thumb.icon_id
    return 0


def load_cabinet_thumbnail(name):
    """Load a cabinet button thumbnail by name (without extension).

    Looks in face_frame_thumbnails/ first, falls back to the frameless folder
    so the library has visible icons before face-frame-specific renders are
    produced. Returns 0 if no thumbnail is found anywhere.
    """
    pcoll = get_cabinet_previews()
    if name in pcoll:
        return pcoll[name].icon_id
    # One resolver, shared with the viewport library panel -- which
    # uploads the same file to a GPU texture instead of a preview icon.
    from . import library_catalog
    path = library_catalog.thumbnail_path(name)
    if path:
        return pcoll.load(name, path, 'IMAGE').icon_id
    return 0


def clear_library_previews():
    """Clear loaded user library previews (called when refreshing)."""
    if "library_previews" in preview_collections:
        preview_collections["library_previews"].clear()


def get_cabinet_group_category_items(self, context):
    """Dynamic enum items for the user library category dropdown. Indirect
    through the operators package so this module doesn't pull operator
    code in at import time."""
    from .operators import ops_library
    return ops_library.get_cabinet_group_categories()


# ---------------------------------------------------------------------------
# Update callbacks
# ---------------------------------------------------------------------------

def get_style_props(context=None):
    """Return the hb_face_frame props that own the shared style pools.

    Cabinet styles and door styles are project-global -- they live on the
    main scene so every room sees the same set. Route any cabinet_styles /
    door_styles / active-index access through here instead of reading
    context.scene.hb_face_frame directly. Per-scene settings (default
    sizes, selection mode) stay on the active scene.
    """
    from ... import hb_project
    ctx = context or bpy.context
    main = hb_project.get_main_scene(ctx)
    if main is not None and hasattr(main, "hb_face_frame"):
        return main.hb_face_frame
    return ctx.scene.hb_face_frame


def update_cabinet_style_name(self, context):
    """Keep style names unique within the collection AND propagate a rename
    to every cabinet already tagged with this style (its STYLE_NAME), so an
    assigned cabinet keeps resolving -- and 2D-colouring -- after a rename.
    The prior name is tracked in rename_anchor because Blender's update
    callback does not expose the old value."""
    main = get_style_props(context)
    base_name = self.name if self.name else "Style"
    existing = [s.name for s in main.cabinet_styles if s != self]
    final = base_name
    if base_name in existing:
        i = 1
        while f"{base_name}.{i:03d}" in existing:
            i += 1
        final = f"{base_name}.{i:03d}"
    old = self.rename_anchor
    if old and old != final:
        for obj in bpy.data.objects:
            if obj.get('STYLE_NAME') == old:
                obj['STYLE_NAME'] = final
    self.rename_anchor = final
    # Apply the de-duplicated name last. If this re-enters the callback,
    # final is already unique and anchor == final, so it is a clean no-op.
    if self.name != final:
        self.name = final


def get_stain_color_enum_items(self, context):
    """Dynamic items for the stain color dropdown. Pulled fresh so newly
    saved custom colors show up without restart."""
    items = []
    colors = finish_colors.get_all_stain_colors()
    for i, name in enumerate(colors.keys()):
        is_custom = finish_colors.is_custom_color(name, 'stain')
        desc = f"Custom: {name}" if is_custom else name
        items.append((name, name, desc, i))
    if not items:
        items.append(('Natural', "Natural", "Natural", 0))
    return items


def get_paint_color_enum_items(self, context):
    """Dynamic items for the paint color dropdown."""
    items = []
    colors = finish_colors.get_all_paint_colors()
    for i, name in enumerate(colors.keys()):
        is_custom = finish_colors.is_custom_color(name, 'paint')
        desc = f"Custom: {name}" if is_custom else name
        items.append((name, name, desc, i))
    if not items:
        items.append(('Arctic White', "Arctic White", "Arctic White", 0))
    return items


def get_door_style_enum_items(self, context):
    """Dynamic items for the cabinet style's door / drawer-front pickers.
    Reads names from the shared door_styles pool on the scene props.
    """
    items = []
    ff = get_style_props(context)
    for i, ds in enumerate(ff.door_styles):
        items.append((ds.name, ds.name, ds.name, i))
    if not items:
        items.append(('NONE', "(none defined)", "No door styles defined", 0))
    return items


def get_drawer_front_style_enum_items(self, context):
    """Dynamic items for the cabinet style's drawer-front picker. Reads names
    from the drawer_front_styles pool (independent from door_styles)."""
    items = []
    ff = get_style_props(context)
    for i, ds in enumerate(ff.drawer_front_styles):
        items.append((ds.name, ds.name, ds.name, i))
    if not items:
        items.append(('NONE', "(none defined)", "No drawer front styles defined", 0))
    return items


# ---------------------------------------------------------------------------
# Catalog options + compatibility cascades (baked in style_options.py from the
# reference partner spreadsheets). These are SPEC selections: they record the
# correct, compatibility-filtered choices -- wood -> color -> varnish/glaze,
# overlay -> hinge, and front series -> shape -> panel -- WITHOUT yet driving
# geometry or material. The existing wood_species / door_overlay_type enums
# still own rendering + face-frame sizing; wiring these to material /
# sizing is a deliberate later pass.
#
# Enum item-tuples are built ONCE at module load into module-level dicts. That
# doubles as the keepalive Blender needs (a callback returning freshly built
# tuples each call risks GC mid-use -- see the _EXTERIOR_CONFIG_ITEMS note).
# The callbacks just look the cached list up by the current upstream value.

def _enum_items(values):
    """[(identifier, name, description, index), ...] from a list of names."""
    return [(v, v, v, i) for i, v in enumerate(values)]


def _hinge_items(rows):
    """De-duplicated hinge items [(code, desc, desc, index), ...]."""
    seen, out = set(), []
    for code, desc, _default in rows:
        if code in seen:
            continue
        seen.add(code)
        out.append((code, desc, desc, len(out)))
    return out


_NONE_ITEMS = [('NONE', "(none)", "No selection", 0)]


def _items_or_none(items):
    return items if items else _NONE_ITEMS


# --- cabinet-style finish caches ---
_FINISH_WOOD_ITEMS = [(i, lbl, lbl, n)
                      for n, (i, lbl) in enumerate(style_options.woods_for_ui())]
_FINISH_COLOR_ITEMS = {w: [(i, lbl, lbl, n)
                           for n, (i, lbl) in enumerate(style_options.colors_for_wood_ui(w))]
                       for w in style_options.WOOD_SPECIES}
_FINISH_VARNISH_ITEMS = {c: _enum_items(style_options.varnishes_for_color(c) or ["N/A"])
                         for c in style_options.COLORS}
_FINISH_GLAZE_ITEMS = {c: _enum_items(style_options.glazes_for_color(c))
                       for c in style_options.COLORS}
_FINISH_OVERLAY_ITEMS = [(i, lbl, lbl, n)
                         for n, (i, lbl) in enumerate(style_options.overlays_for_ui())]
_FINISH_HINGE_ITEMS = {o: _hinge_items(rows)
                       for o, rows in style_options.OVERLAY_TO_HINGES.items()}


def _set_enum_safe(owner, prop, identifier):
    """Assign an enum identifier only if valid for the prop's current items
    (assigning an out-of-list identifier raises). No-op on mismatch."""
    try:
        setattr(owner, prop, identifier)
    except (TypeError, ValueError):
        pass


def get_finish_wood_items(self, context):
    return _items_or_none(_FINISH_WOOD_ITEMS)


def get_finish_color_items(self, context):
    return _items_or_none(_FINISH_COLOR_ITEMS.get(self.finish_wood, []))


def get_finish_varnish_items(self, context):
    return _items_or_none(_FINISH_VARNISH_ITEMS.get(self.finish_color, []))


def get_finish_glaze_items(self, context):
    return _items_or_none(_FINISH_GLAZE_ITEMS.get(self.finish_color, []))


def get_finish_overlay_items(self, context):
    return _items_or_none(_FINISH_OVERLAY_ITEMS)


def get_finish_hinge_items(self, context):
    return _items_or_none(_FINISH_HINGE_ITEMS.get(self.finish_overlay, []))


def update_finish_wood(self, context):
    """Wood gates color: reset to the first compatible color (which cascades
    on to varnish + glaze through update_finish_color)."""
    items = _FINISH_COLOR_ITEMS.get(self.finish_wood, [])
    if items:
        _set_enum_safe(self, "finish_color", items[0][0])
    _propagate_cabinet_style(self, context)


def update_finish_color(self, context):
    """Color gates varnish + glaze: reset both to their first compatible."""
    v = _FINISH_VARNISH_ITEMS.get(self.finish_color, [])
    if v:
        _set_enum_safe(self, "finish_varnish", v[0][0])
    g = _FINISH_GLAZE_ITEMS.get(self.finish_color, [])
    if g:
        _set_enum_safe(self, "finish_glaze", g[0][0])
    _propagate_cabinet_style(self, context)


def update_finish_overlay(self, context):
    """Overlay gates hinge AND drives FF sizing: reset to the overlay's
    default hinge, then map the catalog overlay onto one of the five FF
    sizing buckets by setting door_overlay_type (which runs
    update_face_frame_sizes -> writes the rail/stile widths + reveals)."""
    default = style_options.default_hinge_for_overlay(self.finish_overlay)
    if default:
        _set_enum_safe(self, "finish_hinge", default)
        self.finish_hinge_seeded = True
    bucket = style_options.ff_overlay_bucket(self.finish_overlay)
    if bucket:
        _set_enum_safe(self, "door_overlay_type", bucket)


# --- door / drawer front catalog caches (series -> shape -> panel) ---
# _front_is_drawer (which pool the style lives in) selects which catalog the
# cascade reads -- the door_styles pool models doors, drawer_front_styles
# models drawer fronts.
_DOOR_SERIES_ITEMS = _enum_items(style_options.DOOR_SERIES)
_DRAWER_SERIES_ITEMS = _enum_items(style_options.DRAWER_SERIES)
_DOOR_SHAPE_ITEMS = {s: _enum_items(style_options.door_shapes(s))
                     for s in style_options.DOOR_SERIES}
_DRAWER_SHAPE_ITEMS = {s: _enum_items(style_options.door_shapes(s, drawer=True))
                       for s in style_options.DRAWER_SERIES}
_DOOR_PANEL_ITEMS = {(s, sh): _enum_items(style_options.door_panels(s, sh))
                     for s in style_options.DOOR_SERIES
                     for sh in style_options.door_shapes(s)}
_DRAWER_PANEL_ITEMS = {(s, sh): _enum_items(style_options.door_panels(s, sh, drawer=True))
                       for s in style_options.DRAWER_SERIES
                       for sh in style_options.door_shapes(s, drawer=True)}


def _front_is_drawer(self):
    """A style reads the DRAWER catalog when it lives in the
    drawer_front_styles pool (vs door_styles). Derived from the RNA path so
    there is no separate Kind property. Defaults to door (False) if the path
    can't be read (e.g. transient / unlinked)."""
    try:
        return "drawer_front_styles" in self.path_from_id()
    except Exception:
        return False


def get_front_series_items(self, context):
    return _items_or_none(_DRAWER_SERIES_ITEMS if _front_is_drawer(self) else _DOOR_SERIES_ITEMS)


def get_front_shape_items(self, context):
    table = _DRAWER_SHAPE_ITEMS if _front_is_drawer(self) else _DOOR_SHAPE_ITEMS
    return _items_or_none(table.get(self.front_series, []))


def get_front_panel_items(self, context):
    table = _DRAWER_PANEL_ITEMS if _front_is_drawer(self) else _DOOR_PANEL_ITEMS
    return _items_or_none(table.get((self.front_series, self.front_shape), []))


def update_front_series(self, context):
    table = _DRAWER_SHAPE_ITEMS if _front_is_drawer(self) else _DOOR_SHAPE_ITEMS
    items = table.get(self.front_series, [])
    if items:
        _set_enum_safe(self, "front_shape", items[0][0])
    _apply_series_frame_to_door_style(self)
    _refresh_auto_front_style_name(self)
    _propagate_door_style(self, context)


def _apply_series_frame_to_door_style(self):
    """Derive the door style's construction (stile / rail widths, drawer-rail,
    panel inset/thickness, slab vs 5-piece) from the catalog series + front
    kind, and WRITE it into the construction fields. This keeps the catalog
    (series/shape/panel) as the single source of truth while the existing
    geometry path (assign_style_to_front) and the applied-panel sizing engine
    keep reading stile_width / rail_width / door_type unchanged. Widths in the
    baked spec are inches -> converted with units.inch()."""
    spec = style_options.frame_for_series(self.front_series,
                                          getattr(self, 'front_shape', None),
                                          getattr(self, 'front_panel', None))
    if spec.get('is_slab'):
        self.door_type = 'SLAB'
        return
    self.door_type = '5_PIECE'
    # Stile and rail unlock independently; the catalog cascade (any of kind/
    # series/shape/panel routes through here) must not clobber a field the
    # dealer manages. Everything else still derives.
    if not self.unlock_stile_width:
        self.stile_width = units.inch(spec['stile'])
    if not self.unlock_rail_width:
        # Drawer fronts use the series' drawer-rail width; doors use the rail.
        rail_in = spec['drw_rail'] if _front_is_drawer(self) else spec['rail']
        self.rail_width = units.inch(rail_in)
    if 'panel_inset' in spec:
        self.panel_inset = units.inch(spec['panel_inset'])
    if 'panel_thickness' in spec:
        self.panel_thickness = units.inch(spec['panel_thickness'])
    # Profile picks follow the series unless the dealer unlocked them.
    # The raised-panel profile only applies to a RAISED panel kind;
    # everything else keeps the flat panel.
    if not getattr(self, 'unlock_profiles', False):
        prof = style_options.profiles_for_series(self.front_series)
        _set_enum_safe(self, 'outside_profile_name',
                       prof.get('outside', 'NONE'))
        _set_enum_safe(self, 'inside_profile_name',
                       prof.get('inside', 'NONE'))
        _set_enum_safe(self, 'panel_profile_name',
                       prof.get('panel', 'NONE')
                       if style_options.panel_kind(
                           self.front_panel)['kind'] == 'RAISED'
                       else 'NONE')


def update_front_shape(self, context):
    table = _DRAWER_PANEL_ITEMS if _front_is_drawer(self) else _DOOR_PANEL_ITEMS
    items = table.get((self.front_series, self.front_shape), [])
    if items:
        _set_enum_safe(self, "front_panel", items[0][0])
    # Shape-width series (Konza): the shape IS the member width, so the
    # construction fields must re-derive on a shape change too.
    _apply_series_frame_to_door_style(self)
    # The shape drives geometry (arched tops); the panel reset above
    # only propagates when the panel value actually changes, so push
    # explicitly -- shape-only changes must rebuild fronts too.
    _refresh_auto_front_style_name(self)
    _propagate_door_style(self, context)


def update_front_panel(self, context):
    """Panel chosen -> re-derive the frame construction from the series, push
    to assigned fronts, and re-apply materials so a Prep-for-Glass panel
    renders as glass immediately (and switching away restores the finish)."""
    _apply_series_frame_to_door_style(self)
    _refresh_auto_front_style_name(self)
    _propagate_door_style(self, context)
    _reapply_materials_for_door_style(self, context)


def update_rail_width(self, context):
    """The door's mid rail always mirrors the (top/bottom) rail width, so any
    change to rail_width -- catalog-derived or a manual override while frame
    widths are unlocked -- carries into mid_rail_width before propagating to
    assigned fronts. Setting mid_rail_width fires its own _propagate_door_style,
    so only propagate directly here when mid already matched (one rebuild)."""
    if self.mid_rail_width != self.rail_width:
        self.mid_rail_width = self.rail_width
    else:
        _propagate_door_style(self, context)


def update_unlock_frame_widths(self, context):
    """Shared lock-toggle callback for unlock_stile_width / unlock_rail_width.
    Re-deriving here writes only the still-LOCKED fields from the catalog
    series (the unlocked one is skipped in _apply_series_frame_to_door_style),
    so re-locking a field snaps it back to the series spec while a re-derive of
    an already-locked field is idempotent. The catalog rail write fires
    rail_width's update, which re-mirrors the mid rail."""
    _apply_series_frame_to_door_style(self)
    _propagate_door_style(self, context)


def _reapply_materials_for_door_style(door_style, context):
    """Re-run the CABINET material walk for every cabinet with a front using
    ``door_style``. Material application lives on the cabinet style
    (_apply_materials_to_cabinet), so a door-style change that affects a
    front's surfaces -- grain rotation OR a Prep-for-Glass panel -- only
    takes effect once that walk re-runs. Resolve each affected front's
    cabinet root + cabinet style and run it once per cabinet. Scoped to the
    active scene (same as _propagate_door_style)."""
    target = door_style.name
    ff = get_style_props()
    styles_by_name = {cs.name: cs for cs in ff.cabinet_styles}
    seen = set()
    for obj in list(context.scene.objects):
        if obj.get('DOOR_STYLE_NAME') != target:
            continue
        cur, cab = obj, None
        while cur is not None:
            if cur.get('IS_FACE_FRAME_CABINET_CAGE'):
                cab = cur
                break
            cur = cur.parent
        if cab is None or cab.name in seen:
            continue
        seen.add(cab.name)
        cs = styles_by_name.get(cab.get('STYLE_NAME'))
        if cs is not None:
            cs._apply_materials_to_cabinet(cab)


def update_grain_direction(self, context):
    """Grain direction changed -> re-apply materials to every cabinet with a
    front using this door style so the grain rotation takes effect
    immediately, no manual recalc."""
    _reapply_materials_for_door_style(self, context)


def update_custom_procedural_material(self, context):
    """Forward custom-procedural shader edits to the wood material module."""
    wood_materials.update_finish_material_custom_procedural(self)


# Suspend-propagation refcount. While > 0, _propagate_cabinet_style
# returns immediately - used to silence the storm of update callbacks
# that fire when one user action writes many style props in sequence
# (e.g. an overlay change writes 21 width props, each of which would
# otherwise re-propagate to the whole scene).
_PROPAGATE_SUSPEND_DEPTH = 0


@contextmanager
def suspend_propagate():
    """Refcounted context manager around _propagate_cabinet_style. Use
    around bulk style-prop writes to coalesce into a single explicit
    propagate at the outermost resume.
    """
    global _PROPAGATE_SUSPEND_DEPTH
    _PROPAGATE_SUSPEND_DEPTH += 1
    try:
        yield
    finally:
        _PROPAGATE_SUSPEND_DEPTH -= 1


def _propagate_cabinet_style(self, context):
    """Push this cabinet style's current state to every face frame
    cabinet in the scene tagged with STYLE_NAME == self.name. Wired
    as the update callback on every cabinet-style prop that affects
    cabinet geometry / appearance, so changes in the style panel
    reflect across the scene without needing an explicit Update
    Cabinets click.

    Returns immediately under suspend_propagate(); callers performing
    bulk writes (update_face_frame_sizes' overlay sweep) hold the
    suspend through the inner setattrs and call propagate explicitly
    once at the end.

    Wrapped in suspend_recalc(): each assign_style_to_cabinet ends
    with an explicit recalculate_face_frame_cabinet call; under the
    outer suspend those recalcs queue by name and drain once at
    exit, so we get one recalc per cabinet (not one per assign step
    per cabinet) when a single style change sweeps through the scene.
    """
    if _PROPAGATE_SUSPEND_DEPTH > 0:
        return
    from . import types_face_frame
    target_name = self.name
    with types_face_frame.suspend_recalc():
        # Snapshot the targets BEFORE acting: rebuild_built_hood deletes
        # and recreates the hood's part objects immediately (it is not
        # deferred by suspend_recalc like the cabinet recalcs), and
        # removing scene members under a live scene.objects iterator
        # walks freed memory -- hard crash (EXCEPTION_ACCESS_VIOLATION
        # in Scene_objects_next). The targets themselves are root cages
        # / hood cages, which no step deletes, so the snapshot stays
        # valid throughout.
        targets = [obj for obj in context.scene.objects
                   if obj.get('STYLE_NAME') == target_name
                   and (obj.get('IS_FACE_FRAME_CABINET_CAGE')
                        or obj.get('APPLIANCE_TYPE') == 'HOOD')]
        for obj in targets:
            if obj.get('IS_FACE_FRAME_CABINET_CAGE'):
                self.assign_style_to_cabinet(obj)
            else:
                # Hood doors are static python-built meshes: a door-style
                # / overlay edit must rebuild the built hood (the rebuild
                # re-pushes the finish). Unbuilt hoods just take the
                # finish as before.
                from ..common import wood_hoods
                if not wood_hoods.rebuild_built_hood(obj):
                    self.assign_style_to_hood(obj)


def _propagate_door_style(self, context):
    """Push this door style's current state to every front tagged with
    DOOR_STYLE_NAME == self.name. Same pattern as the cabinet style
    propagator: edits in the door style panel reflect across every
    front using that style without a button press.
    """
    # Both style pools stamp the same DOOR_STYLE_NAME tag on fronts, and
    # a door style and a drawer-front style may share a name. Gate on the
    # front's role so a drawer-style edit can't restyle same-named DOOR
    # fronts (and vice versa) - matches the paint-assign semantics.
    target_name = self.name
    roles = (Face_Frame_Door_Style._DRAWER_FRONT_ROLES
             if _front_is_drawer(self)
             else Face_Frame_Door_Style._DOOR_FRONT_ROLES)
    # Snapshot before acting: restyling can add / remove scene objects,
    # and mutating scene membership under a live scene.objects iterator
    # is a hard crash (see _propagate_cabinet_style).
    fronts = [obj for obj in context.scene.objects
              if obj.get('DOOR_STYLE_NAME') == target_name
              and obj.get('hb_part_role') in roles]
    for obj in fronts:
        self.assign_style_to_front(obj)
    # A style edit can move the stile / rail widths a round-top door's
    # curve is measured from, and restyling fronts is not a recalc, so
    # re-cut the frame members above them.
    if fronts:
        from . import types_face_frame as _tff
        refreshed = []
        for obj in fronts:
            root = _tff.find_cabinet_root(obj)
            if root is not None and root not in refreshed:
                refreshed.append(root)
        for root in refreshed:
            _tff.refresh_round_top_frames(root)
    # Wood-hood doors are static python-built meshes, not restyleable
    # fronts -- rebuild any built hood whose resolved cabinet style uses
    # this door style (STYLE_NAME's style, else the active style, the
    # same fallback wood_hoods._hood_style builds doors with).
    if not _front_is_drawer(self):
        from ..common import wood_hoods
        ff = get_style_props()
        active = (ff.cabinet_styles[ff.active_cabinet_style_index]
                  if 0 <= ff.active_cabinet_style_index < len(ff.cabinet_styles)
                  else None)
        # Snapshot: the hood rebuild deletes / recreates the hood's part
        # objects, which would invalidate a live scene.objects iterator.
        hoods = [obj for obj in context.scene.objects
                 if obj.get('APPLIANCE_TYPE') == 'HOOD']
        for obj in hoods:
            name = obj.get('STYLE_NAME')
            style = next((s for s in ff.cabinet_styles if s.name == name),
                         None) if name else None
            if style is None:
                style = active
            if style is not None and style.door_style == target_name:
                wood_hoods.rebuild_built_hood(obj)
    # A door-style change can move the rail width that match-door-rail
    # drawer styles mirror, so re-push those styles' fronts too. Drawer
    # styles are terminal here (_front_is_drawer) - no recursion.
    if not _front_is_drawer(self):
        ff = get_style_props()
        matched = [ds.name for ds in ff.drawer_front_styles
                   if ds.match_door_rail_width]
        if matched:
            by_name = {ds.name: ds for ds in ff.drawer_front_styles}
            drw_roles = Face_Frame_Door_Style._DRAWER_FRONT_ROLES
            drawer_fronts = [
                obj for obj in context.scene.objects
                if obj.get('DOOR_STYLE_NAME') in matched
                and obj.get('hb_part_role') in drw_roles]
            for obj in drawer_fronts:
                by_name[obj.get('DOOR_STYLE_NAME')].assign_style_to_front(obj)


def update_face_frame_sizes(self, context):
    """door_overlay_type change handler. Writes new widths into every
    locked rail cell + every stile cell based on the overlay. Unlocked
    rails keep the user's value. The bulk width writes are coalesced
    under suspend_propagate(); a single _propagate_cabinet_style at the
    end then pushes the new sizes to every scene cabinet carrying this
    style (same auto-propagation as the other style props - the manual
    Update Cabinets op is a force-resync fallback, not the normal path).
    """
    defaults = self._FF_SIZE_DEFAULTS.get(
        self.door_overlay_type, self._FF_SIZE_DEFAULTS['CLASSIC'])

    # Each ff_*_width_* prop carries update=_propagate_cabinet_style,
    # which would re-propagate to every matching cabinet per setattr.
    # Suspend it for the bulk write and propagate ONCE at the end.
    with suspend_propagate():
        # Rails - only write the cell when its unlock flag is False.
        for row, key in (('top_rail', 'top'),
                         ('bottom_rail', 'bottom'),
                         ('mid_rail', 'mid')):
            base_in, tall_in, upper_in = defaults[row]
            if not getattr(self, f"unlock_base_{key}_rail"):
                setattr(self, f"ff_{row}_width_base", units.inch(base_in))
            if not getattr(self, f"unlock_tall_{key}_rail"):
                setattr(self, f"ff_{row}_width_tall", units.inch(tall_in))
            if not getattr(self, f"unlock_upper_{key}_rail"):
                setattr(self, f"ff_{row}_width_upper", units.inch(upper_in))

        # Stiles - always overlay-driven, no unlocks.
        for row in ('wall_stile', 'mid_stile', 'end_stile', 'blind_stile',
                    'butt_stile', 'inside_90_stile', 'angle_stile'):
            base_in, tall_in, upper_in = defaults[row]
            setattr(self, f"ff_{row}_width_base", units.inch(base_in))
            setattr(self, f"ff_{row}_width_tall", units.inch(tall_in))
            setattr(self, f"ff_{row}_width_upper", units.inch(upper_in))

    # One propagate now that the style is fully consistent.
    _propagate_cabinet_style(self, context)


# Out-of-box default front for a freshly created door / drawer-front style
# (ensure_default_styles). Craftsman / Square / Solid Wood Recessed is a
# common starting point; without it a new style falls on the alphabetical-
# first series. Applied in cascade order (series resets shape, shape resets
# panel) so each level sticks; valid for both the door and drawer catalogs.
_DEFAULT_FRONT = ("Craftsman", "Square", "Solid Wood Recessed")


def _apply_default_front_style(ds):
    series, shape, panel = _DEFAULT_FRONT
    _set_enum_safe(ds, "front_series", series)
    _set_enum_safe(ds, "front_shape", shape)
    _set_enum_safe(ds, "front_panel", panel)


def ensure_default_styles(context):
    """Make sure the scene carries at least one cabinet style and one
    door style. Operators that read from those collections call this
    on entry so the user never sees an empty-active state. Adds a
    Default cabinet style + Slab door style when empty; idempotent.
    """
    ff = get_style_props(context)
    if len(ff.cabinet_styles) == 0:
        cs = ff.cabinet_styles.add()
        cs.name = "Default"
        ff.active_cabinet_style_index = 0
    # One-time hinge seeding: styles whose hinge was never explicitly set
    # otherwise read the number-0 catalog row (Compact) instead of the
    # overlay's default hinge (CLIPtop for the standard overlays).
    for cs in ff.cabinet_styles:
        if not cs.finish_hinge_seeded:
            default = style_options.default_hinge_for_overlay(cs.finish_overlay)
            if default:
                _set_enum_safe(cs, "finish_hinge", default)
            cs.finish_hinge_seeded = True
    if len(ff.door_styles) == 0:
        ds = ff.door_styles.add()
        _apply_default_front_style(ds)
        ds.name = _auto_front_style_name(*_DEFAULT_FRONT)
        # Rail callouts are a drawer-rail concern: door styles start
        # with the callout off (the drawer seed below keeps the
        # enabled default). Copy-based Add duplicates the active
        # style, so this seed value carries into new door styles.
        ds.show_rail_annotation = False
        ff.active_door_style_index = 0
    if len(ff.drawer_front_styles) == 0:
        ds = ff.drawer_front_styles.add()
        _apply_default_front_style(ds)
        ds.name = _auto_front_style_name(*_DEFAULT_FRONT)
        ff.active_drawer_front_style_index = 0


def update_door_style_name(self, context):
    """Keep style names unique within the style's OWN pool (door_styles or
    drawer_front_styles -- independent lists, so a name may repeat across
    pools). Pool is read from the RNA path.

    Fronts are tagged with the style's name (DOOR_STYLE_NAME), so a rename
    re-tags them from the previous name held in rename_anchor -- the same
    scheme the cabinet style uses for STYLE_NAME. Cabinet-style references
    (door_style / drawer_front_style) are index-backed dynamic enums and
    follow a rename on their own."""
    main = get_style_props(context)
    in_drawer = _front_is_drawer(self)
    pool = main.drawer_front_styles if in_drawer else main.door_styles
    base_name = self.name if self.name else "Door Style"
    existing = [s.name for s in pool if s != self]
    final = base_name
    if base_name in existing:
        i = 1
        while f"{base_name}.{i:03d}" in existing:
            i += 1
        final = f"{base_name}.{i:03d}"
    # A live sibling's name can never be this style's previous name, so an
    # anchor that matches one is stale (a copied style) and must not re-tag.
    old = self.rename_anchor
    if old and old != final and old not in existing:
        roles = (Face_Frame_Door_Style._DRAWER_FRONT_ROLES if in_drawer
                 else Face_Frame_Door_Style._DOOR_FRONT_ROLES)
        for obj in bpy.data.objects:
            if (obj.get('DOOR_STYLE_NAME') == old
                    and obj.get('hb_part_role') in roles):
                obj['DOOR_STYLE_NAME'] = final
    self.rename_anchor = final
    # Apply the de-duplicated name last; a re-entry sees anchor == final
    # and is a clean no-op.
    if self.name != final:
        self.name = final


# --- automatic front-style names (series + shape + panel) ---
# A style keeps following its catalog pick as long as its name is one this
# rule would produce (or one of the seed names); typing any other name pins
# it. No stored flag: the name itself is the record.
_LEGACY_AUTO_FRONT_NAMES = {"Door Style", "Craftsman Square Recessed Panel"}
_AUTO_FRONT_NAMES_CACHE = {}
_NAME_SUFFIX_RE = re.compile(r"\.\d{3}$")


def _auto_front_style_name(series, shape, panel):
    return " ".join(part for part in (series, shape, panel) if part)


def _auto_front_style_names(in_drawer):
    names = _AUTO_FRONT_NAMES_CACHE.get(bool(in_drawer))
    if names is None:
        table = _DRAWER_PANEL_ITEMS if in_drawer else _DOOR_PANEL_ITEMS
        names = {_auto_front_style_name(series, shape, panel[0])
                 for (series, shape), panels in table.items()
                 for panel in panels}
        names |= _LEGACY_AUTO_FRONT_NAMES
        _AUTO_FRONT_NAMES_CACHE[bool(in_drawer)] = names
    return names


def _refresh_auto_front_style_name(self):
    """Series / shape / panel changed: rename the style after the pick
    unless the user gave it a name of their own."""
    current = self.name or ""
    base = _NAME_SUFFIX_RE.sub("", current)
    if base not in _auto_front_style_names(_front_is_drawer(self)):
        return
    new = _auto_front_style_name(self.front_series, self.front_shape,
                                 self.front_panel)
    if base == new:
        return
    # The name update callback de-duplicates within the pool and re-tags
    # the fronts carrying the old name.
    self.name = new


def update_top_cabinet_clearance(self, context):
    """Recompute the derived cabinet heights when either the top
    clearance or the wall cabinet location changes. Same callback is
    wired to default_top_cabinet_clearance and default_wall_cabinet_location
    since both formulas read both source props.

    Formulas:
        tall_cabinet_height  = ceiling - top_clearance
        upper_cabinet_height = ceiling - top_clearance - wall_location

    Ceiling height lives on scene.home_builder (the addon-wide scene
    props). Skip silently if it isn't present - the addon may not be
    fully registered yet during initial load.
    """
    if not hasattr(context.scene, 'home_builder'):
        return
    ceiling = context.scene.home_builder.ceiling_height
    self.tall_cabinet_height = ceiling - self.default_top_cabinet_clearance
    self.upper_cabinet_height = (ceiling
                                 - self.default_top_cabinet_clearance
                                 - self.default_wall_cabinet_location)


def update_face_frame_selection_mode(self, context):
    """Apply visibility highlighting for the active selection mode.

    Calls the hb_face_frame.toggle_mode operator which iterates all scene
    objects and highlights/dims them based on which mode is active.
    """
    bpy.ops.hb_face_frame.toggle_mode(search_obj_name="")


# Object colour a cabinet carries when style colours are off. White is
# what an untinted part renders as, so turning the option off puts every
# cabinet back where it started.
_NO_STYLE_TINT = (1.0, 1.0, 1.0, 1.0)
# Where the viewport's own colour mode is parked while style colours are
# on, so turning them off restores what the user had.
_STYLE_COLOR_SHADING_KEY = 'HB_PRE_STYLE_COLOR_SHADING'

# Fill colour per style, by the style's position in the pool: the first
# style is white (the project default) and each one after takes the next
# muted pastel, the last entry repeating for a pool longer than the
# palette. Downstream 2D consumers assign the same palette by the same
# rule, so a cabinet wears the colour on screen that it prints on paper.
STYLE_COLOR_PALETTE = (
    (1.0, 1.0, 1.0),      # White (project default)
    (0.75, 0.85, 0.95),   # Light Blue
    (0.75, 0.92, 0.75),   # Light Green
    (0.95, 0.85, 0.75),   # Light Peach
    (0.88, 0.80, 0.95),   # Light Lavender
    (0.95, 0.95, 0.75),   # Light Yellow
    (0.85, 0.75, 0.75),   # Light Rose
)

# Whatever a selection mode is offering to be clicked is drawn solid and
# in front of the cabinet, so an opaque tint would hide the cabinet it is
# meant to be colouring. It takes the style colour at this alpha instead:
# enough to read the colour, transparent enough to see the cabinet
# through it. Everything else stays opaque.
_STYLE_CAGE_ALPHA = 0.25

# Cages, as opposed to parts: the wash alpha applies to all of them, so a
# bay or opening cage doesn't black out the cabinet in its own mode.
_STYLE_CAGE_TAGS = (
    'IS_FACE_FRAME_CABINET_CAGE',
    'IS_FACE_FRAME_BAY_CAGE',
    'IS_FACE_FRAME_OPENING_CAGE',
    'IS_FACE_FRAME_PRODUCT_CAGE',
    'IS_FRAMELESS_CABINET_CAGE',
    'IS_FRAMELESS_PRODUCT_CAGE',
    'IS_CAGE_GROUP',
)


# The palette is tuned for 2D drawings, where a pastel fill sits behind
# black line work on white paper. Washed over shaded 3D geometry the same
# pastels all read as white, so the viewport uses the same hue at this
# much more saturation -- similar colour, actually distinguishable.
_STYLE_VIEWPORT_SATURATION = 2.2
_STYLE_VIEWPORT_MIN_SATURATION = 0.45


def style_palette_color(index):
    """Palette entry for a style at ``index`` in the pool, last repeating."""
    if index < 0:
        index = 0
    return STYLE_COLOR_PALETTE[min(index, len(STYLE_COLOR_PALETTE) - 1)]


def style_viewport_color(rgb):
    """``rgb`` saturated enough to read as a colour in solid shading.

    Hue and brightness are left alone, so a cabinet still looks like the
    fill its drawings carry. A colourless entry (the first style's white)
    stays white rather than being pushed into a hue it never had.
    """
    import colorsys
    hue, sat, val = colorsys.rgb_to_hsv(rgb[0], rgb[1], rgb[2])
    if sat <= 0.0:
        return (rgb[0], rgb[1], rgb[2])
    sat = max(min(sat * _STYLE_VIEWPORT_SATURATION, 1.0),
              _STYLE_VIEWPORT_MIN_SATURATION)
    return colorsys.hsv_to_rgb(hue, sat, val)


def _is_cage(obj):
    return any(obj.get(tag) for tag in _STYLE_CAGE_TAGS)


def _style_tint_for_cabinet(cabinet_obj, styles):
    """The RGB a cabinet should render as, or None if it has no style.

    The colour comes from the style's place in the pool rather than from
    its stored swatch: the swatch is only filled in once shop drawings
    have been generated, so reading it left every cabinet white until
    then. The stored swatch is refreshed to match on the way past, so the
    style panel shows the colour its cabinets are wearing.
    """
    name = cabinet_obj.get('STYLE_NAME')
    if not name:
        return None
    for index, style in enumerate(styles):
        if style.name != name:
            continue
        colour = style_palette_color(index)
        if tuple(style.color_in_2d_drawings) != colour:
            style.color_in_2d_drawings = colour
        return style_viewport_color(colour)
    return None


def _annotation_color(context):
    """The colour drawing text is meant to wear, from preferences.

    Dimensions and labels are annotation, not cabinet surface: they
    print from ``obj.color``, so they have to keep this colour even
    when the cabinet they hang off is wearing a style tint.
    """
    try:
        hb_props = context.window_manager.home_builder
        return tuple(hb_props.get_user_preferences(context).annotation_color)
    except Exception:
        return (0.0, 0.0, 0.0, 1.0)


def apply_style_colors(context):
    """Paint (or unpaint) every cabinet in the scene with its style's
    drawing colour, and put the viewport in object-colour mode to show
    it. Returns the number of cabinets tinted."""
    from . import types_face_frame
    scene = context.scene
    props = get_style_props(context)
    on = bool(props.show_style_colors)
    styles = props.cabinet_styles

    tinted = 0
    # Annotation hangs off the cabinet it describes, so a plain walk of the
    # children painted the drawing's dimensions and labels in the cabinet's
    # colour (and washed them out again when the tint came off). They are
    # repainted to their own colour on the way past instead, which also
    # puts right any that an earlier build had already tinted.
    note_colour = _annotation_color(context)
    for cage in [o for o in scene.objects
                 if o.get(types_face_frame.TAG_CABINET_CAGE)]:
        tint = _style_tint_for_cabinet(cage, styles) if on else None
        if tint is None:
            cage.color = _NO_STYLE_TINT
            for child in cage.children_recursive:
                child.color = (note_colour if child.get('IS_2D_ANNOTATION')
                               else _NO_STYLE_TINT)
            continue
        part_colour = (tint[0], tint[1], tint[2], 1.0)
        cage_colour = (tint[0], tint[1], tint[2], _STYLE_CAGE_ALPHA)
        cage.color = cage_colour
        for child in cage.children_recursive:
            if child.get('IS_2D_ANNOTATION'):
                child.color = note_colour
                continue
            child.color = cage_colour if _is_cage(child) else part_colour
        tinted += 1

    # The colour only shows in solid shading's OBJECT mode; remember what
    # the viewport had so turning this off gives it back.
    for area in getattr(context.screen, 'areas', ()):
        if area.type != 'VIEW_3D':
            continue
        for space in area.spaces:
            if space.type != 'VIEW_3D':
                continue
            if on:
                if _STYLE_COLOR_SHADING_KEY not in scene:
                    scene[_STYLE_COLOR_SHADING_KEY] = space.shading.color_type
                space.shading.color_type = 'OBJECT'
            else:
                space.shading.color_type = scene.get(
                    _STYLE_COLOR_SHADING_KEY, 'MATERIAL')
    if not on and _STYLE_COLOR_SHADING_KEY in scene:
        del scene[_STYLE_COLOR_SHADING_KEY]
    return tinted


def style_color_for_object(obj, context=None, highlight=None):
    """The colour ``obj`` should wear under style colours, or None.

    Selection modes repaint cages and parts as the user moves between
    them, and would otherwise put a cabinet back to the generic
    highlight. They ask here first, so a cabinet keeps its style's
    colour through a mode change. None means "not our business": the
    option is off, or the object belongs to no cabinet style.

    ``highlight`` says whether this object is the thing the active
    selection mode is offering to be clicked -- a cage in Cabinets mode,
    the frame members in Face Frame, the shelves in Interiors. Those get
    the see-through wash whatever they are, so the cabinet behind them
    stays readable and every mode looks like the others. Left None, a
    cage is treated as the highlight and a part is not, which is what a
    plain repaint of the whole scene wants.
    """
    if obj is None:
        return None
    if obj.get('IS_2D_ANNOTATION'):
        return None          # drawing text keeps its own colour
    context = context or bpy.context
    try:
        props = get_style_props(context)
    except Exception:
        return None
    if not props.show_style_colors:
        return None
    root = obj
    while root is not None and not root.get('IS_FACE_FRAME_CABINET_CAGE'):
        root = root.parent
    if root is None:
        return None
    tint = _style_tint_for_cabinet(root, props.cabinet_styles)
    if tint is None:
        return None
    if highlight is None:
        highlight = _is_cage(obj)
    alpha = _STYLE_CAGE_ALPHA if highlight else 1.0
    return (tint[0], tint[1], tint[2], alpha)


def update_show_style_colors(self, context):
    """Toggle: paint the cabinets by style section, or put them back."""
    apply_style_colors(context)


def update_include_drawer_boxes(self, context):
    """Toggle: rebuild every face frame cabinet so drawer boxes are added
    behind drawer/pullout fronts (when True) or removed (when False).

    Reuses the cabinet recalc path rather than walking children directly
    so drawer-box presence stays a derived consequence of front parts -
    one source of truth in _update_fronts_in_opening. Wrapped in
    suspend_recalc so a scene full of cabinets recalcs once per cabinet
    instead of once per intermediate prop write.
    """
    from . import types_face_frame
    with types_face_frame.suspend_recalc():
        cages = [obj for obj in context.scene.objects
                 if obj.get(types_face_frame.TAG_CABINET_CAGE)]
        for obj in cages:
            types_face_frame.recalculate_face_frame_cabinet(obj)


# ---------------------------------------------------------------------------
# Cabinet Style (placeholder shell, full implementation in Phase 4)
# ---------------------------------------------------------------------------
class Face_Frame_Millwork_Item(PropertyGroup):
    """One millwork line item on a cabinet style's Style Section.

    Shown on the Style Section page as ``name`` + ``quantity`` (always in
    FEET). ``product_code`` is stored for downstream reports. ``auto_collected``
    flags items added by the Collect Millwork scan so a re-collect can replace
    just those while leaving hand-typed items alone.
    """
    name: StringProperty(
        name="Name",
        description="Millwork item name (e.g. 'Finish Toe Kick', '51 Crown')",
        default="Millwork",
    )  # type: ignore
    quantity: FloatProperty(
        name="Quantity (ft)",
        description="Linear quantity in feet",
        default=0.0,
        min=0.0,
        precision=1,
    )  # type: ignore
    product_code: StringProperty(
        name="Product Code",
        description="Millwork product code (used by downstream reports)",
        default="",
    )  # type: ignore
    auto_collected: BoolProperty(
        name="Auto Collected",
        description="True when added by the Collect Millwork scan (replaced on "
                    "re-collect; hand-typed items are kept)",
        default=False,
    )  # type: ignore


def _draw_second_ref_image(col, owner, ref_image_attr):
    """The second image slot for a reference, on its own row under the
    first. Only offered once the first image is set (or the second is
    already filled), so a reference with one picture stays one row."""
    second = ref_image_attr + "_2"
    if not (getattr(owner, ref_image_attr, "") or getattr(owner, second, "")):
        return
    r = col.row(align=True)
    r.label(text="", icon='BLANK1')
    r.prop(owner, second, text="", icon='IMAGE_DATA')


class Face_Frame_Special_Effect(PropertyGroup):
    """One special-effect line on a cabinet style's finish (e.g. a distress
    or rub-through). The built-in ``name`` holds the catalog effect name
    (offered names gated by the style's wood + color via
    style_options.special_effects_for). ``ref_name`` / ``ref_image`` are an
    optional finish reference: the name is appended to the effect's FINISH
    row on the Style Section page, the image is collected into the page's
    right-side references box (mirrors the per-finish refs on the style)."""
    ref_name: StringProperty(
        name="Reference",
        description="Reference name for this special effect, shown on the Style Section finish row",
        default="",
    )  # type: ignore
    ref_image: StringProperty(
        name="Reference Image",
        description="Path to a reference image for this special effect, shown in the Style Section references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    ref_image_2: StringProperty(
        name="Second Reference Image",
        description="A second reference image for this special effect, shown under the first in the references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore


def get_cabinet_extra_front_style_items(self, context):
    """Items for an extra-front-style row on a cabinet style. Resolves the
    pool by the row's RNA path (the _front_is_drawer trick): a row living in
    extra_drawer_front_styles reads the drawer-front pool, otherwise the door
    pool. Works on a collection item as self because it derives the pool from
    the path, not the row's own state."""
    ff = get_style_props(context)
    try:
        drawer = "extra_drawer_front_styles" in self.path_from_id()
    except Exception:
        drawer = False
    pool = ff.drawer_front_styles if drawer else ff.door_styles
    items = [(ds.name, ds.name, ds.name, i) for i, ds in enumerate(pool)]
    if not items:
        items.append(('NONE', "(none defined)", "No front styles defined", 0))
    return items


class Face_Frame_Cabinet_Extra_Front_Style(PropertyGroup):
    """One additional door- or drawer-front style listed on a cabinet style.

    The primary door_style / drawer_front_style drives the geometry; these
    extra entries document the OTHER front styles a designer assigns to this
    cabinet style's cabinets in 3D, so the Style Section page can list every
    front style in use, not just the primary. Pure documentation -- no
    geometric effect. The pool (door vs drawer front) is fixed by which
    collection the row lives in.
    """
    style: EnumProperty(
        name="Front Style",
        description="Additional front style shown on the Style Section page",
        items=get_cabinet_extra_front_style_items,
    )  # type: ignore


class Face_Frame_Style_Note(PropertyGroup):
    """One free-text note line on a cabinet style, printed in a NOTES
    section at the end of the style's Style Section block (e.g.
    'TOUCH LATCH = TL'). Pure documentation -- no geometric effect."""
    text: StringProperty(
        name="Note",
        description="Free-text note printed on the Style Section page",
        default="",
    )  # type: ignore


# Full-inset doors sit inside the frame, so the box hangs from slides on a
# construction that must keep its sides clear of the frame edge -- the product
# spec offers no French dovetail box there. The items list is rebuilt per draw
# and held at module level so the enum strings stay alive.
_SS_BOX_CONSTRUCTION_ITEMS = []


def get_ss_box_construction_items(self, context):
    _SS_BOX_CONSTRUCTION_ITEMS.clear()
    if self.door_overlay_type != 'FULL_INSET':
        _SS_BOX_CONSTRUCTION_ITEMS.append(('French', 'French', ''))
    _SS_BOX_CONSTRUCTION_ITEMS.append(('English', 'English', ''))
    return _SS_BOX_CONSTRUCTION_ITEMS


class Face_Frame_Cabinet_Style(PropertyGroup):
    """Face frame cabinet style: wood species, finish color, interior
    material, door overlay, and references to a door style + drawer front
    style from the shared door_styles collection. Applied via
    assign_style_to_cabinet(), which writes the four overlay floats and
    inset depth onto the cabinet, assigns materials to every part, and
    walks fronts to apply the referenced door/drawer-front styles.
    """

    name: StringProperty(
        name="Name",
        description="Cabinet style name",
        default="Style",
        update=update_cabinet_style_name,
    )  # type: ignore
    rename_anchor: StringProperty(
        name="Rename Anchor",
        description="Internal: the style's previous name, used to propagate a "
                    "rename to cabinets tagged with the old STYLE_NAME",
        default="",
        options={'HIDDEN'},
    )  # type: ignore

    show_expanded: BoolProperty(
        name="Show Expanded",
        description="Show expanded style options",
        default=False,
    )  # type: ignore

    color_in_2d_drawings: FloatVectorProperty(
        name="2D Drawing Color",
        description="Fill color for cabinets of this style in 2D shop drawings",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0),
    )  # type: ignore

    # ---- Wood / exterior material ----
    wood_species: EnumProperty(
        name="Wood Species",
        description="Wood species for cabinet exterior",
        items=[
            ('MAPLE', "Maple", "Maple wood"),
            ('OAK', "Oak", "Oak wood"),
            ('CHERRY', "Cherry", "Cherry wood"),
            ('WALNUT', "Walnut", "Walnut wood"),
            ('BIRCH', "Birch", "Birch wood"),
            ('HICKORY', "Hickory", "Hickory wood"),
            ('ALDER', "Alder", "Alder wood"),
            ('PAINT_GRADE', "Paint Grade", "Paint Grade"),
            ('CUSTOM_PROCEDURAL', "Custom Procedural", "Procedural wood material with custom parameters"),
            ('CUSTOM', "Custom Material", "Use a custom material from the file"),
        ],
        default='MAPLE',
        update=_propagate_cabinet_style,
    )  # type: ignore

    stain_color: EnumProperty(
        name="Stain Color",
        description="Stain color for cabinet finish",
        items=get_stain_color_enum_items,
        update=_propagate_cabinet_style,
    )  # type: ignore

    # A custom catalog finish is "match this sample" - there is no
    # colour on file for it, so the material fell back to a standard one
    # and every custom job rendered the same. This is the colour to use
    # instead: paste a hex from the paint supplier, or pick one.
    custom_finish_color: FloatVectorProperty(
        name="Custom Finish Color",
        description="Colour to render a custom stain or paint in. Used "
                    "when the catalog finish is a custom one",
        subtype='COLOR', size=4, min=0.0, max=1.0,
        default=(0.806947, 0.752943, 0.679543, 1.0),
        update=_propagate_cabinet_style,
    )  # type: ignore

    paint_color: EnumProperty(
        name="Paint Color",
        description="Paint color for cabinet finish",
        items=get_paint_color_enum_items,
        update=_propagate_cabinet_style,
    )  # type: ignore

    # ---- Catalog finish spec (compatibility-filtered; see style_options) ----
    # The correct wood/color/varnish/glaze + overlay/hinge selections with the
    # proper cascade. Spec-only for now (does not drive material or FF sizing).
    finish_wood: EnumProperty(
        name="Wood Specie",
        description="Catalog wood specie (gates the available colors)",
        items=get_finish_wood_items,
        update=update_finish_wood,
    )  # type: ignore
    finish_color: EnumProperty(
        name="Color",
        description="Finish color available for the chosen wood specie",
        items=get_finish_color_items,
        update=update_finish_color,
    )  # type: ignore
    finish_varnish: EnumProperty(
        name="Varnish",
        description="Varnish available for the chosen color (stain colors only)",
        items=get_finish_varnish_items,
    )  # type: ignore
    finish_glaze: EnumProperty(
        name="Glaze",
        description="Glaze available for the chosen color",
        items=get_finish_glaze_items,
    )  # type: ignore
    finish_overlay: EnumProperty(
        name="Overlay (catalog)",
        description="Catalog door overlay (gates the available hinges)",
        items=get_finish_overlay_items,
        update=update_finish_overlay,
    )  # type: ignore
    finish_hinge: EnumProperty(
        name="Hinge",
        description="Hinge available for the chosen overlay",
        items=get_finish_hinge_items,
    )  # type: ignore
    # A never-touched dynamic enum reads as its number-0 item, which for the
    # standard overlays is NOT the catalog default hinge. Styles are seeded
    # with the overlay's default hinge exactly once (ensure_default_styles);
    # this flag keeps the seeding from clobbering a later explicit pick.
    finish_hinge_seeded: BoolProperty(default=False)  # type: ignore

    # ---- Interior material ----
    interior_material_type: EnumProperty(
        name="Interior Material",
        description="Material for cabinet interior",
        items=[
            ('MAPLE_PLY', "UV Plywood", "UV plywood"),
            ('MATCHING', "Matching Exterior", "Use the same material as the exterior"),
            ('CUSTOM', "Custom Material", "Use a custom material from the file"),
        ],
        default='MAPLE_PLY',
        update=_propagate_cabinet_style,
    )  # type: ignore

    # ---- Door overlay (five face frame options) ----
    door_overlay_type: EnumProperty(
        name="Door Overlay",
        description="Door overlay style for face frame cabinets",
        items=[
            ('CLASSIC', "Classic", "Classic partial overlay"),
            ('TRANSITIONAL', "Transitional", "Transitional overlay"),
            ('FULL', "Full Overlay", "Full overlay"),
            ('PARTIAL_INSET', "Partial Inset", "Door is partially inset into the opening"),
            ('FULL_INSET', "Full Inset", "Door is fully inset, flush with the frame"),
        ],
        default='CLASSIC',
        update=update_face_frame_sizes,
    )  # type: ignore

    # ---- Face frame member widths (7 row types x 3 cabinet types) ----
    # Driven by door_overlay_type via update_face_frame_sizes. Rails have
    # per-cell unlock toggles so users can override the overlay default
    # for one cabinet type without losing the others. Stiles are always
    # overlay-driven (no unlock toggles). Defaults below match CLASSIC.
    ff_top_rail_width_base: FloatProperty(
        name="Top Rail (Base)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_top_rail_width_tall: FloatProperty(
        name="Top Rail (Tall)", default=units.inch(3.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_top_rail_width_upper: FloatProperty(
        name="Top Rail (Upper)", default=units.inch(3.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    ff_bottom_rail_width_base: FloatProperty(
        name="Bottom Rail (Base)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_bottom_rail_width_tall: FloatProperty(
        name="Bottom Rail (Tall)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_bottom_rail_width_upper: FloatProperty(
        name="Bottom Rail (Upper)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    ff_mid_rail_width_base: FloatProperty(
        name="Mid Rail (Base)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_mid_rail_width_tall: FloatProperty(
        name="Mid Rail (Tall)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_mid_rail_width_upper: FloatProperty(
        name="Mid Rail (Upper)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    ff_wall_stile_width_base: FloatProperty(
        name="Wall Stile (Base)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_wall_stile_width_tall: FloatProperty(
        name="Wall Stile (Tall)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_wall_stile_width_upper: FloatProperty(
        name="Wall Stile (Upper)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    ff_mid_stile_width_base: FloatProperty(
        name="Mid Stile (Base)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_mid_stile_width_tall: FloatProperty(
        name="Mid Stile (Tall)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_mid_stile_width_upper: FloatProperty(
        name="Mid Stile (Upper)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    ff_end_stile_width_base: FloatProperty(
        name="End Stile (Base)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_end_stile_width_tall: FloatProperty(
        name="End Stile (Tall)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_end_stile_width_upper: FloatProperty(
        name="End Stile (Upper)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    ff_blind_stile_width_base: FloatProperty(
        name="Blind Stile (Base)", default=units.inch(3.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_blind_stile_width_tall: FloatProperty(
        name="Blind Stile (Tall)", default=units.inch(3.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_blind_stile_width_upper: FloatProperty(
        name="Blind Stile (Upper)", default=units.inch(2.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    # Joint stile types (Butt / Inside 90 / Angle) - width-only, sourced
    # from the overlay table like the other stile rows; defaults match CLASSIC.
    ff_butt_stile_width_base: FloatProperty(
        name="Butt Stile (Base)", default=units.inch(1.25),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_butt_stile_width_tall: FloatProperty(
        name="Butt Stile (Tall)", default=units.inch(1.25),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_butt_stile_width_upper: FloatProperty(
        name="Butt Stile (Upper)", default=units.inch(1.25),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_inside_90_stile_width_base: FloatProperty(
        name="Inside 90 Stile (Base)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_inside_90_stile_width_tall: FloatProperty(
        name="Inside 90 Stile (Tall)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_inside_90_stile_width_upper: FloatProperty(
        name="Inside 90 Stile (Upper)", default=units.inch(1.0),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_angle_stile_width_base: FloatProperty(
        name="Angle Stile (Base)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_angle_stile_width_tall: FloatProperty(
        name="Angle Stile (Tall)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore
    ff_angle_stile_width_upper: FloatProperty(
        name="Angle Stile (Upper)", default=units.inch(1.5),
        unit='LENGTH', precision=4,
        update=_propagate_cabinet_style,
    )  # type: ignore

    # ---- Rail unlock toggles (9: 3 row types x 3 cabinet types) ----
    # When False (locked), the rail's width follows the overlay default
    # and is rewritten on overlay change AND immediately on re-lock (the
    # update callback re-derives every locked cell). When True (unlocked),
    # the user's value persists.
    unlock_base_top_rail: BoolProperty(name="Unlock Base Top Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_tall_top_rail: BoolProperty(name="Unlock Tall Top Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_upper_top_rail: BoolProperty(name="Unlock Upper Top Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_base_bottom_rail: BoolProperty(name="Unlock Base Bottom Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_tall_bottom_rail: BoolProperty(name="Unlock Tall Bottom Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_upper_bottom_rail: BoolProperty(name="Unlock Upper Bottom Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_base_mid_rail: BoolProperty(name="Unlock Base Mid Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_tall_mid_rail: BoolProperty(name="Unlock Tall Mid Rail", default=False, update=update_face_frame_sizes)  # type: ignore
    unlock_upper_mid_rail: BoolProperty(name="Unlock Upper Mid Rail", default=False, update=update_face_frame_sizes)  # type: ignore

    # ---- Door / drawer-front style refs (by name into Face_Frame_Scene_Props.door_styles) ----
    door_style: EnumProperty(
        name="Door Style",
        description="Door style applied to door fronts on cabinets carrying this style",
        items=get_door_style_enum_items,
        update=_propagate_cabinet_style,
    )  # type: ignore

    drawer_front_style: EnumProperty(
        name="Drawer Front Style",
        description="Drawer front style applied to drawer fronts on cabinets carrying this style",
        items=get_drawer_front_style_enum_items,
        update=_propagate_cabinet_style,
    )  # type: ignore

    # ---- Style-section descriptors (free text shown on the Style Section
    # page). These have no geometric effect -- they're presentation fields the
    # user types in. Defaults mirror common catalog selections so a fresh style
    # reads sensibly. Editable from the Style Sections panel.
    # Corner treatment DOES drive geometry (see
    # FaceFrameCabinet._apply_corner_treatment): the pick is cut into the
    # face frame's exposed arrises -- the end stile's outer front edge at a
    # flush finished end, and the bottom front edge of upper cabinets.
    # 'Cove' keeps its identifier for saved files; it reads as 1/4" Cove.
    ss_corner_treatment: EnumProperty(
        name="Corner Treatment",
        description="Corner treatment cut into the face frame's exposed front arrises (finished-end stiles, upper cabinet bottoms) and shown on the style section page",
        items=[
            ('1/4" x 1/4" Chamfer', '1/4" x 1/4" Chamfer', ''),
            ('Cove', '1/4" Cove', ''),
            ('1/8" Radius', '1/8" Radius', ''),
            ('Square', 'Square', ''),
            ('1/4" Radius', '1/4" Radius', ''),
            ('3/8" Radius', '3/8" Radius', ''),
        ],
        default='Square',
        update=_propagate_cabinet_style,
    )  # type: ignore
    ss_fin_opening_edge: EnumProperty(
        name="Fin Opening Edge",
        description="Finished opening edge treatment for the style section page",
        items=[
            ('1/8" Radius', '1/8" Radius', ''),
            ('1/4" Radius', '1/4" Radius', ''),
            ('1/4" Drop Radius', '1/4" Drop Radius', ''),
            ('1/4" x 1/4" Chamfer', '1/4" x 1/4" Chamfer', ''),
            ('3/8" Radius', '3/8" Radius', ''),
            ('3/8" Drop Radius', '3/8" Drop Radius', ''),
            ('Beaded', 'Beaded', ''),
            ('Classic Cut', 'Classic Cut', ''),
            ('Cove', 'Cove', ''),
            ('Square', 'Square', ''),
        ],
        default='Square',
    )  # type: ignore
    ss_drawer_grain: StringProperty(
        name="Drawer Grain",
        description="Override the drawer-front grain on the style section page; "
                    "blank uses the drawer front style's grain direction",
        default="",
    )  # type: ignore
    ss_drawer_top_opening_height: StringProperty(
        name="Top Opening Height",
        description="Override the top drawer opening height on the style section "
                    "page; blank uses hb_face_frame.top_drawer_opening_height",
        default="",
    )  # type: ignore
    ss_drawer_slides: EnumProperty(
        name="Drawer Slides",
        description="Drawer slide hardware for the style section page",
        items=[
            # New options append at the END so saved files keep their
            # stored enum indexes.
            ('Tandem BLUMOTION', 'Tandem BLUMOTION', ''),
            ('KV8400', 'KV8400', ''),
            ('KV4270', 'KV4270', ''),
            ('MOVENTO Heavy Duty', 'MOVENTO Heavy Duty', ''),
            ('Tandem Touch Latch', 'Tandem Touch Latch', ''),
            ('Blum Edge Soft Close 7/8 Extension',
             'Blum Edge Soft Close 7/8 Extension', ''),
            ('KV 8505 Heavy Duty', 'KV 8505 Heavy Duty', ''),
        ],
        default='Tandem BLUMOTION',
    )  # type: ignore
    ss_drawer_box_construction: EnumProperty(
        name="Box Construction",
        description="Drawer box construction for the style section page",
        items=get_ss_box_construction_items,
    )  # type: ignore
    # Free-text note lines printed in a NOTES section at the end of this
    # style's Style Section block (e.g. 'TOUCH LATCH = TL').
    ss_notes: CollectionProperty(type=Face_Frame_Style_Note)  # type: ignore

    # ---- Style-section OVERRIDES for the catalog-backed fields ----
    # Each is blank by default: blank => the page shows the catalog/derived
    # value (wood, color, overlay, hinge, the composed door/drawer name, edge
    # profile); type anything in to OVERRIDE what prints for that style. This
    # lets a dealer hand-correct a single line without changing the cabinet's
    # actual catalog selection. Resolved by ``style_section_value``.
    ss_wood: StringProperty(
        name="Wood (override)",
        description="Override the wood text on the style section page (blank = catalog value)",
        default="",
    )  # type: ignore
    ss_interior: StringProperty(
        name="Interior (override)",
        description="Override the interior text (blank = catalog value)",
        default="",
    )  # type: ignore
    ss_overlay: StringProperty(
        name="Overlay (override)",
        description="Override the overlay text (blank = catalog value)",
        default="",
    )  # type: ignore
    ss_color: StringProperty(
        name="Color (override)",
        description="Override the color text (blank = catalog value)",
        default="",
    )  # type: ignore
    ss_varnish: StringProperty(
        name="Varnish (override)",
        description="Override the varnish text (blank = catalog value)",
        default="",
    )  # type: ignore
    ss_glaze: StringProperty(
        name="Glaze (override)",
        description="Override the glaze text (blank = catalog value)",
        default="",
    )  # type: ignore
    # Finish REFERENCE name + image per Color / Varnish / Glaze. A ref name
    # is appended to the field's FINISH row on the Style Section page
    # ("AUBURN – SUNSET"); a ref image is collected into the page's right-side
    # references box. Both are independent and optional (either alone works).
    ss_color_ref_name: StringProperty(
        name="Color Reference",
        description="Reference name for the color, shown on the Style Section finish row",
        default="",
    )  # type: ignore
    ss_color_ref_image: StringProperty(
        name="Color Reference Image",
        description="Path to a reference image for the color, shown in the Style Section references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    # A reference sometimes comes as two pictures (a sample board and a
    # detail, say). Each finish reference and each special effect carries
    # a second image slot; the page stacks it under the first with the
    # same caption.
    ss_color_ref_image_2: StringProperty(
        name="Second Color Reference Image",
        description="A second reference image for the color, shown under the first in the references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    ss_varnish_ref_name: StringProperty(
        name="Varnish Reference",
        description="Reference name for the varnish, shown on the Style Section finish row",
        default="",
    )  # type: ignore
    ss_varnish_ref_image: StringProperty(
        name="Varnish Reference Image",
        description="Path to a reference image for the varnish, shown in the Style Section references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    ss_varnish_ref_image_2: StringProperty(
        name="Second Varnish Reference Image",
        description="A second reference image for the varnish, shown under the first in the references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    ss_glaze_ref_name: StringProperty(
        name="Glaze Reference",
        description="Reference name for the glaze, shown on the Style Section finish row",
        default="",
    )  # type: ignore
    ss_glaze_ref_image: StringProperty(
        name="Glaze Reference Image",
        description="Path to a reference image for the glaze, shown in the Style Section references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    ss_glaze_ref_image_2: StringProperty(
        name="Second Glaze Reference Image",
        description="A second reference image for the glaze, shown under the first in the references box",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    ss_door: StringProperty(
        name="Door Style (override)",
        description="Override the door style text (blank = composed catalog name)",
        default="",
    )  # type: ignore
    ss_hinge: StringProperty(
        name="Hinge (override)",
        description="Override the hinge text (blank = catalog value)",
        default="",
    )  # type: ignore
    ss_drawer: StringProperty(
        name="Drawer Style (override)",
        description="Override the drawer style text (blank = composed catalog name)",
        default="",
    )  # type: ignore
    # Path to a drawer-box brand logo image. When set, the Style Section page
    # renders the logo (textured quad) inside the DRAWERS section. FILE_PATH so
    # the sidebar shows a file-picker. Stored per cabinet style like the other
    # ss_* fields; resolved by style_section.style_section_value.
    ss_drawer_box_brand: StringProperty(
        name="Drawer Box Brand",
        description="Path to a drawer-box brand logo image shown in the DRAWERS section of the Style Section page",
        subtype='FILE_PATH',
        default="",
    )  # type: ignore
    ss_edge_profile: EnumProperty(
        name="Edge Profile",
        description="Door and drawer edge profile: cut into every front's outer edge and shown on the style section page (None = use the door style's outer profile)",
        items=[
            ('None', 'None', ''),
            ('Bay', 'Bay', ''),
            ('Beveled', 'Beveled', ''),
            ('Chamfer', 'Chamfer', ''),
            ('Classic Cut', 'Classic Cut', ''),
            ('Drop Radius', '3/8" Drop Radius', ''),
            ('Eclipse', 'Eclipse', ''),
            ('Estate', 'Estate', ''),
            ('New Cut', 'New Cut', ''),
            ('Square', 'Square', ''),
            ('1/8" Radius', '1/8" Radius', ''),
            ('1/4" Radius', '1/4" Radius', ''),
            ('3/8" Radius', '3/8" Radius', ''),
            ('3/8" Inset 1/8" Radius', '3/8" Inset 1/8" Radius', ''),
            ('3/8" Inset Radius', '3/8" Inset 3/8" Radius', ''),
            ('3/8" Inset square', '3/8" Inset Square', ''),
        ],
        default='None',
        update=_propagate_cabinet_style,
    )  # type: ignore

    # Custom-text companions for the toggleable dropdown fields. When
    # <field>_is_custom is set, the UI shows <field>_custom (free text) in
    # place of the dropdown and the style section resolves the typed value --
    # for entering a value the catalog list doesn't offer.
    ss_corner_treatment_is_custom: BoolProperty(name="Custom Corner Treatment", default=False, update=_propagate_cabinet_style)  # type: ignore
    ss_corner_treatment_custom: StringProperty(name="Corner Treatment", default="", update=_propagate_cabinet_style)  # type: ignore
    ss_fin_opening_edge_is_custom: BoolProperty(name="Custom Fin Opening Edge", default=False)  # type: ignore
    ss_fin_opening_edge_custom: StringProperty(name="Fin Opening Edge", default="")  # type: ignore
    ss_drawer_slides_is_custom: BoolProperty(name="Custom Drawer Slides", default=False)  # type: ignore
    ss_drawer_slides_custom: StringProperty(name="Drawer Slides", default="")  # type: ignore
    ss_drawer_box_construction_is_custom: BoolProperty(name="Custom Box Construction", default=False)  # type: ignore
    ss_drawer_box_construction_custom: StringProperty(name="Box Construction", default="")  # type: ignore
    # Edge profile drives front geometry (unlike the other ss_* doc
    # fields), so its custom companions propagate too.
    ss_edge_profile_is_custom: BoolProperty(name="Custom Edge Profile", default=False, update=_propagate_cabinet_style)  # type: ignore
    ss_edge_profile_custom: StringProperty(name="Edge Profile", default="", update=_propagate_cabinet_style)  # type: ignore
    ss_wood_is_custom: BoolProperty(name="Custom Wood", default=False)  # type: ignore
    ss_wood_custom: StringProperty(name="Wood", default="")  # type: ignore
    ss_interior_is_custom: BoolProperty(name="Custom Interior", default=False)  # type: ignore
    ss_interior_custom: StringProperty(name="Interior", default="")  # type: ignore
    ss_overlay_is_custom: BoolProperty(name="Custom Overlay", default=False)  # type: ignore
    ss_overlay_custom: StringProperty(name="Overlay", default="")  # type: ignore
    ss_color_is_custom: BoolProperty(name="Custom Color", default=False)  # type: ignore
    ss_color_custom: StringProperty(name="Color", default="")  # type: ignore
    ss_varnish_is_custom: BoolProperty(name="Custom Varnish", default=False)  # type: ignore
    ss_varnish_custom: StringProperty(name="Varnish", default="")  # type: ignore
    ss_glaze_is_custom: BoolProperty(name="Custom Glaze", default=False)  # type: ignore
    ss_glaze_custom: StringProperty(name="Glaze", default="")  # type: ignore
    ss_door_is_custom: BoolProperty(name="Custom Door", default=False)  # type: ignore
    ss_door_custom: StringProperty(name="Door", default="")  # type: ignore
    ss_hinge_is_custom: BoolProperty(name="Custom Hinge", default=False)  # type: ignore
    ss_hinge_custom: StringProperty(name="Hinge", default="")  # type: ignore
    ss_drawer_is_custom: BoolProperty(name="Custom Drawer Front", default=False)  # type: ignore
    ss_drawer_custom: StringProperty(name="Drawer Front", default="")  # type: ignore

    # ---- Style-section millwork (per-style list shown under the column on the
    # Style Section page). Each item is name + quantity(ft) + product_code.
    # Populated by hand and/or the Collect Millwork scan.
    millwork_items: CollectionProperty(
        name="Millwork Items",
        type=Face_Frame_Millwork_Item,
    )  # type: ignore
    millwork_index: IntProperty(
        name="Millwork Index",
        default=0,
    )  # type: ignore

    # ---- Style-section special effects (per-style finish add-ons shown in
    # the FINISH section + on the page). Each item is a catalog effect name;
    # the Add dialog offers the wood+color-compatible set.
    special_effects: CollectionProperty(
        name="Special Effects",
        type=Face_Frame_Special_Effect,
    )  # type: ignore
    special_effect_index: IntProperty(
        name="Special Effect Index",
        default=0,
    )  # type: ignore

    # ---- Extra front styles (Style Section documentation) ----
    # The primary door_style / drawer_front_style drives geometry; these list
    # the ADDITIONAL door / drawer-front styles a designer has assigned to this
    # cabinet style's cabinets in 3D, so the Style Section page documents every
    # front style in use. Pure documentation -- no geometric effect.
    extra_door_styles: CollectionProperty(
        name="Extra Door Styles",
        type=Face_Frame_Cabinet_Extra_Front_Style,
    )  # type: ignore
    extra_drawer_front_styles: CollectionProperty(
        name="Extra Drawer Front Styles",
        type=Face_Frame_Cabinet_Extra_Front_Style,
    )  # type: ignore

    # ---- Cached materials (lazy-loaded from face_frame_assets/materials/cabinet_material.blend) ----
    material: PointerProperty(name="Material", type=bpy.types.Material)  # type: ignore
    material_rotated: PointerProperty(name="Material Rotated", type=bpy.types.Material)  # type: ignore
    interior_material: PointerProperty(name="Interior Material", type=bpy.types.Material)  # type: ignore
    interior_material_rotated: PointerProperty(name="Interior Material Rotated", type=bpy.types.Material)  # type: ignore
    custom_material: PointerProperty(name="Custom Exterior Material", type=bpy.types.Material, update=_propagate_cabinet_style)  # type: ignore
    custom_interior_material: PointerProperty(name="Custom Interior Material", type=bpy.types.Material, update=_propagate_cabinet_style)  # type: ignore

    # ---- Custom procedural shader (active when wood_species == 'CUSTOM_PROCEDURAL') ----
    custom_wood_color_1: bpy.props.FloatVectorProperty(
        name="Wood Color 1", subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.8, 0.65, 0.45), update=update_custom_procedural_material)  # type: ignore
    custom_wood_color_2: bpy.props.FloatVectorProperty(
        name="Wood Color 2", subtype='COLOR', size=3, min=0.0, max=1.0,
        default=(0.6, 0.45, 0.3), update=update_custom_procedural_material)  # type: ignore
    custom_noise_scale_1: FloatProperty(name="Noise Scale 1", default=3.5, min=0.0, max=50.0, update=update_custom_procedural_material)  # type: ignore
    custom_noise_scale_2: FloatProperty(name="Noise Scale 2", default=2.5, min=0.0, max=50.0, update=update_custom_procedural_material)  # type: ignore
    custom_texture_variation_1: FloatProperty(name="Texture Variation 1", default=0.1, min=0.0, max=20.0, update=update_custom_procedural_material)  # type: ignore
    custom_texture_variation_2: FloatProperty(name="Texture Variation 2", default=12.5, min=0.0, max=20.0, update=update_custom_procedural_material)  # type: ignore
    custom_noise_detail: FloatProperty(name="Noise Detail", default=15.0, min=0.0, max=20.0, update=update_custom_procedural_material)  # type: ignore
    custom_voronoi_detail_1: FloatProperty(name="Voronoi Detail 1", default=0.0, min=0.0, max=10.0, update=update_custom_procedural_material)  # type: ignore
    custom_voronoi_detail_2: FloatProperty(name="Voronoi Detail 2", default=0.2, min=0.0, max=10.0, update=update_custom_procedural_material)  # type: ignore
    custom_knots_scale: FloatProperty(name="Knots Scale", default=0.0, min=0.0, max=20.0, update=update_custom_procedural_material)  # type: ignore
    custom_knots_darkness: FloatProperty(name="Knots Darkness", default=0.0, min=0.0, max=1.0, update=update_custom_procedural_material)  # type: ignore
    custom_roughness: FloatProperty(name="Roughness", default=1.0, min=0.0, max=1.0, update=update_custom_procedural_material)  # type: ignore
    custom_noise_bump_strength: FloatProperty(name="Noise Bump Strength", default=0.1, min=0.0, max=1.0, update=update_custom_procedural_material)  # type: ignore
    custom_knots_bump_strength: FloatProperty(name="Knots Bump Strength", default=0.15, min=0.0, max=1.0, update=update_custom_procedural_material)  # type: ignore
    custom_wood_bump_strength: FloatProperty(name="Wood Bump Strength", default=0.2, min=0.0, max=1.0, update=update_custom_procedural_material)  # type: ignore
    show_custom_grain_options: BoolProperty(name="Show Grain Options", default=False)  # type: ignore

    show_advanced_color: BoolProperty(
        name="Show Advanced Color Options",
        description="Show advanced shader parameters for color editing",
        default=False,
    )  # type: ignore

    show_face_frame_sizes: BoolProperty(
        name="Show Face Frame Sizes",
        description="Show the face frame sizes grid (top/bottom/mid rail and stile widths per cabinet type)",
        default=False,
    )  # type: ignore
    show_finish_references: BoolProperty(
        name="Show Reference Fields",
        description="Show the per-finish reference name + image fields (Color / Varnish / Glaze / Special Effects) in this style's editor",
        default=False,
    )  # type: ignore

    # =================================================================
    # Material resolution
    # =================================================================
    def _get_material_blend_path(self):
        return os.path.join(
            os.path.dirname(__file__),
            'face_frame_assets', 'materials', 'cabinet_material.blend',
        )

    def get_finish_material(self):
        """Return (material, material_rotated) for the exterior finish.

        CUSTOM returns the user-picked material as-is for both slots.
        CUSTOM_PROCEDURAL + named species lazy-load 'Wood' from the
        face frame material blend, then forward to wood_materials for
        node-graph updates based on the current species / colors.
        """
        if self.wood_species == 'CUSTOM':
            if self.custom_material:
                return self.custom_material, self.custom_material
            return None, None

        if not self.material or not self.material_rotated:
            with bpy.data.libraries.load(self._get_material_blend_path()) as (data_from, data_to):
                data_to.materials = ["Wood"]
            mat = data_to.materials[0]
            mat.name = self.name + " Finish"
            self.material = mat
            rotated = mat.copy()
            rotated.name = mat.name + " ROTATED"
            self.material_rotated = rotated

        if self.wood_species == 'CUSTOM_PROCEDURAL':
            wood_materials.update_finish_material_custom_procedural(self)
        else:
            # Standard finish is catalog-driven (finish_wood / finish_color).
            wood_materials.update_finish_material_from_catalog(self)
        return self.material, self.material_rotated

    def get_interior_material(self):
        """Return (material, material_rotated) for the interior surfaces."""
        if self.interior_material_type == 'CUSTOM':
            if self.custom_interior_material:
                return self.custom_interior_material, self.custom_interior_material
            return None, None
        if self.interior_material_type == 'MATCHING':
            return self.get_finish_material()

        if not self.interior_material or not self.interior_material_rotated:
            with bpy.data.libraries.load(self._get_material_blend_path()) as (data_from, data_to):
                data_to.materials = ["Wood"]
            mat = data_to.materials[0]
            mat.name = self.name + " Interior"
            self.interior_material = mat
            rotated = mat.copy()
            rotated.name = mat.name + " ROTATED"
            self.interior_material_rotated = rotated
        return self.interior_material, self.interior_material_rotated

    # =================================================================
    # Apply style to a cabinet
    # =================================================================
    # overlay -> row_type -> (base, tall, upper) widths in inches.
    # Used by update_face_frame_sizes when door_overlay_type changes.
    # All values are inches; conversion to meters happens in the
    # callback. Tables mirror the reference library defaults.
    _FF_SIZE_DEFAULTS = {
        'CLASSIC': {
            'top_rail':    (1.5, 3.5, 3.5),
            'bottom_rail': (1.5, 1.5, 1.5),
            'mid_rail':    (1.5, 1.5, 1.5),
            'wall_stile':  (2.0, 2.0, 2.0),
            'mid_stile':   (2.0, 2.0, 2.0),
            'end_stile':   (2.0, 2.0, 2.0),
            'blind_stile': (3.0, 3.0, 2.0),
            'butt_stile':      (1.25, 1.25, 1.25),
            'inside_90_stile': (3.0, 3.0, 2.0),
            'angle_stile':     (1.5, 1.5, 1.5),
        },
        'TRANSITIONAL': {
            'top_rail':    (1.5, 3.0, 3.0),
            'bottom_rail': (1.25, 1.25, 1.25),
            'mid_rail':    (2.0, 2.0, 2.0),
            'wall_stile':  (1.5, 1.5, 1.5),
            'mid_stile':   (1.5, 1.5, 1.5),
            'end_stile':   (1.5, 1.5, 1.5),
            # EXPOSED width, same as the 90-degree inside corner row it
            # is measured from (the 0.75" tuck behind the adjacent face
            # is added in code). The old 3.75/2.75 row was the inside
            # corner width with the tuck already baked in, so the void
            # side of a corner came out 0.75" wider than the cabinet
            # placed against it.
            'blind_stile': (3.0, 3.0, 2.0),
            'butt_stile':      (1.25, 1.25, 1.25),
            'inside_90_stile': (3.0, 3.0, 2.0),
            'angle_stile':     (1.5, 1.5, 1.5),
        },
        'FULL': {
            'top_rail':    (1.125, 3.0, 3.0),
            'bottom_rail': (1.25, 1.25, 1.125),
            'mid_rail':    (2.0, 2.0, 2.0),
            'wall_stile':  (2.5, 2.5, 2.5),
            'mid_stile':   (2.25, 2.25, 2.25),
            'end_stile':   (1.25, 1.25, 1.25),
            # EXPOSED width (the 0.75" tuck behind the adjacent face is
            # added in code) - the old 3.75/2.75 row predated that split
            # and double-counted the tuck at 90-degree inside corners.
            'blind_stile': (3.5, 3.5, 3.5),
            'butt_stile':      (1.125, 1.125, 1.125),
            'inside_90_stile': (3.5, 3.5, 3.5),
            'angle_stile':     (1.75, 1.75, 1.75),
        },
        'PARTIAL_INSET': {
            'top_rail':    (1.5, 3.0, 3.0),
            'bottom_rail': (1.25, 1.25, 1.25),
            'mid_rail':    (1.5, 1.5, 1.5),
            'wall_stile':  (1.5, 1.5, 1.5),
            'mid_stile':   (1.5, 1.5, 1.5),
            'end_stile':   (1.5, 1.5, 1.5),
            # EXPOSED width - see the note on the TRANSITIONAL row.
            'blind_stile': (2.5, 2.5, 1.5),
            'butt_stile':      (1.25, 1.25, 1.25),
            'inside_90_stile': (2.5, 2.5, 1.5),
            'angle_stile':     (1.5, 1.5, 1.5),
        },
        'FULL_INSET': {
            'top_rail':    (1.5, 3.0, 3.0),
            'bottom_rail': (1.25, 1.25, 1.25),
            'mid_rail':    (1.5, 1.5, 1.5),
            'wall_stile':  (1.5, 1.5, 1.5),
            'mid_stile':   (1.5, 1.5, 1.5),
            'end_stile':   (1.5, 1.5, 1.5),
            # EXPOSED width - see the note on the TRANSITIONAL row.
            'blind_stile': (2.5, 2.5, 1.5),
            'butt_stile':      (1.25, 1.25, 1.25),
            'inside_90_stile': (2.5, 2.5, 1.5),
            'angle_stile':     (1.5, 1.5, 1.5),
        },
    }

    # door_overlay_type -> (L, R, T, B) overlay reveals in inches. Pure
    # overlay (CLASSIC / TRANSITIONAL / FULL) sits in front of the face
    # frame; inset is computed separately in assign_style_to_cabinet
    # because it scales with door thickness.
    _OVERLAY_TABLE = {
        'CLASSIC':       (0.5,    0.5,    0.5,    0.5),
        'TRANSITIONAL':  (0.625,  0.625,  0.875,  0.875),
        'FULL':          (1.0,    1.0,    0.875,  0.875),
        # Both inset modes size the face INSIDE the opening with a 3/32"
        # reveal all around (face = opening - 3/16" per axis); partial
        # inset differs from full inset only in depth, which
        # assign_style_to_cabinet handles via the inset amount.
        'PARTIAL_INSET': (-0.09375, -0.09375, -0.09375, -0.09375),
        'FULL_INSET':    (-0.09375, -0.09375, -0.09375, -0.09375),
    }

    def apply_overlay_to_cabinet(self, cabinet_obj):
        """Write the style's overlay floats + inset depth onto a cabinet
        (or an applied panel carrying working / false fronts) WITHOUT
        touching face-frame sizes or running a recalc.

        Inset depth scales with door thickness so non-standard doors
        land correctly. FULL_INSET makes the outer face flush with the
        face frame; PARTIAL_INSET sits halfway between flush and the
        standard overlay position. The 0.125 magic number must stay in
        sync with DOOR_TO_FRAME_GAP in solver_face_frame.py.
        """
        l, r, t, b = self._OVERLAY_TABLE.get(
            self.door_overlay_type, self._OVERLAY_TABLE['CLASSIC'])
        props = cabinet_obj.face_frame_cabinet
        props.default_left_overlay = units.inch(l)
        props.default_right_overlay = units.inch(r)
        props.default_top_overlay = units.inch(t)
        props.default_bottom_overlay = units.inch(b)

        door_thickness = props.door_thickness
        door_to_frame_gap = units.inch(0.125)
        full_inset = door_thickness + door_to_frame_gap
        if self.door_overlay_type == 'FULL_INSET':
            props.default_door_inset_amount = full_inset
        elif self.door_overlay_type == 'PARTIAL_INSET':
            props.default_door_inset_amount = full_inset / 2.0
        else:
            props.default_door_inset_amount = 0.0

    def frame_profile_kind(self):
        """Inset face-frame edge profile implied by this style's overlay
        ('SQUARE' / 'BEADED' / 'METRO' / 'CHAMFER'); the recalc mills it
        around every opening via door_profiles.inset_frame_run."""
        return style_options.frame_profile_for_overlay(self.finish_overlay)

    def corner_treatment_name(self):
        """This cabinet style's corner treatment pick (ss_corner_treatment,
        or its custom free text). 'Square' / empty mean no cut; the
        recalc resolves the name through door_profiles.named_edge_run."""
        if getattr(self, 'ss_corner_treatment_is_custom', False):
            return self.ss_corner_treatment_custom.strip() or None
        return self.ss_corner_treatment

    def assign_style_to_cabinet(self, cabinet_obj):
        """Write the style's overlay floats + inset amount onto the cabinet
        and recalc. Material assignment to parts and door-style application
        to fronts ship in the next phase, once Face_Frame_Door_Style and
        the per-part material rules are in place.

        The whole write runs under suspend_recalc(): the five overlay /
        inset props and the face frame widths each carry an update
        callback, so without it one assignment rebuilt the cabinet six
        or seven times before the explicit recalc at the end. Suspended,
        every write queues the same cabinet and the outermost resume
        rebuilds it once.
        """
        from . import types_face_frame
        with types_face_frame.suspend_recalc():
            self._assign_style_to_cabinet_inner(cabinet_obj)

    def _assign_style_to_cabinet_inner(self, cabinet_obj):
        self.apply_overlay_to_cabinet(cabinet_obj)

        cabinet_obj['STYLE_NAME'] = self.name
        # Seed the rename anchor the first time this style is stamped onto a
        # cabinet so a later rename has an old name to propagate from. Without
        # it, renaming a style that was assigned while the anchor was empty
        # leaves the cabinets carrying the stale STYLE_NAME.
        if not self.rename_anchor:
            self.rename_anchor = self.name

        # Push face frame widths to the cabinet BEFORE recalc so the
        # carcass rebuild picks up the new stile/rail dimensions.
        # Assign overwrites whatever the user had per-
        # cabinet; Update Cabinets re-runs this for every cabinet
        # tagged with this style.
        self._apply_face_frame_sizes_to_cabinet(cabinet_obj)

        # Materials -> deferred to next phase.

        # Recalc rebuilds carcass + fronts; its tail hook
        # (_reapply_cabinet_style_to_fronts) reads STYLE_NAME on the
        # root and re-runs _apply_door_styles_to_fronts, so every
        # recalc keeps door styles applied without each caller having
        # to re-trigger it.
        from . import types_face_frame
        types_face_frame.recalculate_face_frame_cabinet(cabinet_obj)

    def assign_style_to_hood(self, hood_obj):
        """Apply this cabinet style's exterior finish to a wood hood and
        tag it with the style name. Hoods have no face frame, overlay, or
        door, so only the finish material is meaningful - the width /
        overlay / door wiring is intentionally skipped. The STYLE_NAME tag
        lets style edits and Update Cabinets re-reach the hood (see
        _propagate_cabinet_style).
        """
        finish_mat, finish_mat_rotated = self.get_finish_material()
        if finish_mat is None:
            return
        hood_obj['STYLE_NAME'] = self.name
        # Seed the rename anchor (see assign_style_to_cabinet) so a later
        # rename propagates to this hood too.
        if not self.rename_anchor:
            self.rename_anchor = self.name
        from ..common import wood_hoods
        wood_hoods.apply_finish_to_hood(hood_obj, finish_mat, finish_mat_rotated)

    # =================================================================
    # Material walking
    # =================================================================
    # Visible exterior surfaces (finish material on top + bottom + edges).
    _FINISH_EXTERIOR_ROLES = {
        # Face frame members
        'TOP_RAIL', 'BOTTOM_RAIL', 'LEFT_STILE', 'RIGHT_STILE', 'MID_STILE',
        'MID_STILE_BEND_HALF',
        'MID_RAIL', 'BAY_MID_RAIL', 'BAY_MID_STILE',
        'INTERIOR_FF_RAIL', 'INTERIOR_FF_STILE',
        # Garage-level dead-zone frame (blind appliance garage)
        'BLIND_GARAGE_STILE', 'BLIND_GARAGE_RAIL',
        # Fronts
        'DOOR', 'DRAWER_FRONT', 'PULLOUT_FRONT', 'FALSE_FRONT', 'TILT_OUT', 'INSET_PANEL',
        # Furniture / veneer wood top (dresser products) + the
        # waterfall drop panels at its ends
        'FURNITURE_TOP', 'FURNITURE_TOP_LEG',
        # Finished back closing a hutch upper's dropped-end recess
        'HUTCH_BACK',
        # Finished bottom panel under an upper - applied finish stock
        'FINISHED_BOTTOM',
        # Over-stool shelf between the extended legs
        'OVERSTOOL_SHELF',
        # Full-overlay wall-stile cover + appliance-opening fillers +
        # front-drop filler - proud face-frame-plane parts
        'FULL_OVERLAY_STILE', 'APPLIANCE_FILLER', 'FRONT_DROP_FILLER',
        # Refrigerator cabinet deep stiles
        'LEFT_REFRIG_STILE', 'RIGHT_REFRIG_STILE',
        # Drawer-look appliance panels (flat slabs mimicking a drawer
        # stack, plus the inset look's mid rails)
        'DRAWER_LOOK_FRONT', 'DRAWER_LOOK_RAIL',
        # Valance product boards
        'VALANCE_BOARD', 'VALANCE_COVER',
        'VALANCE_PANEL_LEFT', 'VALANCE_PANEL_RIGHT',
        # Visible toe kick parts
        'CORNER_MID_RAIL', 'CORNER_FALSE_FRONT',
        'FINISH_TOE_KICK', 'MID_FINISH_KICK',
        'CORNER_LEFT_FINISH_KICK', 'CORNER_RIGHT_FINISH_KICK',
        'LEFT_CORNER_FINISH_KICK', 'RIGHT_CORNER_FINISH_KICK',
        'DIAGONAL_FINISH_KICK',
        'LEFT_KICK_RETURN', 'RIGHT_KICK_RETURN',
        # Loose ladder sub-base boards - finished material
        'LOOSE_KICK_FRONT', 'LOOSE_KICK_REAR',
        'LOOSE_KICK_END_LEFT', 'LOOSE_KICK_END_RIGHT',
        # Leg product boards - finished material
        'LEG_PANEL_LEFT', 'LEG_PANEL_RIGHT', 'LEG_STILE',
        'LEG_TK_STILE', 'LEG_TK_FILLER', 'LEG_FINISH_KICK',
        'LEG_FINISH_X_LEFT', 'LEG_FINISH_X_RIGHT',
        # Floating shelf boards - finished material
        'SHELF_FRONT', 'SHELF_TOP', 'SHELF_BOTTOM',
        'SHELF_PANEL_LEFT', 'SHELF_PANEL_RIGHT',
        # Mantle boards (shelf assembly + surround legs / header) -
        # finished material throughout; the crown / base moulding
        # sweeps are curves handled in _apply_materials_to_cabinet.
        'MANTLE_FRONT', 'MANTLE_TOP', 'MANTLE_BOTTOM',
        'MANTLE_PANEL_LEFT', 'MANTLE_PANEL_RIGHT',
        'MANTLE_CROWN_FRONT', 'MANTLE_CROWN_LEFT', 'MANTLE_CROWN_RIGHT',
        'MANTLE_LEG_FRONT_L', 'MANTLE_LEG_FRONT_R',
        'MANTLE_LEG_OUT_L', 'MANTLE_LEG_OUT_R',
        'MANTLE_LEG_IN_L', 'MANTLE_LEG_IN_R',
        'MANTLE_HEADER_FRONT', 'MANTLE_HEADER_BOTTOM',
        # Blind ends + finished back + flush skins / decorative panels
        'BLIND_PANEL_LEFT', 'BLIND_PANEL_RIGHT',
        'FINISHED_BACK', 'FLUSH_X', 'BEADBOARD', 'SHIPLAP', 'V_GROOVE',
        # Finished-side return closeout (return panel + rear stile) wrapping
        # the exposed corner of a side extended back past a finished back.
        'LEFT_SIDE_RETURN', 'RIGHT_SIDE_RETURN',
        'LEFT_SIDE_RETURN_STILE', 'RIGHT_SIDE_RETURN_STILE',
        # Partition skins fill the exposed step between bays of differing
        # height / depth (added when a bay's height is adjusted) and are
        # visible through the opening, so they take the exterior finish
        # material, not the interior material.
        'PARTITION_SKIN',
        # Wood top (countertop part) slab.
        'WOOD_TOP',
        # NOTE: 'BAY_FINISH' liner panels are NOT in this set -- they get
        # a dedicated branch in _apply_materials_to_cabinet honoring the
        # owning bay/opening's finish_*_material pick (exterior finish by
        # default, or the style's interior material).
    }

    # Hidden surfaces (interior material on top + bottom + edges).
    # Sides land here for v1; the .75 FINISHED end-condition case where
    # a side panel is the visible exterior is a follow-up.
    _INTERIOR_PART_ROLES = {
        # Carcass (LEFT_SIDE / RIGHT_SIDE handled separately in
        # _apply_materials_to_cabinet because their material depends on
        # the per-side finished_end_condition, not the role alone)
        'TOP', 'BOTTOM',
        'FRONT_STRETCHER', 'REAR_STRETCHER', 'BACK',
        'TOE_KICK_SUBFRONT', 'TOE_KICK_SUBREAR',
        # Leg product back + nailers
        'LEG_BACK', 'LEG_NAILER_LEFT', 'LEG_NAILER_RIGHT',
        # Internal dividers / shelves
        'BAY_DIVISION', 'BAY_SHELF', 'MID_DIVISION',
        # Sink apron - face-frame-depth panel behind the FF band
        'APRON',
        # Pipe chase cover panels closing the chase from the interior
        'PIPE_CHASE_PANEL',
        # Interior items (DRAWER_BOX / ROLLOUT_BOX are GeoNodeDrawerBox
        # assets with a single Material input, handled by their own
        # branch in _apply_materials_to_cabinet)
        'ADJUSTABLE_SHELF', 'PULLOUT_SHELF', 'PULLOUT_SPACER',
        'ROLLOUT_SPACER',
        'TRAY_DIVIDER', 'TRAY_LOCKED_SHELF',
        'VANITY_SHELF', 'VANITY_SUPPORT',
        'INTERIOR_FIXED_SHELF', 'INTERIOR_DIVISION',
        # Corner cabinet carcass kicks. Corner finish kicks are visible
        # exterior (listed above). The corner sides / backs / angled
        # back / top / bottom are routed explicitly in
        # _apply_materials_to_cabinet (finished-end conditions pick the
        # outer face, corner_finish_interior the cavity face); their
        # entries below are dead fallbacks kept for safety.
        'CORNER_BOTTOM', 'CORNER_TOP',
        'CORNER_LEFT_BACK', 'CORNER_RIGHT_BACK',
        'CORNER_LEFT_SIDE', 'CORNER_RIGHT_SIDE',
        'CORNER_LEFT_KICK', 'CORNER_RIGHT_KICK', 'DIAGONAL_KICK',
        # Corner loose ladder rear rails + end boards (utility sub-base,
        # same interior material as the corner kicks above).
        'CORNER_LOOSE_REAR_LEFT', 'CORNER_LOOSE_REAR_RIGHT',
        'CORNER_LOOSE_END_LEFT', 'CORNER_LOOSE_END_RIGHT',
        'CORNER_PARTITION', 'CORNER_TRAY_DIVIDER', 'CORNER_SHELF',
        'CORNER_FIXED_SHELF', 'CORNER_ANGLED_BACK',
        # Pie-cut drawer corner: the 45-degree channel walls the drawer
        # slides between.
        'CORNER_CHANNEL_LEFT', 'CORNER_CHANNEL_RIGHT',
    }

    # Roles that read materials from the 5-piece door modifier instead
    # of (or in addition to) the cutpart surface inputs.
    _FRONT_ROLES = {'DOOR', 'DRAWER_FRONT', 'PULLOUT_FRONT', 'FALSE_FRONT', 'TILT_OUT'}

    # Interior shelving that follows the bay's finish_bay flag: a finished
    # bay shows the exterior finish on its shelves too, otherwise they
    # stay interior. Glass shelves and functional hardware (pullouts /
    # rollouts / trays) are excluded.
    _BAY_FINISH_SHELF_ROLES = {
        'ADJUSTABLE_SHELF', 'INTERIOR_FIXED_SHELF', 'BAY_SHELF', 'VANITY_SHELF',
        # Corner cabinet shelves live under the cabinet root (no bay /
        # opening cage above them), so the bay / opening finish walk
        # resolves to not-finished; the cabinet-level
        # corner_finish_interior toggle finishes them instead.
        'CORNER_SHELF', 'CORNER_FIXED_SHELF',
    }

    @staticmethod
    def _set_part_route_material(part_obj, mat):
        """Push mat into the Material input of every CPM_ routing
        modifier on a part (notches, cutouts). The faces a route opens
        are new geometry with no slot of their own, so without this a
        notched panel shows raw white where it was cut. The routed face
        is an edge condition, so callers pass the edge material.
        """
        if mat is None:
            return
        for mod in part_obj.modifiers:
            ng = getattr(mod, 'node_group', None)
            if ng is None or not ng.name.startswith('CPM_'):
                continue
            node_input = ng.interface.items_tree.get('Material')
            if node_input is None:
                continue
            try:
                hb_utils.set_gn_input(mod, node_input.identifier, mat)
            except Exception:
                pass

    def _set_part_surfaces(self, part_obj, surface_mat, edge_mat):
        """Plug surface_mat into Top Surface + Bottom Surface and edge_mat
        into all four edge slots of a cutpart. Silently no-ops when
        either material is None (uncached / unresolved custom material)
        so the user just sees the previous slot value.
        """
        from ... import hb_types
        part = hb_types.GeoNodeCutpart(part_obj)
        if surface_mat is not None:
            try:
                part.set_input("Top Surface", surface_mat)
                part.set_input("Bottom Surface", surface_mat)
            except Exception:
                pass
        if edge_mat is not None:
            try:
                part.set_input("Edge W1", edge_mat)
                part.set_input("Edge W2", edge_mat)
                part.set_input("Edge L1", edge_mat)
                part.set_input("Edge L2", edge_mat)
            except Exception:
                pass
        self._set_part_route_material(part_obj, edge_mat or surface_mat)

    def _set_part_surfaces_split(self, part_obj, top_mat, bottom_mat, edge_mat):
        """Like _set_part_surfaces but writes Top Surface and Bottom
        Surface independently. Used when the two faces of a cutpart
        should differ - a FINISHED side panel's outer face (Bottom
        Surface, regardless of left vs right side - see analysis in
        the chat thread that introduced this) gets finish material
        while the inner face (Top Surface) gets interior. Silent
        no-op for any material that's None.
        """
        from ... import hb_types
        part = hb_types.GeoNodeCutpart(part_obj)
        try:
            if top_mat is not None:
                part.set_input("Top Surface", top_mat)
            if bottom_mat is not None:
                part.set_input("Bottom Surface", bottom_mat)
            if edge_mat is not None:
                part.set_input("Edge W1", edge_mat)
                part.set_input("Edge W2", edge_mat)
                part.set_input("Edge L1", edge_mat)
                part.set_input("Edge L2", edge_mat)
        except Exception:
            pass
        self._set_part_route_material(part_obj, edge_mat or bottom_mat)

    def _door_style_grain(self, front_obj):
        """Grain direction ('VERTICAL' / 'HORIZONTAL', default VERTICAL) of the
        style assigned to front_obj, resolved by DOOR_STYLE_NAME. A DOOR-role
        front resolves in the door_styles pool; a drawer front in the separate
        drawer_front_styles pool. The two are independent lists, so a name may
        appear in both -- the front's role picks the right pool.
        """
        ds_name = front_obj.get('DOOR_STYLE_NAME')
        if not ds_name:
            return 'VERTICAL'
        ff = get_style_props()
        role = front_obj.get('hb_part_role')
        pool = (ff.drawer_front_styles
                if role in ('DRAWER_FRONT', 'FALSE_FRONT', 'TILT_OUT')
                else ff.door_styles)
        for ds in pool:
            if ds.name == ds_name:
                return ds.grain_direction
        return 'VERTICAL'

    def _door_style_is_glass(self, front_obj):
        """True if the style assigned to front_obj is a 'Prep for Glass' panel
        (the centre panel should render as glass). Resolved by DOOR_STYLE_NAME
        in the role-appropriate pool, same lookup as _door_style_grain."""
        ds_name = front_obj.get('DOOR_STYLE_NAME')
        if not ds_name:
            return False
        ff = get_style_props()
        role = front_obj.get('hb_part_role')
        pool = (ff.drawer_front_styles
                if role in ('DRAWER_FRONT', 'FALSE_FRONT', 'TILT_OUT')
                else ff.door_styles)
        for ds in pool:
            if ds.name == ds_name:
                return style_options.panel_kind(
                    getattr(ds, 'front_panel', ''))['kind'] == 'GLASS'
        return False

    @staticmethod
    def _get_glass_panel_material():
        """Get/create the 'Door Panel Glass' material for prep-for-glass door
        panels. A Glass BSDF mixed 50/50 with a
        Transparent shader -- near-clear, very slight blue tint, roughness 0,
        IOR 1.45. Cached by name. Socket writes are guarded so a renamed input
        on a future Blender can't raise."""
        name = "Door Panel Glass"
        mat = bpy.data.materials.get(name)
        if mat is not None:
            return mat
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        nodes.clear()
        output = nodes.new('ShaderNodeOutputMaterial')
        output.location = (400, 0)
        mix = nodes.new('ShaderNodeMixShader')
        mix.location = (200, 0)
        if 'Fac' in mix.inputs:
            mix.inputs['Fac'].default_value = 0.5
        glass = nodes.new('ShaderNodeBsdfGlass')
        glass.location = (0, 100)
        if 'Color' in glass.inputs:
            glass.inputs['Color'].default_value = (0.95, 0.97, 1.0, 1.0)
        if 'Roughness' in glass.inputs:
            glass.inputs['Roughness'].default_value = 0.0
        if 'IOR' in glass.inputs:
            glass.inputs['IOR'].default_value = 1.45
        transparent = nodes.new('ShaderNodeBsdfTransparent')
        transparent.location = (0, -100)
        if 'Color' in transparent.inputs:
            transparent.inputs['Color'].default_value = (1.0, 1.0, 1.0, 1.0)
        links.new(transparent.outputs['BSDF'], mix.inputs[1])
        links.new(glass.outputs['BSDF'], mix.inputs[2])
        links.new(mix.outputs['Shader'], output.inputs['Surface'])
        # Blender 5.x EEVEE-Next dropped Material.blend_method; set only if present.
        if hasattr(mat, 'blend_method'):
            mat.blend_method = 'BLEND'
        if hasattr(mat, 'use_backface_culling'):
            mat.use_backface_culling = False
        return mat

    @staticmethod
    def _get_mirror_panel_material():
        """Get/create the 'Door Panel Mirror' material for mirror panels
        (tri-view doors, the Mirror Frame's inset panel). A fully
        metallic, near-zero-roughness Principled surface with a slight
        cool tint -- reads as mirror glass in EEVEE / Cycles and as a
        bright cool sheen in the solid viewport. Cached by name; socket
        writes guarded like the glass material."""
        name = "Door Panel Mirror"
        mat = bpy.data.materials.get(name)
        if mat is not None:
            return mat
        mat = bpy.data.materials.new(name=name)
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        nodes.clear()
        output = nodes.new('ShaderNodeOutputMaterial')
        output.location = (300, 0)
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (0, 0)
        if 'Base Color' in bsdf.inputs:
            bsdf.inputs['Base Color'].default_value = (0.9, 0.92, 0.95, 1.0)
        if 'Metallic' in bsdf.inputs:
            bsdf.inputs['Metallic'].default_value = 1.0
        if 'Roughness' in bsdf.inputs:
            bsdf.inputs['Roughness'].default_value = 0.02
        links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
        # Solid-viewport approximation: bright cool tint + full metallic.
        mat.diffuse_color = (0.85, 0.88, 0.92, 1.0)
        if hasattr(mat, 'metallic'):
            mat.metallic = 1.0
        if hasattr(mat, 'roughness'):
            mat.roughness = 0.05
        return mat

    def _set_door_modifier_materials(self, front_obj, finish_mat, finish_mat_rotated):
        """Set Stile / Rail / Panel material on a 5-piece front: the mesh's
        material slots for a python-built door (HB_DOOR_FRAME), else the
        'Door Style' CPM_5PIECEDOOR modifier, when present. Slab fronts
        have neither and skip silently. Rails get the rotated variant
        so cross-grain reads correctly. The PANEL follows the door style's
        grain_direction: VERTICAL -> finish_mat, HORIZONTAL -> the rotated
        variant (falling back to finish_mat when no rotated material exists).
        """
        # Panel grain follows the door style's grain_direction (see
        # _door_style_grain): HORIZONTAL feeds the rotated finish material.
        panel_mat = finish_mat
        if (self._door_style_grain(front_obj) == 'HORIZONTAL'
                and finish_mat_rotated is not None):
            panel_mat = finish_mat_rotated
        # Prep-for-glass fronts render the centre panel as glass, not wood.
        if self._door_style_is_glass(front_obj):
            panel_mat = self._get_glass_panel_material()
        # Tri-view mirror doors render the centre panel as mirror
        # (stamped by _apply_mirror_door_front, which runs in the door
        # style pass -- before this material walk).
        if front_obj.get('HB_MIRROR_DOOR'):
            panel_mat = self._get_mirror_panel_material()
        if 'HB_STATIC_SLAB' in front_obj:
            # Python-built slab (profiled edge): single-slot mesh; the
            # whole front follows the style's grain like the panel.
            slab_mat = finish_mat
            if (self._door_style_grain(front_obj) == 'HORIZONTAL'
                    and finish_mat_rotated is not None):
                slab_mat = finish_mat_rotated
            if slab_mat is not None:
                me = front_obj.data
                while len(me.materials) < 1:
                    me.materials.append(None)
                me.materials[0] = slab_mat
            return
        if 'HB_DOOR_FRAME' in front_obj:
            # Python-built door: build_door_mesh indexes faces against
            # fixed slots (0 stile, 1 rail, 2 panel). Assign by index --
            # never clear the slot list, that drops the material_index
            # face attribute along with it.
            me = front_obj.data
            while len(me.materials) < 3:
                me.materials.append(None)
            if finish_mat is not None:
                me.materials[0] = finish_mat
            if finish_mat_rotated is not None:
                me.materials[1] = finish_mat_rotated
            if panel_mat is not None:
                me.materials[2] = panel_mat
            # Per-row glass lites index slot 3 (door_builder 'glass').
            if front_obj.get('HB_GLASS_CELLS'):
                while len(me.materials) < 4:
                    me.materials.append(None)
                me.materials[3] = self._get_glass_panel_material()
            return
        for mod in front_obj.modifiers:
            if mod.type != 'NODES' or not mod.node_group:
                continue
            if 'Door Style' not in mod.name:
                continue
            tree = mod.node_group.interface.items_tree
            if 'Stile Material' in tree and finish_mat is not None:
                hb_utils.set_gn_input(mod, tree['Stile Material'].identifier, finish_mat)
            if 'Rail Material' in tree and finish_mat_rotated is not None:
                hb_utils.set_gn_input(mod, tree['Rail Material'].identifier, finish_mat_rotated)
            if 'Panel Material' in tree and panel_mat is not None:
                # panel_mat is the glass material for prep-for-glass fronts,
                # else the finish (rotated for HORIZONTAL grain -- see above).
                hb_utils.set_gn_input(mod, tree['Panel Material'].identifier, panel_mat)
            break

    def _part_paint_override(self, part_obj):
        """(surface, edge) the Paint Part tool put on ``part_obj``, or
        (None, None) when it wasn't painted.

        The stamp names the style the user painted WITH, which can differ
        from the cabinet's own; an unknown name (style since deleted or
        renamed) falls back to this cabinet's style rather than dropping
        the paint entirely.
        """
        override = part_obj.get('hb_part_material_override')
        if override not in ('FINISH', 'INTERIOR'):
            return None, None
        ov_style = self
        ov_name = part_obj.get('hb_part_material_style')
        if ov_name:
            for cs in get_style_props().cabinet_styles:
                if cs.name == ov_name:
                    ov_style = cs
                    break
        if override == 'FINISH':
            return ov_style.get_finish_material()
        return ov_style.get_interior_material()

    def _apply_materials_to_cabinet(self, cabinet_obj):
        """Walk every CABINET_PART under cabinet_obj and write surface
        materials based on role. Face frame classifies by part role
        (face frame member / front / carcass / interior item) rather
        than the per-part Finish Top/Bottom flags frameless uses,
        because face frame construction does not vary those flags.
        Also wires the 5-piece door modifier material slots on fronts.
        """
        finish_mat, finish_mat_rotated = self.get_finish_material()
        interior_mat, interior_mat_rotated = self.get_interior_material()

        # Bail entirely if we have nothing useful to apply (e.g. CUSTOM
        # wood species with no custom_material picked yet).
        if finish_mat is None and interior_mat is None:
            return

        # Side panels read from the cabinet's per-side finished-end
        # condition: 'FINISHED' = the side itself is the visible
        # exterior (3/4" stock), all other values mean a covering part
        # (FLUSH_X / BEADBOARD / SHIPLAP / PANELED / FALSE_FF /
        # WORKING_FF) provides the visible face and the side stays
        # interior. Read once outside the loop.
        ff_cab = cabinet_obj.face_frame_cabinet
        left_side_finished = (ff_cab.left_finished_end_condition == 'FINISHED')
        right_side_finished = (ff_cab.right_finished_end_condition == 'FINISHED')
        # Inside faces are finished on request only (a hutch's dropped
        # end); the outer condition never implies it.
        left_side_inside = getattr(ff_cab, 'left_side_finish_inside', False)
        right_side_inside = getattr(ff_cab, 'right_side_finish_inside', False)
        # Corner cabinets: backs sit against the walls, so the back
        # condition covers both back panels (and the diagonal's angled
        # back); corner_finish_interior finishes the cavity-facing
        # surfaces. Read once here like the side conditions above.
        back_side_finished = (ff_cab.back_finished_end_condition == 'FINISHED')
        corner_finish_interior = ff_cab.corner_finish_interior

        # Floating-shelf products placed INSIDE an opening are nested
        # under this cabinet but keep their OWN style assignment -- skip
        # their whole subtree (their own style's walk covers them).
        nested_skip = set()
        for nested in cabinet_obj.children_recursive:
            if nested.get('IS_FLOATING_SHELF'):
                nested_skip.add(nested.name)
                nested_skip.update(
                    d.name for d in nested.children_recursive)

        for child in cabinet_obj.children_recursive:
            if child.name in nested_skip:
                continue
            if 'CABINET_PART' not in child:
                # Shelf nosings and bar storage inserts are plain
                # meshes, deliberately not CABINET_PART (molding stock
                # / purchased catalog units, not cutparts), so the
                # material goes on the mesh slot directly. Always the
                # exterior finish: nosing is finished-opening trim and
                # the bar storage units are "finished to match
                # exterior" per the catalog. Drawer-interior accessory
                # geometry (dividers and inserts) matches the drawer box
                # instead.
                slot_role = child.get('hb_part_role')
                slot_mat = None
                if slot_role in ('SHELF_NOSING', 'BAR_STORAGE',
                                 # Blind-section tambour: purchased slat
                                 # stock over the garage-level blind
                                 # section, finished to match exterior.
                                 'BLIND_SECTION_TAMBOUR',
                                 'LEG_CURVED_PANEL',
                                 # Decorative corner posts: milled stock
                                 # standing in the cabinet's own corner,
                                 # so always the exterior finish.
                                 'DECORATIVE_CORNER',
                                 # Cabinet column turnings: purchased
                                 # split turnings applied over stiles,
                                 # finished to match the exterior.
                                 'CABINET_COLUMN',
                                 # Mantle moulding sweeps: curve objects
                                 # whose bevel geometry renders the
                                 # curve's material slot.
                                 'MANTLE_CROWN_SWEEP', 'MANTLE_BASE_SWEEP',
                                 # Tip-up wedge: the corner cut off the
                                 # cabinet and glued back on, so it is
                                 # the cabinet's own outside face.
                                 'WEDGE',
                                 # Boolean cutters: the cut faces
                                 # transfer the cutter's material, so
                                 # the finish rides along onto the cut.
                                 'BOTTOM_RAIL_PROFILE_CUTTER',
                                 'CORNER_TREATMENT_CUTTER',
                                 'FRAME_PROFILE_CUTTER',
                                 'FINISHED_BOTTOM_LED_CUTTER',
                                 'DECORATIVE_CORNER_CUTTER',
                                 'BOX_MITER_CUTTER'):
                    slot_mat = finish_mat
                elif slot_role in ('DRAWER_DIVIDER', 'DRAWER_INSERT',
                                   # Drawer / rollout box cutters (finger
                                   # scoop, U-notch): their material is
                                   # what the cut faces transfer, so they
                                   # follow the box rather than the
                                   # exterior finish the other cutters take.
                                   'DRAWER_BOX_CUTTER'):
                    slot_mat = interior_mat or finish_mat
                if slot_mat is not None:
                    if child.data.materials:
                        child.data.materials[0] = slot_mat
                    else:
                        child.data.materials.append(slot_mat)
                continue
            role = child.get('hb_part_role')

            # Per-part paint override (set by the Paint Part tool) wins
            # over the role-based default and survives recalc since it
            # lives on the part. Unset / 'AUTO' leaves this None and the
            # role logic below decides.
            ov_mat, ov_edge = self._part_paint_override(child)

            # Static textured panels (beadboard / shiplap / v-groove ends,
            # wood tops, inset panels, and textured return members): the
            # carved python mesh is the visible geometry (GN cutpart
            # display hidden), so the finish goes on the mesh slot
            # directly - cutpart surface inputs are inert here. A painted
            # one takes the colour it was painted with; this branch used
            # to overwrite it with the cabinet's own finish on every
            # rebuild, so painting a beadboard end came undone the next
            # time anything resized the cabinet.
            if ((role in ('BEADBOARD', 'SHIPLAP', 'V_GROOVE', 'WOOD_TOP',
                          'INSET_PANEL')
                 or child.get('hb_return_member'))
                    and child.get('HB_STATIC_TEXTURED')):
                slot_mat = ov_mat if ov_mat is not None else finish_mat
                if slot_mat is not None:
                    me = child.data
                    while len(me.materials) < 1:
                        me.materials.append(None)
                    me.materials[0] = slot_mat
                continue

            if ov_mat is not None:
                self._set_part_surfaces(child, ov_mat, ov_edge)
                continue

            # Sides routed per-condition. For FINISHED sides the outer
            # face (Bottom Surface) gets finish, the inner face (Top
            # Surface, visible from inside the cabinet) gets interior
            # unless the side asks for its inside finished too (a hutch
            # end showing below the box). Edges stay interior - they're
            # mostly hidden behind the face frame / against neighbors -
            # except when the inside is finished, where the bottom edge
            # is in plain view at the drop. Non-FINISHED sides are
            # interior throughout; the visible exterior comes from a
            # separate covering part (FLUSH_X / BEADBOARD / etc.).
            if role in ('LEFT_SIDE', 'LEFT_SIDE_SEAM',
                        'RIGHT_SIDE', 'RIGHT_SIDE_SEAM'):
                if role.startswith('LEFT'):
                    outer, inside = left_side_finished, left_side_inside
                else:
                    outer, inside = right_side_finished, right_side_inside
                if outer or inside:
                    self._set_part_surfaces_split(
                        child,
                        top_mat=finish_mat if inside else interior_mat,
                        bottom_mat=finish_mat if outer else interior_mat,
                        edge_mat=(finish_mat_rotated if inside
                                  else interior_mat_rotated),
                    )
                else:
                    self._set_part_surfaces(child, interior_mat, interior_mat_rotated)
                continue
            if role == 'WING':
                # Attached wing: a free-standing angled return, finished on its
                # OUTER face only (Bottom Surface = finish, like a FINISHED
                # side); inner face + edges stay interior. Mirror Z is set per
                # side at create so Bottom = the outer face.
                self._set_part_surfaces_split(
                    child,
                    top_mat=interior_mat,
                    bottom_mat=finish_mat,
                    edge_mat=interior_mat_rotated,
                )
                continue

            # Corner cabinet carcass panels (pie cut + diagonal). Every
            # vertical corner panel is built with its OUTER face as the
            # Bottom Surface (verified empirically against both corner
            # builders), the same convention as FINISHED sides above.
            # The outer face follows the matching finished-end condition
            # (sides -> left / right, backs + angled back -> back); the
            # cavity face follows corner_finish_interior.
            if role in ('CORNER_LEFT_SIDE', 'CORNER_RIGHT_SIDE',
                        'CORNER_LEFT_BACK', 'CORNER_RIGHT_BACK',
                        'CORNER_ANGLED_BACK'):
                if role == 'CORNER_LEFT_SIDE':
                    outer_finished = left_side_finished
                elif role == 'CORNER_RIGHT_SIDE':
                    outer_finished = right_side_finished
                else:
                    outer_finished = back_side_finished
                self._set_part_surfaces_split(
                    child,
                    top_mat=(finish_mat if corner_finish_interior
                             else interior_mat),
                    bottom_mat=(finish_mat if outer_finished
                                else interior_mat),
                    edge_mat=(finish_mat_rotated
                              if (corner_finish_interior or outer_finished)
                              else interior_mat_rotated),
                )
                continue
            # Corner top / bottom: only the cavity-facing surface (Bottom
            # on the top panel, Top on the bottom panel) takes the finish
            # when the interior is finished; the outward face is hidden
            # (under the countertop / against the floor or upper top) and
            # stays interior either way.
            if role in ('CORNER_TOP', 'CORNER_BOTTOM'):
                if corner_finish_interior:
                    cavity_is_top = (role == 'CORNER_BOTTOM')
                    self._set_part_surfaces_split(
                        child,
                        top_mat=(finish_mat if cavity_is_top
                                 else interior_mat),
                        bottom_mat=(interior_mat if cavity_is_top
                                    else finish_mat),
                        edge_mat=finish_mat_rotated,
                    )
                else:
                    self._set_part_surfaces(
                        child, interior_mat, interior_mat_rotated)
                continue

            # The panel a finished OPENING sits on. Its floor is never
            # lined - the part already there (carcass bottom, or the bay
            # shelf / division under the opening) is the finish. Stamped
            # during recalc by _stamp_finish_opening_floor, which knows
            # the bay tree; checked ahead of the shelf branch below so it
            # also covers a BAY_SHELF, whose cage walk resolves to the
            # bay rather than the finished opening above it.
            if child.get('hb_finish_floor'):
                self._set_part_surfaces(child, finish_mat, finish_mat_rotated)
                continue

            # Interior shelves in a finished region take the exterior
            # finish so the finished look continues onto the shelving;
            # shelves elsewhere stay interior. A shelf is finished when its
            # bay is finished (nearest IS_FACE_FRAME_BAY_CAGE -> finish_bay)
            # OR its opening is finished (nearest IS_FACE_FRAME_OPENING_CAGE
            # -> finish_opening).
            if role in self._BAY_FINISH_SHELF_ROLES:
                bay_cage = self._bay_cage_for_part(child)
                opening_cage = self._opening_cage_for_part(child)
                finished = (
                    (bay_cage is not None
                     and bay_cage.face_frame_bay.finish_bay)
                    or (opening_cage is not None
                        and opening_cage.face_frame_opening.finish_opening)
                    or (corner_finish_interior
                        and role in ('CORNER_SHELF', 'CORNER_FIXED_SHELF'))
                )
                if finish_mat is not None and finished:
                    # The finished region picks which style material its
                    # shelving shows (finish_*_material; FINISH default).
                    if self._region_material_mode(bay_cage,
                                                  opening_cage) == 'INTERIOR':
                        base_mat, base_edge = interior_mat, interior_mat_rotated
                    else:
                        base_mat, base_edge = finish_mat, finish_mat_rotated
                else:
                    base_mat, base_edge = interior_mat, interior_mat_rotated
                # Per-region shelf paint override. Shelves are wiped and
                # rebuilt every recalc, so the Paint Part stamp lives on
                # the stable opening (or bay) cage, like fronts do.
                ov_src = None
                for cage in (opening_cage, bay_cage):
                    if (cage is not None
                            and cage.get('hb_shelf_material_override')
                            in ('FINISH', 'INTERIOR')):
                        ov_src = cage
                        break
                if ov_src is not None:
                    sstyle = self
                    sname = ov_src.get('hb_shelf_material_style')
                    if sname:
                        for cs in get_style_props().cabinet_styles:
                            if cs.name == sname:
                                sstyle = cs
                                break
                    if ov_src['hb_shelf_material_override'] == 'FINISH':
                        base_mat, base_edge = sstyle.get_finish_material()
                    else:
                        base_mat, base_edge = sstyle.get_interior_material()
                self._set_part_surfaces(child, base_mat, base_edge)
                continue

            # Drawer / rollout boxes are a single GeoNodeDrawerBox asset
            # with one Material input, not a cutpart with per-surface
            # slots. They take the interior material.
            if role in ('DRAWER_BOX', 'ROLLOUT_BOX'):
                if interior_mat is not None:
                    from ... import hb_types
                    try:
                        hb_types.GeoNodeObject(child).set_input(
                            'Material', interior_mat)
                    except Exception:
                        pass
                continue

            # Glass shelves render as glass, not wood - same material the
            # prep-for-glass door panels use.
            if role == 'GLASS_SHELF':
                glass = self._get_glass_panel_material()
                self._set_part_surfaces(child, glass, glass)
                continue

            # Mirror Frame (and any cabinet stamped HB_MIRROR_PANEL_FRONTS):
            # the inset panel filling the face frame IS the mirror. Also
            # tagged prep-for-glass so the 2D layer hatches it.
            if (role == 'INSET_PANEL'
                    and cabinet_obj.get('HB_MIRROR_PANEL_FRONTS')):
                m = self._get_mirror_panel_material()
                self._set_part_surfaces(child, m, m)
                child['IS_PREP_FOR_GLASS'] = True
                continue

            # A bay-height step gap's mid division is the void's
            # FINISHED surface (flush with the stile's notch plane):
            # the face toward the removed bay half takes the exterior
            # finish; the box face stays interior.
            if (role == 'MID_DIVISION'
                    and child.get('HB_STEP_FINISHED_SIDE')):
                fin_right = child['HB_STEP_FINISHED_SIDE'] == 'RIGHT'
                self._set_part_surfaces_split(
                    child,
                    top_mat=(finish_mat if fin_right else interior_mat),
                    bottom_mat=(interior_mat if fin_right
                                else finish_mat),
                    edge_mat=finish_mat_rotated,
                )
                continue

            # Carcass back / bay floor behind a finished region: those
            # faces get no applied liner - the panel itself is cut from
            # finish stock (see _finish_region_specs). The solver splits
            # these segments at finish boundaries and stamps the flag, so
            # one read covers the whole part and unfinished neighbouring
            # bays keep their own interior panels.
            if role in ('BACK', 'BOTTOM') and child.get('hb_segment_finished'):
                self._set_part_surfaces(child, finish_mat, finish_mat_rotated)
                continue

            # Finished-region liner panels: the exterior finish by default,
            # or the style's interior material when the owning bay/opening
            # asks for it. Liners are parented to the cabinet ROOT, so the
            # owning region resolves through the index tags stamped at
            # emit time, not the parent walk.
            if role == 'BAY_FINISH':
                lined_interior = self._liner_material_mode(
                    cabinet_obj, child) == 'INTERIOR'
                if child.get('HB_STATIC_TEXTURED'):
                    # A carved liner draws its python mesh, not the
                    # cutpart, so the colour goes on the mesh slot -
                    # same as the textured ends above.
                    slot_mat = interior_mat if lined_interior else finish_mat
                    if slot_mat is not None:
                        me = child.data
                        while len(me.materials) < 1:
                            me.materials.append(None)
                        me.materials[0] = slot_mat
                elif lined_interior:
                    self._set_part_surfaces(
                        child, interior_mat, interior_mat_rotated)
                else:
                    self._set_part_surfaces(
                        child, finish_mat, finish_mat_rotated)
                continue

            if role in self._FRONT_ROLES:
                # A front's paint override lives on the stable OPENING cage
                # (fronts are wiped + rebuilt each recalc, so a prop on the
                # front itself would not survive). Default = finish material.
                base_mat, base_edge = finish_mat, finish_mat_rotated
                opening = self._opening_cage_for_part(child)
                fov = opening.get('hb_front_material_override') if opening else None
                if fov in ('FINISH', 'INTERIOR'):
                    fstyle = self
                    fname = opening.get('hb_front_material_style')
                    if fname:
                        for cs in get_style_props().cabinet_styles:
                            if cs.name == fname:
                                fstyle = cs
                                break
                    if fov == 'FINISH':
                        base_mat, base_edge = fstyle.get_finish_material()
                    else:
                        base_mat, base_edge = fstyle.get_interior_material()
                # Cutpart face honors the door style's grain (a no-op for a
                # 5-piece front, whose visible faces come from the door
                # modifier set just below).
                face_mat = base_mat
                if (self._door_style_grain(child) == 'HORIZONTAL'
                        and base_edge is not None):
                    face_mat = base_edge
                self._set_part_surfaces(child, face_mat, base_edge)
                self._set_door_modifier_materials(child, base_mat, base_edge)
                continue
            elif role in self._FINISH_EXTERIOR_ROLES:
                self._set_part_surfaces(
                    child, finish_mat, finish_mat_rotated,
                )
                # Step-notch cut faces on a mid stile read as finished
                # end grain -- the corner-notch node group exposes a
                # Material socket for the faces the cut creates.
                if role == 'MID_STILE' and finish_mat is not None:
                    for mname in ('Step Notch Bottom', 'Step Notch Top'):
                        m = child.modifiers.get(mname)
                        if (m is not None and m.node_group is not None
                                and m.show_viewport):
                            ni = m.node_group.interface.items_tree.get(
                                'Material')
                            if ni is not None:
                                hb_utils.set_gn_input(
                                    m, ni.identifier, finish_mat)
            elif role in self._INTERIOR_PART_ROLES:
                self._set_part_surfaces(
                    child, interior_mat, interior_mat_rotated,
                )

    @staticmethod
    def _region_material_mode(bay_cage, opening_cage):
        """FINISH / INTERIOR pick for a finished bay / opening region.
        The opening's own setting wins when the part sits under an
        opening cage; otherwise the bay's; FINISH when neither resolves
        (historic behavior)."""
        if opening_cage is not None:
            return opening_cage.face_frame_opening.finish_opening_material
        if bay_cage is not None:
            return bay_cage.face_frame_bay.finish_bay_material
        return 'FINISH'

    @staticmethod
    def _liner_material_mode(cabinet_obj, liner):
        """finish_*_material mode for a BAY_FINISH liner panel, resolved
        via the bay / opening index tags the liner carries (liners are
        parented to the cabinet root, so the cage parent-walk can't find
        their region). FINISH when the region can't be resolved."""
        bay_idx = liner.get('hb_bay_finish_bay')
        op_idx = liner.get('hb_bay_finish_opening', -1)
        if bay_idx is None:
            return 'FINISH'
        for node in cabinet_obj.children:
            if (not node.get('IS_FACE_FRAME_BAY_CAGE')
                    or node.get('hb_bay_index') != bay_idx):
                continue
            if op_idx is not None and op_idx >= 0:
                for sub in node.children_recursive:
                    if (sub.get('IS_FACE_FRAME_OPENING_CAGE')
                            and sub.get('hb_opening_index') == op_idx
                            and sub.face_frame_opening.finish_opening):
                        return sub.face_frame_opening.finish_opening_material
            return node.face_frame_bay.finish_bay_material
        return 'FINISH'

    def _bay_cage_for_part(self, part_obj):
        """Walk up from a part to its nearest face-frame bay cage
        (IS_FACE_FRAME_BAY_CAGE) so per-bay flags like finish_bay can be
        read from bay_cage.face_frame_bay. Returns None if the part isn't
        under a bay cage (e.g. carcass parts parented to the cabinet root).
        The tag string mirrors types_face_frame.TAG_BAY_CAGE.
        """
        node = part_obj.parent
        while node is not None:
            if node.get('IS_FACE_FRAME_BAY_CAGE'):
                return node
            node = node.parent
        return None

    def _opening_cage_for_part(self, part_obj):
        """Walk up from a part to its nearest face-frame opening cage
        (IS_FACE_FRAME_OPENING_CAGE) so per-opening flags like
        finish_opening can be read from opening_cage.face_frame_opening.
        Returns None if the part isn't under an opening cage. The tag
        string mirrors types_face_frame.TAG_OPENING_CAGE.
        """
        node = part_obj.parent
        while node is not None:
            if node.get('IS_FACE_FRAME_OPENING_CAGE'):
                return node
            node = node.parent
        return None

    # cabinet_type -> column key in the ff_* width props.
    # LAP_DRAWER behaves as a base-cabinet; PANEL has no per-type
    # column yet (parent-cabinet inheritance is a follow-up) so it
    # falls back to base values.
    _CABINET_TYPE_COLUMN = {
        'BASE': 'base',
        'TALL': 'tall',
        'UPPER': 'upper',
        'LAP_DRAWER': 'base',
        'PANEL': 'base',
    }

    # left/right_stile_type -> ff_*_stile_width row prefix.
    _STILE_TYPE_TO_ROW = {
        'STANDARD': 'end_stile',
        'WALL': 'wall_stile',
        'BLIND': 'blind_stile',
        'BUTT': 'butt_stile',
        'INSIDE_90': 'inside_90_stile',
        'ANGLE': 'angle_stile',
    }

    def _ff_size_for(self, row, col):
        """Read the inch-meter value for a (row, col) cell."""
        return getattr(self, f"ff_{row}_width_{col}")

    def _apply_face_frame_sizes_to_cabinet(self, cabinet_obj):
        """Push the style's 21 face frame widths into the cabinet's
        stile/rail props. cabinet_type picks the column; left and
        right stile widths additionally depend on each side's
        stile_type. PANEL cabinets get the panel_* slot trio drawn
        from the BASE column.

        Wrapped in suspend_recalc(): the cabinet- and bay-level width
        props carry update callbacks that trigger recalc, and recalc
        wipes and rebuilds bays. Without suspending, the first bay
        write tears down the very list children_recursive is iterating
        and the next child reference dangles. Suspend coalesces all
        writes into one queued recalc that fires at the outermost
        resume - which here is the explicit recalc call back in
        assign_style_to_cabinet.
        """
        from . import types_face_frame
        with types_face_frame.suspend_recalc():
            self._apply_face_frame_sizes_to_cabinet_inner(cabinet_obj)

    def _apply_face_frame_sizes_to_cabinet_inner(self, cabinet_obj):
        props = cabinet_obj.face_frame_cabinet
        col = self._CABINET_TYPE_COLUMN.get(props.cabinet_type, 'base')

        if props.cabinet_type == 'PANEL':
            # PANEL has its own three-prop slot, no left/right or bays
            # to write into. Stile width borrows the end-stile row.
            props.panel_top_rail_width = self._ff_size_for('top_rail', 'base')
            props.panel_bottom_rail_width = self._ff_size_for('bottom_rail', 'base')
            props.panel_stile_width = self._ff_size_for('end_stile', 'base')
            # Face Frame and Doors is PANEL-typed (carcass-less) but
            # builds a REAL face frame with bays / doors, so it keeps
            # going: its stiles / rails / mid members follow the
            # cabinet face frame sizes like any cabinet.
            if cabinet_obj.get('CLASS_NAME') != 'FaceFrameAndDoorsCabinet':
                return

        # Regular carcass cabinets - top/bottom rail at cabinet level.
        # Respect the per-cabinet unlock flags: a style change re-applies the
        # style to every cabinet carrying it, so writing these unconditionally
        # would wipe a cabinet's own rail/stile override back to the style
        # default. An unlocked field keeps the cabinet's value - mirrors the
        # bay-rail / split unlock handling noted below.
        if not props.unlock_top_rail:
            props.top_rail_width = self._ff_size_for('top_rail', col)
        if not props.unlock_bottom_rail:
            props.bottom_rail_width = self._ff_size_for('bottom_rail', col)

        # Per-side stile widths: each side picks its row by its
        # stile_type. Unknown stile types fall back to end_stile.
        left_row = self._STILE_TYPE_TO_ROW.get(props.left_stile_type, 'end_stile')
        right_row = self._STILE_TYPE_TO_ROW.get(props.right_stile_type, 'end_stile')
        if not props.unlock_left_stile:
            props.left_stile_width = self._ff_size_for(left_row, col)
        if not props.unlock_right_stile:
            props.right_stile_width = self._ff_size_for(right_row, col)
        # A revolving susan's stiles are fixed by the product, so the
        # style's stile row must not write over them.
        apply_revolving_stile_widths(props)

        # Bay-level rail widths are intentionally NOT written here. Each
        # bay carries its own top/bottom rail copy with an unlock flag;
        # the recalc that follows this apply runs _distribute_bay_rails,
        # which pushes the cabinet rail width into locked bays and leaves
        # an unlocked bay's per-bay override intact. Writing every bay
        # directly here would clobber that override.

        # Mid rail / mid stile widths cascade in THREE places:
        #
        # 1. The cabinet's bay_mid_rail_width / bay_mid_stile_width are
        #    the *defaults* used to initialize the per-split copy when a
        #    new split node is created. Setting these affects future
        #    splits only.
        #
        # 2. Each existing split node (inside-a-bay subdivisions) carries
        #    its own splitter_width on its face_frame_split PropertyGroup;
        #    bay mid rail / mid stile parts read THAT value at construction
        #    time. H-axis splits produce mid rails, V-axis splits produce
        #    mid stiles, so the per-split value picks from a different row.
        #    A split whose unlock_splitter_width is set is left alone,
        #    mirroring the per-stile unlock handling in (3).
        #
        # 3. The cabinet's mid_stile_widths CollectionProperty stores the
        #    width of each BETWEEN-BAYS mid stile (PART_ROLE_MID_STILE).
        #    Entry index N is the stile between bay N and bay N+1. Each
        #    entry carries an `unlock` flag - True means the user has
        #    overridden that specific stile and the style apply should
        #    leave it alone.
        mid_rail_w = self._ff_size_for('mid_rail', col)
        mid_stile_w = self._ff_size_for('mid_stile', col)
        props.bay_mid_rail_width = mid_rail_w
        props.bay_mid_stile_width = mid_stile_w

        split_nodes = [
            child for child in cabinet_obj.children_recursive
            if child.get('IS_FACE_FRAME_SPLIT_NODE')
        ]
        for split_obj in split_nodes:
            sp = split_obj.face_frame_split
            if sp.unlock_splitter_width:
                continue
            sp.splitter_width = mid_rail_w if sp.axis == 'H' else mid_stile_w

        for entry in props.mid_stile_widths:
            if not entry.unlock:
                entry.width = mid_stile_w

    def _apply_door_styles_to_fronts(self, cabinet_obj):
        """Walk every front under cabinet_obj. DOOR-role and PULLOUT_FRONT
        fronts get self.door_style (a pullout is a door on a slide, so it
        reads the door pool, not the drawer-front pool); DRAWER_FRONT /
        FALSE_FRONT get self.drawer_front_style. The exception is a false
        face frame end, whose fixed fronts stand in for door panels and so
        read the door pool (front_reads_door_pool). Other roles
        (INSET_PANEL, structural parts, hardware) are skipped.
        """
        from . import types_face_frame as _tff

        DOOR_ROLES = {'DOOR', 'PULLOUT_FRONT'}
        DRAWER_ROLES = {'DRAWER_FRONT', 'FALSE_FRONT', 'TILT_OUT',
                        'DRAWER_LOOK_FRONT'}

        ff = get_style_props()

        def resolve(name, pool):
            if not name or name == 'NONE':
                return None
            for ds in pool:
                if ds.name == name:
                    return ds
            return None

        # door_style resolves in door_styles, drawer_front_style in the
        # separate drawer_front_styles pool (independent lists). These are the
        # cabinet-level DEFAULTS, applied only to fronts that carry no per-front
        # assignment of their own (see the DOOR_STYLE_NAME check below).
        door_ds = resolve(self.door_style, ff.door_styles)
        drawer_ds = resolve(self.drawer_front_style, ff.drawer_front_styles)

        for child in cabinet_obj.children_recursive:
            if 'CABINET_PART' not in child:
                continue
            # Manual (applied / hand-edited) fronts have no Door Style modifier
            # to drive - re-styling would add geometry onto the baked mesh.
            if child.get('IS_MANUAL_PART'):
                continue
            # Drawer-look carrier leaf stays a flat slab (its applied
            # drawer fronts carry the visible style); never style it.
            if child.get('HB_DRAWER_LOOK_CARRIER'):
                continue
            role = child.get('hb_part_role')
            if role not in DOOR_ROLES and role not in DRAWER_ROLES:
                continue
            reads_door = (role in DOOR_ROLES
                          or _tff.front_reads_door_pool(child))
            if reads_door:
                pool, default_ds = ff.door_styles, door_ds
            else:
                pool, default_ds = ff.drawer_front_styles, drawer_ds
            # The solver wipes and rebuilds every front on each recalc, so an
            # opening-size edit (or any cabinet alteration) lands here. Prefer a
            # per-front override the user explicitly assigned, persisted on the
            # durable OPENING cage - the rebuilt front object is blank, so its
            # DOOR_STYLE_NAME does not survive the rebuild. Fall back to the
            # front's own tag (same-recalc reapply) and then the cabinet
            # default. Mirrors _reapply_front_style (ops_part_commands.py).
            cage = self._opening_cage_for_part(child)
            ovr_key = ('hb_front_door_style' if reads_door
                       else 'hb_front_drawer_style')
            ovr_name = cage.get(ovr_key) if cage is not None else None
            ds = (resolve(ovr_name, pool)
                  or resolve(child.get('DOOR_STYLE_NAME'), pool)
                  or default_ds)
            if ds is not None:
                ds.assign_style_to_front(child)

    # =================================================================
    # UI
    # =================================================================
    def _draw_face_frame_sizes(self, layout, context):
        """7x3 grid of face frame sizes drawn inside the cabinet style
        panel. Rail cells get an unlock checkbox + either a float input
        (unlocked) or a read-only inch label (locked). Stile cells are
        always overlay-driven and render as read-only inch labels.
        """
        from ... import units as _units  # for inch() display conversion

        def inch_label(meters):
            return f'{_units.meter_to_inch(meters):.4g}"'

        box = layout.box()
        row = box.row()
        row.label(text=f"Face Frame Sizes: Overlay = {self.door_overlay_type.replace('_', ' ').title()}")

        # Header row
        row = box.row(align=True)
        row.label(text="")
        row.label(text="", icon='BLANK1')
        row.label(text="Base")
        row.label(text="Tall")
        row.label(text="Upper")

        # Rail rows - each cell has an unlock checkbox + value
        for row_label, row_key, prop_root in (
            ("Top Rail", "top", "ff_top_rail_width"),
            ("Bottom Rail", "bottom", "ff_bottom_rail_width"),
            ("Mid Rail", "mid", "ff_mid_rail_width"),
        ):
            r = box.row(align=True)
            r.label(text=row_label)
            for col_key in ("base", "tall", "upper"):
                unlock_name = f"unlock_{col_key}_{row_key}_rail"
                unlocked = getattr(self, unlock_name)
                r.prop(self, unlock_name, text="",
                       icon='UNLOCKED' if unlocked else 'LOCKED',
                       emboss=False)
                if unlocked:
                    r.prop(self, f"{prop_root}_{col_key}", text="")
                else:
                    r.label(text=inch_label(getattr(self, f"{prop_root}_{col_key}")))

        # Stile rows - read-only labels (overlay-driven)
        for row_label, prop_root in (
            ("Wall Stile", "ff_wall_stile_width"),
            ("Mid Stile", "ff_mid_stile_width"),
            ("End Stile", "ff_end_stile_width"),
            ("Blind Stile", "ff_blind_stile_width"),
            ("Butt Stile", "ff_butt_stile_width"),
            ("Inside 90 Stile", "ff_inside_90_stile_width"),
            ("Angle Stile", "ff_angle_stile_width"),
        ):
            r = box.row(align=True)
            r.label(text=row_label)
            for col_key in ("base", "tall", "upper"):
                r.label(text="", icon='BLANK1')
                r.label(text=inch_label(getattr(self, f"{prop_root}_{col_key}")))

    def _draw_toggle_field(self, col, dropdown_attr, label, custom_base=None):
        """Draw a dropdown field with a button toggling to a free-text field,
        so a value outside the list can be typed. The typed value is stored on
        <base>_custom, gated by <base>_is_custom. ``base`` defaults to the
        dropdown attr; pass custom_base when the page-override store differs
        from the dropdown (e.g. the finish_wood dropdown stores custom text on
        ss_wood). The dropdown still drives geometry/material; custom text is a
        print-only spec value."""
        base = custom_base or dropdown_attr
        row = col.row(align=True)
        if getattr(self, base + "_is_custom", False):
            row.prop(self, base + "_custom", text=label)
        else:
            row.prop(self, dropdown_attr, text=label)
        row.prop(self, base + "_is_custom", text="",
                 icon='GREASEPENCIL', toggle=True)

    def _draw_finish_reference(self, col, ref_name_attr, ref_image_attr):
        """Compact reference row beneath a finish field: a ref NAME (appended
        to the field's row on the Style Section page) and a ref IMAGE path
        (collected into the page's right-side references box). Both optional."""
        r = col.row(align=True)
        r.prop(self, ref_name_attr, text="Ref")
        r.prop(self, ref_image_attr, text="", icon='IMAGE_DATA')
        _draw_second_ref_image(col, self, ref_image_attr)

    def _pool_index(self, context):
        """This style's own index in the shared pool, or -1.

        The row buttons below act on a style, and the form is drawn from
        two places: the sidebar list, where the drawn style is the
        highlighted one, and the settings dialog, which opens whichever
        row's gear was clicked. Handing the operators this index keeps
        them on the style in front of the user rather than on whatever
        row the list happens to have highlighted.
        """
        pool = getattr(get_style_props(context), "cabinet_styles", None)
        if not pool:
            return -1
        mine = self.as_pointer()
        for i, style in enumerate(pool):
            if style.as_pointer() == mine:
                return i
        return -1

    def draw_cabinet_style_ui(self, layout, context):
        """Per-style settings drawn inside the cabinet styles UIList panel.

        Sections: CABINET / FINISH / FRONTS / DOORS / DRAWERS / EDGE PROFILE.
        The Door / Drawer Front pickers reference a style by name from the
        shared front-style pools.
        """
        main = layout.column()
        style_index = self._pool_index(context)

        name_box = main.box()
        name_box.prop(self, "name", text="Style Name")

        box = main.box()
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text="CABINET")
        col = box.column(align=True)
        self._draw_toggle_field(col, "finish_wood", "Wood", "ss_wood")
        self._draw_toggle_field(col, "interior_material_type", "Interior",
                                "ss_interior")
        if not self.ss_interior_is_custom and self.interior_material_type == 'CUSTOM':
            col.prop(self, "custom_interior_material", text="")
        self._draw_toggle_field(col, "finish_overlay", "Overlay", "ss_overlay")
        self._draw_toggle_field(col, "ss_corner_treatment", "Corner Treatment")
        self._draw_toggle_field(col, "ss_fin_opening_edge", "Fin Opening Edge")
        # Face frame size grid is large; collapsed by default.
        row = box.row()
        row.alignment = 'LEFT'
        row.prop(self, "show_face_frame_sizes",
                 text="Face Frame Sizes",
                 icon='TRIA_DOWN' if self.show_face_frame_sizes else 'TRIA_RIGHT',
                 emboss=False)
        if self.show_face_frame_sizes:
            self._draw_face_frame_sizes(box, context)

        box = main.box()
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text="FINISH")
        # Toggle the per-finish reference name + image fields on/off (off by
        # default to keep the editor compact when references aren't in use).
        trow = box.row()
        trow.alignment = 'RIGHT'
        trow.prop(self, "show_finish_references", text="References",
                  icon='IMAGE_REFERENCE', toggle=True)
        show_refs = self.show_finish_references
        col = box.column(align=True)
        # Each finish field optionally shows a Reference row beneath it: a ref
        # NAME (shown on the Style Section page next to the field descriptor)
        # and a ref IMAGE path (collected into the page's right-side references
        # box). Gated on the References toggle above.
        self._draw_toggle_field(col, "finish_color", "Color", "ss_color")
        # A custom finish is matched to a sample, so there is no colour on
        # file for it - this is the one to render in.
        if style_options.is_custom_finish(self.finish_color):
            col.prop(self, "custom_finish_color", text="Custom Color")
        if show_refs:
            self._draw_finish_reference(col, "ss_color_ref_name", "ss_color_ref_image")
        self._draw_toggle_field(col, "finish_varnish", "Varnish", "ss_varnish")
        if show_refs:
            self._draw_finish_reference(col, "ss_varnish_ref_name", "ss_varnish_ref_image")
        self._draw_toggle_field(col, "finish_glaze", "Glaze", "ss_glaze")
        if show_refs:
            self._draw_finish_reference(col, "ss_glaze_ref_name", "ss_glaze_ref_image")
        # Special effects: catalog finish add-ons gated by this style's
        # wood + color. Add opens a checkbox dialog of the compatible set.
        # Each effect row also carries its own ref name + image.
        sfx = box.column(align=True)
        sfx.operator("hb_face_frame.add_special_effects",
                     text="Add Special Effects",
                     icon='ADD').style_index = style_index
        for effect in self.special_effects:
            r = sfx.row(align=True)
            r.label(text=effect.name, icon='DOT')
            if show_refs:
                r.prop(effect, "ref_name", text="")
                r.prop(effect, "ref_image", text="", icon='IMAGE_DATA')
            op = r.operator("hb_face_frame.remove_special_effect",
                            text="", icon='X', emboss=False)
            op.effect_name = effect.name
            op.style_index = style_index
            if show_refs:
                _draw_second_ref_image(sfx, effect, "ref_image")

        box = main.box()
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text="FRONTS")
        col = box.column(align=True)
        self._draw_toggle_field(col, "door_style", "Door", "ss_door")
        # Extra door styles: additional front styles listed on the Style
        # Section page (documentation only; no geometric effect).
        for i, ex in enumerate(self.extra_door_styles):
            r = col.row(align=True)
            r.prop(ex, "style", text="")
            op = r.operator("hb_face_frame.remove_cabinet_extra_front_style",
                            text="", icon='X', emboss=False)
            op.kind = 'DOOR'
            op.index = i
            op.style_index = style_index
        op = col.operator("hb_face_frame.add_cabinet_extra_front_style",
                          text="Add Door Style", icon='ADD')
        op.kind = 'DOOR'
        op.style_index = style_index

        col.separator()
        self._draw_toggle_field(col, "drawer_front_style", "Drawer Front", "ss_drawer")
        for i, ex in enumerate(self.extra_drawer_front_styles):
            r = col.row(align=True)
            r.prop(ex, "style", text="")
            op = r.operator("hb_face_frame.remove_cabinet_extra_front_style",
                            text="", icon='X', emboss=False)
            op.kind = 'DRAWER'
            op.index = i
            op.style_index = style_index
        op = col.operator("hb_face_frame.add_cabinet_extra_front_style",
                          text="Add Drawer Front Style", icon='ADD')
        op.kind = 'DRAWER'
        op.style_index = style_index

        box = main.box()
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text="DOORS")
        col = box.column(align=True)
        self._draw_toggle_field(col, "finish_hinge", "Hinge", "ss_hinge")

        box = main.box()
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text="DRAWERS")
        col = box.column(align=True)
        self._draw_toggle_field(col, "ss_drawer_slides", "Drawer Slides")
        self._draw_toggle_field(col, "ss_drawer_box_construction", "Box Construction")
        # Drawer-box brand logo (FILE_PATH image) -- plain file-picker row; the
        # Style Section page renders the logo in the DRAWERS section when set.
        col.prop(self, "ss_drawer_box_brand", text="Box Brand Logo")

        box = main.box()
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text="DOOR & DRAWER EDGE PROFILE")
        col = box.column(align=True)
        self._draw_toggle_field(col, "ss_edge_profile", "Edge Profile")

        # Free-text notes printed in a NOTES section at the end of this
        # style's Style Section block (e.g. 'TOUCH LATCH = TL').
        box = main.box()
        row = box.row()
        row.alignment = 'CENTER'
        row.label(text="NOTES")
        col = box.column(align=True)
        for i, note in enumerate(self.ss_notes):
            r = col.row(align=True)
            r.prop(note, "text", text="")
            op = r.operator("hb_face_frame.remove_style_note",
                            text="", icon='X', emboss=False)
            op.index = i
            op.style_index = style_index
        col.operator("hb_face_frame.add_style_note",
                     text="Add Note", icon='ADD').style_index = style_index


class HB_UL_face_frame_cabinet_styles(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        layout.prop(item, "name", text="", emboss=False, icon='SHADERFX')


# ---------------------------------------------------------------------------
# Door Style - shared pool, referenced from cabinet styles via index
# ---------------------------------------------------------------------------
RAIL_SIZE_ANNOTATION_TAG = 'DOOR_ANNOTATION'


# Dynamic enum items must stay referenced on the python side or
# Blender's enum strings go stale; one cached list per category.
_PROFILE_ENUM_CACHE = {}


def _profile_enum_items(category, none_label):
    """Items for a profile picker: 'NONE' plus the .blend stems in the
    shipped door_profiles category folder, refreshed per redraw so
    newly dropped-in files appear without a restart."""
    from ..common import door_profiles
    try:
        names = door_profiles.list_profiles(category)
    except Exception:
        names = []
    items = [('NONE', none_label, "")]
    items += [(n, n, "") for n in names]
    _PROFILE_ENUM_CACHE[category] = items
    return items


def get_outer_profile_items(self, context):
    return _profile_enum_items('OUTER', "Square")


def get_inner_profile_items(self, context):
    return _profile_enum_items('INNER', "Square")


def get_panel_profile_items(self, context):
    return _profile_enum_items('PANEL', "Flat")


def _sync_rail_size_annotation(front_obj, part, top_rail_width,
                               right_stile_width, active):
    """Maintain the '<N>R' rail-size FONT callout on a 5-piece front.

    Shown when the front's rail width deviates from the catalog spec
    (the style's rail unlock, or a locked per-front frame override) so
    the shop drawing calls out the non-standard rail. Parented to the
    front, it is torn down with the front on every recalc (the pivot
    wipe removes children_recursive) and recreated here; it rides into
    elevations like any other IS_2D_ANNOTATION FONT under the cabinet,
    where the host add-on's elevation pass links it to IGNORE freestyle.

    Idempotent: an existing annotation is removed first, covering live
    style edits (unlock toggled off) with no front rebuild in between.
    Placement matches the legacy convention: text sits centered on the
    top rail, inset 1" from the hinge-far stile, just proud of the
    face (part-local; Mirror Y flips the cross-width axis).
    """
    for child in list(front_obj.children):
        if child.get(RAIL_SIZE_ANNOTATION_TAG):
            bpy.data.objects.remove(child, do_unlink=True)
    if not active:
        return

    inches = units.meter_to_inch(top_rail_width)
    label = ('%g' % round(inches, 3)) + 'R'

    fd = bpy.data.curves.new('Rail Size Annotation', type='FONT')
    fd.body = label
    fd.size = 0.04
    fd.align_x = 'RIGHT'
    fd.align_y = 'CENTER'
    text_obj = hb_utils.new_object('Rail Size Annotation', fd)
    text_obj[RAIL_SIZE_ANNOTATION_TAG] = True
    text_obj['IS_2D_ANNOTATION'] = True
    text_obj.color = (0.0, 0.0, 0.0, 1.0)
    for coll in front_obj.users_collection:
        coll.objects.link(text_obj)
    if not text_obj.users_collection:
        bpy.context.scene.collection.objects.link(text_obj)
    text_obj.parent = front_obj
    text_obj.rotation_euler.z = -1.5707963267948966  # -90 deg

    try:
        front_length = part.get_input('Length')
        front_width = part.get_input('Width')
    except Exception:
        return
    try:
        mirror_y = bool(part.get_input('Mirror Y'))
    except Exception:
        mirror_y = False
    text_obj.location.x = front_length - top_rail_width / 2.0
    y = front_width - right_stile_width - units.inch(1.0)
    text_obj.location.y = -y if mirror_y else y
    text_obj.location.z = units.inch(0.76)


def _front_glass_rows(frame_store, n_rows):
    """Panel rows (0 = TOP) the user marked as glass in the Set Door
    Frame dialog: Top / Bottom toggles plus an explicit 1-based
    from-the-top list ("1 3") for grids. Independent of the frame lock
    -- it is a panel choice, not frame geometry. Empty set = none."""
    rows = set()
    if n_rows <= 0:
        return rows
    if frame_store.get('HB_FRAME_OVR_GLASS_TOP', False):
        rows.add(0)
    if frame_store.get('HB_FRAME_OVR_GLASS_BOTTOM', False):
        rows.add(n_rows - 1)
    text = str(frame_store.get('HB_FRAME_OVR_GLASS_ROWS', '') or '')
    for tok in text.replace(',', ' ').split():
        try:
            i = int(tok) - 1
        except ValueError:
            continue
        if 0 <= i < n_rows:
            rows.add(i)
    return rows


def front_frame_info(front_obj):
    """A door_builder info dict for the frame a front actually rendered
    with, read off its HB_DOOR_FRAME stamp. None for a slab / unstyled
    front. Lets a consumer re-derive the door's geometry without
    re-running the whole style resolve."""
    from ..common import door_builder
    stamp = front_obj.get('HB_DOOR_FRAME') if front_obj else None
    if stamp is None:
        return None
    info = door_builder.door_style_info(None)
    top = stamp.get('top_rail', 0.0)
    left = stamp.get('left_stile', 0.0)
    mid_w = stamp.get('mid_rail_width', 0.0)
    info.update(door_type='5_PIECE',
                stile_width=left, rail_width=top,
                left_stile_width=left,
                right_stile_width=stamp.get('right_stile', 0.0),
                top_rail_width=top,
                bottom_rail_width=stamp.get('bottom_rail', 0.0),
                mid_rail_width=mid_w,
                mid_stile_width=(stamp.get('mid_stile_width', 0.0) or None),
                add_mid_rail=False,
                mid_rail_z=(((0.5, 0.0) if stamp.get('mid_center', True)
                             else (0.0, stamp.get('mid_loc', 0.0)))
                            if stamp.get('add_mid_rail', False) else None))
    return info


def front_round_top_geometry(front_obj):
    """(geom, reason) for a front's round top -- door_builder.
    round_top_layout run against the frame the door rendered with, so
    every consumer (the dialog's warning, the face frame member above
    the door) reads the same curve the door was built to. (None, None)
    when the front isn't round-topped."""
    from ... import hb_types
    from ..common import door_builder
    spec = front_round_top(front_obj)
    if spec is None:
        return None, None
    info = front_frame_info(front_obj)
    if info is None:
        return None, None
    try:
        part = hb_types.GeoNodeCutpart(front_obj)
        width = part.get_input('Width')
        height = part.get_input('Length')
    except Exception:
        return None, None
    return door_builder.round_top_layout(info, width, height, spec)


def _front_frame_store(front_obj):
    """Persistent home for a front's locked frame overrides.

    Fronts (and their pivots) are torn down and rebuilt as NEW objects
    on every recalc, so custom props set on the front do not survive a
    cabinet edit. The front's OPENING cage (IS_FACE_FRAME_OPENING_CAGE)
    does survive, so the lock flag + HB_FRAME_OVR_* values live there.
    A cage-less front (bare Door Part) is its own store - it is not
    rebuilt by a cabinet recalc. NOTE: an opening with two leaves (double
    door) shares one store, so both leaves take the same locked frame.
    """
    o = front_obj.parent
    while o is not None:
        if o.get('IS_FACE_FRAME_OPENING_CAGE'):
            return o
        o = o.parent
    return front_obj


def _front_cutpart_mod(front_obj):
    """The front's GeoNodeCutpart NODES modifier (box generator carrying
    the Length / Width / Thickness inputs), or None."""
    for mod in front_obj.modifiers:
        if (mod.type == 'NODES' and mod.node_group
                and mod.node_group.name == 'GeoNodeCutpart'):
            return mod
    return None


# Round-top (quarter / half circle) doors. Unlike the style's shape
# these are set on ONE door - a pair often has a round leaf and a
# square one - so they are stamped per leaf on the front's opening
# store, keyed by the leaf index the type code stamps on each front.
ROUND_TOP_KEY = 'HB_DOOR_SHAPE'
ROUND_TOP_HAND_KEY = 'HB_DOOR_SHAPE_HAND'
ROUND_TOP_RADIUS_KEY = 'HB_DOOR_SHAPE_RADIUS'


def opening_door_pivots(store):
    """The door leaves of an opening store, as their PIVOTS, left to
    right. One pivot per leaf is how the type code builds them, so
    pivots count leaves even when a leaf has been made editable and
    carries several loose part objects. Sorted on opening-local x, which
    reads the same however the cabinet is turned in the room."""
    if store is None:
        return []
    pivots = []
    for obj in store.children_recursive:
        if obj.get('hb_part_role') != 'DOOR' or obj.parent is None:
            continue
        if obj.parent not in pivots:
            pivots.append(obj.parent)
    return sorted(pivots, key=lambda p: p.location.x)


def front_leaf_index(front_obj, store=None):
    """Which leaf of its opening a front is (0 = leftmost). The type
    code stamps this when it builds the front; a door built before the
    stamp existed falls back to its pivot's position in the opening, so
    an old file behaves without needing a recalc first."""
    stamped = front_obj.get('HB_LEAF_INDEX')
    if stamped is not None:
        return int(stamped)
    if store is None:
        store = _front_frame_store(front_obj)
    pivots = opening_door_pivots(store)
    if front_obj.parent in pivots:
        return pivots.index(front_obj.parent)
    return 0


def front_round_top_keys(front_obj, store=None):
    """(shape, hand, radius) store keys for this front's leaf."""
    i = front_leaf_index(front_obj, store)
    return ('%s_%d' % (ROUND_TOP_KEY, i),
            '%s_%d' % (ROUND_TOP_HAND_KEY, i),
            '%s_%d' % (ROUND_TOP_RADIUS_KEY, i))


def front_default_round_hand(front_obj, store=None):
    """Default tall side for a round top: the door's pull side, the one
    opposite its hinges. On a pair that puts the arcs' high points at
    the meeting stiles, the way the catalog draws them; on a single
    door it follows the opening's hinge side."""
    if store is None:
        store = _front_frame_store(front_obj)
    if len(opening_door_pivots(store)) > 1:
        return 'RIGHT' if front_leaf_index(front_obj, store) == 0 else 'LEFT'
    op = getattr(store, 'face_frame_opening', None)
    return 'LEFT' if getattr(op, 'hinge_side', 'LEFT') == 'RIGHT' else 'RIGHT'


# Hardware callouts (restrictor clips / touch latches / finger rout).
# Like the round tops these belong to ONE door rather than to the
# opening - a pair is often clipped on a single leaf - so they are
# stamped per leaf on the opening store. The un-suffixed keys are what
# an opening stamped before per-leaf existed carries; they still answer
# for any leaf that has no stamp of its own, so old jobs letter the way
# they always did until a leaf is set individually.
DOOR_HW_SET_KEY = 'HB_DOOR_HW_SET'
DOOR_HW_KEYS = (('RC', 'HB_DOOR_HW_RC'),
                ('TL', 'HB_DOOR_HW_TL'),
                ('FR', 'HB_DOOR_HW_FR'))


def front_door_hw_keys(front_obj, store=None):
    """(set_key, {code: key}) naming THIS leaf's hardware stamps."""
    i = front_leaf_index(front_obj, store)
    return ('%s_%d' % (DOOR_HW_SET_KEY, i),
            dict((code, '%s_%d' % (key, i)) for code, key in DOOR_HW_KEYS))


def front_door_hw(front_obj, store=None):
    """{'RC': bool, 'TL': bool, 'FR': bool} for THIS leaf: its own
    stamps when it has them, else the opening-wide stamps of an older
    file, else no callouts."""
    if store is None:
        store = _front_frame_store(front_obj)
    set_key, keys = front_door_hw_keys(front_obj, store)
    if store.get(set_key):
        return dict((code, bool(store.get(key, False)))
                    for code, key in keys.items())
    if store.get(DOOR_HW_SET_KEY):
        return dict((code, bool(store.get(key, False)))
                    for code, key in DOOR_HW_KEYS)
    return dict((code, False) for code, _key in DOOR_HW_KEYS)


def set_front_door_hw(front_obj, values, store=None):
    """Stamp THIS leaf's hardware callouts, values keyed RC / TL / FR.
    The leaf's partner is untouched - that is the point of the keys."""
    if store is None:
        store = _front_frame_store(front_obj)
    set_key, keys = front_door_hw_keys(front_obj, store)
    for code, key in keys.items():
        store[key] = bool(values[code])
    store[set_key] = True


def front_cabinet_style(front_obj):
    """The cabinet style governing a front -- its cabinet root's
    STYLE_NAME resolved against the scene's style list -- or None.
    Module-level twin of Face_Frame_Door_Style.get_parent_cabinet_style,
    for the front helpers that have no style instance in hand."""
    cur = front_obj
    while cur is not None and not cur.get('IS_FACE_FRAME_CABINET_CAGE'):
        cur = cur.parent
    if cur is None:
        return None
    name = cur.get('STYLE_NAME')
    if not name:
        return None
    ff = get_style_props()
    if ff is None:
        return None
    for cs in ff.cabinet_styles:
        if cs.name == name:
            return cs
    return None


def round_top_frame_block(front_obj):
    """Why this cabinet's face frame can't carry a curved opening, or
    None.

    A beaded inset frame runs a bead around every opening, and the bead
    can't be milled around an arc -- so the catalog does not offer a
    curved face frame there. An inset door needs its opening to follow
    its top, which leaves the round top itself unavailable. Read at
    BUILD time (front_round_top), not just in the dialog, so a cabinet
    restyled onto a beaded overlay squares its doors instead of drawing
    something the shop won't make. The per-leaf keys stay put, so
    moving back off the beaded overlay brings the curves back.
    """
    cs = front_cabinet_style(front_obj)
    if cs is None:
        return None
    try:
        beaded = cs.frame_profile_kind() == 'BEADED'
    except Exception:
        return None
    if beaded:
        return "A beaded inset face frame can't be curved"
    return None


def front_round_top(front_obj, store=None):
    """The round-top spec for a front (door_builder.round_top_layout),
    or None when this door is a plain square-top. The mesh is built for
    the standard Mirror Y front and flipped after when the cutpart is
    unmirrored (the corner cabinets' right door), so the hand flips
    with it."""
    if front_obj is None:
        return None
    if store is None:
        store = _front_frame_store(front_obj)
    k_shape, k_hand, k_radius = front_round_top_keys(front_obj, store)
    kind = store.get(k_shape)
    if not kind or kind == 'SQUARE':
        return None
    if round_top_frame_block(front_obj):
        return None
    hand = store.get(k_hand) or front_default_round_hand(front_obj, store)
    try:
        from ... import hb_types
        if not hb_types.GeoNodeCutpart(front_obj).get_input('Mirror Y'):
            hand = 'RIGHT' if hand == 'LEFT' else 'LEFT'
    except Exception:
        pass
    return {'kind': kind, 'hand': hand,
            'radius_mode': store.get(k_radius) or 'OUTSIDE'}


def _clear_static_door(front_obj):
    """Undo a python-built door on a front: drop the HB_DOOR_FRAME /
    HB_STATIC_SLAB stamp and the static mesh, and re-enable the cutpart
    box so the front renders as a plain slab again. No-op on a front
    that never had one."""
    if 'HB_DOOR_FRAME' not in front_obj and 'HB_STATIC_SLAB' not in front_obj:
        return
    if 'HB_DOOR_FRAME' in front_obj:
        del front_obj['HB_DOOR_FRAME']
    if 'HB_STATIC_SLAB' in front_obj:
        del front_obj['HB_STATIC_SLAB']
    front_obj.data.clear_geometry()
    cut = _front_cutpart_mod(front_obj)
    if cut is not None:
        cut.show_viewport = True
        cut.show_render = True


def _mirror_front_mesh_y_if_unmirrored(front_obj):
    """Python-built door / slab meshes are authored for the standard
    front convention (cutpart Mirror Y on: width spans part-local -Y).
    A front built with Mirror Y False -- the corner cabinets' RIGHT
    door and RIGHT drawer front -- was mirrored by the old
    CPM_5PIECEDOOR GN tree, which read the flag; the python builder
    does not, leaving the mesh a full width off along local Y. Mirror
    the static mesh to match: flip local Y and the normals. No-op when
    the cutpart modifier is missing or Mirror Y is on."""
    from ... import hb_types
    try:
        if hb_types.GeoNodeCutpart(front_obj).get_input('Mirror Y'):
            return
    except Exception:
        return
    me = front_obj.data
    for v in me.vertices:
        v.co.y = -v.co.y
    me.flip_normals()


def _door_rail_for_front(style, front_obj):
    """Rail width of the door style paired with ``front_obj``'s cabinet
    (front -> cabinet cage -> cabinet style -> door style), or None when
    any link is missing or the paired door style is a slab. Feeds the
    drawer-front match-door-rail option so drawer fronts can carry the
    same rail the cabinet's doors show."""
    cab = front_obj
    while cab is not None and not cab.get('IS_FACE_FRAME_CABINET_CAGE'):
        cab = cab.parent
    if cab is None:
        return None
    ff = get_style_props()
    cs = next((c for c in ff.cabinet_styles
               if c.name == cab.get('STYLE_NAME')), None)
    if cs is None:
        return None
    ds = next((d for d in ff.door_styles if d.name == cs.door_style), None)
    if ds is None or ds.door_type != '5_PIECE':
        return None
    return ds.rail_width


class Face_Frame_Door_Style(PropertyGroup):
    """Door / drawer-front construction style. Lives in a single
    Face_Frame_Scene_Props.door_styles collection; cabinet styles reference
    one entry as the door style and another as the drawer-front style via
    integer indices.
    """

    name: StringProperty(
        name="Name",
        description="Door style name",
        default="Door Style",
        update=update_door_style_name,
    )  # type: ignore

    rename_anchor: StringProperty(
        name="Rename Anchor",
        description="Internal: the style's previous name, used to re-tag "
                    "fronts carrying the old DOOR_STYLE_NAME on a rename",
        default="",
        options={'HIDDEN'},
    )  # type: ignore

    show_expanded: BoolProperty(
        name="Show Expanded",
        description="Show expanded style options",
        default=False,
    )  # type: ignore

    # ---- Catalog front spec (series -> shape -> panel; see style_options) ----
    # Whether this style reads the DOOR or DRAWER catalog is implied by which
    # pool it lives in (door_styles vs drawer_front_styles); see
    # _front_is_drawer (path-based). No stored "kind" property.
    front_series: EnumProperty(
        name="Series",
        description="Catalog series (gates the available shapes)",
        items=get_front_series_items,
        update=update_front_series,
    )  # type: ignore
    front_shape: EnumProperty(
        name="Shape",
        description="Shape available for the chosen series",
        items=get_front_shape_items,
        update=update_front_shape,
    )  # type: ignore
    front_panel: EnumProperty(
        name="Panel",
        description="Panel available for the chosen series + shape",
        items=get_front_panel_items,
        update=update_front_panel,
    )  # type: ignore

    # ---- Construction type ----
    door_type: EnumProperty(
        name="Door Type",
        description="Door construction type",
        items=[
            ('SLAB', "Slab", "Solid slab door"),
            ('5_PIECE', "5 Piece", "5-piece frame and panel door"),
        ],
        default='5_PIECE',
        update=_propagate_door_style,
    )  # type: ignore

    panel_material: EnumProperty(
        name="Panel Material",
        description="Material for door panel center",
        items=[
            ('MATCH_CABINET', "Match Cabinet", "Match the parent cabinet style material"),
            ('GLASS', "Glass", "Glass panel"),
        ],
        default='MATCH_CABINET',
        update=_propagate_door_style,
    )  # type: ignore

    # Wood-grain run direction for this front. HORIZONTAL feeds the 5-piece
    # panel the rotated finish material (finish_mat_rotated) so the panel
    # grain runs across; VERTICAL uses finish_mat (see
    # _set_door_modifier_materials). NONE renders like VERTICAL (only
    # HORIZONTAL is special-cased in the material walk) but carries no
    # grain spec: the Style Section page skips its Grain row, for
    # painted / non-grained fronts where a grain callout is noise.
    grain_direction: EnumProperty(
        name="Grain Direction",
        description="Direction the wood grain runs on this front",
        items=[
            ('NONE', "None", "No grain direction (painted / non-grained fronts; no callout on the style section)"),
            ('VERTICAL', "Vertical", "Grain runs vertically"),
            ('HORIZONTAL', "Horizontal", "Grain runs horizontally"),
        ],
        default='VERTICAL',
        update=update_grain_direction,
    )  # type: ignore

    # ---- Hardware / machining callouts ----
    # Documentation flags with no 3D geometry: downstream drawing
    # consumers letter-mark fronts using this style (RC / TL / FR) and
    # list the option beside the style name.
    include_restrictor_clips: BoolProperty(
        name="Include Restrictor Clips (RC)",
        description="Fronts using this style get an RC callout on drawings",
        default=False,
    )  # type: ignore
    include_touch_latches: BoolProperty(
        name="Include Touch Latches (TL)",
        description="Fronts using this style get a TL callout on drawings",
        default=False,
    )  # type: ignore
    include_finger_rout: BoolProperty(
        name="Include Finger Route (FR)",
        description="Fronts using this style get an FR callout on drawings",
        default=False,
    )  # type: ignore

    # ---- Profile references ----
    # Named picks from the shipped face_frame_assets/door_profiles
    # library (see _profile_enum_items); the Object pointers below are
    # custom-curve overrides that win when set.
    outside_profile_name: EnumProperty(
        name="Outside Profile",
        description="Outside edge profile from the shipped library",
        items=get_outer_profile_items,
        update=_propagate_door_style,
    )  # type: ignore

    inside_profile_name: EnumProperty(
        name="Inside Profile",
        description="Inside (sticking) profile from the shipped library",
        items=get_inner_profile_items,
        update=_propagate_door_style,
    )  # type: ignore

    panel_profile_name: EnumProperty(
        name="Panel Profile",
        description="Raised panel profile from the shipped library",
        items=get_panel_profile_items,
        update=_propagate_door_style,
    )  # type: ignore

    unlock_profiles: BoolProperty(
        name="Unlock Profiles",
        description="Override the series' outside / inside / panel profiles",
        default=False,
        update=update_unlock_frame_widths,
    )  # type: ignore

    outside_profile: PointerProperty(
        name="Outside Profile",
        type=bpy.types.Object,
        update=_propagate_door_style,
    )  # type: ignore

    inside_profile: PointerProperty(
        name="Inside Profile",
        type=bpy.types.Object,
        update=_propagate_door_style,
    )  # type: ignore

    panel_profile: PointerProperty(
        name="Panel Profile",
        type=bpy.types.Object,
        update=_propagate_door_style,
    )  # type: ignore

    # ---- 5-piece dimensions ----
    # Stile / rail widths derive from the catalog series by default; each has
    # its own unlock toggle to override it (see update_unlock_frame_widths /
    # _apply_series_frame_to_door_style).
    unlock_stile_width: BoolProperty(
        name="Unlock Stile Width",
        description="Override the catalog stile width; re-lock to snap back "
                    "to the series spec",
        default=False,
        update=update_unlock_frame_widths,
    )  # type: ignore

    unlock_rail_width: BoolProperty(
        name="Unlock Rail Width",
        description="Override the catalog rail width; re-lock to snap back "
                    "to the series spec",
        default=False,
        update=update_unlock_frame_widths,
    )  # type: ignore

    show_rail_annotation: BoolProperty(
        name="Show Rail Callout",
        description="Show the rail-size callout (e.g. '3R') on fronts whose "
                    "rail width deviates from the catalog spec",
        default=True,
        update=_propagate_door_style,
    )  # type: ignore

    match_door_rail_width: BoolProperty(
        name="Match Door Rail Width When Possible",
        description="Drawer fronts tall enough to carry the door rail "
                    "widths take the paired door style's rail width "
                    "instead of the drawer rail (drawer-front styles only)",
        default=False,
        update=_propagate_door_style,
    )  # type: ignore

    stile_width: FloatProperty(
        name="Stile Width",
        description="Width of left and right stiles",
        default=units.inch(3.0), unit='LENGTH', precision=4,
        update=_propagate_door_style,
    )  # type: ignore

    rail_width: FloatProperty(
        name="Rail Width",
        description="Width of top and bottom rails (the mid rail follows it)",
        default=units.inch(3.0), unit='LENGTH', precision=4,
        update=update_rail_width,
    )  # type: ignore

    # ---- Mid rail ----
    add_mid_rail: BoolProperty(
        name="Add Mid Rail",
        description="Add a horizontal mid rail",
        default=False,
        update=_propagate_door_style,
    )  # type: ignore

    center_mid_rail: BoolProperty(
        name="Center Mid Rail",
        description="Center the mid rail vertically",
        default=True,
        update=_propagate_door_style,
    )  # type: ignore

    mid_rail_width: FloatProperty(
        name="Mid Rail Width",
        description="Width of the mid rail",
        default=units.inch(3.0), unit='LENGTH', precision=4,
        update=_propagate_door_style,
    )  # type: ignore

    mid_rail_location: FloatProperty(
        name="Mid Rail Location",
        description="Distance from bottom of door to mid rail (if not centered)",
        default=units.inch(12.0), unit='LENGTH', precision=4,
        update=_propagate_door_style,
    )  # type: ignore

    # ---- Panel ----
    panel_thickness: FloatProperty(
        name="Panel Thickness",
        description="Thickness of the center panel",
        default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_propagate_door_style,
    )  # type: ignore

    panel_inset: FloatProperty(
        name="Panel Inset",
        description="How far panel is inset from frame face",
        default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_propagate_door_style,
    )  # type: ignore

    # ---- Edge profile (slab doors) ----
    edge_profile_type: EnumProperty(
        name="Edge Profile",
        description="Edge profile for slab doors",
        items=[
            ('SQUARE', "Square", "Square edge"),
            ('EASED', "Eased", "Slightly rounded edge"),
            ('OGEE', "Ogee", "Ogee profile"),
            ('BEVEL', "Bevel", "Beveled edge"),
            ('ROUNDOVER', "Roundover", "Rounded edge"),
        ],
        default='SQUARE',
        update=_propagate_door_style,
    )  # type: ignore

    # Front roles this style will act on (DOOR + PULLOUT_FRONT read door_style
    # on the parent cabinet style - a pullout is a door on a slide; the rest
    # read drawer_front_style).
    _DOOR_FRONT_ROLES = {'DOOR', 'PULLOUT_FRONT'}
    _DRAWER_FRONT_ROLES = {'DRAWER_FRONT', 'FALSE_FRONT', 'TILT_OUT',
                            'DRAWER_LOOK_FRONT'}
    _STYLEABLE_ROLES = _DOOR_FRONT_ROLES | _DRAWER_FRONT_ROLES

    def get_parent_cabinet_style(self, front_obj):
        """Walk up from a front object to its face frame cabinet root,
        read the cabinet's STYLE_NAME custom prop, and return the matching
        Face_Frame_Cabinet_Style on the scene (or None if unresolvable).
        Used for material inheritance once material walking is wired.
        """
        cur = front_obj
        cabinet_obj = None
        while cur is not None:
            if cur.get('IS_FACE_FRAME_CABINET_CAGE'):
                cabinet_obj = cur
                break
            cur = cur.parent
        if cabinet_obj is None:
            return None

        style_name = cabinet_obj.get('STYLE_NAME')
        if not style_name:
            return None

        ff = get_style_props()
        for cs in ff.cabinet_styles:
            if cs.name == style_name:
                return cs
        return None

    def _cabinet_edge_profile(self, front_obj):
        """The parent cabinet style's Door and Drawer Edge Profile pick
        (ss_edge_profile, or its custom free text), or None when unset.
        A per-order catalog styling option, so it lives on the CABINET
        style -- not the door style -- and applies to every front."""
        cs = self.get_parent_cabinet_style(front_obj)
        if cs is None:
            return None
        if getattr(cs, 'ss_edge_profile_is_custom', False):
            return cs.ss_edge_profile_custom.strip() or None
        name = cs.ss_edge_profile
        return None if name == 'None' else name

    def resolve_member_section(self, front_thickness):
        """Mitered-series member cross-section for this style at a door
        thickness, or None (not a mitered series / profiles unlocked /
        profile missing). The member profile IS the whole face profile;
        callers set every frame width to its width."""
        if getattr(self, 'unlock_profiles', False):
            return None
        from ..common import door_profiles
        _mname = style_options.profiles_for_series(
            self.front_series).get('member')
        if not _mname:
            return None
        try:
            return door_profiles.member_section(
                door_profiles.load_profile('MITERED', _mname),
                front_thickness)
        except Exception:
            return None

    def effective_panel_fields(self, front_thickness):
        """(panel_kind, panel_thickness, panel_inset) for this style at
        a door thickness. Center panel construction by panel KIND
        (style_options.panel_kind): RAISED uses the series' raised spec
        (the style's panel fields, typically thick and front-flush);
        every other kind is a RECESSED panel referenced off the BACK of
        the door (1/4" held 1/8" forward by default --
        recessed_panel_spec -- with a per-name thickness override for
        choices like the 3/8" MDF Reverse Panel)."""
        pkind = style_options.panel_kind(self.front_panel)
        eff_panel_th = self.panel_thickness
        eff_panel_inset = self.panel_inset
        if pkind['kind'] != 'RAISED':
            rp = style_options.recessed_panel_spec(self.front_series)
            _p_th_in = pkind.get('thickness', rp['thickness'])
            eff_panel_th = units.inch(_p_th_in)
            eff_panel_inset = max(
                front_thickness - units.inch(_p_th_in + rp['back_inset']),
                0.0)
        return pkind, eff_panel_th, eff_panel_inset

    def resolve_mesh_sections(self, front_thickness, eff_panel_inset,
                              pkind, member_sec, edge_name=None):
        """build_door_mesh keyword set for this style at a door
        thickness: profile sweep sections (outer / inner / split
        rail-stile / panel / member / applied), grooved-panel and
        mullion specs. Shared by the cabinet front path
        (assign_style_to_front) and the wood hood door builder.

        Profile sweeps: with profiles unlocked a custom curve pointer
        wins; else the named pick (series-derived when locked) from the
        shipped library. Anything broken or missing falls back to a
        square edge / flat panel. ``edge_name`` is a cabinet-level Door
        and Drawer Edge Profile override when the caller has one; it
        wins over the style's outer profile (Square -- and catalog
        names without a section builder yet -- read as a square edge).
        """
        from ..common import door_profiles
        _unlocked = getattr(self, 'unlock_profiles', False)

        def _resolve_profile(pointer, name, category):
            pr = door_profiles.profile_from_object(
                pointer if _unlocked else None)
            if pr is None and name and name != 'NONE':
                pr = door_profiles.load_profile(category, name)
            return pr

        outer_sec = inner_sec = panel_sec = None
        try:
            pr = _resolve_profile(self.outside_profile,
                                  getattr(self, 'outside_profile_name', ''),
                                  'OUTER')
            if pr is not None:
                outer_sec = door_profiles.edge_profile_section(
                    pr, front_thickness)
        except Exception:
            outer_sec = None
        if edge_name is not None:
            outer_sec = door_profiles.named_edge_section(
                edge_name, front_thickness)
        # Recessed panels seat the sticking strip on the panel
        # plane; raised panels let it run to its natural depth.
        _strip_floor = (eff_panel_inset
                        if pkind['kind'] != 'RAISED'
                        else None)
        try:
            pr = _resolve_profile(self.inside_profile,
                                  getattr(self, 'inside_profile_name', ''),
                                  'INNER')
            if pr is not None:
                inner_sec = door_profiles.sticking_strip(
                    pr, front_thickness, _strip_floor)
        except Exception:
            inner_sec = None
        # Split rail / stile sticking (series-driven only): some
        # series carve the opening's horizontal and vertical edges
        # with different cutters (SERIES_PROFILES inside_rail /
        # inside_stile). Hand-picked profiles apply to all sides.
        rail_sec = stile_sec = None
        if member_sec is not None:
            # The member profile carries the whole face; the other
            # sweeps don't apply.
            outer_sec = inner_sec = None
        if not _unlocked and member_sec is None:
            sprof = style_options.profiles_for_series(self.front_series)
            for key, cur in (('inside_rail', 'rail'),
                             ('inside_stile', 'stile')):
                name = sprof.get(key)
                if not name:
                    continue
                try:
                    s = door_profiles.sticking_strip(
                        door_profiles.load_profile('INNER', name),
                        front_thickness, _strip_floor)
                except Exception:
                    s = None
                if cur == 'rail':
                    rail_sec = s
                else:
                    stile_sec = s
        try:
            pr = _resolve_profile(getattr(self, 'panel_profile', None),
                                  getattr(self, 'panel_profile_name', ''),
                                  'PANEL')
            if pr is not None:
                panel_sec = door_profiles.panel_profile_section(
                    pr, front_thickness - max(eff_panel_inset, 0.0))
        except Exception:
            panel_sec = None
        # Applied decorative molding (series-driven): OUT moldings
        # seat proud on the door face, IN moldings on the recessed
        # panel inside the opening; scope RAILS runs top / bottom
        # only (Brunswick).
        applied_sec = None
        applied_scope = 'ALL'
        if not _unlocked and member_sec is None:
            _aprof = style_options.profiles_for_series(self.front_series)
            _aname = _aprof.get('applied')
            if _aname:
                applied_scope = _aprof.get('applied_scope', 'ALL')
                try:
                    applied_sec = door_profiles.applied_strip(
                        door_profiles.load_profile('APPLIED', _aname),
                        side=_aprof.get('applied_side', 'OUT'),
                        panel_front=eff_panel_inset)
                except Exception:
                    applied_sec = None
        # Grooved panel kinds (beadboard / kerf) cut their vertical
        # grooves into the flat recessed panel.
        panel_grv = None
        if pkind['kind'] == 'GROOVED':
            panel_grv = dict(
                style=pkind.get('style', 'BEAD'),
                spacing=units.inch(pkind.get('spacing', 2.0)))
        # Straight-bar mullion choices: bars over the glass, front
        # flush with the door face, back at the glass plane.
        mull = None
        if pkind['kind'] == 'GLASS' and pkind.get('mullion'):
            mull = dict(
                pattern=pkind['mullion'],
                bar_width=units.inch(pkind.get('bar_width', 0.875)),
                depth=eff_panel_inset)
        # Shape-width series (Konza): Glass / Speaker Cloth adds an inner
        # hardwood trim frame inside the opening (catalog total width
        # minus the outer member) - rendered as a FRAME border of bars
        # from the door face back to the panel plane.
        if mull is None:
            _ifw = style_options.glass_inner_frame_width(
                self.front_series, getattr(self, 'front_shape', ''),
                self.front_panel)
            if _ifw:
                mull = dict(pattern='FRAME',
                            bar_width=units.inch(_ifw),
                            depth=eff_panel_inset)
        return dict(outer_section=outer_sec, inner_section=inner_sec,
                    panel_section=panel_sec, inner_rail_section=rail_sec,
                    inner_stile_section=stile_sec,
                    member_section=member_sec,
                    applied_section=applied_sec,
                    applied_scope=applied_scope,
                    panel_grooves=panel_grv, mullion=mull)

    def _apply_slab_front(self, front_obj, front_length=None,
                          front_width=None, front_thickness=None):
        """Render front_obj as a slab: a python-built static mesh with
        the cabinet-level edge profile cut in when one is active, else
        the plain GN cutpart box. Shared by SLAB door styles and the
        5-piece too-small fallback (which passes the dims it already
        read; otherwise they come off the cutpart modifier). Strips any
        Door Style modifier either way."""
        from ... import hb_types
        from ..common import door_builder
        for mod in list(front_obj.modifiers):
            if mod.type == 'NODES' and 'Door Style' in mod.name:
                front_obj.modifiers.remove(mod)
        edge_sec = None
        if door_builder.USE_PYTHON_DOORS:
            _edge_name = self._cabinet_edge_profile(front_obj)
            if _edge_name is not None:
                if front_width is None:
                    slab_part = hb_types.GeoNodeCutpart(front_obj)
                    try:
                        front_length = slab_part.get_input("Length")
                        front_width = slab_part.get_input("Width")
                    except Exception:
                        front_width = front_length = None
                    try:
                        front_thickness = slab_part.get_input("Thickness")
                    except Exception:
                        front_thickness = units.inch(0.75)
                if front_width is not None:
                    from ..common import door_profiles
                    edge_sec = door_profiles.named_edge_section(
                        _edge_name, front_thickness)
        if edge_sec is not None:
            info = door_builder.door_style_info(self)
            info['door_type'] = 'SLAB'
            door_builder.build_door_mesh(front_obj.data, info,
                                         front_width, front_length,
                                         front_thickness,
                                         outer_section=edge_sec)
            _mirror_front_mesh_y_if_unmirrored(front_obj)
            cut = _front_cutpart_mod(front_obj)
            if cut is not None:
                cut.show_viewport = False
                cut.show_render = False
            if 'HB_DOOR_FRAME' in front_obj:
                del front_obj['HB_DOOR_FRAME']
            front_obj['HB_STATIC_SLAB'] = True
        else:
            _clear_static_door(front_obj)
        # Slabs carry no rails; drop a stale rail-size callout left
        # over from a live 5-piece -> slab edit.
        _sync_rail_size_annotation(front_obj, None, 0.0, 0.0, False)
        front_obj['DOOR_STYLE_NAME'] = self.name
        if not self.rename_anchor:
            self.rename_anchor = self.name

    def _apply_mirror_door_front(self, front_obj):
        """Fixed tri-view mirror-door build: a plain SQUARE wood frame at
        the opening cage's locked frame-override widths (the product
        stamps the meeting edges 0 so only the outer perimeter carries
        trim), a flat recessed panel (the mirror), and NO profiles, mid
        members, shape, or pull styling from the assigned door style --
        a slab or heavily profiled style can't change the mirror look.
        Marked IS_PREP_FOR_GLASS so the 2D layer hatches the mirror
        like glass."""
        from ... import hb_types
        from ..common import door_builder
        part = hb_types.GeoNodeCutpart(front_obj)
        try:
            front_length = part.get_input("Length")
            front_width = part.get_input("Width")
        except Exception:
            return "Could not read front dimensions"
        try:
            front_thickness = part.get_input("Thickness")
        except Exception:
            front_thickness = units.inch(0.75)

        store = _front_frame_store(front_obj)
        eff_left = store.get('HB_FRAME_OVR_LEFT_STILE', self.stile_width)
        eff_right = store.get('HB_FRAME_OVR_RIGHT_STILE', self.stile_width)
        eff_top = store.get('HB_FRAME_OVR_TOP_RAIL', self.rail_width)
        eff_bottom = store.get('HB_FRAME_OVR_BOTTOM_RAIL', self.rail_width)

        # Recessed flat panel per the global recessed rule (1/4" held
        # 1/8" off the door back) -- same math as the styled path.
        rp = style_options.recessed_panel_spec(self.front_series)
        panel_th = units.inch(rp['thickness'])
        panel_inset = max(
            front_thickness - units.inch(rp['thickness'] + rp['back_inset']),
            0.0)

        for mod in list(front_obj.modifiers):
            if mod.type == 'NODES' and 'Door Style' in mod.name:
                front_obj.modifiers.remove(mod)
        info = door_builder.door_style_info(self)
        info.update(
            door_type='5_PIECE',
            left_stile_width=eff_left,
            right_stile_width=eff_right,
            top_rail_width=eff_top,
            bottom_rail_width=eff_bottom,
            panel_thickness=panel_th,
            panel_inset=panel_inset,
            add_mid_rail=False,
            mid_rail_z=None,
            mid_rail_count=0,
            mid_stile_count=0,
        )
        door_builder.build_door_mesh(front_obj.data, info,
                                     front_width, front_length,
                                     front_thickness)
        _mirror_front_mesh_y_if_unmirrored(front_obj)
        cut = _front_cutpart_mod(front_obj)
        if cut is not None:
            cut.show_viewport = False
            cut.show_render = False
        if 'HB_STATIC_SLAB' in front_obj:
            del front_obj['HB_STATIC_SLAB']
        front_obj['IS_PREP_FOR_GLASS'] = True
        front_obj['HB_MIRROR_DOOR'] = True
        front_obj['HB_DOOR_FRAME'] = {
            'left_stile': eff_left,
            'right_stile': eff_right,
            'top_rail': eff_top,
            'bottom_rail': eff_bottom,
            'add_mid_rail': False,
            'mid_center': True,
            'mid_loc': 0.0,
            'mid_rail_width': self.mid_rail_width,
        }
        _sync_rail_size_annotation(front_obj, None, 0.0, 0.0, False)
        front_obj['DOOR_STYLE_NAME'] = self.name
        if not self.rename_anchor:
            self.rename_anchor = self.name
        return True

    def assign_style_to_front(self, front_obj, record_override=False):
        """Apply this door style to a face frame front object.

        SLAB: strip any 5-piece geometry so the front renders as the
        plain cutpart box.
        5_PIECE: build the door as a static mesh from door_builder
        (stiles / rails / panel boxes in the front's mesh, the cutpart
        modifier kept disabled for its Length / Width / Thickness
        inputs) and stamp the effective frame values on HB_DOOR_FRAME
        for downstream readers. With door_builder.USE_PYTHON_DOORS off,
        fall back to the CPM_5PIECEDOOR 'Door Style' modifier instead.

        Returns:
            True on success.
            False if front_obj is not a styleable face frame front.
            A string with an error message on a 5-piece dimension check
            failure (front too narrow / too short for the configured
            stiles + rails); the front is built as a slab -- edge
            profile still applied -- so the message is informational.
        """
        role = front_obj.get('hb_part_role')
        if role not in self._STYLEABLE_ROLES:
            return False

        # Per-front style override: when the user explicitly assigns a style to
        # THIS front (paint / assign-to-selected), persist the choice on the
        # stable OPENING cage so it survives the per-recalc front wipe+rebuild
        # (the front object is destroyed each recalc; the opening cage is not -
        # the same durable-store pattern as the front material override and the
        # locked frame store). Recalc-time reapply / propagate paths pass
        # record_override=False so a cabinet-default front never becomes a
        # sticky override.
        if record_override:
            _cage = front_obj.parent
            while _cage is not None and not _cage.get('IS_FACE_FRAME_OPENING_CAGE'):
                _cage = _cage.parent
            if _cage is not None:
                _key = ('hb_front_drawer_style'
                        if role in self._DRAWER_FRONT_ROLES
                        else 'hb_front_door_style')
                _cage[_key] = self.name

        # Every styleable front carries the part right-click menu. Fronts are
        # rebuilt each recalc (new objects), so stamping here - on the freshly
        # built front - is reliable where the recalc-time backfill is not.
        if not front_obj.get('MENU_ID'):
            front_obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_part_commands'

        # Tag glass-panel fronts so the 2D drawing layer can hatch the glass
        # panel (the host add-on reads IS_PREP_FOR_GLASS); mirrors the 3D glass render.
        # Set on every style assignment so it tracks the current panel choice.
        # Covers every GLASS panel kind (Prep for Glass + the mullion
        # choices, which render as plain glass until the bars land).
        front_obj['IS_PREP_FOR_GLASS'] = (
            style_options.panel_kind(self.front_panel)['kind'] == 'GLASS')

        # Tri-view mirror doors carry a fixed look -- plain square wood
        # frame + flat mirror panel -- independent of this style's
        # door_type / series (no catalog door style models a wood-trimmed
        # mirror door; the tri-view product stamps HB_MIRROR_DOOR on its
        # opening cages).
        if _front_frame_store(front_obj).get('HB_MIRROR_DOOR'):
            return self._apply_mirror_door_front(front_obj)

        from ... import hb_types
        from ..common import door_builder

        # Slab: strip any existing door style modifier / static door and tag.
        # With a cabinet-level edge profile the slab builds as a python
        # static mesh (the profile is real cut geometry), the same
        # cutpart-modifier-as-input-carrier mechanics as the 5-piece
        # path below; a square slab keeps the plain GN cutpart box.
        if self.door_type == 'SLAB':
            self._apply_slab_front(front_obj)
            return True

        # 5-piece: dimension check, then add / update the modifier.
        # GeoNodeCutpart (not GeoNodeObject) is the class that exposes
        # add_part_modifier - matches the wrap used elsewhere for fronts.
        part = hb_types.GeoNodeCutpart(front_obj)
        try:
            front_length = part.get_input("Length")
            front_width = part.get_input("Width")
        except Exception:
            return "Could not read front dimensions"
        try:
            front_thickness = part.get_input("Thickness")
        except Exception:
            front_thickness = units.inch(0.75)

        # Auto-add a centered mid rail above 45.5" so tall doors are
        # split. Matches the frameless convention. Series with no
        # divisible center panel opt out (see auto_mid_rail_allowed) --
        # they only get a rail the user asks for.
        auto_mid_rail_threshold = units.inch(45.5)
        needs_auto_mid_rail = (
            front_length > auto_mid_rail_threshold
            and style_options.auto_mid_rail_allowed(self.front_series))

        # Per-side frame-width overrides, visual-true (eff_left renders on
        # the viewer's left). Two sources:
        # - The user's Set Door Frame lock: the whole interface is pinned
        #   on the OPENING-cage store (HB_FRAME_FRAME_LOCKED) so a cabinet
        #   edit can't overwrite it.
        # - Unlocked, the solver's per-leaf stamps on the front object
        #   (tri-view mirror doors zero the interior stiles so adjacent
        #   mirrors butt; re-stamped on every recalc), falling back to the
        #   uniform door-style widths.
        frame_store = _front_frame_store(front_obj)
        frame_locked = bool(frame_store.get('HB_FRAME_FRAME_LOCKED', False))
        if frame_locked:
            eff_left_stile  = frame_store.get('HB_FRAME_OVR_LEFT_STILE',  self.stile_width)
            eff_right_stile = frame_store.get('HB_FRAME_OVR_RIGHT_STILE', self.stile_width)
            eff_top_rail    = frame_store.get('HB_FRAME_OVR_TOP_RAIL',    self.rail_width)
            eff_bottom_rail = frame_store.get('HB_FRAME_OVR_BOTTOM_RAIL', self.rail_width)
        else:
            eff_left_stile  = front_obj.get('HB_FRAME_OVR_LEFT_STILE',  self.stile_width)
            eff_right_stile = front_obj.get('HB_FRAME_OVR_RIGHT_STILE', self.stile_width)
            eff_top_rail    = front_obj.get('HB_FRAME_OVR_TOP_RAIL',    self.rail_width)
            eff_bottom_rail = front_obj.get('HB_FRAME_OVR_BOTTOM_RAIL', self.rail_width)

        # Mid-member widths. The style carries one mid rail width and no
        # mid stile width at all (a mid stile follows the outer stile), so
        # both are overridable per front from the same locked store - a
        # stored 0 / missing key means "follow the style".
        eff_mid_rail = self.mid_rail_width
        eff_mid_stile = getattr(self, 'mid_stile_width', 0.0) or self.stile_width
        if frame_locked:
            eff_mid_rail = (frame_store.get('HB_FRAME_OVR_MID_RAIL_WIDTH', 0.0)
                            or eff_mid_rail)
            eff_mid_stile = (frame_store.get('HB_FRAME_OVR_MID_STILE_WIDTH', 0.0)
                             or eff_mid_stile)

        # Mitered series: the member cross-section IS the profile; its
        # width becomes the frame width on all four sides (mitred
        # corners need equal members) and per-side overrides don't
        # apply.
        member_sec = self.resolve_member_section(front_thickness)
        if member_sec is not None:
            mw = max(u for u, v in member_sec)
            eff_left_stile = eff_right_stile = mw
            eff_top_rail = eff_bottom_rail = mw

        # Locked NONE mode removes the mid rail entirely, overriding both the
        # style's add_mid_rail and the tall-door auto rail.
        ovr_mid_mode = frame_store.get('HB_FRAME_OVR_MID_RAIL_MODE') if frame_locked else None
        # Per-front mid-member GRID (Set Door Frame): N mid rails / mid
        # stiles with optional row / column weights. Active only while
        # the frame is locked; a rail count > 0 supersedes the single
        # mid-rail modes below.
        ovr_grid_rails = 0
        ovr_grid_stiles = 0
        if frame_locked:
            ovr_grid_rails = max(
                int(frame_store.get('HB_FRAME_OVR_MID_RAIL_COUNT', 0) or 0), 0)
            ovr_grid_stiles = max(
                int(frame_store.get('HB_FRAME_OVR_MID_STILE_COUNT', 0) or 0), 0)

        # Match-door-rail (drawer-front styles): a drawer front tall
        # enough to carry the door rails takes the paired door style's
        # rail width instead of the drawer rail, so doors and drawer
        # fronts read as one family. Manual control wins - skipped when
        # this style's rail is unlocked or the front's frame is locked.
        # Only ever widens, and only when the front still clears the
        # 2*rail + 1" panel minimum enforced below.
        rail_matched = False
        if (self.match_door_rail_width and _front_is_drawer(self)
                and role in self._DRAWER_FRONT_ROLES
                and not frame_locked and not self.unlock_rail_width):
            door_rail = _door_rail_for_front(self, front_obj)
            if door_rail is not None and door_rail > eff_top_rail:
                need = door_rail * 2.0 + units.inch(1)
                if ovr_mid_mode != 'NONE' and (self.add_mid_rail or needs_auto_mid_rail):
                    need += eff_mid_rail
                if front_length >= need:
                    eff_top_rail = eff_bottom_rail = door_rail
                    rail_matched = True

        # Shaped (arched) top edge: widen the shaped rail(s) by the
        # curve's peak rise so the catalog rail width survives at the
        # crest; the geometry follows in build_door_mesh (shape=).
        # Twin carries no curve -- it only forces the mid stile below,
        # so the rails stay at their catalog width. Mitered members
        # keep their own profile -- the catalog offers no shapes there.
        # Round top (quarter / half circle): a per-door override, not
        # a style trait. The arc owns the whole top, so it supersedes
        # the style's arched-opening shape and needs no rail widening -
        # the curved rail keeps its catalog width around the curve.
        round_top = front_round_top(front_obj, frame_store)
        shape_k = None
        shape_rise_cap = 0.0
        _msw = 0.0
        if member_sec is None and round_top is None:
            shape_k = style_options.shape_kind(self.front_shape)
        if shape_k is not None:
            _msw = eff_mid_stile
            _n_ms = 1 if shape_k.get('twin') else 0
            if shape_k.get('curve'):
                _cell_w = (front_width - eff_left_stile - eff_right_stile
                           - _n_ms * _msw) / (_n_ms + 1)
                if _cell_w > units.inch(2):
                    shape_rise_cap = door_builder.shape_rise(
                        shape_k['curve'], _cell_w)
                    eff_top_rail += shape_rise_cap
                    if shape_k.get('double'):
                        eff_bottom_rail += shape_rise_cap
                else:
                    shape_k = None

        min_width = eff_left_stile + eff_right_stile + units.inch(1)
        if ovr_grid_stiles:
            _grid_msw = eff_mid_stile
            min_width += ovr_grid_stiles * _grid_msw
        min_height = eff_top_rail + eff_bottom_rail + units.inch(1)
        if ovr_grid_rails:
            min_height += ovr_grid_rails * eff_mid_rail
        elif ovr_mid_mode != 'NONE' and (self.add_mid_rail or needs_auto_mid_rail):
            min_height += eff_mid_rail

        # Too small for the frame -> the front renders as a slab, which
        # still carries the cabinet-level edge profile. The message
        # return is kept for callers that report the fallback.
        if front_width < min_width:
            self._apply_slab_front(front_obj, front_length, front_width,
                                   front_thickness)
            return (f"Front too narrow ({front_width:.3f}m) for stile "
                    f"widths (need {min_width:.3f}m)")
        if front_length < min_height:
            self._apply_slab_front(front_obj, front_length, front_width,
                                   front_thickness)
            return (f"Front too short ({front_length:.3f}m) for rail "
                    f"widths (need {min_height:.3f}m)")

        # Per-front mid rail override (durable, set from the Set Door Frame
        # popup) wins over the style / auto-center. CENTERED centers it; THIRD /
        # QUARTER place it by fraction; CUSTOM, TOP_PANEL and BOTTOM_PANEL use the
        # single stored value (a from-bottom centerline, or an interior panel
        # height that the solver converts to a centerline). Presence of an
        # override also forces a mid rail on. Resolved here to plain values
        # (on / centered / absolute centerline from the bottom) so both
        # geometry paths consume the same decision.
        # Center panel construction by panel KIND -- see
        # effective_panel_fields (shared with the wood hood doors).
        _pkind, eff_panel_th, eff_panel_inset = (
            self.effective_panel_fields(front_thickness))

        mid_on = False
        mid_center = True
        mid_loc = 0.0
        if not ovr_grid_rails and ovr_mid_mode != 'NONE' \
                and (needs_auto_mid_rail or self.add_mid_rail or ovr_mid_mode):
            mid_on = True
            if ovr_mid_mode == 'CENTERED':
                pass
            elif ovr_mid_mode == 'THIRD':
                # The centerline is measured from the BOTTOM, so 2/3 up puts
                # the rail near the top (bottom opening = 2/3, top = 1/3).
                mid_center = False
                mid_loc = front_length * 2.0 / 3.0
            elif ovr_mid_mode == 'QUARTER':
                # 3/4 up from the bottom (bottom opening = 3/4, top = 1/4).
                mid_center = False
                mid_loc = front_length * 3.0 / 4.0
            elif ovr_mid_mode in ('CUSTOM', 'TOP_PANEL', 'BOTTOM_PANEL'):
                # One stored value, interpreted by mode. The door spans
                # [0, L] along its length; the rail spans [loc - Rm/2,
                # loc + Rm/2] about its centerline loc. So the bottom opening
                # is (loc - Rm/2) - bottom_rail and the top opening is
                # (L - top_rail) - (loc + Rm/2). CUSTOM stores loc directly;
                # the panel modes store the opening height on that side and we
                # solve for loc, clamping so a too-large height can't push the
                # rail past either end rail.
                mid_center = False
                stored = frame_store.get('HB_FRAME_OVR_MID_RAIL_LOCATION',
                                         self.mid_rail_location)
                half_rm = eff_mid_rail / 2.0
                if ovr_mid_mode == 'BOTTOM_PANEL':
                    loc = eff_bottom_rail + stored + half_rm
                elif ovr_mid_mode == 'TOP_PANEL':
                    loc = front_length - eff_top_rail - stored - half_rm
                else:
                    loc = stored
                loc_min = eff_bottom_rail + half_rm
                loc_max = front_length - eff_top_rail - half_rm
                if loc_max >= loc_min:
                    loc = max(loc_min, min(loc, loc_max))
                mid_loc = loc
            elif needs_auto_mid_rail:
                pass
            else:
                mid_center = self.center_mid_rail
                if not mid_center:
                    mid_loc = self.mid_rail_location
        if member_sec is not None:
            # A mitered door is one continuous molding loop -- no mid
            # rail geometry exists for it.
            mid_on = False

        if door_builder.USE_PYTHON_DOORS:
            # Python-built door: static boxes in the front's own mesh. The
            # cutpart modifier stays for its Length / Width / Thickness
            # inputs (the solver keeps writing them) but its box is hidden;
            # any modifier from the GN fallback is dropped.
            for mod in list(front_obj.modifiers):
                if mod.type == 'NODES' and 'Door Style' in mod.name:
                    front_obj.modifiers.remove(mod)
            info = door_builder.door_style_info(self)
            info.update(
                door_type='5_PIECE',
                left_stile_width=eff_left_stile,
                right_stile_width=eff_right_stile,
                top_rail_width=eff_top_rail,
                bottom_rail_width=eff_bottom_rail,
                panel_thickness=eff_panel_th,
                panel_inset=eff_panel_inset,
                add_mid_rail=False,
                mid_rail_z=(((0.5, 0.0) if mid_center else (0.0, mid_loc))
                            if mid_on else None),
            )
            # Locked mid-member widths: the style has one mid rail width
            # and no mid stile width, so a pinned front takes both off its
            # own store (unlocked, door_style_info's values already stand).
            if frame_locked:
                info['mid_rail_width'] = eff_mid_rail
                info['mid_stile_width'] = eff_mid_stile
            # Mid-member grid override: counts + optional row / column
            # weights (door_layout divides the field; weight strings are
            # parsed leniently, blank / invalid = equal cells). Mitered
            # doors have no mid-member geometry, matching the single
            # mid rail above.
            if member_sec is None:
                if ovr_grid_rails:
                    info['mid_rail_count'] = ovr_grid_rails
                    info['mid_rail_z'] = None
                    info['mid_rail_fractions'] = door_builder.parse_grid_ratios(
                        frame_store.get('HB_FRAME_OVR_ROW_RATIOS', ''))
                if ovr_grid_stiles:
                    info['mid_stile_count'] = max(
                        int(info.get('mid_stile_count', 0) or 0),
                        ovr_grid_stiles)
                    info['mid_stile_fractions'] = door_builder.parse_grid_ratios(
                        frame_store.get('HB_FRAME_OVR_COL_RATIOS', ''))
            if shape_k is not None and shape_k.get('twin') \
                    and not info.get('mid_stile_count'):
                info['mid_stile_count'] = 1
                info['mid_stile_width'] = _msw
            # Profile sweeps / panel construction / mullions resolved
            # from the style via resolve_mesh_sections (shared with the
            # wood hood door builder). The cabinet-level "Door and
            # Drawer Edge Profile" (a per-order catalog styling option,
            # not a series trait) rides in as the edge override.
            secs = self.resolve_mesh_sections(
                front_thickness, eff_panel_inset, _pkind, member_sec,
                edge_name=self._cabinet_edge_profile(front_obj))
            # Locked-frame mullion override: the Set Door Frame dialog
            # can pin the Wood Mullion grid's lite counts per front
            # (0 / absent = the pattern's standard counts).
            if (frame_locked and secs.get('mullion') is not None
                    and secs['mullion'].get('pattern') == 'GRID'):
                _mrows = int(frame_store.get('HB_FRAME_OVR_MULLION_ROWS', 0) or 0)
                _mcols = int(frame_store.get('HB_FRAME_OVR_MULLION_COLS', 0) or 0)
                if _mrows > 0:
                    secs['mullion']['rows'] = _mrows
                if _mcols > 0:
                    secs['mullion']['cols'] = _mcols
            # Per-row glass (Set Door Frame > Glass Panels): a split
            # door with a glass top and a wood bottom. Rows resolve
            # against THIS door's layout; the lite rects are stamped
            # for the drawings' hatch pass.
            glass_rows = _front_glass_rows(
                frame_store,
                door_builder.panel_row_count(info, front_width,
                                             front_length))
            # A door too small for its arc builds square; the Change
            # Door Shape dialog is where the user hears why.
            if round_top is not None and door_builder.round_top_layout(
                    info, front_width, front_length, round_top)[0] is None:
                round_top = None
            door_builder.build_door_mesh(front_obj.data, info,
                                         front_width, front_length,
                                         front_thickness,
                                         shape=(dict(shape_k,
                                                     rise=shape_rise_cap)
                                                if shape_k
                                                and shape_k.get('curve')
                                                else None),
                                         glass_rows=glass_rows or None,
                                         round_top=round_top,
                                         **secs)
            if glass_rows:
                cells = door_builder.glass_cell_rects(
                    info, front_width, front_length, glass_rows)
                front_obj['HB_GLASS_CELLS'] = [
                    v for rect in cells for v in rect]
                # The lite faces index slot 3; give it the glass material
                # now (the cabinet material walk keeps it current after).
                me = front_obj.data
                while len(me.materials) < 4:
                    me.materials.append(None)
                me.materials[3] = (
                    Face_Frame_Cabinet_Style._get_glass_panel_material())
            elif 'HB_GLASS_CELLS' in front_obj:
                del front_obj['HB_GLASS_CELLS']
            _mirror_front_mesh_y_if_unmirrored(front_obj)
            cut = _front_cutpart_mod(front_obj)
            if cut is not None:
                cut.show_viewport = False
                cut.show_render = False
            if 'HB_STATIC_SLAB' in front_obj:
                del front_obj['HB_STATIC_SLAB']
            # Effective frame record for readers that used to consult the
            # modifier inputs (Set Door Frame dialog, panel-opening readout,
            # the host add-on's glass-hatch pass).
            front_obj['HB_DOOR_FRAME'] = {
                'left_stile': eff_left_stile,
                'right_stile': eff_right_stile,
                'top_rail': eff_top_rail,
                'bottom_rail': eff_bottom_rail,
                'add_mid_rail': mid_on,
                'mid_center': mid_center,
                'mid_loc': mid_loc,
                'mid_rail_width': eff_mid_rail,
                'mid_stile_width': eff_mid_stile,
            }
        else:
            # GN fallback: find or add the 'Door Style' CPM_5PIECEDOOR
            # modifier (undoing any python-built door first).
            _clear_static_door(front_obj)
            existing_mod = None
            for mod in front_obj.modifiers:
                if mod.type == 'NODES' and 'Door Style' in mod.name:
                    existing_mod = mod
                    break
            if existing_mod is not None:
                door_style_mod = hb_types.CabinetPartModifier()
                door_style_mod.obj = front_obj
                door_style_mod.mod = existing_mod
            else:
                door_style_mod = part.add_part_modifier('CPM_5PIECEDOOR', 'Door Style')

            # The node renders its Left / Right stile inputs on the OPPOSITE
            # visual sides from their names, so the visual-true values are
            # swapped at this boundary: the node's 'Left Stile Width' input
            # has always carried the viewer's RIGHT stile (readers swap the
            # same way -- see _front_frame_values).
            door_style_mod.set_input("Left Stile Width", eff_right_stile)
            door_style_mod.set_input("Right Stile Width", eff_left_stile)
            door_style_mod.set_input("Top Rail Width", eff_top_rail)
            door_style_mod.set_input("Bottom Rail Width", eff_bottom_rail)
            door_style_mod.set_input("Panel Thickness", eff_panel_th)
            door_style_mod.set_input("Panel Inset", eff_panel_inset)

            try:
                door_style_mod.set_input("Add Mid Rail", mid_on)
                if mid_on:
                    door_style_mod.set_input("Mid Rail Width", eff_mid_rail)
                    door_style_mod.set_input("Center Mid Rail", mid_center)
                    if not mid_center:
                        door_style_mod.set_input("Mid Rail Location", mid_loc)
            except Exception:
                pass

        # Rail-size callout ('3R'): rail width deviates from the catalog
        # via the style's rail unlock, a matched door rail on a drawer
        # front, or a locked per-front frame override whose top rail
        # differs from the style.
        _sync_rail_size_annotation(
            front_obj, part, eff_top_rail, eff_right_stile,
            active=(self.show_rail_annotation
                    and (self.unlock_rail_width
                         or rail_matched
                         or (frame_locked
                             and abs(eff_top_rail - self.rail_width) > 1e-6))),
        )

        # Material inheritance from the parent cabinet style lands once
        # cabinet-style material walking is implemented.
        front_obj['DOOR_STYLE_NAME'] = self.name
        if not self.rename_anchor:
            self.rename_anchor = self.name
        return True

    def draw_door_style_ui(self, layout, context):
        """Per-style settings drawn inside the door styles UIList panel.
        Assign / Update ops for fronts ship alongside assign_style_to_front.
        """
        box = layout.box()
        box.prop(self, "name", text="Style Name")

        # Catalog front spec (series -> shape -> panel) is the single source
        # of truth. Series + kind derive the stile / rail widths, drawer-rail,
        # panel inset/thickness and slab-vs-5-piece (see
        # _apply_series_frame_to_door_style); the construction fields are
        # written from it and consumed by the geometry + applied-panel-sizing
        # engines, so they're no longer shown here.
        col = box.column(align=True)
        col.label(text="Catalog:")
        col.prop(self, "front_series", text="Series")
        col.prop(self, "front_shape", text="Shape")
        col.prop(self, "front_panel", text="Panel")

        box.prop(self, "grain_direction", text="Grain Direction")

        # Hardware callouts: the checkbox DECLARES the option for the
        # job (style-page legend line); the brush button paints which
        # doors actually carry the letter mark on drawings.
        hw = box.column(align=True)
        for prop_id, code in (("include_restrictor_clips", 'RC'),
                              ("include_touch_latches", 'TL'),
                              ("include_finger_rout", 'FR')):
            hrow = hw.row(align=True)
            hrow.prop(self, prop_id)
            op = hrow.operator("hb_face_frame.paint_door_hardware",
                               text="", icon='BRUSH_DATA')
            op.callout = code

        # Frame widths derive from the catalog series by default (read-only).
        # Stile and rail each have an independent unlock toggle to override
        # them; the mid rail always follows the rail width. Re-locking a field
        # snaps it back to the series spec (see update_unlock_frame_widths).
        if self.door_type == '5_PIECE':
            box.label(text="Frame Widths:")
            srow = box.row(align=True)
            sfield = srow.column(align=True)
            sfield.enabled = self.unlock_stile_width
            sfield.prop(self, "stile_width", text="Stile Width")
            srow.prop(self, "unlock_stile_width", text="",
                      icon='UNLOCKED' if self.unlock_stile_width else 'LOCKED')
            rrow = box.row(align=True)
            rfield = rrow.column(align=True)
            rfield.enabled = self.unlock_rail_width
            rfield.prop(self, "rail_width", text="Rail Width")
            rrow.prop(self, "unlock_rail_width", text="",
                      icon='UNLOCKED' if self.unlock_rail_width else 'LOCKED')
            box.prop(self, "show_rail_annotation", text="Show Rail Callout")
            if _front_is_drawer(self):
                box.prop(self, "match_door_rail_width",
                         text="Match Door Rail Width When Possible")
            # Profile picks derive from the catalog series (locked, like
            # the frame widths); unlock to hand-pick from the shipped
            # library. A custom curve object overrides the named pick.
            prow = box.row(align=True)
            prow.label(text="Profiles:")
            prow.prop(self, "unlock_profiles", text="",
                      icon='UNLOCKED' if self.unlock_profiles else 'LOCKED')
            pcol = box.column(align=True)
            pcol.enabled = self.unlock_profiles
            pcol.prop(self, "outside_profile_name", text="Outside")
            pcol.prop(self, "inside_profile_name", text="Inside")
            pcol.prop(self, "panel_profile_name", text="Panel")
            if self.unlock_profiles:
                ccol = box.column(align=True)
                ccol.label(text="Custom Curves (override):")
                ccol.prop(self, "outside_profile", text="Outside")
                ccol.prop(self, "inside_profile", text="Inside")
                ccol.prop(self, "panel_profile", text="Panel")

        # Assign by Painting starts a modal brush: click fronts in the
        # viewport to apply THIS style. Door styles paint door fronts,
        # drawer-front styles paint drawer fronts (kind derived from the
        # pool this style lives in). Update re-applies to every matching
        # front already tagged with the style name.
        try:
            kind = 'DRAWER' if "drawer_front_styles" in self.path_from_id() else 'DOOR'
        except Exception:
            kind = 'DOOR'
        row = box.row(align=True)
        row.scale_y = 1.3
        op = row.operator("hb_face_frame.paint_assign_front_style",
                          text="Assign by Painting", icon='BRUSH_DATA')
        op.kind = kind
        op = row.operator("hb_face_frame.update_fronts_from_style",
                          text="Update Fronts", icon='FILE_REFRESH')
        op.kind = kind


class HB_UL_face_frame_door_styles(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        layout.prop(item, "name", text="", emboss=False, icon='MESH_PLANE')


# ---------------------------------------------------------------------------
# Object-level PropertyGroups - face frame cabinet & bay state
# ---------------------------------------------------------------------------
def _update_cabinet_dim(self, context):
    """Triggered when a cabinet-level dimension changes. Walks back to the
    cabinet root (works even if the prop is on a descendant somehow) and
    runs recalculate() to push values to all parts.

    Imported lazily to avoid any chance of a circular import at module load.
    """
    from . import types_face_frame
    types_face_frame.recalculate_face_frame_cabinet(self.id_data)


# Revolving-door susans carry 1-1/2" front stiles whatever the style's
# stile width is - the door turns with the susan, so the frame opening
# is sized to it rather than to the style. Both the revolving exterior
# option and the pie-cut revolving susan interiors count.
REVOLVING_STILE_WIDTH = units.inch(1.5)
REVOLVING_INTERIOR_OPTIONS = ('POLYMER_PIE_CUT_REVOLVING',
                              'WOOD_PIE_CUT_REVOLVING')


def is_revolving_susan(cab_props):
    """True when this corner cabinet is a revolving-door susan."""
    return (getattr(cab_props, 'exterior_option', '') == 'REVOLVING_DOORS'
            or getattr(cab_props, 'interior_option', '')
            in REVOLVING_INTERIOR_OPTIONS)


def apply_revolving_stile_widths(cab_props):
    """Force both front stiles to 1-1/2" on a revolving susan. Written
    to the properties rather than applied at build time so the sizes the
    user reads match the parts. An unlocked stile is left alone - that
    flag is the deliberate per-cabinet override everywhere else."""
    if not is_revolving_susan(cab_props):
        return False
    changed = False
    for attr, lock in (('left_stile_width', 'unlock_left_stile'),
                       ('right_stile_width', 'unlock_right_stile')):
        if getattr(cab_props, lock, False):
            continue
        if abs(getattr(cab_props, attr) - REVOLVING_STILE_WIDTH) > 1e-6:
            setattr(cab_props, attr, REVOLVING_STILE_WIDTH)
            changed = True
    return changed


def _update_corner_option(self, context):
    """Corner exterior / interior option changed: a revolving susan
    takes its own stile width before the rebuild reads it."""
    apply_revolving_stile_widths(self)
    _update_cabinet_dim(self, context)


# Per-side band width. get/set rather than a plain property so an unset
# right side reads through to the left one - the two were a single value
# until legs could carry a different band each side.
_FLUSH_X_RIGHT_KEY = "HB_FLUSH_X_WIDTH_RIGHT"


def _get_flush_x_right(self):
    v = self.get(_FLUSH_X_RIGHT_KEY)
    return float(v) if v is not None else float(self.flush_x_panel_width)


def _set_flush_x_right(self, value):
    self[_FLUSH_X_RIGHT_KEY] = float(value)
    _update_cabinet_dim(self, bpy.context)


def _update_overstool_accessory(self, context):
    """Accessory change on an over-stool cabinet: sync the leg drop to the
    product spec (face frame 7" less than overall height, 13" with shelf
    AND towel bar) before the recalc. Only moves the drop when it still
    sits at one of the presets - a hand-edited amount is left alone."""
    presets = (units.inch(7.0), units.inch(13.0))
    if self.extend_sides_down and any(
            abs(self.extend_sides_down_amount - p) < 0.0001 for p in presets):
        want = (units.inch(13.0)
                if self.overstool_accessory == 'SHELF_AND_TOWEL_BAR'
                else units.inch(7.0))
        if abs(self.extend_sides_down_amount - want) > 0.0001:
            self.extend_sides_down_amount = want
            return  # its own update already ran the recalc
    _update_cabinet_dim(self, context)


def _overall_height_get(self):
    """Box height plus the leg drop when the sides extend down - the
    catalog's overall height for over-stool style cabinets."""
    drop = self.extend_sides_down_amount if self.extend_sides_down else 0.0
    return self.height + drop


def _overall_height_set(self, value):
    drop = self.extend_sides_down_amount if self.extend_sides_down else 0.0
    # Writing height runs its own update / recalc.
    self.height = max(value - drop, units.inch(1.0))


def _width_axis(root):
    """The direction the cabinet's width grows in, in parent space.

    Usually the parent's +X, but a cabinet can carry a rotation of its
    own while still parented to the same wall - one snapped into a
    corner turns onto the adjacent wall, and cabinets in a run can face
    another way. Those grow along the rotated axis, so shifting
    location.x alone slid the whole cabinet sideways instead of holding
    an edge. Normalized, so a scaled root can't inflate the shift.
    """
    from mathutils import Vector
    axis = root.matrix_basis.to_3x3() @ Vector((1.0, 0.0, 0.0))
    if axis.length < 1e-9:
        return Vector((1.0, 0.0, 0.0))
    return axis.normalized()


def _update_cabinet_width(self, context):
    """Width update: honor the cabinet's anchor side, then recalc.

    A cabinet's origin is its LEFT edge, so a width change naturally
    grows / shrinks the right side. Anchored RIGHT, the origin shifts
    by the full width delta so the right edge stays put instead;
    anchored CENTER it shifts by half, holding the centreline (the old
    version's anchor left / center / right). Resize without having to
    move the cabinet after. The shift runs along the cabinet's OWN
    width axis (_width_axis), not the parent's X. The previous width
    is stashed on the object (seeded from the cage's Dim X, which
    still holds the pre-write
    value when the callback fires) so back-to-back writes under a
    suspended recalc compute the right delta. System width writes
    during a group/bay distribution (_DISTRIBUTING_WIDTHS) never
    shift - those passes place cabinets themselves.
    """
    from . import types_face_frame
    root = self.id_data
    old = root.get('HB_ANCHOR_LAST_WIDTH')
    if old is None:
        from ... import hb_types
        try:
            old = hb_types.GeoNodeCage(root).get_input('Dim X')
        except Exception:
            old = None
    share = {'RIGHT': 1.0, 'CENTER': 0.5}.get(
        getattr(self, 'anchor_side', 'LEFT'), 0.0)
    if (old is not None and share
            and id(root) not in types_face_frame._DISTRIBUTING_WIDTHS):
        delta = self.width - old
        if abs(delta) > 1e-9:
            root.location -= _width_axis(root) * (delta * share)
    root['HB_ANCHOR_LAST_WIDTH'] = self.width
    _update_cabinet_dim(self, context)


_BOTTOM_RAIL_PROFILE_ITEMS_CACHE = []


def _bottom_rail_profile_items(self, context):
    """Enum items for bottom_rail_profile: 'None' plus every '* Cutter.blend'
    in face_frame_assets/profiles (id = the blend stem, e.g. 'Beckony Cutter').
    Held in a module global so Blender does not GC the returned strings (the
    dynamic-enum-callback gotcha)."""
    items = [('NONE', 'None', 'No decorative bottom-rail profile'),
             ('ARCH', 'Arched', 'A smooth circular arch cut into the bottom rail')]
    d = os.path.join(os.path.dirname(__file__), 'face_frame_assets', 'profiles')
    if os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            if fn.endswith(' Cutter.blend'):
                stem = fn[:-len('.blend')]        # 'Beckony Cutter'
                label = stem[:-len(' Cutter')]     # 'Beckony'
                items.append((stem, label, label + ' bottom-rail profile'))
    # Explicit values: positional for the historical entries (what saved
    # files already hold), a fixed high slot for the procedural additions
    # so new '* Cutter.blend' assets can't renumber them.
    items = [(i[0], i[1], i[2], n) for n, i in enumerate(items)]
    items.append(('TRADITIONAL', 'Traditional',
                  'Straight ramps into a rounded shoulder and a flat raised '
                  'centre', 100))
    _BOTTOM_RAIL_PROFILE_ITEMS_CACHE[:] = items
    return _BOTTOM_RAIL_PROFILE_ITEMS_CACHE


_BAY_BOTTOM_RAIL_PROFILE_ITEMS_CACHE = []


def _bay_bottom_rail_profile_items(self, context):
    """Per-bay variant of _bottom_rail_profile_items with a leading
    'Use Cabinet Setting' inherit entry (same GC-guard cache pattern)."""
    items = [('CABINET', 'Use Cabinet Setting',
              'Follow the cabinet-level Bottom Rail Profile pick', 0)]
    # Cabinet-level values shifted by one behind the CABINET entry (the
    # positional numbering saved bay overrides already carry).
    items += [(i[0], i[1], i[2], i[3] + 1)
              for i in _bottom_rail_profile_items(self, context)]
    _BAY_BOTTOM_RAIL_PROFILE_ITEMS_CACHE[:] = items
    return _BAY_BOTTOM_RAIL_PROFILE_ITEMS_CACHE


def _update_panel_split_auto(self, context):
    """Auto-openings toggle on an applied panel. Recalc the HOST cabinet
    so _reconcile_applied_panels re-runs the split: auto on re-applies the
    width ladder, auto off preserves the current bay count. On a non-panel
    cabinet (the flag is on the shared propgroup) this is a plain recalc."""
    from . import types_face_frame
    obj = self.id_data
    if obj is None:
        return
    if obj.get(types_face_frame.TAG_APPLIED_PANEL_SIDE) and obj.parent is not None:
        types_face_frame.recalculate_face_frame_cabinet(obj.parent)
    else:
        types_face_frame.recalculate_face_frame_cabinet(obj)


# Vertical-divisions override on an applied panel: same host-recalc
# routing as the split-auto toggle (the split structure is rebuilt by
# the host's _reconcile_applied_panels pass).
_update_panel_vertical_bays = _update_panel_split_auto


def _update_panel_rows(self, context):
    """Row-count override on an applied panel: sync the per-row height
    list to the new count (fresh entries start on auto-equal) before
    the host recalc rebuilds the split tree. The builder computes the
    auto shares and writes them back for display."""
    obj = self.id_data
    if obj is None:
        return
    cab = obj.face_frame_cabinet
    heights = cab.panel_row_heights
    want = cab.panel_horizontal_rows
    while len(heights) < want:
        heights.add()
    while len(heights) > want:
        heights.remove(len(heights) - 1)
    _update_panel_split_auto(self, context)


# Standard rollout box heights (inches) keyed by the preset enum id, plus the
# matching enum items. CUSTOM is intentionally absent from the map: it leaves
# a box's height untouched so a typed value stands.
_ROLLOUT_HEIGHT_PRESETS_IN = {
    'IN_3_125': 3.125,
    'IN_3_625': 3.625,
    'IN_4_125': 4.125,
    'IN_5_125': 5.125,
    'IN_6_125': 6.125,
    'IN_7_125': 7.125,
    'IN_8_125': 8.125,
    'IN_9_125': 9.125,
    'IN_10_125': 10.125,
    'IN_11_125': 11.125,
}

# Explicit enum numbers: files save the item NUMBER, not the identifier,
# and under the old 4-preset list CUSTOM saved as 4 (every box migrated
# from the uniform-height era carries it). Keeping CUSTOM pinned at 4 and
# numbering the size presets from 5 up means those boxes still read as
# Custom; boxes saved on a removed old size preset fall back to the
# default label while keeping their real height in `height`.
ROLLOUT_HEIGHT_PRESET_ITEMS = [
    ('IN_3_125',  '3 1/8"',  'Standard 3 1/8" rollout box height', 5),
    ('IN_3_625',  '3 5/8"',  'Standard 3 5/8" rollout box height', 6),
    ('IN_4_125',  '4 1/8"',  'Standard 4 1/8" rollout box height', 7),
    ('IN_5_125',  '5 1/8"',  'Standard 5 1/8" rollout box height', 8),
    ('IN_6_125',  '6 1/8"',  'Standard 6 1/8" rollout box height', 9),
    ('IN_7_125',  '7 1/8"',  'Standard 7 1/8" rollout box height', 10),
    ('IN_8_125',  '8 1/8"',  'Standard 8 1/8" rollout box height', 11),
    ('IN_9_125',  '9 1/8"',  'Standard 9 1/8" rollout box height', 12),
    ('IN_10_125', '10 1/8"', 'Standard 10 1/8" rollout box height', 13),
    ('IN_11_125', '11 1/8"', 'Standard 11 1/8" rollout box height', 14),
    ('CUSTOM',    'Custom',  'Type an exact box height in the field beside it', 4),
]


def rollout_height_preset_for(height):
    """Return the preset id whose standard height matches `height` within
    half a millimeter, or 'CUSTOM' when no standard size matches. Lets
    boxes seeded from a stored plain height land on the matching preset
    instead of always reading as Custom."""
    for key, inches in _ROLLOUT_HEIGHT_PRESETS_IN.items():
        if abs(height - units.inch(inches)) < 0.0005:
            return key
    return 'CUSTOM'


def _update_rollout_box_preset(self, context):
    """A rollout box's preset writes its inch value into the box's height
    (the field the solver reads when stacking boxes); CUSTOM leaves height
    alone for a typed value. The inner write is suspended so it coalesces
    into the one recalc below.
    """
    from . import types_face_frame
    inches = _ROLLOUT_HEIGHT_PRESETS_IN.get(self.height_preset)
    with types_face_frame.suspend_recalc():
        if inches is not None:
            self.height = units.inch(inches)
    _update_cabinet_dim(self, context)


def _update_galley_size(self, context):
    """A workstation cabinet's size: width and bay widths follow it."""
    from . import types_face_frame
    types_face_frame.apply_galley_size(self.id_data)


def _update_refrigerator_opening_height(self, context):
    """Per-cabinet refrigerator opening height.

    Drives the bottom APPLIANCE opening node (SIZE_ROLE == 'REFRIGERATOR')
    and keeps back_bottom_inset in sync so the carcass back keeps spanning
    only the door zone above the opening (kick + opening + rail - mt,
    mirroring the create-time formula). The rail term is the cabinet's
    BOTTOM rail: the fridge cabinet's bays carry remove_bottom, so the
    appliance opening runs open to the kick and the member capping it is
    built as the bay's bottom rail rather than a mid rail. Batched under
    suspend_recalc so the inset + node-size writes collapse into one
    recalc.
    """
    from . import types_face_frame
    cab_obj = self.id_data
    value = self.refrigerator_opening_height
    with types_face_frame.suspend_recalc():
        self.back_bottom_inset = (
            self.toe_kick_height
            + value
            + self.bottom_rail_width
            - self.material_thickness
        )
        for child in cab_obj.children_recursive:
            if child.get('SIZE_ROLE') == 'REFRIGERATOR':
                op = child.face_frame_opening
                op.unlock_size = True
                op.size = value


def _update_opening_size(self, context):
    """Update callback for Face_Frame_Opening_Props.size.

    Any opening size edit recalcs like a cabinet dimension. Editing the
    refrigerator APPLIANCE opening's size directly (opening dialog or a
    dimension edit) additionally routes through the cabinet-level
    refrigerator_opening_height, whose update owns the derived state:
    back_bottom_inset (the carcass back spanning only the door zone)
    and the Raise Side Up anchor both read that prop. Skipped for
    redistribution system writes and for echo writes of the same value,
    so the two callbacks settle instead of ping-ponging.
    """
    from . import types_face_frame
    obj = self.id_data
    if obj.get('SIZE_ROLE') == 'REFRIGERATOR':
        root = types_face_frame.find_cabinet_root(obj)
        if (root is not None
                and root.get('CLASS_NAME') == 'RefrigeratorCabinet'
                and id(root) not in types_face_frame._DISTRIBUTING_WIDTHS):
            cab = root.face_frame_cabinet
            if abs(cab.refrigerator_opening_height - self.size) > 1e-6:
                cab.refrigerator_opening_height = self.size
                return  # its update already ran the recalc
    _update_cabinet_dim(self, context)


def _update_remove_bottom(self, context):
    """Update callback for a bay's remove_bottom toggle.

    Removing the bottom rail makes the opening grow down into the rail's
    space (see solver.effective_bottom_rail_width). The door that sat on
    that rail then has no rail to overlay, so we default it flush:
    unlock the opening's bottom overlay and set it to 0. The value stays
    editable - the user can dial in a bottom overlay afterwards in the
    opening properties and it will be honored (unlocked wins over the
    cabinet default). Restoring the rail re-locks the override so the
    bottom overlay follows the cabinet default again.

    The affected openings are the bay's bottom-perimeter leaves: the
    lowest opening of an H-split, or every opening of a V-split. They are
    identified geometrically as the leaves at the lowest bay-local cage Z,
    which holds regardless of split layout.
    """
    from . import types_face_frame, solver_face_frame
    bay_obj = self.id_data
    bi = bay_obj.get('hb_bay_index')
    removing = self.remove_bottom
    # One suspend so the overlay writes + the dimension recalc coalesce
    # into a single cabinet recalc when this callback returns.
    with types_face_frame.suspend_recalc():
        root = types_face_frame.find_cabinet_root(bay_obj)
        if root is not None and bi is not None:
            layout = solver_face_frame.FaceFrameLayout(root)
            leaves = solver_face_frame.bay_openings(layout, bi).get('leaves', [])
            if leaves:
                min_z = min(lf['cage_z'] for lf in leaves)
                for lf in leaves:
                    if abs(lf['cage_z'] - min_z) > 1e-5:
                        continue  # not a bottom-perimeter opening
                    opening = bpy.data.objects.get(lf['obj_name'])
                    if opening is None:
                        continue
                    op = opening.face_frame_opening
                    if removing:
                        op.unlock_bottom_overlay = True
                        op.bottom_overlay = 0.0
                    else:
                        op.unlock_bottom_overlay = False
            # A user-sized mid rail about to be promoted to the bay's
            # bottom rail (see _walk_tree's remove_bottom
            # reclassification) keeps its width: migrate the per-member
            # override into bottom_rail_width so the promoted rail and
            # its role-based width UI agree. The prior bottom-rail
            # values are stashed on the bay object and restored when
            # the rail comes back.
            tree = (layout.bays[bi].get('tree')
                    if bi < len(layout.bays) else None)
            if removing:
                if (tree and tree.get('kind') == 'split'
                        and tree.get('axis') == 'H'):
                    children = tree.get('children') or []
                    n_split = len(children) - 1
                    removes = tree.get('splitter_removes') or []
                    frontless = solver_face_frame._FRONTLESS_FRONT_TYPES
                    if (n_split >= 1
                            and children[-1].get('kind') == 'leaf'
                            and children[-1].get('front_type') in frontless
                            and not (len(removes) == n_split
                                     and removes[n_split - 1])):
                        split_obj = bpy.data.objects.get(
                            tree.get('obj_name') or '')
                        coll = (split_obj.face_frame_split.splitter_widths
                                if split_obj is not None else [])
                        idx = n_split - 1
                        if idx < len(coll) and coll[idx].active:
                            bay_obj['hb_pre_remove_bottom_rail'] = [
                                self.bottom_rail_width,
                                1.0 if self.unlock_bottom_rail else 0.0,
                            ]
                            self.unlock_bottom_rail = True
                            self.bottom_rail_width = coll[idx].width
            else:
                stash = bay_obj.get('hb_pre_remove_bottom_rail')
                if stash is not None and len(stash) == 2:
                    self.bottom_rail_width = stash[0]
                    self.unlock_bottom_rail = bool(stash[1])
                    del bay_obj['hb_pre_remove_bottom_rail']
        # Always recalc - even when there were no openings to adjust the
        # rail removal still changes the carcass / face frame.
        types_face_frame.recalculate_face_frame_cabinet(bay_obj)


# When the user edits a finished-end-condition enum from the UI, flip the
# matching auto flag off so subsequent exposure recalcs don't clobber the
# choice. Exposure recalc re-arms auto explicitly after writing its own
# value, so its own writes don't permanently disable auto.
def _restore_scribe_on_unfinished(self, side):
    """Manually switching a side back to UNFINISHED restores its scribe.
    The finished state zeroed the scribe (non-UNFINISHED types carry
    none), and pinning the side (auto off) meant nothing ever put it
    back -- the user had to re-type 0.5" every time a placed-in
    finished end was removed (islands especially). Re-resolve from the
    side's live exposure facts (wall edge 0.5", neighbor / dishwasher
    0.25"); an EXPOSED side -- the usual case, that's why it came in
    finished -- falls back to the scene's Default Scribe (0.5"). A
    nonzero scribe is a prior manual overwrite and is left alone.
    """
    if getattr(self, f'{side}_finished_end_condition') != 'UNFINISHED':
        return
    if getattr(self, f'{side}_scribe') > 1e-9:
        return
    from . import exposure
    cab_obj = self.id_data
    if not cab_obj or not cab_obj.get('IS_FACE_FRAME_CABINET_CAGE'):
        return
    try:
        state, dishwasher, wall_edge = exposure._side_exposure(cab_obj, side)
        scribe = exposure._resolve_scribe(state, dishwasher, wall_edge,
                                          'UNFINISHED')
    except Exception:
        scribe = 0.0
    if scribe <= 0.0:
        scene = bpy.context.scene
        props = getattr(scene, 'hb_face_frame', None)
        scribe = getattr(props, 'default_scribe', 0.0) or units.inch(0.5)
    setattr(self, f'{side}_scribe', scribe)


def _on_left_finish_end_user_set(self, context):
    self.left_finish_end_auto = False
    _restore_scribe_on_unfinished(self, 'left')
    _update_cabinet_dim(self, context)


def _on_right_finish_end_user_set(self, context):
    self.right_finish_end_auto = False
    _restore_scribe_on_unfinished(self, 'right')
    _update_cabinet_dim(self, context)


def _on_back_finish_end_user_set(self, context):
    self.back_finish_end_auto = False
    _update_cabinet_dim(self, context)


# Scribe edits also flip the side's auto flag off. The single auto flag
# governs both finish type and scribe so the user's mental model stays
# "this side is auto-managed" or not - touching either auto-managed
# value pins it.
def _on_left_scribe_user_set(self, context):
    self.left_finish_end_auto = False
    _update_cabinet_dim(self, context)


def _on_right_scribe_user_set(self, context):
    self.right_finish_end_auto = False
    _update_cabinet_dim(self, context)

def _update_front_type(self, context):
    """Front-type write hook: when a user picks DOOR, ensure the opening
    carries an ADJUSTABLE_SHELF interior item. If the user later removes
    the shelves manually, switching front_type away and back to DOOR
    re-adds them; switching to any other front_type leaves the
    interior_items collection untouched.
    """
    if self.front_type == 'DOOR':
        has_shelves = any(
            item.kind in ('ADJUSTABLE_SHELF', 'HALF_DEPTH_SHELF',
                          'QUARTER_DEPTH_SHELF')
            for item in self.interior_items
        )
        if not has_shelves:
            # .add() picks up the EnumProperty default ('ADJUSTABLE_SHELF')
            # without firing the kind update. Quantity is left at the
            # IntProperty default (1) and gets recomputed by the recalc
            # below since unlock_shelf_qty defaults to False.
            self.interior_items.add()
    _update_cabinet_dim(self, context)


def _update_bay_width(self, context):
    """Update callback for Face_Frame_Bay_Props.width.

    Distinguishes user edits from system writes:
    - System writes (during the cabinet's _distribute_bay_widths) are
      bracketed by _DISTRIBUTING_WIDTHS. We exit immediately for those.
    - User edits flip unlock_width=True so the new width holds during
      future redistributions, then trigger a recalc. Setting unlock_width
      itself fires _update_cabinet_dim which runs the recalc, so we don't
      need to call it again here.
    """
    from . import types_face_frame
    root = types_face_frame.find_cabinet_root(self.id_data)
    if root is None:
        return
    if id(root) in types_face_frame._DISTRIBUTING_WIDTHS:
        return  # system write - skip auto-lock and skip recalc
    # User edit
    if not self.unlock_width:
        # Auto-lock. Setting unlock_width fires _update_cabinet_dim
        # which triggers recalc, so we don't call recalc directly here.
        self.unlock_width = True
    else:
        # Already locked - user is just nudging the value. Run recalc
        # so other unlocked bays redistribute around the new locked value.
        types_face_frame.recalculate_face_frame_cabinet(self.id_data)


def _update_interior_size(self, context):
    """Auto-lock-on-edit for interior tree node sizes (region or split).

    Mirrors _update_bay_width: distinguishes user edits from the
    redistribution pass by checking the _DISTRIBUTING_WIDTHS guard.
    User edits flip unlock_size=True so the new size holds during
    future redistributions; that flip itself fires _update_cabinet_dim
    which runs the recalc, so we don't call recalc directly here.
    """
    from . import types_face_frame
    root = types_face_frame.find_cabinet_root(self.id_data)
    if root is None:
        return
    if id(root) in types_face_frame._DISTRIBUTING_WIDTHS:
        return  # system write - skip auto-lock and skip recalc
    if not self.unlock_size:
        self.unlock_size = True
    else:
        types_face_frame.recalculate_face_frame_cabinet(self.id_data)


def _update_bay_kick_height(self, context):
    """Auto-lock-on-edit for Face_Frame_Bay_Props.kick_height.

    Mirrors _update_bay_width. Without this, _distribute_bay_kick_heights
    overwrites the user's edit on the recalc that fires from the prop
    update, because unlock_kick_height is still False at that point.
    Reuses _DISTRIBUTING_WIDTHS as the system-write guard since recalc
    already adds the cabinet id to it for the entire body.
    """
    from . import types_face_frame
    root = types_face_frame.find_cabinet_root(self.id_data)
    if root is None:
        return
    if id(root) in types_face_frame._DISTRIBUTING_WIDTHS:
        return  # system write - skip auto-lock and skip recalc
    if not self.unlock_kick_height:
        self.unlock_kick_height = True
    else:
        types_face_frame.recalculate_face_frame_cabinet(self.id_data)


class Face_Frame_Panel_Row_Height(PropertyGroup):
    """Opening height of one row of an applied panel with a manual row
    count (panel_horizontal_rows > 0). Lives in a CollectionProperty on
    Face_Frame_Cabinet_Props; index 0 is the BOTTOM row (the dialog
    lists them top-down). Rows without the override flag auto-calculate
    to an equal share of the remaining space (the builder writes the
    computed value back so the field displays it); flagged rows hold
    their typed height. Each entry also carries the mid rail ABOVE its
    row: auto follows the panel's default mid rail width, the rail
    override holds a typed width for that one rail."""
    height: FloatProperty(
        name="Row Height",
        default=units.inch(12.0), min=units.inch(1.0),
        unit='LENGTH', precision=4,
        update=_update_panel_split_auto,
    )  # type: ignore
    override: BoolProperty(
        name="Set Height",
        description="Hold this row at the typed height; unchecked rows "
                    "share the remaining space equally",
        default=False,
        update=_update_panel_split_auto,
    )  # type: ignore
    rail_width: FloatProperty(
        name="Rail Width",
        description="Width of the mid rail above this row",
        default=units.inch(1.5), min=units.inch(0.5),
        unit='LENGTH', precision=4,
        update=_update_panel_split_auto,
    )  # type: ignore
    rail_override: BoolProperty(
        name="Set Rail Width",
        description="Hold this mid rail at the typed width; unchecked "
                    "rails follow the default mid rail width",
        default=False,
        update=_update_panel_split_auto,
    )  # type: ignore


class Face_Frame_Panel_Col_Width(PropertyGroup):
    """Opening width of one column of an applied panel, left to right.
    Same auto/override model as the row heights: unchecked columns
    share the remaining width equally, flagged ones hold."""
    width: FloatProperty(
        name="Column Width",
        default=units.inch(12.0), min=units.inch(1.0),
        unit='LENGTH', precision=4,
        update=_update_panel_split_auto,
    )  # type: ignore
    override: BoolProperty(
        name="Set Width",
        description="Hold this column at the typed width; unchecked "
                    "columns share the remaining width equally",
        default=False,
        update=_update_panel_split_auto,
    )  # type: ignore


class Face_Frame_Mid_Stile_Width(PropertyGroup):
    """Width of the mid stile that sits between two adjacent bays.

    Lives in a CollectionProperty on Face_Frame_Cabinet_Props.
    Index N is the mid stile between bay N and bay N+1.
    """
    width: FloatProperty(
        name="Width",
        default=units.inch(2.0),
        unit='LENGTH',
        precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    unlock: BoolProperty(
        name="Unlock",
        description="Hold this mid stile width independent of cabinet defaults",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    extend_up_amount: FloatProperty(
        name="Extend Up Amount",
        default=0.0,
        unit='LENGTH',
        precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    extend_down_amount: FloatProperty(
        name="Extend Down Amount",
        default=0.0,
        unit='LENGTH',
        precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    to_floor: BoolProperty(
        name="Stile to Floor",
        default=False,
        description="Extend this mid stile past the toe kick down to the "
                    "floor (pins its bottom to Z=0, like an end stile)",
        update=_update_cabinet_dim,
    )  # type: ignore

    # Where the carcass division sits under this stile. CENTERED keeps the
    # historical behavior (division centered on the stile). FLUSH_LEFT /
    # FLUSH_RIGHT pin the division's outer face to that edge of the stile
    # and re-track if the stile width or division thickness changes.
    # OFFSET uses the typed division_offset, measured from the stile
    # centerline (the interior analog of the side scribe amount).
    division_location: EnumProperty(
        name="Division Location",
        items=[
            ('CENTERED', "Centered", "Division centered on the mid stile"),
            ('FLUSH_LEFT', "Flush Left", "Division's left face flush with the stile's left edge"),
            ('FLUSH_RIGHT', "Flush Right", "Division's right face flush with the stile's right edge"),
            ('OFFSET', "Offset", "Signed offset from the stile centerline (+ = toward the right bay)"),
        ],
        default='CENTERED',
        update=_update_cabinet_dim,
    )  # type: ignore

    division_offset: FloatProperty(
        name="Division Offset",
        description="Signed shift of the carcass division off the stile "
                    "centerline (negative = toward the left bay)",
        default=0.0,
        unit='LENGTH',
        precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore


class Face_Frame_Cabinet_Column(PropertyGroup):
    """One cabinet column applied over a face frame stile: a split
    turning (end blocks, spools, styled shaft) standing proud of the
    frame face. Lives in a CollectionProperty on
    Face_Frame_Cabinet_Props keyed by stile_key; edited via the
    Cabinet Column dialog on the stile's right-click menu. No update
    callbacks - the operator runs one recalc after writing the entry
    (see cabinet_column.py and types_face_frame._apply_cabinet_columns).
    """
    stile_key: StringProperty(
        name="Stile Key",
        description="Which stile carries this column: LEFT, RIGHT, or "
                    "MID_<gap index>",
    )  # type: ignore
    style: EnumProperty(
        name="Column Style",
        items=cabinet_column.STYLE_ITEMS,
        default='SMOOTH',
    )  # type: ignore
    size: EnumProperty(
        name="Column Size",
        items=cabinet_column.SIZE_ITEMS,
        default='LARGE',
    )  # type: ignore
    top_block: BoolProperty(
        name="Top End Block", default=True,
    )  # type: ignore
    top_block_height: FloatProperty(
        name="Top Block Height", default=0.0,
        unit='LENGTH', precision=4, min=0.0,
        description="0 = default (1\" taller than the top rail)",
    )  # type: ignore
    bottom_block: BoolProperty(
        name="Bottom End Block", default=True,
    )  # type: ignore
    bottom_block_height: FloatProperty(
        name="Bottom Block Height", default=0.0,
        unit='LENGTH', precision=4, min=0.0,
        description="0 = default (1\" taller than the top rail, like "
                    "the top block)",
    )  # type: ignore
    # Width the stile was opened up to when the column was set, so
    # removing the column can put it back (only if it still holds
    # that width). 0 = the stile was left alone.
    stile_width: FloatProperty(
        name="Stile Width", default=0.0,
        unit='LENGTH', precision=4, min=0.0,
    )  # type: ignore
    floor_block: BoolProperty(
        name="Bottom Block at Floor", default=False,
        description="Plain plinth block at the floor (for a flush kick "
                    "or a stile extended to the floor)",
    )  # type: ignore
    floor_block_height: FloatProperty(
        name="Floor Block Height", default=0.0,
        unit='LENGTH', precision=4, min=0.0,
        description="0 = default (fills the kick recess, or 4\" on a "
                    "flush kick)",
    )  # type: ignore


# ---------------------------------------------------------------------------
# Corner cabinet exterior configuration
# ---------------------------------------------------------------------------
class Face_Frame_Corner_Section(PropertyGroup):
    """One stacked section of a diagonal corner cabinet's front.

    Lives in a CollectionProperty on Face_Frame_Cabinet_Props, ordered
    top to bottom. content is fixed by the chosen exterior_config preset;
    the user only adjusts heights. A section's height is auto - an equal
    share of the leftover space - unless unlock_height is on, mirroring
    the bay-width / mid-stile lock pattern.
    """
    content: EnumProperty(
        name="Content",
        items=[
            ('DOORS',       "Doors",       "Double-door pair"),
            ('FALSE_FRONT', "False Front", "Fixed false front panel"),
            ('OPEN',        "Open",        "Open section with shelves"),
            ('GARAGE',      "Appliance Garage",
             "Appliance garage section reaching the countertop (doors, "
             "no shelves)"),
        ],
        default='DOORS',
    )  # type: ignore
    height: FloatProperty(
        name="Section Height",
        description="Opening height of this section (used when Unlock Height is on)",
        default=units.inch(12.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_height: BoolProperty(
        name="Unlock Height",
        description="Hold this section's height; the other sections share the leftover space equally",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    shelf_qty: IntProperty(
        name="Shelf Qty",
        description="Number of adjustable shelves in this section",
        default=2, min=0, max=10,
        update=_update_cabinet_dim,
    )  # type: ignore
    # DOORS sections on upper corner cabinets auto-count their shelves
    # by section height (synced into shelf_qty each recalc so the UI
    # shows the live count). Unlock to override with a manual count.
    # OPEN sections are unaffected -- their shelf_qty has always been
    # fully manual and stays that way.
    unlock_shelf_qty: BoolProperty(
        name="Unlock Shelf Qty",
        description="Override the auto shelf count for this door section",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-section door overlay overrides. Corner cabinets have no
    # opening cages, so the standard per-opening overlay unlocks don't
    # exist here; these mirror that pattern at section level (locked =
    # cabinet default, unlocked = this value). Lets e.g. a corner
    # upper's door grow extra bottom overlay to cover a light rail.
    top_overlay: FloatProperty(
        name="Top Overlay",
        description="This section's door top overlay (used when unlocked)",
        default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_top_overlay: BoolProperty(
        name="Unlock Top Overlay",
        description="Override the cabinet's top overlay for this section",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    bottom_overlay: FloatProperty(
        name="Bottom Overlay",
        description="This section's door bottom overlay (used when unlocked)",
        default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_bottom_overlay: BoolProperty(
        name="Unlock Bottom Overlay",
        description="Override the cabinet's bottom overlay for this section",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # GARAGE sections: which appliance-garage door option fills the
    # diagonal opening (per the diagonal-corner appliance garage
    # catalog page). Hinged singles / doubles are the base options;
    # tambour / retracting / swing-up are adders. The side doors are a
    # separate adder (garage_side_doors below) that combines with any
    # of these - including OPEN, which leaves the diagonal as a
    # finished opening.
    garage_door_type: EnumProperty(
        name="Garage Door",
        items=[
            ('DOUBLE', "Double Hinged Door",
             "Hinged door pair on the diagonal opening"),
            ('SINGLE_LEFT', "Single Hinged Door (Hinge Left)",
             "One full-width door hinged on the left"),
            ('SINGLE_RIGHT', "Single Hinged Door (Hinge Right)",
             "One full-width door hinged on the right"),
            ('TAMBOUR', "Tambour Door",
             "Slatted roll-up door inside the opening"),
            ('RETRACTING', "Top Mounted Retracting Door",
             "Full-width door that retracts up into the cabinet"),
            ('SWING_UP', "Swing-Up Door",
             "Full-width door that swings up on lift hardware"),
            ('OPEN', "Open (No Door)",
             "Leave the diagonal garage opening open"),
        ],
        default='DOUBLE',
        update=_update_cabinet_dim,
    )  # type: ignore
    # Hinged Doors on Sides adder: a hinged door on each arm end face,
    # independent of what fills the diagonal opening.
    garage_side_doors: BoolProperty(
        name="Hinged Doors on Sides",
        description="Add a hinged door on each side face of the "
                    "garage, in addition to the garage door option",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-section vertical pull placement (right-click a corner door ->
    # Set Pull Location...). Corner cabinets have no opening cages, so
    # this mirrors the per-opening pull_location_override at section
    # level, exactly like the overlay unlocks above. Same items and same
    # meaning; the corner recalc feeds it to the shared pull placement.
    pull_location_override: EnumProperty(
        name="Pull Location",
        items=[
            ('AUTO', "Automatic", "Cabinet-type rule (base: top, upper: bottom, tall: by door height)"),
            ('TOP', "Top of Door", "Base-style: measured down from the top of the door"),
            ('MIDDLE', "Middle of Door", "Centered on the door height"),
            ('BOTTOM', "Bottom of Door", "Upper-style: measured up from the bottom of the door"),
            ('TALL', "Tall Reach Height", "Tall-style: the tall vertical offset up from the door bottom"),
        ],
        default='AUTO',
        update=_update_cabinet_dim,
    )  # type: ignore


# exterior_config items vary by cabinet type. Module-level lists keep the
# string references alive - a dynamic EnumProperty items callback that
# rebuilt fresh tuples each call would risk them being garbage collected.
_EXTERIOR_CONFIG_ITEMS = {
    'BASE': [
        ('DOORS',             "Full Height Doors",      "One full-height door pair"),
        ('FALSE_FRONT_DOORS', "False Front with Doors", "False front above a door pair"),
        # Corner sink configs. Geometry matches the two plain configs;
        # the config choice drives the SINK plan annotation and the
        # apron (SINK_DOORS builds a real apron panel behind the
        # full-height doors).
        ('SINK', "Sink (False Front with Doors)",
         "Corner sink: false front above the doors"),
        ('SINK_DOORS', "Sink with Full Height Doors",
         "Corner sink: full-height doors with a sink apron behind"),
    ],
    'UPPER': [
        ('DOORS',         "Doors",             "One door pair"),
        ('STACKED_DOORS', "Stacked Doors",     "Two stacked door pairs"),
        ('HUTCH',         "Hutch",             "Doors on top, open below"),
        ('OPEN_SHELVES',  "Open with Shelves", "Open shelf section"),
        ('DOORS_GARAGE',  "Doors + Appliance Garage",
         "Door pair above an appliance garage; the cabinet extends down "
         "to the countertop"),
    ],
    'TALL': [
        ('HUTCH',    "Hutch",    "Upper doors, open middle, base doors"),
        ('BOOKCASE', "Bookcase", "Open shelves on top, base doors below"),
    ],
}


# Pie cut exterior configs. Pie cut has two face frames (one per arm);
# a config splits both arms together. Base pie cut is full-height door
# only; upper pie cut adds a two-section stacked option.
_PIE_CUT_CONFIG_ITEMS = {
    'BASE': [
        ('DOORS', "Full Height Doors", "One full-height door per arm"),
    ],
    'UPPER': [
        ('DOORS',         "Full Height Doors", "One full-height door per arm"),
        ('STACKED_DOORS', "Stacked Doors",     "Two stacked doors per arm"),
        ('DOORS_GARAGE',  "Doors + Appliance Garage",
         "Doors above an appliance garage; the cabinet extends down to "
         "the countertop"),
    ],
}


def _exterior_config_items(self, context):
    """Dynamic items for exterior_config, filtered by corner type and
    cabinet type. Pie cut and diagonal offer different config sets."""
    obj = self.id_data
    ctype = obj.get('CABINET_TYPE', 'BASE') if obj is not None else 'BASE'
    if self.corner_type == 'PIE_CUT':
        return _PIE_CUT_CONFIG_ITEMS.get(ctype, _PIE_CUT_CONFIG_ITEMS['BASE'])
    return _EXTERIOR_CONFIG_ITEMS.get(ctype, _EXTERIOR_CONFIG_ITEMS['BASE'])


# (cabinet_type, exterior_config) -> ordered tuple of section content kinds,
# top to bottom. The preset fixes section count and content; section
# heights stay user-adjustable (see Face_Frame_Corner_Section).
_CORNER_SECTION_PRESETS = {
    ('BASE',  'DOORS'):             ('DOORS',),
    ('BASE',  'FALSE_FRONT_DOORS'): ('FALSE_FRONT', 'DOORS'),
    ('BASE',  'SINK'):              ('FALSE_FRONT', 'DOORS'),
    ('BASE',  'SINK_DOORS'):        ('DOORS',),
    ('UPPER', 'DOORS'):             ('DOORS',),
    ('UPPER', 'STACKED_DOORS'):     ('DOORS', 'DOORS'),
    ('UPPER', 'DOORS_GARAGE'):      ('DOORS', 'GARAGE'),
    ('UPPER', 'HUTCH'):             ('DOORS', 'OPEN'),
    ('UPPER', 'OPEN_SHELVES'):      ('OPEN',),
    ('TALL',  'HUTCH'):             ('DOORS', 'OPEN', 'DOORS'),
    ('TALL',  'BOOKCASE'):          ('OPEN', 'DOORS'),
}

# Optional per-section DEFAULT heights for a preset, ordered like the
# preset's content tuple (top to bottom). A non-None entry pins that
# section when the config is selected (height written + unlock_height
# on) so it starts at a sensible opening size instead of an equal
# share - e.g. the bookcase's bottom door opening at 24". Configs not
# listed (or None entries) keep the unlocked equal-share default. The
# sentinel 'TOP_DRAWER' resolves to the scene's
# hb_face_frame.top_drawer_opening_height at populate time (same size
# role the bay presets use), so the false front lines up with adjacent
# drawer fronts.
_CORNER_SECTION_DEFAULT_HEIGHTS = {
    ('TALL', 'BOOKCASE'): (None, units.inch(24.0)),
    ('BASE', 'FALSE_FRONT_DOORS'): ('TOP_DRAWER', None),
    ('BASE', 'SINK'): ('TOP_DRAWER', None),
}


def corner_section_contents(cab_props):
    """Section content tuple for the cabinet's current type and config,
    falling back to a single door section for unknown combinations."""
    obj = cab_props.id_data
    ctype = obj.get('CABINET_TYPE', 'BASE') if obj is not None else 'BASE'
    return _CORNER_SECTION_PRESETS.get(
        (ctype, cab_props.exterior_config), ('DOORS',))


def populate_corner_sections(cab_props):
    """Rebuild cab_props.corner_sections from the current exterior_config
    preset. Sections start unlocked (evenly spaced) unless the preset
    carries a default height for them in _CORNER_SECTION_DEFAULT_HEIGHTS,
    in which case the section is pinned to that height (e.g. the
    bookcase's bottom door opening at 24")."""
    contents = corner_section_contents(cab_props)
    obj = cab_props.id_data
    ctype = obj.get('CABINET_TYPE', 'BASE') if obj is not None else 'BASE'
    defaults = _CORNER_SECTION_DEFAULT_HEIGHTS.get(
        (ctype, cab_props.exterior_config), ())
    cab_props.corner_sections.clear()
    for i, content in enumerate(contents):
        sec = cab_props.corner_sections.add()
        sec.content = content
        h = defaults[i] if i < len(defaults) else None
        if h == 'TOP_DRAWER':
            # Scene-level size preference; None during first-load /
            # unregister when the scene props aren't attached yet.
            ff_scene = getattr(bpy.context.scene, 'hb_face_frame', None)
            h = (ff_scene.top_drawer_opening_height
                 if ff_scene is not None else None)
        if h is not None:
            # Unlock BEFORE writing the height: each write fires a
            # recalc, and the recalc's height-sync overwrites an
            # unlocked section's height with the solved share - so a
            # height written first would be clobbered before the
            # unlock landed.
            sec.unlock_height = True
            sec.height = h
        else:
            sec.unlock_height = False


def _sync_corner_garage_extension(cab_props):
    """Grow / shrink the cabinet for a GARAGE section. Entering a garage
    config extends the cabinet down to the countertop plane (base cabinet
    height + countertop thickness) and pins the garage section to the
    added extent (minus the new mid rail) so the section above keeps its
    opening; leaving the config reverts the stored extension. The extent
    is stored on the object so the revert is exact even if scene
    defaults changed in between."""
    obj = cab_props.id_data
    from . import types_face_frame
    has_garage = any(
        s.content == 'GARAGE' for s in cab_props.corner_sections)
    stored = obj.get('hb_garage_extension', 0.0)
    if has_garage and not stored:
        ff_scene = getattr(bpy.context.scene, 'hb_face_frame', None)
        if ff_scene is None:
            return
        counter_z = (ff_scene.base_cabinet_height
                     + ff_scene.countertop_thickness)
        ext = obj.location.z - counter_z
        if ext <= 0.0:
            return
        with types_face_frame.suspend_recalc():
            cab_props.height = cab_props.height + ext
            obj.location.z = counter_z
            for s in cab_props.corner_sections:
                if s.content == 'GARAGE':
                    s.unlock_height = True
                    s.height = max(
                        ext - cab_props.bay_mid_rail_width,
                        units.inch(4.0))
        obj['hb_garage_extension'] = ext
    elif not has_garage and stored:
        with types_face_frame.suspend_recalc():
            cab_props.height = cab_props.height - stored
            obj.location.z = obj.location.z + stored
        del obj['hb_garage_extension']


def _update_bay_appliance_garage(self, context):
    """Per-bay Appliance Garage toggle (uppers, incl. blind corners).

    ON: the CABINET extends down to the countertop plane (once, stored
    as hb_garage_extension on the root); every non-garage bay is locked
    at its pre-extension height so its bottom stays at the old mount,
    while this bay syncs to the full height and rebuilds as a stacked
    pair whose bottom opening pins to the extension (GARAGE_BOTTOM size
    role). OFF: the bay goes back to a raised standard bay; when the
    last garage bay turns off, the extension reverts exactly and every
    bay re-syncs to the cabinet height.
    """
    obj = self.id_data
    from . import types_face_frame
    from . import bay_presets
    from .operators import ops_cabinet
    root = types_face_frame.find_cabinet_root(obj)
    ff_scene = getattr(bpy.context.scene, 'hb_face_frame', None)
    if root is None or ff_scene is None:
        return
    cab = root.face_frame_cabinet
    bays = [c for c in root.children
            if c.get(types_face_frame.TAG_BAY_CAGE)]
    stored = root.get('hb_garage_extension', 0.0)

    if self.appliance_garage:
        if not stored:
            counter_z = (ff_scene.base_cabinet_height
                         + ff_scene.countertop_thickness)
            ext = root.location.z - counter_z
            if ext <= 0.0:
                return
            old_height = cab.height
            with types_face_frame.suspend_recalc():
                # Non-garage bays keep their bottom at the old mount:
                # lock each at the pre-extension height BEFORE the
                # cabinet grows (already-unlocked custom heights hold
                # on their own).
                for b in bays:
                    bp = b.face_frame_bay
                    if b is not obj and not bp.unlock_height:
                        bp.unlock_height = True
                        bp.height = old_height
                cab.height = cab.height + ext
                root.location.z = counter_z
            root['hb_garage_extension'] = ext
        # The garage bay itself spans the full (extended) height.
        with types_face_frame.suspend_recalc():
            self.unlock_height = False
            self.top_offset = 0.0
        cfg = ('DOUBLE_DOOR_GARAGE'
               if self.width > bay_presets.DOUBLE_DOOR_WIDTH_THRESHOLD
               else 'LEFT_DOOR_GARAGE')
        ops_cabinet.apply_bay_preset(obj, cfg)
    else:
        remaining = [b for b in bays
                     if b is not obj and b.face_frame_bay.appliance_garage]
        if stored and not remaining:
            # Last garage bay off: revert the extension and re-sync
            # every bay to the cabinet height (per-bay height
            # customizations reset).
            with types_face_frame.suspend_recalc():
                cab.height = cab.height - stored
                root.location.z = root.location.z + stored
                for b in bays:
                    b.face_frame_bay.unlock_height = False
            del root['hb_garage_extension']
        elif stored:
            # Other garage bays remain: this bay becomes a raised
            # standard bay at the pre-extension height.
            with types_face_frame.suspend_recalc():
                self.unlock_height = True
                self.height = max(cab.height - stored, units.inch(6.0))
                self.top_offset = 0.0
        cfg = ('DOUBLE_DOOR'
               if self.width > bay_presets.DOUBLE_DOOR_WIDTH_THRESHOLD
               else 'LEFT_SWING_DOOR')
        ops_cabinet.apply_bay_preset(obj, cfg)
    types_face_frame.recalculate_face_frame_cabinet(root)


# ---- Under-cabinet appliance: opening resize -------------------------
# Custom-prop keys on the bay cage holding what the opening looked like
# before an appliance shrank it, so clearing the appliance puts it back.
UCA_SAVED_HEIGHT = 'hb_uca_saved_height'
UCA_SAVED_UNLOCK_HEIGHT = 'hb_uca_saved_unlock_height'
UCA_SAVED_WIDTH = 'hb_uca_saved_width'
UCA_SAVED_UNLOCK_WIDTH = 'hb_uca_saved_unlock_width'
UCA_SAVED_CAB_WIDTH = 'hb_uca_saved_cab_width'
UCA_MIN_OPENING_HEIGHT = units.inch(6.0)


def _sync_under_cabinet_opening(bay_obj, root):
    """Resize this bay's opening around its under-cabinet appliance.

    The appliance takes the bottom of the bay's vertical space: the
    opening is raised by the appliance height, and since an upper's box
    anchors at the bay bottom the carcass and its sides come up with it,
    leaving the appliance hanging in the space they gave up.

    The appliance width does the same horizontally. On the only bay of a
    cabinet there is no neighbour to give up the space, so the CABINET
    takes the width (a 30" microwave wants a 30" upper); with neighbours
    the bay locks to the width and they redistribute around it. A width
    of 0 leaves the widths alone, which is the usual case for a hood -
    it is ordered to the cabinet, not the other way round.

    Everything changed here is saved on the bay first, so clearing the
    appliance restores the opening exactly. Re-runs recompute from the
    saved values, so editing the appliance size never compounds.
    """
    from . import types_face_frame
    bp = bay_obj.face_frame_bay
    cab = root.face_frame_cabinet
    if bp.under_cabinet_appliance == 'NONE':
        if UCA_SAVED_HEIGHT in bay_obj:
            bp.unlock_height = bool(bay_obj[UCA_SAVED_UNLOCK_HEIGHT])
            bp.height = bay_obj[UCA_SAVED_HEIGHT]
            del bay_obj[UCA_SAVED_HEIGHT]
            del bay_obj[UCA_SAVED_UNLOCK_HEIGHT]
        if UCA_SAVED_CAB_WIDTH in bay_obj:
            cab.width = bay_obj[UCA_SAVED_CAB_WIDTH]
            del bay_obj[UCA_SAVED_CAB_WIDTH]
        if UCA_SAVED_WIDTH in bay_obj:
            bp.unlock_width = bool(bay_obj[UCA_SAVED_UNLOCK_WIDTH])
            bp.width = bay_obj[UCA_SAVED_WIDTH]
            del bay_obj[UCA_SAVED_WIDTH]
            del bay_obj[UCA_SAVED_UNLOCK_WIDTH]
        return

    if UCA_SAVED_HEIGHT not in bay_obj:
        bay_obj[UCA_SAVED_HEIGHT] = bp.height
        bay_obj[UCA_SAVED_UNLOCK_HEIGHT] = bp.unlock_height
    # Unlock before writing the height: the write fires a recalc whose
    # height sync would otherwise put the bay straight back to the
    # cabinet height.
    bp.unlock_height = True
    bp.height = max(bay_obj[UCA_SAVED_HEIGHT] - bp.under_cabinet_appliance_height,
                    UCA_MIN_OPENING_HEIGHT)

    appl_width = bp.under_cabinet_appliance_width
    if appl_width <= 0.0:
        return
    bays = [c for c in root.children
            if c.get(types_face_frame.TAG_BAY_CAGE)]
    if len(bays) > 1:
        if UCA_SAVED_WIDTH not in bay_obj:
            bay_obj[UCA_SAVED_WIDTH] = bp.width
            bay_obj[UCA_SAVED_UNLOCK_WIDTH] = bp.unlock_width
        bp.unlock_width = True
        bp.width = appl_width
    elif (cab.corner_type == 'NONE'
          and not cab.unlock_left_depth and not cab.unlock_right_depth):
        # Single square bay: the cabinet is the opening's width, so it
        # resizes instead. (An angled single bay sizes its opening off
        # the hypotenuse - left alone rather than guessed at.)
        if UCA_SAVED_CAB_WIDTH not in bay_obj:
            bay_obj[UCA_SAVED_CAB_WIDTH] = cab.width
        cab.width = appl_width


def _appliance_finish_enum_items(self, context):
    # Deferred import, and a module-level list so Blender keeps the
    # item strings alive (same reasoning as the pull finish items).
    from . import pulls
    return pulls.APPLIANCE_FINISHES


def _update_under_cabinet_appliance(self, context):
    """The appliance under this bay, or its width / height, changed:
    resize the bay's opening around it, then recalc."""
    from . import types_face_frame
    obj = self.id_data
    root = types_face_frame.find_cabinet_root(obj)
    if root is None:
        return
    if root.face_frame_cabinet.cabinet_type == 'UPPER':
        with types_face_frame.suspend_recalc():
            _sync_under_cabinet_opening(obj, root)
    types_face_frame.recalculate_face_frame_cabinet(root)


def _update_exterior_config(self, context):
    """exterior_config changed: repopulate the section collection from the
    new preset, sync the garage extension, then recalc."""
    populate_corner_sections(self)
    _sync_corner_garage_extension(self)
    from . import types_face_frame
    types_face_frame.recalculate_face_frame_cabinet(self.id_data)


def populate_pie_drawer_sections(cab_props):
    """Rebuild corner_sections for a pie-cut drawer corner to match
    pie_drawer_qty - one stacked DOORS section per drawer (rendered as drawer
    fronts). For 3+ drawer stacks the TOP opening is pinned to the scene's
    Top Drawer Opening Height by default (mirroring the base drawer presets);
    the remaining sections share the leftover space equally. The user can then
    lock / set any section's height in the Sections box.
    """
    qty = cab_props.pie_drawer_qty
    secs = cab_props.corner_sections
    secs.clear()
    for _ in range(qty):
        secs.add().content = 'DOORS'
    if qty >= 3:
        ff_scene = getattr(bpy.context.scene, 'hb_face_frame', None)
        if ff_scene is not None:
            # Unlock BEFORE writing the height (same ordering reason as
            # populate_corner_sections: each write fires a recalc whose
            # height-sync would clobber an unlocked section's height).
            secs[0].unlock_height = True
            secs[0].height = ff_scene.top_drawer_opening_height


def _update_pie_drawer_qty(self, context):
    """pie_drawer_qty changed: repopulate the stacked drawer sections, then
    recalc. Only repopulates on a pie-cut drawer corner."""
    if self.corner_type == 'PIE_CUT_DRAWER':
        populate_pie_drawer_sections(self)
    from . import types_face_frame
    types_face_frame.recalculate_face_frame_cabinet(self.id_data)


def _style_stile_width_for(cab_props, stile_type):
    """Per-(row, column) stile width from the cabinet's assigned style, or
    None if it can't be resolved. Lets a width-only joint stile type take its
    value from the style's row for that type + the cabinet's column."""
    cabinet_obj = cab_props.id_data
    style_name = cabinet_obj.get('STYLE_NAME') if cabinet_obj else None
    if not style_name:
        return None
    try:
        ff = get_style_props()
    except Exception:
        return None
    style = next((cs for cs in ff.cabinet_styles if cs.name == style_name), None)
    if style is None:
        return None
    row = style._STILE_TYPE_TO_ROW.get(stile_type, 'end_stile')
    col = style._CABINET_TYPE_COLUMN.get(cab_props.cabinet_type, 'base')
    return getattr(style, f"ff_{row}_width_{col}", None)


def _recompute_blind_stile_width(cab_props, side):
    """Set left_stile_width or right_stile_width from the current stile-type
    and blind-state combination. No-op when the side's unlock flag is True
    (user has taken manual control) or when the scene doesn't carry the
    face frame defaults yet (during first-load / unregister).

    Coupling: stile_type=='BLIND' uses the style's per-type Blind Stile row
    (upper 2" / base + tall 3" by default), falling back to the scene's
    ff_blind_stile_width; the blind_left/blind_right flag adds 0.75" for
    the adjacent cabinet's face. stile_type=='STANDARD' or 'WALL' restores
    the plain ff_end_stile_width default.
    """
    scene = bpy.context.scene
    ff_scene = getattr(scene, 'hb_face_frame', None)
    if ff_scene is None:
        return

    if side == 'LEFT':
        if cab_props.unlock_left_stile:
            return
        stile_type = cab_props.left_stile_type
        is_blind = cab_props.blind_left
        target_attr = 'left_stile_width'
    else:
        if cab_props.unlock_right_stile:
            return
        stile_type = cab_props.right_stile_type
        is_blind = cab_props.blind_right
        target_attr = 'right_stile_width'

    if stile_type == 'BLIND':
        # Per-type width from the cabinet's style row (upper inside
        # corners take a narrower stile than base / tall per the
        # catalog); the scene-level single value stays the fallback for
        # an unstyled cabinet.
        width = _style_stile_width_for(cab_props, 'BLIND')
        if width is None:
            width = ff_scene.ff_blind_stile_width
        # +0.75" for the portion tucked behind the adjacent cabinet's
        # face, keeping the EXPOSED amount at the entered width. True
        # for a void blind side (blind flag on) AND a match-depth corner
        # (flag off, but the HB_BLIND_VOID_* marker names this side as
        # the corner's void owner). The PLACED cabinet's corner stile is
        # also typed BLIND but tucks behind nothing -- no marker, no
        # flag, no add.
        marker = ('HB_BLIND_VOID_LEFT' if side == 'LEFT'
                  else 'HB_BLIND_VOID_RIGHT')
        if is_blind or marker in cab_props.id_data:
            width += units.inch(0.75)
    elif stile_type in ('WALL', 'BUTT', 'INSIDE_90', 'ANGLE'):
        # Width-only types (incl. WALL): take the style's per-row/column value.
        width = _style_stile_width_for(cab_props, stile_type)
        if width is None:
            return
    else:
        width = ff_scene.ff_end_stile_width

    # Only write if the value actually changed - avoids a redundant
    # _update_cabinet_dim recalc trip in the common case where the user
    # toggles a flag that doesn't change the resulting width.
    if abs(getattr(cab_props, target_attr) - width) > 1e-7:
        setattr(cab_props, target_attr, width)


def _update_left_stile_type(self, context):
    _recompute_blind_stile_width(self, 'LEFT')
    _update_cabinet_dim(self, context)


def _update_right_stile_type(self, context):
    _recompute_blind_stile_width(self, 'RIGHT')
    _update_cabinet_dim(self, context)


def _sync_decorative_corner_stile(cab_props, side):
    """Write the end stile width for a front decorative corner.

    The frame butts into the post, and the stile beside it is a 1-1/2"
    member (1-1/4" on full overlay). The stile is unlocked while it
    holds that width so a style re-apply leaves it alone; when the
    post on that side goes away and the stile still carries the
    post width, it is re-locked and drops back to its style / type
    driven width. A stile the user already unlocked (manual control)
    is left alone, like the blind stile coupling.
    """
    if side == 'LEFT':
        on = cab_props.decorative_corner_front_left
        attr, lock_attr = 'left_stile_width', 'unlock_left_stile'
    else:
        on = cab_props.decorative_corner_front_right
        attr, lock_attr = 'right_stile_width', 'unlock_right_stile'
    on = on and cab_props.decorative_corner_style != 'NONE'
    width = decorative_corner.stile_width(cab_props.id_data)
    stamp = 'HB_DECO_CORNER_STILE_%s' % side
    root = cab_props.id_data
    if on:
        if not root.get(stamp):
            # Remember whether the unlock is ours to undo.
            if getattr(cab_props, lock_attr):
                root[stamp] = 'USER_UNLOCKED'
            else:
                root[stamp] = 'UNLOCKED_BY_CORNER'
                setattr(cab_props, lock_attr, True)
        if abs(getattr(cab_props, attr) - width) > 1e-7:
            setattr(cab_props, attr, width)
        return
    was = root.get(stamp)
    if not was:
        return
    del root[stamp]
    if abs(getattr(cab_props, attr) - width) > 1e-7:
        # User moved it since; keep their width (and their unlock).
        return
    if was == 'UNLOCKED_BY_CORNER':
        # Re-locking re-applies the style's stile width; unstyled
        # cabinets fall back to the type-driven width.
        setattr(cab_props, lock_attr, False)
        if not root.get('STYLE_NAME'):
            _recompute_blind_stile_width(cab_props, side)


def _update_decorative_corners(self, context):
    _sync_decorative_corner_stile(self, 'LEFT')
    _sync_decorative_corner_stile(self, 'RIGHT')
    _update_cabinet_dim(self, context)


def _update_garage_bottom(self, context):
    """Full-width garage bottom sync (blind appliance garage, the
    "3-opening" configuration): one front spans the entire garage
    level, dead zone included, instead of a separate blind-section
    treatment beside the garage doors. DOORS extends the garage
    opening's real leaves across the dead zone via the blind-side
    overlay (they stay opening-backed, so open-door mode still works);
    TAMBOUR / RETRACTING / SWING_UP blank the opening's own front and
    let the blind-section part builder draw one full-span front
    instead. Turning full-width off restores the opening's door front
    and cabinet-default overlays.
    """
    cab_obj = self.id_data
    from . import types_face_frame
    garage_op = None
    for child in cab_obj.children_recursive:
        if (child.get(types_face_frame.TAG_OPENING_CAGE)
                and child.get('SIZE_ROLE') == 'GARAGE_BOTTOM'):
            garage_op = child
            break
    if garage_op is None:
        _update_cabinet_dim(self, context)
        return
    op = garage_op.face_frame_opening
    full = self.garage_bottom_full
    front = self.garage_bottom_front
    # The garage bay's position decides which blind side the bottom can
    # extend toward: only the end whose bay IS the garage bay has a
    # garage-level dead zone. A run blind at both corners with the
    # garage at one end must not stretch the doors toward the other.
    bay = garage_op
    while bay is not None and not bay.get(types_face_frame.TAG_BAY_CAGE):
        bay = bay.parent
    bay_idx = bay.get('hb_bay_index', 0) if bay is not None else 0
    bay_count = sum(1 for c in cab_obj.children
                    if c.get(types_face_frame.TAG_BAY_CAGE))
    with types_face_frame.suspend_recalc():
        for side in ('left', 'right'):
            is_blind = (getattr(self, f'{side}_stile_type') == 'BLIND'
                        and getattr(self, f'blind_{side}'))
            at_garage_end = (bay_idx == 0 if side == 'left'
                             else bay_idx == max(bay_count - 1, 0))
            if full and front == 'DOORS' and is_blind and at_garage_end:
                # Door edge lands 1/8" off the cabinet end: overlay =
                # dead zone + end stile, less the reveal.
                setattr(op, f'unlock_{side}_overlay', True)
                setattr(op, f'{side}_overlay',
                        getattr(self, f'blind_amount_{side}')
                        + getattr(self, f'{side}_stile_width')
                        - units.inch(0.125))
            elif getattr(op, f'unlock_{side}_overlay'):
                setattr(op, f'unlock_{side}_overlay', False)
        want_front = 'NONE' if (full and front != 'DOORS') else 'DOOR'
        if op.front_type != want_front:
            op.front_type = want_front
    _update_cabinet_dim(self, context)


def _update_blind_left(self, context):
    _recompute_blind_stile_width(self, 'LEFT')
    _update_cabinet_dim(self, context)


def _update_blind_right(self, context):
    _recompute_blind_stile_width(self, 'RIGHT')
    _update_cabinet_dim(self, context)


def update_cabinet_frame_lock(self, context):
    """Toggling a per-cabinet stile / rail lock re-applies the assigned
    cabinet style's frame sizes to this cabinet: a re-locked field snaps
    back to the style value, while still-unlocked fields keep the user's
    override (the apply respects each unlock flag). No-op when the cabinet
    has no resolvable style (e.g. during load)."""
    cabinet_obj = self.id_data
    if cabinet_obj is None:
        return
    style_name = cabinet_obj.get('STYLE_NAME')
    if not style_name:
        return
    try:
        ff = get_style_props(context)
    except Exception:
        return
    style = next((cs for cs in ff.cabinet_styles if cs.name == style_name), None)
    if style is not None:
        style._apply_face_frame_sizes_to_cabinet(cabinet_obj)


class Face_Frame_Cabinet_Props(PropertyGroup):
    """Cabinet-level face frame state. Attached to the cabinet's root object
    as bpy.types.Object.face_frame_cabinet.

    Holds everything that describes the cabinet as a whole: type, finished
    end conditions, blind setup, stile/rail defaults, toe kick, optional
    parts, mid stile collection. Per-bay data lives on each bay child object.
    """

    # ---- Live dimensions (single source of truth; cage Dim X/Y/Z is mirrored from these) ----
    width: FloatProperty(
        name="Width",
        description="Cabinet width (X dimension)",
        default=units.inch(36.0), unit='LENGTH', precision=4,
        update=_update_cabinet_width,
    )  # type: ignore
    # Which edge stays put when the width changes. LEFT is the natural
    # behavior (origin at the left edge); RIGHT shifts the origin by the
    # width delta so the cabinet resizes toward the left instead; CENTER
    # splits the delta so the centreline holds -- what you want when the
    # cabinet is centred on something fixed (a window, an appliance
    # whose size changed) and both edges should move evenly.
    anchor_side: EnumProperty(
        name="Anchor Side",
        description="Which part of the cabinet stays put when the width changes",
        items=[
            ('LEFT', "Left", "The left edge stays put; width changes move the right edge"),
            ('CENTER', "Center", "The centreline stays put; width changes move both edges evenly"),
            ('RIGHT', "Right", "The right edge stays put; width changes move the left edge"),
        ],
        default='LEFT',
    )  # type: ignore
    height: FloatProperty(
        name="Height",
        description="Cabinet height (Z dimension)",
        default=units.inch(34.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    depth: FloatProperty(
        name="Depth",
        description="Cabinet depth (Y dimension)",
        default=units.inch(24.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Width lock - consulted by the Grab Cabinet Group operator when
    # distributing a delta across cabinets in a group. Locked cabinets
    # hold their width; unlocked ones absorb. Defaulting False matches
    # bay-level unlock_width semantics (unlocked = free to resize).
    lock_width: BoolProperty(
        name="Lock Width",
        description="Hold this cabinet's width when a containing group is resized",
        default=False,
    )  # type: ignore

    cabinet_type: EnumProperty(
        name="Cabinet Type",
        items=[
            ('BASE', "Base", "Base cabinet"),
            ('TALL', "Tall", "Tall cabinet"),
            ('UPPER', "Upper", "Upper cabinet"),
            ('LAP_DRAWER', "Lap Drawer", "Lap drawer cabinet"),
            ('PANEL', "Panel", "Standalone face frame panel (no carcass)"),
        ],
        default='BASE',
    )  # type: ignore

    is_sink: BoolProperty(name="Is Sink Cabinet", default=False)  # type: ignore
    is_built_in_appliance: BoolProperty(name="Is Built-in Appliance", default=False)  # type: ignore
    is_double: BoolProperty(name="Is Stacked / Double", default=False)  # type: ignore

    left_finished_end_condition: EnumProperty(
        name="Left Finished End", items=FIN_END_ITEMS, default='UNFINISHED',
        update=_on_left_finish_end_user_set,
    )  # type: ignore
    right_finished_end_condition: EnumProperty(
        name="Right Finished End", items=FIN_END_ITEMS, default='UNFINISHED',
        update=_on_right_finish_end_user_set,
    )  # type: ignore
    back_finished_end_condition: EnumProperty(
        name="Back Finished End", items=FIN_END_ITEMS, default='UNFINISHED',
        update=_on_back_finish_end_user_set,
    )  # type: ignore

    # Panel seam: where a finished side panel is joined when it is
    # longer than the stock it is cut from. Measured from the CABINET
    # BOTTOM (the floor, on a floor-standing cabinet), which is the
    # datum the drafter reads off the elevation. 0 = no seam, the panel
    # is one board. Only FINISHED ends can carry one - see
    # Face_Frame_Cabinet._side_seam_blocked.
    # "This end is one piece" said out loud. A finished end long enough
    # to need a seam is flagged for the designer; ticking this is the
    # answer "no it isn't", which both keeps the panel whole and stops
    # the flag coming back. Distinct from a seam height of 0, which only
    # means nobody has looked at it yet.
    left_side_no_seam: BoolProperty(
        name="No Seam",
        description="Build the left finished end as one piece, however "
                    "long it is, and stop flagging it",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_side_no_seam: BoolProperty(
        name="No Seam",
        description="Build the right finished end as one piece, however "
                    "long it is, and stop flagging it",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore

    left_side_seam_height: FloatProperty(
        name="Left Seam Height",
        description="Height above the cabinet bottom where the left finished "
                    "end is seamed. 0 = one piece",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_side_seam_height: FloatProperty(
        name="Right Seam Height",
        description="Height above the cabinet bottom where the right finished "
                    "end is seamed. 0 = one piece",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Spacing between v-grooves, where a shop cuts them at something
    # other than the usual 4" sheet layout. 0 keeps that default.
    v_groove_spacing: FloatProperty(
        name="V-Groove Spacing",
        description="Distance between v-grooves. 0 uses the standard "
                    "4\" layout",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Shiplap course width for SHIPLAP finished ends (all shiplap sides
    # of this cabinet share it). Same 4 / 5 / 6 ladder as the wood-hood
    # shiplap board width.
    shiplap_board_width: EnumProperty(
        name="Shiplap Width",
        description="Course width of the shiplap planks on shiplap finished ends",
        items=[('4', "4\"", "4 inch shiplap planks"),
               ('5', "5\"", "5 inch shiplap planks"),
               ('6', "6\"", "6 inch shiplap planks")],
        default='6',
        update=_update_cabinet_dim,
    )  # type: ignore
    # Which way the shiplap planks run. Horizontal courses climb from
    # the floor; vertical planks are balanced across the panel so both
    # end planks match. Shared by every shiplap side, like the width.
    shiplap_direction: EnumProperty(
        name="Shiplap Direction",
        description="Direction the shiplap planks run on shiplap finished ends",
        items=[('HORIZONTAL', "Horizontal", "Courses run across, stacked from the floor"),
               ('VERTICAL', "Vertical", "Planks stand upright, balanced across the panel")],
        default='HORIZONTAL',
        update=_update_cabinet_dim,
    )  # type: ignore

    # Scribe = inset from the face frame outer face to the side panel
    # outer face. The solver multiplexes this against the finish end
    # condition (3/4 finished forces 0 since the side IS the outer face;
    # paneled reserves 3/4" for the panel; others use the typed value),
    # so this prop holds the user setpoint for the unfinished /
    # against-a-wall case (~1/2" typical, 0 for an adjacent cabinet).
    left_scribe: FloatProperty(
        name="Left Scribe", default=0.0, unit='LENGTH', precision=4,
        update=_on_left_scribe_user_set,
    )  # type: ignore
    right_scribe: FloatProperty(
        name="Right Scribe", default=0.0, unit='LENGTH', precision=4,
        update=_on_right_scribe_user_set,
    )  # type: ignore

    # Per-side exposure state. Computed by exposure.recalc_cabinet_exposure
    # from wall edges and parent-wall siblings (cabinets + appliances).
    # Drives the auto-pick of finished_end_condition. Defaults are EXPOSED
    # so a cabinet that hasn't yet been touched by detection reads as if
    # it stands alone - matches the prior default-True placeholder.
    left_exposure: EnumProperty(
        name="Left Exposure", items=EXPOSURE_ITEMS, default='EXPOSED',
    )  # type: ignore
    right_exposure: EnumProperty(
        name="Right Exposure", items=EXPOSURE_ITEMS, default='EXPOSED',
    )  # type: ignore
    back_exposure: EnumProperty(
        name="Back Exposure", items=EXPOSURE_ITEMS, default='EXPOSED',
    )  # type: ignore

    # Adjacent dishwasher (or other panel-ready appliance handled the same
    # way) on this side. Forces FLUSH_X regardless of exposure state when
    # auto-pick is on. Back has no dishwasher concept by design.
    left_dishwasher_adjacent: BoolProperty(
        name="Left Dishwasher Adjacent", default=False,
    )  # type: ignore
    right_dishwasher_adjacent: BoolProperty(
        name="Right Dishwasher Adjacent", default=False,
    )  # type: ignore

    # Auto flag per side. True = exposure recalc is allowed to overwrite
    # the finished_end_condition based on detection. Flipped to False
    # automatically when the user edits the enum directly (see the
    # per-side update callbacks). The Recalculate operator re-arms all
    # three before re-running detection.
    left_finish_end_auto: BoolProperty(
        name="Left Finish End Auto", default=True,
    )  # type: ignore
    right_finish_end_auto: BoolProperty(
        name="Right Finish End Auto", default=True,
    )  # type: ignore
    back_finish_end_auto: BoolProperty(
        name="Back Finish End Auto", default=True,
    )  # type: ignore

    # Finished-end overhang extensions (signed; meters). Applied to the
    # finished-end PART for a side (the FINISHED back/side panel, an
    # applied panel, or a beadboard/shiplap panel) AFTER the carcass is
    # built, growing that part past the cabinet body without changing the
    # carcass. FLUSH_X is excluded - its depth already IS flush_x_amount.
    #   back L/R  -> grow the BACK finished part past the cabinet's left
    #               (-X) / right (+X) end. Positive = overhang, negative
    #               = inset that edge.
    #   side back -> run the LEFT / RIGHT finished part past the cabinet
    #               back (+Y). Positive = overhang behind the cabinet,
    #               negative = inset the back edge forward. The square
    #               front edge stays put.
    back_finished_extend_left: FloatProperty(
        name="Back Extend Left", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    back_finished_extend_right: FloatProperty(
        name="Back Extend Right", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    left_side_finished_extend_back: FloatProperty(
        name="Left Side Extend Back", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_side_finished_extend_back: FloatProperty(
        name="Right Side Extend Back", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Finish the INSIDE face of a carcass side as well. The end condition
    # only ever covers the outer face; a side that drops below the box
    # (a hutch upper's extended end) shows its inner face to the room
    # from the counter up, and that face is bare stock unless asked
    # for. Independent of the outer condition, so a side against a
    # wall can stay unfinished outside and still finish the drop.
    left_side_finish_inside: BoolProperty(
        name="Left Side Finish Inside",
        default=False,
        description="Finish the inside face of the left side (the face "
                    "seen below the box when the end extends down)",
        update=_update_cabinet_dim,
    )  # type: ignore
    right_side_finish_inside: BoolProperty(
        name="Right Side Finish Inside",
        default=False,
        description="Finish the inside face of the right side (the face "
                    "seen below the box when the end extends down)",
        update=_update_cabinet_dim,
    )  # type: ignore

    # Return closeout on a FINISHED side that is extended back past a
    # FINISHED back. Nonzero return width builds a finished "post" wrapping
    # the exposed back corner: a return panel parallel to the side (its
    # depth = the side's extend-back amount) dying into the finished back,
    # capped at the rear by a stile whose width IS this value (e.g. 4" ->
    # a 4"-wide stile running full height to the floor). Zero = no return
    # (bare extended side, the prior behaviour). Gated per-side on that side
    # being FINISHED or PANELED + extended back with a FINISHED or PANELED
    # back; see _reconcile_finished_side_returns in types_face_frame.
    left_side_return_width: FloatProperty(
        name="Left Side Return Width", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_side_return_width: FloatProperty(
        name="Right Side Return Width", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Per-member construction of the return closeout: the return panel and
    # its rear stile can each be a flat FINISHED part (default) or a PANELED
    # applied panel. Per side. Read by _reconcile_finished_side_returns.
    left_side_return_panel_type: EnumProperty(
        name="Left Side Return Type", items=RETURN_MEMBER_TYPE_ITEMS,
        default='FINISHED', update=_update_cabinet_dim,
    )  # type: ignore
    right_side_return_panel_type: EnumProperty(
        name="Right Side Return Type", items=RETURN_MEMBER_TYPE_ITEMS,
        default='FINISHED', update=_update_cabinet_dim,
    )  # type: ignore
    left_side_return_stile_type: EnumProperty(
        name="Left Side Return Stile Type", items=RETURN_MEMBER_TYPE_ITEMS,
        default='FINISHED', update=_update_cabinet_dim,
    )  # type: ignore
    right_side_return_stile_type: EnumProperty(
        name="Right Side Return Stile Type", items=RETURN_MEMBER_TYPE_ITEMS,
        default='FINISHED', update=_update_cabinet_dim,
    )  # type: ignore

    # FLUSH_X writes a finished strip running the front X inches of the
    # side panel; per-side because adjacent-appliance widths can differ.
    # Back has no FLUSH_X by design.
    left_flush_x_amount: FloatProperty(
        name="Left Flush X Amount", default=units.inch(4),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_flush_x_amount: FloatProperty(
        name="Right Flush X Amount", default=units.inch(4),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Applied-panel frame member sizes. Used when a side's finish type is
    # PANELED / FALSE_FF / WORKING_FF. panel_frame_auto=True (default)
    # asks the parts builder to compute widths from opening/cabinet
    # dimensions; turning it off uses the explicit values below. One set
    # per cabinet rather than per-side - builder style is uniform within
    # a cabinet in practice. Easy to split later if that doesn't hold.
    panel_frame_auto: BoolProperty(name="Auto Panel Frame Widths", default=True)  # type: ignore
    # Applied-panel opening count. Auto (default) follows the width
    # ladder; inserting/deleting a bay on the panel flips this off so the
    # manual count survives the host recalc. On the shared propgroup but
    # only read for applied panels (PanelFaceFrameCabinet roots).
    panel_split_auto: BoolProperty(
        name="Auto Openings", default=True,
        description="When on, the applied panel's number of openings "
                    "follows its width. Inserting or deleting a bay "
                    "turns this off so your opening count survives "
                    "recalculation",
        update=_update_panel_split_auto)  # type: ignore
    # Explicit vertical-division override for the width ladder. 0 keeps
    # the automatic count. Rail-matched side panels (the panel mirrors
    # the source bay's stacked-door rails) build their columns as
    # in-bay V-splits and support at most 2.
    panel_vertical_bays: IntProperty(
        name="Vertical Divisions",
        description="Number of vertical panel divisions (columns). "
                    "0 = automatic from the panel width. Panels that "
                    "mirror a stacked-door mid rail support at most 2",
        default=0, min=0, max=8,
        update=_update_panel_vertical_bays)  # type: ignore
    # X-Frame End: one open frame with a 3/4" x 3" solid lumber X
    # applied within it, held 1/4" back of the frame face. Typical
    # frame sizes are 3" stiles, 3" top rail, 5-1/4" bottom rail --
    # unlock + type those on the panel if the auto-sized frame should
    # not stand.
    panel_x_frame: BoolProperty(
        name="X Frame",
        description="Build this applied panel as an X-Frame End: one "
                    "open frame with a crossing lumber X held 1/4\" "
                    "back of the frame face",
        default=False,
        update=_update_panel_split_auto)  # type: ignore
    # Explicit row override. 0 keeps the automatic rows (mirroring the
    # source cabinet's stacked-door rails). N > 0 builds N stacked rows
    # with mid rails between, row heights from panel_row_heights
    # (bottom-up; the top row absorbs the remainder).
    panel_horizontal_rows: IntProperty(
        name="Rows",
        description="Number of stacked panel rows. 0 = match the "
                    "cabinet's own splits; 1 = one full-height panel; "
                    "N builds N rows with mid rails between, heights "
                    "set per row (bottom up, top row takes the rest)",
        default=0, min=0, max=8,
        update=_update_panel_rows)  # type: ignore
    panel_row_rail_width: FloatProperty(
        name="Mid Rail Width",
        description="Width of the mid rails between manual panel rows",
        default=units.inch(1.5), min=units.inch(0.5),
        unit='LENGTH', precision=4,
        update=_update_panel_rows)  # type: ignore
    panel_row_heights: CollectionProperty(
        type=Face_Frame_Panel_Row_Height)  # type: ignore
    # Mid stile width: auto follows the door style (5-piece stile
    # width, else the cabinet's end stile); the override lets the
    # panel's stiles be set independently of its rails.
    panel_mid_stile_override: BoolProperty(
        name="Set Mid Stile Width",
        description="Set the panel's mid stile width directly instead "
                    "of following the door style",
        default=False,
        update=_update_panel_split_auto)  # type: ignore
    panel_mid_stile_width: FloatProperty(
        name="Mid Stile Width",
        description="Width of the mid stiles between panel columns "
                    "(applies when Set Mid Stile Width is on)",
        default=units.inch(1.5), min=units.inch(0.5),
        unit='LENGTH', precision=4,
        update=_update_panel_split_auto)  # type: ignore
    panel_col_widths: CollectionProperty(
        type=Face_Frame_Panel_Col_Width)  # type: ignore
    panel_top_rail_width: FloatProperty(
        name="Panel Top Rail Width", default=units.inch(1.5),
        unit='LENGTH', precision=4,
    )  # type: ignore
    panel_bottom_rail_width: FloatProperty(
        name="Panel Bottom Rail Width", default=units.inch(1.5),
        unit='LENGTH', precision=4,
    )  # type: ignore
    panel_stile_width: FloatProperty(
        name="Panel Stile Width", default=units.inch(1.5),
        unit='LENGTH', precision=4,
    )  # type: ignore

    # Top scribe = amount the carcass top (top panel or stretchers) is
    # held down from the bay's top opening. Sides matching the held-down
    # top drop with it; sides flagged as the finished face stay
    # full-height to provide a visible end face. Type defaults are
    # seeded in create_cabinet_root: Upper 1/8", Tall 1/2", Base 0.
    top_scribe: FloatProperty(
        name="Top Scribe", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    blind_left: BoolProperty(
        name="Blind Left", default=False, update=_update_blind_left
    )  # type: ignore
    blind_right: BoolProperty(
        name="Blind Right", default=False, update=_update_blind_right
    )  # type: ignore
    blind_amount_left: FloatProperty(
        name="Blind Amount Left", default=units.inch(24.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    blind_amount_right: FloatProperty(
        name="Blind Amount Right", default=units.inch(24.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # With a garage extension active and a blind side set, how the
    # garage-level blind section (the strip of front the neighbor does
    # not cover, from the countertop to the top of the garage zone) is
    # treated. PANEL keeps the 1/4" blind panel running to the counter;
    # every other choice stops the panel at the top of the garage zone
    # and either leaves the section open into the corner or fronts it
    # with a door so the corner countertop stays usable garage space.
    GARAGE_BLIND_SECTION_ITEMS = [
        ('PANEL', "Blind Panel",
         "Close the section with the blind panel down to the countertop"),
        ('OPEN', "Open",
         "Leave the section open into the corner at garage level"),
        ('DOOR', "Hinged Door",
         "Hinged door on the section, hinged at the corner end"),
        ('TAMBOUR', "Tambour Door",
         "Vertical-travel tambour across the section"),
        ('RETRACTING', "Top Retracting Door",
         "Top-mounted retracting door (drawn closed)"),
        ('SWING_UP', "Swing-Up Door",
         "Swing-up door hinged at the top (drawn closed)"),
    ]
    garage_blind_section: EnumProperty(
        name="Blind Section",
        items=GARAGE_BLIND_SECTION_ITEMS,
        default='PANEL',
        description="Treatment of the garage-level blind section not "
                    "covered by the adjacent cabinet",
        update=_update_cabinet_dim,
    )  # type: ignore
    # "3-opening" alternative to the split blind-section treatment: the
    # entire garage level - dead zone included - carries ONE front.
    garage_bottom_full: BoolProperty(
        name="Full-Width Bottom",
        default=False,
        description="Run one front across the entire garage level, "
                    "dead zone included, instead of a separate blind "
                    "section beside the garage doors",
        update=_update_garage_bottom,
    )  # type: ignore
    garage_bottom_front: EnumProperty(
        name="Bottom Front",
        items=[
            ('DOORS', "Doors",
             "The garage opening's own doors extend across the dead "
             "zone (still open in open-door mode)"),
            ('TAMBOUR', "Tambour Door",
             "One tambour across the entire garage level"),
            ('RETRACTING', "Top Retracting Door",
             "One top-mounted retracting door across the garage level "
             "(drawn closed)"),
            ('SWING_UP', "Swing-Up Door",
             "One swing-up door across the garage level (drawn "
             "closed)"),
        ],
        default='DOORS',
        update=_update_garage_bottom,
    )  # type: ignore
    # Galley workstation cabinets: the size sets the width and bay
    # split; the setback places the front apron the sink rests on.
    galley_size: EnumProperty(
        name="Galley Size",
        items=[
            ('IWS2', "IWS 2", "28 in, one opening"),
            ('IWS3', "IWS 3", "39 3/4 in, two openings"),
            ('IWS4', "IWS 4", "51 3/4 in, two openings and an 18 in sink base"),
            ('IWS5', "IWS 5", "62 in, three openings"),
            ('IWS6', "IWS 6", "77 3/4 in, three openings and an 18 in sink base"),
            ('IWS7', "IWS 7", "83 1/4 in, four openings"),
        ],
        default='IWS3', update=_update_galley_size,
    )  # type: ignore
    galley_front_apron_setback: FloatProperty(
        name="Front Apron Setback",
        description="From the cabinet front to the front apron; the sink runs from there to the back",
        default=units.inch(4.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    blind_reveal: FloatProperty(
        name="Blind Reveal", default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    left_stile_width: FloatProperty(
        name="Left Stile Width", default=units.inch(2.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_stile_width: FloatProperty(
        name="Right Stile Width", default=units.inch(2.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_left_stile: BoolProperty(name="Unlock Left Stile", default=False, update=update_cabinet_frame_lock)  # type: ignore
    unlock_right_stile: BoolProperty(name="Unlock Right Stile", default=False, update=update_cabinet_frame_lock)  # type: ignore
    turn_off_left_stile: BoolProperty(name="Turn Off Left Stile", default=False)  # type: ignore
    turn_off_right_stile: BoolProperty(name="Turn Off Right Stile", default=False)  # type: ignore

    LEFT_STILE_TYPE_ITEMS = [
        ('STANDARD', "Standard", "Standard stile"),
        ('WALL', "Wall", "Wall stile (extends past carcass)"),
        ('BLIND', "Blind", "Blind corner stile"),
        ('BUTT', "Butt", "Butt joint against an adjacent cabinet"),
        ('INSIDE_90', "Inside 90", "Blind-stile condition: two runs meeting at an open 90-degree inside corner"),
        ('ANGLE', "Angle", "Against a diagonal / angled cabinet"),
    ]
    left_stile_type: EnumProperty(
        name="Left Stile Type", items=LEFT_STILE_TYPE_ITEMS, default='STANDARD',
        update=_update_left_stile_type,
    )  # type: ignore
    right_stile_type: EnumProperty(
        name="Right Stile Type", items=LEFT_STILE_TYPE_ITEMS, default='STANDARD',
        update=_update_right_stile_type,
    )  # type: ignore

    # End stile drops to the floor instead of stopping at the bay bottom,
    # filling the area beside the kick recess. Solver also forces this on
    # for FLUSH so the wide bottom rail butts into a full-height stile.
    extend_left_stile_to_floor: BoolProperty(
        name="Extend Left Stile To Floor", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_right_stile_to_floor: BoolProperty(
        name="Extend Right Stile To Floor", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Refrigerator cabinet: per-cabinet opening height + per-side raise.
    # refrigerator_opening_height drives the bottom appliance opening node
    # and keeps the carcass back in sync (see _update_refrigerator_opening_height).
    # The two raise toggles lift that side's carcass side panel AND end stile
    # up to the top of the fridge opening so the side spans only the door zone
    # (consumed in solver_face_frame: side_bottom_z + left/right_end_stile_*).
    refrigerator_opening_height: FloatProperty(
        name="Refrigerator Opening Height", default=units.inch(62.0),
        unit='LENGTH', precision=4,
        update=_update_refrigerator_opening_height,
    )  # type: ignore
    raise_left_to_refrigerator_height: BoolProperty(
        name="Raise Left To Refrigerator Height", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    raise_right_to_refrigerator_height: BoolProperty(
        name="Raise Right To Refrigerator Height", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # "Stile in lieu of leg": build a separate face-frame stile from the floor
    # to the top of the fridge opening on that side (in place of a leg). Turning
    # it on also raises that side's end stile to the opening top (via
    # solver.raise_side_to_refrigerator), so the end stile spans the door zone
    # above and this lower stile fills the floor-to-opening zone below. Width
    # matches that side's end stile. Geometry + 2D only for now.
    refrigerator_stile_left: BoolProperty(
        name="Refrigerator Stile In Lieu Of Leg (Left)", default=False,
        description="Add a floor-to-opening face-frame stile on the left in "
                    "lieu of a leg; also raises the left end stile to the "
                    "opening top",
        update=_update_cabinet_dim,
    )  # type: ignore
    refrigerator_stile_right: BoolProperty(
        name="Refrigerator Stile In Lieu Of Leg (Right)", default=False,
        description="Add a floor-to-opening face-frame stile on the right in "
                    "lieu of a leg; also raises the right end stile to the "
                    "opening top",
        update=_update_cabinet_dim,
    )  # type: ignore

    extend_left_stile_up: BoolProperty(name="Extend Left Stile Up", default=False)  # type: ignore
    extend_left_stile_down: BoolProperty(name="Extend Left Stile Down", default=False)  # type: ignore
    extend_right_stile_up: BoolProperty(name="Extend Right Stile Up", default=False)  # type: ignore
    extend_right_stile_down: BoolProperty(name="Extend Right Stile Down", default=False)  # type: ignore
    extend_left_stile_up_amount: FloatProperty(
        name="Extend Left Stile Up Amount", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore
    extend_left_stile_down_amount: FloatProperty(
        name="Extend Left Stile Down Amount", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore
    extend_right_stile_up_amount: FloatProperty(
        name="Extend Right Stile Up Amount", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore
    extend_right_stile_down_amount: FloatProperty(
        name="Extend Right Stile Down Amount", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore

    extend_left: FloatProperty(
        name="Extend Left", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore
    extend_right: FloatProperty(
        name="Extend Right", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore
    left_offset: FloatProperty(
        name="Left Offset", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore
    right_offset: FloatProperty(
        name="Right Offset", default=0.0, unit='LENGTH', precision=4
    )  # type: ignore

    top_rail_width: FloatProperty(
        name="Top Rail Width", default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    stretcher_width: FloatProperty(
        name="Stretcher Width",
        description="Front-to-back depth of the top stretchers (typical 3.5 in)",
        default=units.inch(3.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    stretcher_thickness: FloatProperty(
        name="Stretcher Thickness",
        description="Vertical thickness of the top stretchers (typical 3/4 in)",
        default=units.inch(0.75), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    bottom_rail_width: FloatProperty(
        name="Bottom Rail Width", default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_top_rail: BoolProperty(name="Unlock Top Rail (Cabinet)", default=False, update=update_cabinet_frame_lock)  # type: ignore
    unlock_bottom_rail: BoolProperty(name="Unlock Bottom Rail (Cabinet)", default=False, update=update_cabinet_frame_lock)  # type: ignore

    # Mid rails / mid stiles INSIDE a bay (face frame members created by
    # splitting an opening). Cabinet-level defaults; per-member override
    # comes later if needed.
    bay_mid_rail_width: FloatProperty(
        name="Bay Mid Rail Width",
        description="Vertical extent of mid rails created by horizontal splits inside a bay",
        default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    bay_mid_stile_width: FloatProperty(
        name="Bay Mid Stile Width",
        description="Horizontal extent of mid stiles created by vertical splits inside a bay",
        default=units.inch(2.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Cabinet-level overlay defaults. Applied to every opening unless the
    # opening unlocks the corresponding side and supplies its own value.
    default_top_overlay: FloatProperty(
        name="Default Top Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    default_bottom_overlay: FloatProperty(
        name="Default Bottom Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    default_left_overlay: FloatProperty(
        name="Default Left Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    default_right_overlay: FloatProperty(
        name="Default Right Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Distance the door is recessed into the face frame thickness. Zero for
    # overlay doors (door front face sits proud of the frame face); positive
    # for inset doors (door pushed back into the opening). Partial inset
    # typically ~0.375"; full inset = face_frame_thickness (flush).
    default_door_inset_amount: FloatProperty(
        name="Default Door Inset Amount",
        description="Distance the door is recessed from the face frame face (0 = overlay, full = flush inset)",
        default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    material_thickness: FloatProperty(
        name="Material Thickness", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    face_frame_thickness: FloatProperty(
        name="Face Frame Thickness", default=units.inch(0.75), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    door_thickness: FloatProperty(
        name="Door Thickness",
        description="Thickness of doors and drawer fronts attached to openings",
        default=units.inch(0.75), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Accessible sink: the carcass is cut away underneath at the FRONT,
    # which is the end a wheelchair comes at. The box keeps its full
    # height against the wall, rakes down toward the room, and is left
    # as a shallow band at the front where the knees go under. The shop
    # drawing has 8" full at the wall, 8" of band at the front (so a 5"
    # rake on a 21" box) and a 5-1/2" band.
    ada_side_shape: BoolProperty(
        name="Raked Sides",
        description="Cut the carcass away underneath at the front, "
                    "leaving knee clearance under the sink",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    ada_side_wall_run: FloatProperty(
        name="Full Height At Wall",
        description="How far forward from the wall the sides keep their "
                    "full height before the rake starts",
        default=units.inch(8.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    ada_side_front_run: FloatProperty(
        name="Band At Front",
        description="How far back from the front the shallow band runs. "
                    "The rake takes what is left between the two",
        default=units.inch(8.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    ada_side_front_height: FloatProperty(
        name="Band Height",
        description="Height of the band left at the front, measured "
                    "down from the top of the box",
        default=units.inch(5.5), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Floating vanity construction, on a base cabinet whose toe kick
    # is FLOATING - the kick height is then the gap the vanity hangs
    # above the floor. The box closes at the top with a panel instead
    # of stretchers (there is a sink sitting on it), that top is 1/2
    # over a 3/4 back, and the basin drops through a cutout in it.
    floating_vanity: BoolProperty(
        name="Floating Vanity Construction",
        description="Build this floating base as a vanity: a closed top "
                    "over a 3/4 back, with a cutout for the basin. The "
                    "toe kick height is the gap above the floor",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    # Carcass top thickness, where it differs from the cabinet's
    # material. 0 keeps the material thickness.
    top_thickness_override: FloatProperty(
        name="Top Thickness",
        description="Thickness of the carcass top panel. 0 uses the "
                    "cabinet's material thickness",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Top over back: the top runs the full depth and lands on the back
    # panel's top edge, which then stops below it. Off, the two meet at
    # the back panel's front face and both reach the cabinet top.
    top_over_back: BoolProperty(
        name="Top Over Back",
        description="Run the carcass top back over the top edge of the "
                    "back panel instead of butting into its front face",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    # Sink cutout in the carcass top - the hole the basin drops through
    # on a vanity whose top IS the carcass top.
    top_sink_cutout: BoolProperty(
        name="Sink Cutout",
        description="Cut a centered opening in the carcass top for a "
                    "sink to drop through",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    top_sink_cutout_width: FloatProperty(
        name="Sink Cutout Width",
        default=units.inch(12.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    top_sink_cutout_depth: FloatProperty(
        name="Sink Cutout Depth",
        default=units.inch(12.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    back_thickness: FloatProperty(
        name="Back Thickness", default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Mid-division panels are typically thinner than carcass sides /
    # tops / bottoms (1/2" plywood) - exposed as its own prop so it can
    # diverge from material_thickness without changing other parts.
    division_thickness: FloatProperty(
        name="Division Thickness", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    finish_toe_kick_thickness: FloatProperty(
        name="Finish Toe Kick Thickness", default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    toe_kick_type: EnumProperty(
        name="Toe Kick Type",
        items=[
            ('NOTCH', "Notched Ends to Floor",
             "Sides extend to the floor with a front-bottom notch sized "
             "by toe_kick_height x toe_kick_setback"),
            ('FLUSH', "Flush (Wide Bottom Rail)",
             "No recess; the face frame's bottom rail extends to the floor"),
            ('FLOATING', "Floating",
             "Sides start above the floor by toe_kick_height; the kick is "
             "left open for a separate base the user supplies"),
            ('LOOSE', "Loose (Ladder Base)",
             "Sides float by toe_kick_height; a separate ladder sub-base "
             "(front + rear rail + two end boards) is built on the floor "
             "for the cabinet to sit on"),
            ('LOOSE_FLUSH', "Loose Flush (Ladder Base)",
             "Like Loose, but the ladder sub-base sits FLUSH with the "
             "cabinet front (setback 0) instead of recessed"),
        ],
        default='NOTCH',
        update=_update_cabinet_dim,
    )  # type: ignore
    toe_kick_height: FloatProperty(
        # Floored at zero: on a NOTCH kick a negative height is a recess
        # cut upward into nothing, and on a FLOATING one it hangs the
        # box below the floor.
        name="Toe Kick Height", default=units.inch(4.0), min=0.0,
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    toe_kick_setback: FloatProperty(
        name="Toe Kick Setback", default=units.inch(3.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    toe_kick_thickness: FloatProperty(
        name="Toe Kick Thickness", default=units.inch(0.75), unit='LENGTH', precision=4
    )  # type: ignore
    # Raises the carcass back panel's bottom edge above the cabinet
    # floor by this amount. Default 0 leaves the back full-height
    # (current behavior); a positive value leaves the lower portion
    # open at the back, used by refrigerator cabinets so the fridge
    # zone is open both at the front (no door) and at the back.
    back_bottom_inset: FloatProperty(
        name="Back Bottom Inset", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Tip-up wedge (refrigerator / tall cabinets). When enabled, recalc
    # chamfers the back-bottom corner so the cabinet's tip-up diagonal
    # clears the ceiling. Inputs persist on the cabinet so the wedge
    # recomputes live whenever depth / height / ceiling change; the
    # computed length + height are derived in the solver, not stored.
    wedge_enabled: BoolProperty(
        name="Tip-Up Wedge", default=False,
        description="Chamfer the back-bottom corner so a tall cabinet clears "
                    "the ceiling when tipped upright into place",
        update=_update_cabinet_dim,
    )  # type: ignore
    wedge_ceiling_height: FloatProperty(
        name="Wedge Ceiling Height", default=units.inch(96.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    wedge_fudge: FloatProperty(
        name="Wedge Fudge Allowance", default=units.inch(0.5),
        unit='LENGTH', precision=4, min=0.0, update=_update_cabinet_dim,
    )  # type: ignore
    # Typed wedge, over the calculated one. The sizes here are what
    # gets built, so a shop working from its own calculator can enter
    # what that gives rather than being held to this one's arithmetic.
    wedge_override: BoolProperty(
        name="Use My Sizes",
        description="Build the wedge at the sizes entered here instead "
                    "of the calculated ones",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    wedge_length: FloatProperty(
        name="Wedge Length",
        description="Length of the wedge along the cabinet depth, used "
                    "when the sizes are entered rather than calculated",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    wedge_height: FloatProperty(
        name="Wedge Height",
        description="Height of the wedge up the cabinet back, used when "
                    "the sizes are entered rather than calculated",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    wedge_max_height: FloatProperty(
        name="Wedge Max Height", default=units.inch(3.0),
        unit='LENGTH', precision=4, min=0.0, update=_update_cabinet_dim,
    )  # type: ignore
    # Pipe chase: full-height notch at a back corner (or the back middle)
    # so the cabinet clears plumbing / vent runs, with cover panels
    # closing the opening from the cabinet interior. The typed size is
    # the size of the CUT; recalc builds the cutter + covers from these
    # (see types_face_frame._apply_pipe_chase).
    chase_enabled: BoolProperty(
        name="Pipe Chase", default=False,
        description="Notch the cabinet back for a pipe chase and cover "
                    "the opening with panels",
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_location: EnumProperty(
        name="Chase Location",
        items=[
            ('LEFT_BACK', "Left Back Corner",
             "Notch the back-left corner of the cabinet"),
            ('BACK_MIDDLE', "Back Middle",
             "Notch the middle of the cabinet back"),
            ('RIGHT_BACK', "Right Back Corner",
             "Notch the back-right corner of the cabinet"),
        ],
        default='LEFT_BACK',
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_width: FloatProperty(
        name="Chase Width", default=units.inch(6.0),
        unit='LENGTH', precision=4, min=0.0,
        description="Size of the notch along the cabinet back",
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_depth: FloatProperty(
        name="Chase Depth", default=units.inch(4.0),
        unit='LENGTH', precision=4, min=0.0,
        description="Size of the notch into the cabinet, measured from "
                    "the back",
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_offset: FloatProperty(
        name="Chase Offset", default=0.0,
        unit='LENGTH', precision=4, min=0.0,
        description="Back Middle only: distance from the cabinet edge "
                    "(see Offset From) to the near edge of the notch",
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_offset_from: EnumProperty(
        name="Offset From",
        items=[
            ('LEFT', "Left", "Measure the offset from the cabinet's left edge"),
            ('RIGHT', "Right", "Measure the offset from the cabinet's right edge"),
        ],
        default='LEFT',
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_height: FloatProperty(
        name="Chase Height", default=0.0,
        unit='LENGTH', precision=4, min=0.0,
        description="Vertical size of the notch; 0 runs the chase the "
                    "full cabinet height",
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_z_offset: FloatProperty(
        name="Chase Bottom Offset", default=0.0,
        unit='LENGTH', precision=4, min=0.0,
        description="Distance from the cabinet bottom to the bottom of a "
                    "partial-height notch",
        update=_update_cabinet_dim,
    )  # type: ignore
    chase_notch_side: BoolProperty(
        name="Notch Side Panel", default=False,
        description="Corner chases only: also notch the adjacent side "
                    "panel (pipe intrudes past the cabinet side)",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Decorative corners: a milled post let into a vertical corner of
    # the cabinet. The corner is notched square, the post fills the
    # notch, and its outer face carries the chosen profile (see
    # decorative_corner.py and types_face_frame._apply_decorative_corners).
    decorative_corner_style: EnumProperty(
        name="Decorative Corner Style",
        items=decorative_corner.STYLE_ITEMS,
        default='NONE',
        update=_update_decorative_corners,
    )  # type: ignore
    decorative_corner_bottom: EnumProperty(
        name="Bottom Condition",
        items=decorative_corner.BOTTOM_ITEMS,
        default='STANDARD',
        description="Where the post ends at the floor and whether it "
                    "gets a transition detail and square bottom block",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Front corners move the face frame over by the post size and set
    # the stile beside the post (see _update_decorative_corners).
    decorative_corner_front_left: BoolProperty(
        name="Front Left", default=False, update=_update_decorative_corners,
    )  # type: ignore
    decorative_corner_front_right: BoolProperty(
        name="Front Right", default=False, update=_update_decorative_corners,
    )  # type: ignore
    decorative_corner_back_left: BoolProperty(
        name="Back Left", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    decorative_corner_back_right: BoolProperty(
        name="Back Right", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    # The vendor posts are 2" x 2" only; the size is not offered in the
    # UI (kept as a property for older files and for the solver, which
    # pulls the face frame in by it).
    decorative_corner_size: FloatProperty(
        name="Corner Size", default=decorative_corner.DEFAULT_SIZE,
        unit='LENGTH', precision=4, min=units.inch(0.25),
        description="Face size of the post, and the size of the square "
                    "notch cut into the cabinet corner",
        update=_update_decorative_corners,
    )  # type: ignore
    decorative_corner_detail_height: FloatProperty(
        name="Transition Detail Height",
        default=decorative_corner.DEFAULT_DETAIL_HEIGHT,
        unit='LENGTH', precision=4, min=0.0,
        description="Square base of the bottom transition detail, under "
                    "the bead ring (the bead itself adds 3/4\")",
        update=_update_cabinet_dim,
    )  # type: ignore
    decorative_corner_block_run: FloatProperty(
        name="Square Block Run",
        default=decorative_corner.DEFAULT_BLOCK_RUN,
        unit='LENGTH', precision=4, min=0.0,
        description="Length of the plain square block above the top "
                    "transition detail, that crown moulding dies into",
        update=_update_cabinet_dim,
    )  # type: ignore
    decorative_corner_top_detail: BoolProperty(
        name="Top Transition Detail", default=True,
        description="Finish the top of the post with a transition "
                    "detail under a square block for crown moulding",
        update=_update_cabinet_dim,
    )  # type: ignore
    # ---- Construction-tab section visibility (UI only) ----
    show_angled_back_extension: BoolProperty(
        name="Show Angled Back Extension", default=False)  # type: ignore
    show_upper_extensions: BoolProperty(
        name="Show Upper Extensions", default=False)  # type: ignore
    show_toe_kick: BoolProperty(name="Show Toe Kick", default=True)  # type: ignore
    show_finished_ends: BoolProperty(name="Show Finished Ends", default=True)  # type: ignore
    show_wood_top: BoolProperty(name="Show Wood Top", default=False)  # type: ignore
    show_decorative_corners: BoolProperty(
        name="Show Decorative Corners", default=False)  # type: ignore
    show_bottom_rail_profile: BoolProperty(
        name="Show Bottom Rail Profile", default=False)  # type: ignore
    # ---- Angled back extension (trapezoidal back) ----
    # Per-cabinet, per-end: extend the BACK corner outward in +X (left or
    # right) by the given amount, splaying that side panel so the back is
    # wider than the front while depth and the front face frame stay
    # square. Used to angle a cabinet's back into an angled wall corner so
    # it provides access into the corner instead of leaving a void. Zero
    # = square (no extension); either / both ends may be extended.
    extend_back_left: FloatProperty(
        name="Extend Back Left X", default=0.0,
        unit='LENGTH', precision=4,
        description="Angle the left side by moving the back-left corner along "
                    "X. Positive moves it outward (-X, back wider than front); "
                    "NEGATIVE moves it inward (back narrower than front, e.g. "
                    "into an acute corner). 0 = square.",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top: BoolProperty(
        name="Furniture Top",
        default=False,
        description="Add an overhanging veneer wood top sitting proud on "
                    "the carcass (dresser / furniture products)",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_thickness: FloatProperty(
        name="Wood Top Thickness", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Thickness of the furniture wood top",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_overhang: FloatProperty(
        name="Wood Top Overhang", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang of the wood top past the carcass on the "
                    "left, right, and front (the back stays flush)",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-side furniture wood top overhang past the carcass. Replaces the
    # single furniture_top_overhang above (kept for backward data compat,
    # used as the legacy fallback in _position_furniture_top). Front / left
    # / right default to 1" (the old uniform default); back defaults to 0"
    # (flush against the wall, the previous fixed behavior).
    furniture_top_overhang_front: FloatProperty(
        name="Wood Top Front Overhang", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang of the wood top past the front of the carcass",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_overhang_back: FloatProperty(
        name="Wood Top Back Overhang", default=0.0, min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang of the wood top past the back of the carcass",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_overhang_left: FloatProperty(
        name="Wood Top Left Overhang", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang of the wood top past the left side of the carcass",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_overhang_right: FloatProperty(
        name="Wood Top Right Overhang", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang of the wood top past the right side of the carcass",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Furniture wood top plan shape. RECTANGLE is the original slab.
    # BOW_BACK bows the back edge outward in a circular arc (the arc's
    # corners stay on the straight back-overhang line; the apex sits
    # furniture_top_bow_altitude past it). RADIUS rounds each plan corner
    # with its own radius. WATERFALL drops a panel from the underside of
    # each end of the top to the floor.
    furniture_top_shape: EnumProperty(
        name="Wood Top Shape",
        items=[
            ('RECTANGLE', "Rectangle", "Square-cornered rectangular top"),
            ('BOW_BACK', "Bow Back",
             "Bow the back edge outward in a circular arc"),
            ('RADIUS', "Radius Edges",
             "Round each corner with its own radius"),
            ('WATERFALL', "Waterfall",
             "Drop the ends of the top to the floor"),
        ],
        default='RECTANGLE',
        description="Plan shape of the furniture wood top",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_bow_altitude: FloatProperty(
        name="Wood Top Bow Altitude", default=units.inch(2.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Bow Back shape: distance from the straight back edge "
                    "to the apex of the arc",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_radius_front_left: FloatProperty(
        name="Wood Top Front Left Radius", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Radius Edges shape: corner radius at the front-left "
                    "corner of the top (0 = square)",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_radius_front_right: FloatProperty(
        name="Wood Top Front Right Radius", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Radius Edges shape: corner radius at the front-right "
                    "corner of the top (0 = square)",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_radius_back_left: FloatProperty(
        name="Wood Top Back Left Radius", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Radius Edges shape: corner radius at the back-left "
                    "corner of the top (0 = square)",
        update=_update_cabinet_dim,
    )  # type: ignore
    furniture_top_radius_back_right: FloatProperty(
        name="Wood Top Back Right Radius", default=units.inch(1.0), min=0.0,
        unit='LENGTH', precision=4,
        description="Radius Edges shape: corner radius at the back-right "
                    "corner of the top (0 = square)",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_left_end_down: BoolProperty(
        name="Extend Left End Down",
        default=False,
        description="Upper cabinets only: drop the LEFT side and left end "
                    "stile below the box (toward the counter) for a hutch "
                    "look. Independent of the right end; box / doors / back "
                    "stay at standard upper height",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_left_end_down_amount: FloatProperty(
        name="Left End Drop", default=units.inch(19.5), min=0.0,
        unit='LENGTH', precision=4,
        description="How far the left side / end stile drops below the box "
                    "bottom (defaults to the wall-cabinet mount minus the "
                    "base-cabinet height - the counter gap)",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_right_end_down: BoolProperty(
        name="Extend Right End Down",
        default=False,
        description="Upper cabinets only: drop the RIGHT side and right end "
                    "stile below the box (toward the counter) for a hutch "
                    "look. Independent of the left end; box / doors / back "
                    "stay at standard upper height",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_right_end_down_amount: FloatProperty(
        name="Right End Drop", default=units.inch(19.5), min=0.0,
        unit='LENGTH', precision=4,
        description="How far the right side / end stile drops below the box "
                    "bottom (defaults to the wall-cabinet mount minus the "
                    "base-cabinet height - the counter gap)",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_sides_down: BoolProperty(
        name="Extend Sides Down",
        default=False,
        description="Upper cabinets only: drop BOTH carcass side panels "
                    "below the box as furniture legs (the over-stool look). "
                    "Unlike Extend Ends Down, ONLY the sides move - the end "
                    "stiles, face frame, doors and box stay at box bottom",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_sides_down_amount: FloatProperty(
        name="Sides Drop", default=units.inch(7.0), min=0.0,
        unit='LENGTH', precision=4,
        description="How far both side panels drop below the box bottom",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Derived, not stored: box height + leg drop. Lets the user type the
    # catalog's overall height directly instead of doing the drop math.
    overall_height: FloatProperty(
        name="Overall Height",
        unit='LENGTH', precision=4,
        description="Total height including the extended legs; writing it "
                    "sets the box height to this value minus the leg drop",
        get=_overall_height_get, set=_overall_height_set,
    )  # type: ignore
    side_front_profile: BoolProperty(
        name="Side Front Profile",
        default=False,
        description="Cut the over-stool decorative profile into the "
                    "bottom-front corner of each extended side panel",
        update=_update_cabinet_dim,
    )  # type: ignore
    bottom_rail_profile: EnumProperty(
        name="Bottom Rail Profile",
        description="Decorative profile cut into the bottom rail (base / "
                    "upper). Options are the '* Cutter' curves in "
                    "face_frame_assets/profiles; the end details stay fixed "
                    "while the middle stretches to the rail length",
        items=_bottom_rail_profile_items,
        update=_update_cabinet_dim,
    )  # type: ignore
    overstool_accessory: EnumProperty(
        name="Leg Accessory",
        items=[
            ('SHELF', "With Shelf",
             "A shelf spanning between the extended sides"),
            ('TOWEL_BAR', "With Towel Bar",
             "A towel bar spanning between the extended sides"),
            ('SHELF_AND_TOWEL_BAR', "With Shelf and Towel Bar",
             "Both a shelf and a towel bar between the extended sides"),
        ],
        default='SHELF',
        description="What hangs between the extended sides (over-stool legs)",
        update=_update_overstool_accessory,
    )  # type: ignore
    hutch_finished_back: BoolProperty(
        name="Finished Back in Recess",
        default=False,
        description="When an upper's ends are extended down, add a finished "
                    "back panel closing the open recess between the dropped "
                    "sides",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_back_right: FloatProperty(
        name="Extend Back Right X", default=0.0,
        unit='LENGTH', precision=4,
        description="Angle the right side by moving the back-right corner along "
                    "X. Positive moves it outward (+X, back wider than front); "
                    "NEGATIVE moves it inward (back narrower than front, e.g. "
                    "into an acute corner). 0 = square.",
        update=_update_cabinet_dim,
    )  # type: ignore
    # ---- Wing Attached (convert the back extension into a wing) ----
    # Per-cabinet, per-end modifier of extend_back_left / extend_back_right.
    # When ON (and that end's extend is non-zero): instead of splaying the
    # carcass into a trapezoid, keep the carcass SQUARE and add a flat wing
    # panel along the SAME angled line the extension would have used. So the
    # wing's angle / depth come entirely from the extend value - no separate
    # size. No-op when that end's extend is 0. Built in the cabinet recalc
    # (_apply_back_extension branches on these).
    wing_attached_left: BoolProperty(
        name="Attach Left as Wing",
        default=False,
        description="Convert the LEFT end's back extension into an attached "
                    "wing: keep the carcass square and add a flat angled panel "
                    "along the extension line. No effect when Extend Back Left "
                    "is 0.",
        update=_update_cabinet_dim,
    )  # type: ignore
    wing_attached_right: BoolProperty(
        name="Attach Right as Wing",
        default=False,
        description="Convert the RIGHT end's back extension into an attached "
                    "wing: keep the carcass square and add a flat angled panel "
                    "along the extension line. No effect when Extend Back Right "
                    "is 0.",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Optional manual wing size: the run of the wing panel measured from
    # the cabinet's front corner along the extension line. 0 = automatic
    # (the full line, front corner to the extended back corner). Lets the
    # wing stop short when the automatic reach would run past the end of
    # a wall. The front edge stays anchored on the cabinet regardless.
    wing_width_left: FloatProperty(
        name="Left Wing Width", default=0.0, min=0.0,
        unit='LENGTH', precision=4,
        description="Width of the LEFT wing panel from the cabinet front "
                    "corner along the extension line. 0 = size automatically "
                    "from the extension.",
        update=_update_cabinet_dim,
    )  # type: ignore
    wing_width_right: FloatProperty(
        name="Right Wing Width", default=0.0, min=0.0,
        unit='LENGTH', precision=4,
        description="Width of the RIGHT wing panel from the cabinet front "
                    "corner along the extension line. 0 = size automatically "
                    "from the extension.",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Extend Bottom (uppers): push the carcass bottom panel laterally past
    # the side(s) to cover the void left in a corner where two uppers meet.
    # Outward only (min 0); only the bottom panel overhangs - the face frame,
    # sides, and doors stay square. Applied in _apply_bottom_extension.
    extend_bottom_left: FloatProperty(
        name="Extend Bottom Left X", default=0.0, min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang the carcass bottom past the LEFT side by this "
                    "amount to cover a corner void. 0 = flush with the side.",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_bottom_right: FloatProperty(
        name="Extend Bottom Right X", default=0.0, min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang the carcass bottom past the RIGHT side by this "
                    "amount to cover a corner void. 0 = flush with the side.",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Extend Top (uppers): same idea for the carcass top panel, covering the
    # void above the corner meeting. Applied in _apply_top_extension.
    extend_top_left: FloatProperty(
        name="Extend Top Left X", default=0.0, min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang the carcass top past the LEFT side by this "
                    "amount to cover a corner void. 0 = flush with the side.",
        update=_update_cabinet_dim,
    )  # type: ignore
    extend_top_right: FloatProperty(
        name="Extend Top Right X", default=0.0, min=0.0,
        unit='LENGTH', precision=4,
        description="Overhang the carcass top past the RIGHT side by this "
                    "amount to cover a corner void. 0 = flush with the side.",
        update=_update_cabinet_dim,
    )  # type: ignore
    inset_toe_kick_left: FloatProperty(
        name="Inset Toe Kick Left", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    inset_toe_kick_right: FloatProperty(
        name="Inset Toe Kick Right", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Corner cabinets only: pull each arm's rear (wall-side) toe-kick /
    # loose-ladder rail away from its wall by this amount (left arm off
    # the left wall, right arm off the back wall). 0 = flush to the wall.
    inset_toe_kick_back_left: FloatProperty(
        name="Inset Toe Kick Back Left", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    inset_toe_kick_back_right: FloatProperty(
        name="Inset Toe Kick Back Right", default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    include_finish_toe_kick: BoolProperty(
        name="Include Finish Toe Kick", default=True,
        update=_update_cabinet_dim,
    )  # type: ignore

    include_external_nailer: BoolProperty(name="Include External Nailer", default=False)  # type: ignore
    include_internal_nailer: BoolProperty(name="Include Internal Nailer", default=False)  # type: ignore
    include_thin_finished_bottom: BoolProperty(name="Include 1/4 Finished Bottom", default=False)  # type: ignore
    include_thick_finished_bottom: BoolProperty(name="Include 3/4 Finished Bottom", default=False)  # type: ignore
    include_blocking: BoolProperty(name="Include Blocking", default=False)  # type: ignore

    # ---- Corner cabinet props (PIE_CUT / DIAGONAL / CORNER_DRAWER) and
    # angled standard cabinets ----
    # corner_type defaults to NONE on regular cabinets. left_depth and
    # right_depth serve two roles:
    #   - Corner cabinets: perpendicular stub-side lengths along each
    #     wall (always authoritative when corner_type != NONE).
    #   - Standard single-bay cabinets: per-side depths used when
    #     unlock_left_depth / unlock_right_depth is on, producing an
    #     angled face frame plane (face frame becomes the hypotenuse;
    #     back stays at cab_props.depth between the sides).
    # Width / depth tweaks propagate through recalc via
    # _update_cabinet_dim.
    corner_type: EnumProperty(
        name="Corner Type",
        items=[
            ('NONE', "None", "Not a corner cabinet"),
            ('PIE_CUT', "Pie Cut", "Pie cut corner cabinet"),
            ('DIAGONAL', "Diagonal", "Diagonal corner cabinet with angled front face"),
            ('PIE_CUT_DRAWER', "Pie Cut Drawer", "Pie cut corner drawer base: 45-degree channel carcass with stacked drawer fronts"),
        ],
        default='NONE',
    )  # type: ignore
    left_depth: FloatProperty(
        name="Left Depth", default=units.inch(24.0),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_depth: FloatProperty(
        name="Right Depth", default=units.inch(24.0),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Angled standard cabinet unlocks. Single-bay only (UI hides them
    # when bay count > 1). When on, the matching left_depth / right_depth
    # drives that side's depth; when off, the side falls back to
    # cab_props.depth and the face frame stays square to the back.
    unlock_left_depth: BoolProperty(
        name="Unlock Left Depth", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_right_depth: BoolProperty(
        name="Unlock Right Depth", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore

    # ---- Pie cut corner options ----
    # exterior_option: door / front configuration on the L-front faces.
    # interior_option: rotating-shelf accessory inside the cabinet.
    # tray_compartment: optional partitioned tray storage on one side.
    # All three are wired to recalc but only the LEFT/RIGHT door-opens-
    # first variants currently affect geometry; the rest are UI stubs.
    exterior_option: EnumProperty(
        name="Exterior Option",
        items=[
            ('LEFT_DOOR_OPENS_FIRST',  "Left Door Opens First",  "Left door tucks behind right at the corner"),
            ('RIGHT_DOOR_OPENS_FIRST', "Right Door Opens First", "Right door tucks behind left at the corner"),
            ('BIFOLD_LEFT_SWING',      "Bi-fold Left Swing",     "Bi-fold pair hinged on the left, pull leads on the right"),
            ('BIFOLD_RIGHT_SWING',     "Bi-fold Right Swing",    "Bi-fold pair hinged on the right, pull leads on the left"),
            ('REVOLVING_DOORS',        "Revolving Doors",        "Door rotates with the susan inside"),
        ],
        default='LEFT_DOOR_OPENS_FIRST',
        update=_update_corner_option,
    )  # type: ignore
    interior_option: EnumProperty(
        name="Interior Option",
        items=[
            ('NONE',                       "None",                                  "No interior accessory"),
            ('POLYMER_KIDNEY_SUSANS_POLE', "Polymer Kidney Susans on Pole",         "Polymer kidney susans on a center pole"),
            ('WOOD_KIDNEY_SUSANS_POLE',    "Wood Kidney Susans on Pole",            "Wood kidney susans on a center pole"),
            ('POLYMER_PIE_CUT_REVOLVING',  "Polymer Pie-cut Revolving Door Susans", "Polymer revolving-door susans for a pie-cut corner"),
            ('WOOD_PIE_CUT_REVOLVING',     "Wood Pie-Cut Revolving Door Susans",    "Wood revolving-door susans for a pie-cut corner"),
            ('SUPER_SUSANS',               "Super Susans",                          "Round rotating shelves on bearings"),
            ('NOT_SO_LAZY_SUSANS',         "Not So Lazy Susan",                     "Pan storage with hooks plus a lower tray"),
        ],
        default='NONE',
        update=_update_corner_option,
    )  # type: ignore
    # Finish the corner cabinet's interior: the cavity-facing surfaces
    # of the sides / backs / top / bottom and the corner shelves take
    # the exterior finish material instead of the interior material.
    # Corner cabinets have no bay / opening cages, so the per-bay
    # finish_bay / finish_opening flags standard cabinets use can't
    # reach them - this cabinet-level toggle is their equivalent.
    corner_finish_interior: BoolProperty(
        name="Finish Interior",
        description="Use the exterior finish material on the interior surfaces and shelves of this corner cabinet",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Drop the carcass bottom + FF bottom rail so the lowest opening
    # runs to the carcass floor. The corner equivalent of a bay's
    # remove_bottom (corner cabinets have no bay cages). Previously the
    # Hutch / Open with Shelves diagonal upper configs forced this;
    # it's now user-controlled and available on any config.
    corner_remove_bottom: BoolProperty(
        name="Remove Bottom",
        description="Remove the carcass bottom and the bottom rail; the lowest opening runs to the carcass floor",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # ---- Finished bottom (uppers) ----
    # Finished bottom condition, matching the upper-bottom detail
    # card's options. Any non-NONE choice builds the finish panel with
    # an LED route cut near its front edge; the light toggle adds a
    # Blender area light in the route for renders.
    finished_bottom_type: EnumProperty(
        name="Finished Bottom",
        description="Finished bottom condition for this upper cabinet",
        items=[
            ('NONE', "None", "No finished bottom panel"),
            ('QUARTER', "1/4\"",
             "1/4\" finished bottom under the cabinet bottom"),
            ('THREE_QUARTER', "3/4\"",
             "3/4\" finished bottom under the cabinet bottom"),
            ('QUARTER_FLUSH', "1/4\" Flush",
             "1/4\" finished bottom, flush at the rail bottom"),
            ('THREE_QUARTER_FLUSH', "3/4\" Flush",
             "3/4\" finished bottom, flush at the rail bottom"),
        ],
        default='NONE',
        update=_update_cabinet_dim,
    )  # type: ignore
    # LED route: opt-in groove across the finish panel's underside,
    # with adjustable size and location. The render light rides the
    # route (no route, no light).
    finished_bottom_led_route: BoolProperty(
        name="LED Route",
        description="Cut an LED route into the finished bottom's underside",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    finished_bottom_route_width: FloatProperty(
        name="Route Width",
        description="Front-to-back width of the LED route",
        default=units.inch(0.875), min=units.inch(0.125),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    finished_bottom_route_depth: FloatProperty(
        name="Route Depth",
        description="How deep the route cuts into the panel (clamped to leave material above)",
        default=units.inch(0.375), min=units.inch(0.0625),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    finished_bottom_route_inset: FloatProperty(
        name="Route Inset",
        description="Distance from the panel's front edge to the front of the route",
        default=units.inch(1.5), min=0.0,
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    finished_bottom_light: BoolProperty(
        name="LED Light",
        description="Add an area light in the LED route for renders",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-bay scope: comma-separated hb_segment_start_bay keys of the
    # carcass-bottom segments that get the finish panel. Empty covers
    # every segment (whole cabinet - the pre-scope behavior).
    finished_bottom_bays: StringProperty(
        name="Finished Bottom Bays",
        description="Bottom segments the finished bottom applies to; empty applies to all",
        default='',
        update=_update_cabinet_dim,
    )  # type: ignore

    # Sink apron height for the diagonal SINK_DOORS config: a fixed
    # face-frame-depth panel across the top of the door opening, behind
    # the full-height doors. The corner counterpart of the per-opening
    # apron_height (corner cabinets have no opening cages).
    corner_apron_height: FloatProperty(
        name="Apron Height",
        description="Height of the sink apron panel behind the full-height doors",
        default=units.inch(7.0), unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_compartment: EnumProperty(
        name="Tray Compartment",
        items=[
            ('NONE',  "None",  "No tray compartment"),
            ('LEFT',  "Left",  "Tray compartment on the left side"),
            ('RIGHT', "Right", "Tray compartment on the right side"),
        ],
        default='NONE',
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_compartment_width: FloatProperty(
        name="Tray Compartment Width",
        description="Clear width of the tray storage strip walled off by the partition",
        default=units.inch(6.0),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_compartment_qty: IntProperty(
        name="Tray Divider Qty",
        description="Number of dividers inside the tray compartment (slots = qty + 1)",
        default=3, min=0, max=10,
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_compartment_divider_thickness: FloatProperty(
        name="Tray Divider Thickness",
        default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_compartment_setback: FloatProperty(
        name="Tray Divider Setback",
        description="Front setback of the tray compartment dividers from the face frame",
        default=units.inch(1.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    exterior_config: EnumProperty(
        name="Exterior Config",
        description="Stacked-section layout of a diagonal corner cabinet front",
        items=_exterior_config_items,
        update=_update_exterior_config,
    )  # type: ignore
    # Door swing for the diagonal face's DOORS sections. Per-cabinet,
    # applied to every DOORS section (matches the pie cut's per-cabinet
    # exterior_option swing handling). The single swings build one
    # full-width leaf hinged on the named edge, pull on the unhinged
    # edge. Default LEFT_SWING (was DOUBLE_DOOR historically; changed
    # by request -- note an old blend's diagonal cabinet left at the
    # default will read LEFT_SWING after this change and flip on its
    # next recalc).
    diag_door_swing: EnumProperty(
        name="Door Swing",
        description="Door leaf layout for the diagonal face's door sections",
        items=[
            ('DOUBLE_DOOR', "Double Door", "Pair of doors meeting at the center, hinged on the outer edges"),
            ('LEFT_SWING',  "Left Swing",  "Single full-width door hinged on the left edge"),
            ('RIGHT_SWING', "Right Swing", "Single full-width door hinged on the right edge"),
        ],
        default='LEFT_SWING',
        update=_update_cabinet_dim,
    )  # type: ignore
    clip_back_amount: FloatProperty(
        name="Clip Back",
        description="Length of the 45 degree clip taken off each wall side at the rear corner (0 = no clip)",
        default=units.inch(6.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    mid_stile_widths: CollectionProperty(type=Face_Frame_Mid_Stile_Width)  # type: ignore
    # Cabinet columns: split turnings applied over stiles, keyed by
    # stile (LEFT / RIGHT / MID_<gap>). See cabinet_column.py.
    cabinet_columns: CollectionProperty(type=Face_Frame_Cabinet_Column)  # type: ignore
    corner_sections: CollectionProperty(type=Face_Frame_Corner_Section)  # type: ignore
    pie_drawer_qty: IntProperty(
        name="Drawer Qty",
        description="Number of stacked drawers in a pie-cut drawer corner; the top opening defaults to the Top Drawer Opening Height for 3 or 4 drawers",
        default=3, min=2, max=4,
        update=_update_pie_drawer_qty,
    )  # type: ignore


class Face_Frame_Bay_Props(PropertyGroup):
    """Per-bay state for face frame cabinets. Attached to each bay's cage
    object as bpy.types.Object.face_frame_bay.

    Each bay carries its own width, height, depth, kick height, top offset,
    plus per-bay rail widths. Unlock toggles mark bays that hold their values
    independently of cabinet-level defaults.
    """

    bay_index: IntProperty(
        name="Bay Index",
        description="Position in the parent cabinet's bay list (0-based)",
        default=0,
    )  # type: ignore

    width: FloatProperty(
        name="Width", default=units.inch(18.0), unit='LENGTH', precision=4,
        update=_update_bay_width,
    )  # type: ignore
    height: FloatProperty(
        name="Height", default=units.inch(34.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    depth: FloatProperty(
        name="Depth", default=units.inch(24.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    kick_height: FloatProperty(
        name="Kick Height", default=units.inch(4.0), unit='LENGTH', precision=4,
        update=_update_bay_kick_height,
    )  # type: ignore
    top_offset: FloatProperty(
        name="Top Offset",
        description="Distance from cabinet top to top of this bay's opening",
        default=0.0,
        unit='LENGTH',
        precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    front_drop: FloatProperty(
        name="Front Drop",
        description="Lower this bay's FRONT construction (top rail and front "
                    "stretcher) below the bay top for a sink or cooktop. The "
                    "back, rear stretcher, sides and end stiles stay full "
                    "height",
        default=0.0, min=0.0,
        unit='LENGTH',
        precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # ---- Front-drop fillers: fit a farm sink / cooktop to the drop ----
    # With a front_drop set, up to two filler stiles can be added in the
    # dropped band (above the dropped top rail, between the bay's bounding
    # stiles) so the clear width matches the appliance. Mirrors the
    # APPLIANCE opening's filler model: set-width mode splits the remainder
    # into equal left/right fillers; direct mode types each side. Gated by
    # front_drop_include_fillers so a drop can exist without fillers.
    front_drop_include_fillers: BoolProperty(
        name="Include Drop Fillers",
        description="Build filler stiles in the dropped band so the clear "
                    "width fits the farm sink / cooktop",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    front_drop_set_appliance_width: BoolProperty(
        name="Set Appliance Width",
        description="Enter the appliance width and split the remainder into "
                    "equal left/right fillers; off lets you type each filler "
                    "width directly",
        default=True, update=_update_cabinet_dim,
    )  # type: ignore
    front_drop_appliance_width: FloatProperty(
        name="Appliance Width",
        description="Width of the farm sink / cooktop the dropped band must "
                    "fit; fillers fill the remainder",
        default=units.inch(30.0), unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    front_drop_left_filler: FloatProperty(
        name="Left Drop Filler",
        description="Width of the left drop filler stile (used directly when "
                    "Set Appliance Width is off)",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    front_drop_right_filler: FloatProperty(
        name="Right Drop Filler",
        description="Width of the right drop filler stile (used directly when "
                    "Set Appliance Width is off)",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore

    top_rail_width: FloatProperty(
        name="Top Rail Width", default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    bottom_rail_width: FloatProperty(
        name="Bottom Rail Width", default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    remove_bottom: BoolProperty(
        name="Remove Bottom", default=False,
        update=_update_remove_bottom,
    )  # type: ignore
    remove_carcass: BoolProperty(
        name="Remove Carcass", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-bay override: when True this bay behaves as FLOATING regardless
    # of the cabinet's toe_kick_type. Sides under an end bay anchor at the
    # bay bottom rather than the floor, and kick subfront / finish kick
    # segments skip this bay. Bay kick_height is the lift amount.
    floating_bay: BoolProperty(
        name="Floating", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Appliance garage (uppers): this bay extends down to the countertop
    # with a garage opening pinned to the added zone; the rest of the
    # cabinet keeps its mount height. See _update_bay_appliance_garage.
    appliance_garage: BoolProperty(
        name="Appliance Garage", default=False,
        description="Extend THIS bay down to the countertop with a "
                    "garage opening below its doors; other bays keep "
                    "their height",
        update=_update_bay_appliance_garage,
    )  # type: ignore
    apron_bay: BoolProperty(name="Apron Bay", default=False)  # type: ignore
    # Finished interior: the exterior finish material reads inside this
    # bay's opening, realized by adding finish-material liner panels on
    # the left / right / top / back inner faces (a shared carcass back /
    # top can't be re-materialed per-bay, so dedicated liner parts carry
    # the finish). finish_bay_flush brings those liners flush with the
    # face frame opening and runs them only finish_bay_flush_depth back
    # into the opening - the common "refrigerator opening finished flush
    # X inches" case. Flush off = liner lines the full cavity depth.
    finish_bay: BoolProperty(
        name="Finish Bay", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    finish_bay_flush: BoolProperty(
        name="Finish Flush", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    finish_bay_flush_depth: FloatProperty(
        name="Flush Depth", default=0.0, unit='LENGTH', precision=4,
        description="How far the flush finish runs back into the opening; "
                    "0 runs the full cavity depth",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Which of the cabinet style's two materials the finished bay shows
    # on its liner panels and shelves. FINISH = the exterior finish
    # (historic behavior); INTERIOR = the style's interior material, for
    # a finished opening colored differently from the face frame.
    finish_bay_material: EnumProperty(
        name="Finish Color",
        items=[('FINISH', "Exterior Finish",
                "Liner panels and shelves take the cabinet's exterior finish"),
               ('INTERIOR', "Interior Material",
                "Liner panels and shelves take the style's interior material")],
        default='FINISH',
        update=_update_cabinet_dim,
    )  # type: ignore
    # Texture carved into this bay's liner panels. Anything but NONE also
    # brings a BACK liner in on a finished bay, where the carcass back is
    # finish stock and would otherwise be the flat surface behind the
    # texture.
    finish_bay_texture: EnumProperty(
        name="Interior Texture",
        description="Texture carved into the finished interior's panels",
        items=INTERIOR_TEXTURE_ITEMS, default='NONE',
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-bay bottom-rail profile override. CABINET follows the cabinet-
    # level pick; NONE forces a plain rail on this bay; any profile id
    # cuts just this bay's rail segment -- so split rails can carry e.g.
    # one arched valance bay between plain neighbours.
    bottom_rail_profile: EnumProperty(
        name="Bottom Rail Profile",
        items=_bay_bottom_rail_profile_items,
        update=_update_cabinet_dim,
    )  # type: ignore

    # UI-only toggle: in the cabinet_prompts popup each bay shows just
    # its size by default; flipping this expands the bay's secondary
    # properties (kick height, top offset, rails, flags) inline. Per-
    # bay so each bay collapses independently.
    prompts_expanded: BoolProperty(
        name="Show More Bay Properties",
        description="Expand secondary properties for this bay in the cabinet prompts popup",
        default=False,
    )  # type: ignore

    unlock_width: BoolProperty(
        name="Unlock Width",
        description="Hold this bay's width during gang-construction redistribution",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_height: BoolProperty(
        name="Unlock Height", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Back type for THIS bay, over the cabinet's own back. Backs are a
    # cabinet-level setting by default; a bay that carries its own is
    # built at its own depth, which is what makes a run of bays at
    # different depths read right from behind. WORKING_FF also drops the
    # carcass back, since a working front needs the bay open behind it.
    # The textured backs (beadboard / shiplap / v-groove / flush X) stay
    # cabinet-level for now - they are built by a different reconciler.
    back_condition: EnumProperty(
        name="Back Type",
        description="Back construction for this bay. Cabinet Default "
                    "follows the cabinet's own back",
        items=[
            ('DEFAULT', "Cabinet Default",
             "Follow the cabinet's back type"),
            ('UNFINISHED', "Unfinished",
             "Plain carcass back, nothing applied"),
            ('FINISHED', "Finished",
             "Finished panel applied over this bay's back"),
            ('PANELED', "Paneled",
             "Applied panel with rails and stiles on this bay's back"),
            ('FALSE_FF', "False Face Frame",
             "Applied frame with non-working fronts on this bay's back"),
            ('WORKING_FF', "Working Face Frame",
             "Applied frame with working fronts on this bay's back, for "
             "access from behind. The carcass back is left off"),
        ],
        default='DEFAULT',
        update=_update_cabinet_dim,
    )  # type: ignore

    unlock_depth: BoolProperty(
        name="Unlock Depth", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_kick_height: BoolProperty(
        name="Unlock Kick Height", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_top_offset: BoolProperty(
        name="Unlock Top Offset", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_top_rail: BoolProperty(
        name="Unlock Top Rail", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_bottom_rail: BoolProperty(
        name="Unlock Bottom Rail", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore

    # ---- Under-cabinet appliance (uppers) ----
    # A microwave or short vent hood hanging under this bay. Block
    # geometry only, sized to the real appliance, so it reads in 3D and
    # lands on the elevations; detailed models ship separately and are
    # swapped in over the block. The opening resizes around it - see
    # _sync_under_cabinet_opening.
    under_cabinet_appliance: EnumProperty(
        name="Under Cabinet Appliance",
        description="Appliance hanging under this bay",
        items=[
            ('NONE',      "None",       "Nothing under this bay"),
            ('MICROWAVE', "Microwave",  "Over-the-range microwave"),
            ('HOOD',      "Hood",       "Short under-cabinet vent hood"),
        ],
        default='NONE', update=_update_under_cabinet_appliance,
    )  # type: ignore
    under_cabinet_appliance_width: FloatProperty(
        name="Appliance Width",
        description="Width of the appliance under this bay; the opening "
                    "resizes to it. 0 leaves the widths alone",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_under_cabinet_appliance,
    )  # type: ignore
    under_cabinet_appliance_height: FloatProperty(
        name="Appliance Height",
        description="How far the appliance hangs below the bay; the "
                    "opening is raised by this much to make room",
        default=units.inch(16.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_under_cabinet_appliance,
    )  # type: ignore
    under_cabinet_appliance_finish: EnumProperty(
        name="Appliance Finish",
        description="Metal finish on the appliance under this bay",
        items=_appliance_finish_enum_items,
        update=_update_cabinet_dim,
    )  # type: ignore
    under_cabinet_appliance_depth: FloatProperty(
        name="Appliance Depth",
        description="Front-to-back depth of the appliance, measured from "
                    "the back of the cabinet",
        default=units.inch(15.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore


class Face_Frame_Rollout_Box(bpy.types.PropertyGroup):
    """One drawer box in a ROLLOUT stack. Each box carries its own height
    so a stack can mix sizes; height_preset picks a standard size (or
    Custom to type one). The preset writes its value into `height`, which
    the solver reads when stacking the boxes bottom to top.
    """
    height_preset: EnumProperty(
        name="Height",
        description="Standard rollout box height, or Custom to type an exact value",
        items=ROLLOUT_HEIGHT_PRESET_ITEMS, default='IN_3_625',
        update=_update_rollout_box_preset,
    )  # type: ignore
    height: FloatProperty(
        name="Box Height",
        description="Height of this rollout drawer box",
        default=units.inch(3.625), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # U-shaped rollout: same notch the sink duo drawer cuts, but per BOX
    # rather than per opening -- a stack under a sink usually needs the
    # top box wrapped around the plumbing and the lower one left whole.
    # Field names match the opening's sink_duo_* so _apply_sink_duo_notch
    # reads either one unchanged.
    # Workstation culinary-kit roll-out: a 1/2 in plywood top over the
    # box with the opening the kit's bowl or bins drop through.
    galley_top: EnumProperty(
        name="Top Opening",
        description="A 1/2 in top over this box with an opening for a workstation's culinary kit",
        items=[
            ('NONE', "None", "No top"),
            ('BOWL_10', "10 1/2 in Bowl", "Top with a 10 1/2 in round opening"),
            ('BOWL_14', "14 in Bowl", "Top with a 14 in round opening"),
            ('BINS', "Two Bins", "Top with two 6 1/8 x 3 5/8 in openings"),
        ],
        default='NONE', update=_update_cabinet_dim,
    )  # type: ignore
    sink_duo: BoolProperty(
        name="U-Shaped Box",
        description="Notch this rollout box from the back so it wraps "
                    "the sink basin / plumbing",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    sink_duo_notch_width: FloatProperty(
        name="Notch Width",
        description="Width of the U-notch, centered across the box",
        default=units.inch(9.0), unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    sink_duo_notch_depth: FloatProperty(
        name="Notch Depth",
        description="How far the U-notch reaches into the box from the "
                    "back; 0 uses two-thirds of the box depth",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore


class Face_Frame_Interior_Item(bpy.types.PropertyGroup):
    """One interior item attached to an opening - shelf, accessory, etc.
    Holds every kind's data side-by-side; the recalc reads only the
    fields relevant to the active kind. New kinds add their own fields
    here and a mapping in INTERIOR_KIND_TO_ROLE.

    Field naming convention:
      - shared shelf-like fields use shelf_*
      - shared multi-count assembly fields (PULLOUT_SHELF, ROLLOUT) use
        the bare names qty / unlock_qty / spacer_height / item_setback /
        bottom_gap / distance_between / item_height
      - kind-specific fields use the kind as a prefix (tray_*, vanity_*)
    """

    INTERIOR_KIND_ITEMS = [
        ('ADJUSTABLE_SHELF', "Adjustable Shelves", "Set of evenly-spaced shelves on shelf pins"),
        ('GLASS_SHELF',      "Glass Shelves",      "Adjustable shelves with a glass material override"),
        ('PULLOUT_SHELF',    "Roll-out Shelves",   "Stack of flat shelves on slide hardware"),
        ('ROLLOUT',          "Roll-outs",          "Stack of drawer boxes on slide hardware"),
        ('TRAY_DIVIDERS',    "Tray Dividers",      "Vertical dividers for trays / cookie sheets, optionally with a locked shelf above"),
        ('VANITY_SHELVES',   "Vanity Shelves",     "Pair of L/R shelves on corbel supports, around plumbing"),
        # Called "Text" because that is all it does: no geometry, just a
        # label in the opening and on the drawings. It sat in this list
        # named "Accessory" next to the items that build something, and
        # next to the accessory browser that adds real catalog products,
        # which left designers unsure which one they had reached for.
        # The identifier stays ACCESSORY - saved files, the drawer
        # inserts and the legend all key off it.
        ('ACCESSORY',        "Text",               "A line of text shown inside the opening - a label only, nothing is built"),
        # Tableware & Bar Storage Solutions (catalog printed pages
        # 293-295). All auto-sized from the opening per the catalog
        # charts; geometry lives in bar_storage.py. Appended at the end
        # so saved files keep their stored enum indices.
        ('WINE_CUBBY',       "Wine Storage Cubby", "WRC: 1/2\" plywood cubbies, openings 4\"-6\" equally spaced"),
        ('WINE_CELLAR',      "Wine Cellar Rack",   "WRWCR: 3/4\" hardwood grid with exact 4\" x 4\" bottle openings"),
        ('WINE_LATTICE',     "Lattice Wine Rack",  "WRL: 45-degree lattice, max 3-3/4\" square bottle openings"),
        ('WINE_X',           "X-Style Wine Rack",  "WRXS/WRXR: two panels crossing corner to corner"),
        ('WINE_DIAGONAL',    "Diagonal Wine Dividers", "WRD: parallel 45-degree dividers spaced equally 4\"-7\""),
        ('WINE_HALF_CIRCLE', "Half Circle Wine Rack",  "WRHC: scalloped rails, bottles 5\" on center"),
        ('STEMWARE_RACK',    "Stemware Rack",      "SR: slotted hardwood slats at the top of the opening, slots 4\" on center"),
        ('PLATE_RACK',       "Plate Rack",         "PR: 3/8\" birch dowels 2\" on center"),
        ('CLOSET_ROD',       "Closet Rod",         "CR: hang rod across the opening, set down from the opening top"),
        # Appended at the end (same reason as above): a distinct kind so
        # the dropdown offers it directly. Solver emits ADJUSTABLE_SHELF
        # parts with the front edge at a set fraction of the cavity depth.
        ('HALF_DEPTH_SHELF', "Half Depth Shelves", "Adjustable shelves whose depth is half the opening depth"),
        ('QUARTER_DEPTH_SHELF', "Quarter Depth Shelves", "Adjustable shelves whose depth is a quarter of the opening depth"),
    ]
    kind: EnumProperty(
        name="Kind", items=INTERIOR_KIND_ITEMS, default='ADJUSTABLE_SHELF',
        update=_update_cabinet_dim,
    )  # type: ignore

    # ADJUSTABLE_SHELF / GLASS_SHELF
    # shelf_qty is auto-recomputed from opening height every recalc
    # while unlock_shelf_qty is False. Set unlock_shelf_qty to True to
    # pin a specific count and stop the auto-recompute.
    shelf_qty: IntProperty(
        name="Shelf Qty", default=1, min=0, max=20,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_shelf_qty: BoolProperty(
        name="Unlock Shelf Qty",
        description="When on, hold the shelf count at the value above instead of auto-computing it from the opening's height",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    # Front setback for shelf-likes. Default = standard pin clearance;
    # the half-depth preset bumps this to 6" for a half-depth feel.
    shelf_setback: FloatProperty(
        name="Shelf Setback",
        description="Distance the shelf is pulled back from the front of the cavity",
        default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Vertical anchor: lifts the item's zone up from the opening bottom.
    # Shelf stacks distribute in the space above it; tray dividers start
    # at it. Lets several items share one opening without overlapping
    # (e.g. tray dividers below, shelves above).
    bottom_offset: FloatProperty(
        name="From Bottom",
        description="Raise this item's zone up from the bottom of the opening; shelves spread out in the space above",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Finished-opening nosing on the shelf front edge (ADJUSTABLE_SHELF
    # only). Clover / Kelli match the shelf thickness; the extra-height
    # styles read shelf_nosing_height. The old 1-1/4"..3" catalog range
    # is no longer enforced -- custom jobs run outside it; only a tiny
    # floor remains so a zero height can't build degenerate geometry.
    shelf_nosing_style: EnumProperty(
        name="Shelf Nosing",
        description="Finished-opening nosing profile applied to the front edge of each shelf",
        items=shelf_nosing.NOSING_STYLE_ITEMS, default='NONE',
        update=_update_cabinet_dim,
    )  # type: ignore
    shelf_nosing_height: FloatProperty(
        name="Nosing Height",
        description="Overall height of an extra-height nosing. Clover / Kelli ignore this and match the shelf thickness",
        default=units.inch(1.5), min=units.inch(0.125),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # PULLOUT_SHELF / ROLLOUT
    # Multi-count assembly fields. qty defaults to 2 (typical use); the
    # auto rule (when unlock_qty is False) fills the opening from
    # item_height + distance_between.
    qty: IntProperty(
        name="Qty", default=2, min=0, max=10,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_qty: BoolProperty(
        name="Unlock Qty",
        description="When on, hold the count at the value above instead of auto-computing it from the opening's height",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    # LEGACY -- no longer read. Rollout and pullout-shelf spacer
    # dimensions are fixed / computed in the solver
    # (ASSEMBLY_SPACER_WIDTH + per-side reveals). Kept so saved files
    # with the old value still load cleanly.
    spacer_height: FloatProperty(
        name="Spacer Width",
        description="Width of the side spacer parts the slides mount to (front and back, both sides)",
        default=units.inch(2.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    item_setback: FloatProperty(
        name="Item Setback",
        description="Front setback for each item in the stack",
        default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    bottom_gap: FloatProperty(
        name="Bottom Gap",
        description="Gap below the bottom-most item in the stack",
        default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    distance_between: FloatProperty(
        name="Distance Between",
        description="Vertical gap between consecutive items in the stack",
        default=units.inch(6.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Split per kind because the natural defaults are far apart: a
    # pullout shelf is 0.75" stock; a rollout drawer box is ~3.625" tall.
    # Sharing the field would force one or the other to be wrong on
    # creation and on kind switches.
    pullout_thickness: FloatProperty(
        name="Pullout Thickness",
        description="Thickness of each pullout shelf (PULLOUT_SHELF only)",
        default=units.inch(0.75), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    rollout_height: FloatProperty(
        name="Rollout Height",
        description="Height of each rollout drawer box (ROLLOUT only)",
        default=units.inch(3.625), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-box rollout heights: each ROLLOUT box is an entry here with its
    # own height, so a stack can mix sizes. Empty on items saved before this
    # field; the recalc seeds it once from rollout_height x qty (migration)
    # and the solver falls back to that uniform stack until it does. For a
    # ROLLOUT the box count is len(rollout_boxes); qty/unlock_qty are now
    # PULLOUT_SHELF-only.
    rollout_boxes: CollectionProperty(type=Face_Frame_Rollout_Box)  # type: ignore
    rollout_boxes_index: IntProperty(default=0)  # type: ignore
    # Explicit rollout box depth; 0 = automatic (cavity depth less the
    # front setback). A typed value shortens the boxes at the BACK -
    # e.g. 18" deep rollouts clearing a pipe run behind them.
    rollout_depth: FloatProperty(
        name="Rollout Depth",
        description="Depth of the rollout boxes; 0 fits the cavity "
                    "automatically. A typed depth shortens the boxes at "
                    "the back (e.g. to clear plumbing behind them)",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Omit the four slide-mount spacer parts for this ROLLOUT or
    # PULLOUT_SHELF. One fixed at the floor mounts straight to the
    # cabinet, so no spacer/ladder assembly is wanted (or manufactured)
    # for it. Shared by both kinds - they build the same assembly.
    hide_rollout_spacers: BoolProperty(
        name="Hide Spacer Ladders",
        description="Don't build the side spacer ladders the slides "
                    "mount to - e.g. a single rollout or shelf fixed at "
                    "the floor that needs no spacer assembly",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    # How far up the opening the spacer ladders run. 0 = the full
    # opening height, which is how they have always built. A typed
    # height stops them short so what sits above - adjustable shelves,
    # say - clears them instead of being notched around them.
    rollout_spacer_height: FloatProperty(
        name="Spacer Ladder Height",
        description="Height the side spacer ladders run to. 0 runs them "
                    "the full height of the opening",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Finger scoop, the notch in the front of a rollout box that gives
    # you somewhere to pull. It is how these are built, so it is ON by
    # default and an existing job picks it up the next time its cabinet
    # recalculates - a box drawn square was understating what the shop
    # was already making.
    finger_scoop: BoolProperty(
        name="Finger Scoop",
        description="Cut the finger scoop into the front of each rollout "
                    "box (ROLLOUT only). On by default - it is standard "
                    "construction; turn it off for a square front",
        default=True, update=_update_cabinet_dim,
    )  # type: ignore

    # TRAY_DIVIDERS
    # Vertical dividers; tray_remove_shelf=False adds a horizontal locked
    # shelf at tray_opening_height that the dividers stop against.
    tray_qty: IntProperty(
        name="Tray Qty", default=3, min=1, max=10,
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_remove_shelf: BoolProperty(
        name="Remove Locked Shelf",
        description="When on, dividers run the full opening height. Off = dividers stop at a horizontal locked shelf at Tray Opening Height",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    tray_opening_height: FloatProperty(
        name="Tray Opening Height",
        description="Z position of the locked shelf above the tray dividers (only when Remove Locked Shelf is off)",
        default=units.inch(20.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_divider_thickness: FloatProperty(
        name="Tray Divider Thickness",
        default=units.inch(0.25), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    tray_setback: FloatProperty(
        name="Tray Setback",
        description="Front setback for the tray dividers",
        default=units.inch(1.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # VANITY_SHELVES
    # Pair of side-mounted shelves around plumbing. Single Z, mirrored
    # length L/R.
    vanity_z: FloatProperty(
        name="Shelf Z",
        description="Z height of the vanity shelves (both sides)",
        default=units.inch(11.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    vanity_length: FloatProperty(
        name="Shelf Length",
        description="Length of each side shelf (mirrored L and R)",
        default=units.inch(7.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # CLOSET_ROD
    # Rod centerline measured DOWN from the opening (or region) top, so
    # a rod under a fixed shelf keeps its drop when the cabinet grows.
    rod_distance_from_top: FloatProperty(
        name="Distance From Top",
        description="Rod centerline distance down from the top of the opening (a rod under a fixed shelf keeps this drop)",
        default=units.inch(3.0), min=units.inch(1.0),
        unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # ACCESSORY: free-text label (e.g., 'Lazy Susan', 'Trash Pullout').
    accessory_label: StringProperty(
        name="Accessory Label", default="ACCESSORY",
        update=_update_cabinet_dim,
    )  # type: ignore

    # ACCESSORY: product code from the host application's accessory catalog,
    # set when the accessory is picked from the catalog rather than typed as
    # a free label. Drives the 2D legend + reports; no 3D effect. Empty for a
    # hand-typed accessory_label.
    accessory_code: StringProperty(
        name="Accessory Code", default="",
    )  # type: ignore

    # ACCESSORY: how many of this accessory the opening carries (e.g. two
    # removable dividers in one drawer). Dedicated field - the generic qty
    # defaults to 2 for the multi-count assembly kinds, which would misread
    # accessories saved before this field existed.
    accessory_qty: IntProperty(
        name="Accessory Qty", default=1, min=1, max=10,
        update=_update_cabinet_dim,
    )  # type: ignore

    # ACCESSORY: geometry hint from the product entry ('render' field),
    # stamped when the accessory is picked from the browser. Items with
    # a hint build real parts inside the drawer box (see
    # _spawn_drawer_inserts); blank stays data-only.
    accessory_render: StringProperty(
        name="Accessory Render", default="",
    )  # type: ignore
    divider_lengthwise: BoolProperty(
        name="Run Front to Back",
        description="Turn the divider(s) to run front-to-back, splitting "
                    "the drawer left / right instead of front / back",
        # On by default: a removable divider is nearly always added to
        # close off the space beside an insert that didn't fill the
        # drawer, which is a front-to-back panel.
        default=True, update=_update_cabinet_dim,
    )  # type: ignore
    divider_offset: FloatProperty(
        name="Position",
        description="Distance from the drawer front (or left side when "
                    "running front to back) to a single divider. 0 "
                    "puts a front-to-back divider against the accessory "
                    "before it, or spaces the divider(s) evenly when "
                    "there is nothing to sit against",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    # ACCESSORY: placement and size of a rendered drawer insert (tray,
    # knife block, spice shelves, organizer). Every one of these is an
    # override: left at 0 the insert takes the size on its product
    # spec, or fills what is left of the drawer when the spec is silent,
    # and packs in after the insert before it in the list.
    insert_offset: FloatProperty(
        name="From Left",
        description="Distance from the left inside face of the drawer box "
                    "to this insert. 0 packs it in after the insert above "
                    "it in the list",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    insert_from_front: FloatProperty(
        name="From Front",
        description="Distance from the inside of the drawer box front to "
                    "this insert",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    insert_width: FloatProperty(
        name="Insert Width",
        description="Width of this insert. 0 uses the size it is made in, "
                    "or fills the rest of the drawer",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    insert_depth: FloatProperty(
        name="Insert Depth",
        description="Front-to-back size of this insert. 0 uses the size it "
                    "is made in, or fills the depth of the drawer",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    insert_height: FloatProperty(
        name="Insert Height",
        description="Height of this insert. 0 uses the size it is made in; "
                    "a taller value is clipped to the drawer box",
        default=0.0, min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    insert_slots: IntProperty(
        name="Compartments",
        description="How many compartments (or knife slots) this insert is "
                    "divided into. 0 uses the standard layout",
        default=0, min=0, max=24,
        update=_update_cabinet_dim,
    )  # type: ignore


# Front-type options for a face-frame opening. Module-level so operators
# (e.g. the split-opening dialog) can build per-opening enums from the
# same canonical list the opening PropertyGroup uses.
FRONT_TYPE_ITEMS = [
    ('NONE', "None", "No front (open shelving)"),
    ('DOOR', "Door", "Hinged door"),
    ('DRAWER_FRONT', "Drawer Front", "Drawer front"),
    ('PULLOUT', "Pullout", "Door front on a pullout slide; supports pullout accessories"),
    ('FALSE_FRONT', "False Front", "Decorative drawer-style panel; fixed (does not open)"),
    ('TILT_OUT', "Tilt-Out", "Drawer-style front hinged on the bottom; tilts down to open"),
    ('INSET_PANEL', "Inset Panel", "1/4\" panel filling the face frame opening; no overlay, no swing"),
    ('APPLIANCE', "Appliance", "Open opening sized for an appliance; adds left/right filler stiles to fit the appliance width"),
]


def _update_drawer_look_divisions(self, context):
    """Sync the per-opening height list to the division count, then recalc.

    Mirrors a standard drawer stack: on a count change the top opening is
    seeded to the scene Top Drawer Opening Height (held) and the rest start
    auto / equal. Editing the rows afterwards behaves like stack openings.
    """
    from . import types_face_frame
    coll = self.drawer_look_openings
    n = 0 if self.drawer_look_divisions == 'NONE' else int(self.drawer_look_divisions)
    with types_face_frame.suspend_recalc():
        while len(coll) > n:
            coll.remove(len(coll) - 1)
        while len(coll) < n:
            coll.add()
        if n:
            top_oh = bpy.context.scene.hb_face_frame.top_drawer_opening_height
            for i, item in enumerate(coll):
                # index n-1 == top opening: held at the top-drawer height;
                # the rest auto (share the remainder equally).
                item.unlock_size = (i == n - 1)
                if i == n - 1:
                    item.size = top_oh
        types_face_frame.recalculate_face_frame_cabinet(self.id_data)


class Face_Frame_Drawer_Look_Opening(PropertyGroup):
    """One drawer-opening height for a drawer-look door. unlock_size = the
    user set this height (held); locked rows share the remainder equally,
    matching a standard drawer stack. Heights are OPENING heights (front
    height = opening + overlays), consumed by _build_drawer_look_fronts."""
    size: FloatProperty(
        name="Opening Height", default=units.inch(6.0), unit='LENGTH',
        precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    unlock_size: BoolProperty(
        name="Unlock Opening Height",
        description="Hold this opening height; locked rows share the remainder equally",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore


class Face_Frame_Opening_Props(PropertyGroup):
    """Per-opening state for face frame cabinets. Attached to each
    opening's cage object as bpy.types.Object.face_frame_opening.

    A bay starts with one opening filling its face frame opening.
    Splitter operations subdivide a bay by adding more openings to it.

    Each opening carries its front type and per-side overlay overrides.
    Unlocked overlays use the opening's own value; locked overlays fall
    back to the cabinet-level default (Face_Frame_Cabinet_Props.default_*_overlay).
    """

    opening_index: IntProperty(
        name="Opening Index",
        description="Position in the parent bay's opening list (0-based)",
        default=0,
    )  # type: ignore
    # ---- Opening dialog section visibility (UI only) ----
    show_front: BoolProperty(name="Show Front Type", default=True)  # type: ignore
    show_finish: BoolProperty(name="Show Finish Options", default=False)  # type: ignore
    show_overlays: BoolProperty(name="Show Overlays", default=False)  # type: ignore
    show_interior_items: BoolProperty(name="Show Interior Items", default=True)  # type: ignore

    # Size along the parent split's axis (height when parent is an
    # H-split, width when parent is a V-split). Meaningful only when
    # this opening is a child of a Face_Frame_Split node; ignored when
    # the opening is the bay's root tree node. Behaves like
    # Face_Frame_Bay_Props.width: equally redistributed by default,
    # held during redistribution when unlocked.
    size: FloatProperty(
        name="Size", default=units.inch(12.0), unit='LENGTH', precision=4,
        update=_update_opening_size,
    )  # type: ignore
    unlock_size: BoolProperty(
        name="Unlock Size",
        description="Hold this opening's size during gang-construction redistribution",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    front_type: EnumProperty(
        name="Front Type", items=FRONT_TYPE_ITEMS, default='NONE',
        update=_update_front_type,
    )  # type: ignore

    # INSET_PANEL fronts: optional carved texture on the panel face,
    # mirroring the Misc Part panel types (plain / beadboard / shiplap).
    inset_panel_type: EnumProperty(
        name="Panel Type",
        items=[
            ('PANEL', "Panel", "Plain flat panel"),
            ('BEADBOARD', "Beadboard",
             "Vertical quirk-bead grooves carved across the face"),
            ('SHIPLAP', "Shiplap",
             "Nickel-gap plank reveals carved across the face"),
            ('V_GROOVE', "V-Groove",
             "Vertical v-groove cuts carved across the face"),
        ],
        default='PANEL',
        update=_update_cabinet_dim,
    )  # type: ignore

    # ---- APPLIANCE front type: filler stiles fitting an appliance ----
    # When front_type == 'APPLIANCE' the opening carries no door/drawer;
    # instead up to two narrow face-frame filler stiles are added at the
    # left/right inboard edges so the clear opening matches the appliance
    # width. Two input modes, toggled by set_appliance_width:
    #   ON  -> user types appliance_width; left/right fillers are computed
    #          at build time as (clear_opening - appliance_width)/2 each.
    #   OFF -> user types left/right filler widths directly; the appliance
    #          width is whatever clear opening remains.
    # include_fillers gates whether the filler parts are built, so an
    # opening can be reserved as an appliance without fillers yet.
    set_appliance_width: BoolProperty(
        name="Set Appliance Width",
        description="Enter the appliance width and split the remainder into equal left/right fillers; off lets you type each filler width directly",
        default=True, update=_update_cabinet_dim,
    )  # type: ignore
    appliance_width: FloatProperty(
        name="Appliance Width",
        description="Width of the appliance the opening must fit; fillers fill the remainder",
        default=units.inch(24.0), unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    # The appliance model shown in the opening. AUTO reads the opening:
    # a short one takes a microwave, a tall one a wall oven.
    appliance_kind: EnumProperty(
        name="Appliance",
        items=[
            ('AUTO', "Auto", "A microwave in a short opening, a wall oven in a tall one"),
            ('OVEN', "Wall Oven", "A wall oven"),
            ('MICROWAVE', "Microwave", "A built-in microwave"),
            ('NONE', "None", "No appliance model in this opening"),
        ],
        default='AUTO', update=_update_cabinet_dim,
    )  # type: ignore
    include_fillers: BoolProperty(
        name="Include Fillers",
        description="Build the left/right filler stiles; off reserves the opening as an appliance with no fillers",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    left_filler_amount: FloatProperty(
        name="Left Filler",
        description="Width of the left filler stile (used directly when Set Appliance Width is off)",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_filler_amount: FloatProperty(
        name="Right Filler",
        description="Width of the right filler stile (used directly when Set Appliance Width is off)",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore

    # PULLOUT model: an accessory product code chosen for a PULLOUT
    # opening. Stored as a bare string code; the display name, price and
    # minimum opening width are looked up from whatever accessory catalog
    # the host application registers (see accessory_registry). Empty when
    # no model is chosen. No 3D effect -- drives 2D annotation and reports.
    pullout_accessory_code: StringProperty(
        name="Pullout Model",
        description="Accessory product code selected for this pullout opening",
        default="",
    )  # type: ignore
    # Tilt-out: a FALSE_FRONT on hinges (tray behind). Geometrically
    # identical to a plain false front, so it's a flag rather than a
    # front_type -- the only behavioral difference is the 2D elevation
    # label (TILT-OUT instead of FALSE, read by the host add-on). Set / cleared
    # by the TILT_OUT opening preset; lives on the persistent opening
    # cage so it survives recalcs.
    is_tilt_out: BoolProperty(
        name="Tilt-Out",
        description="Label this false front as a tilt-out on 2D drawings",
        default=False,
    )  # type: ignore

    # ---- Pull override ----
    # Per-opening pull override (right-click a door / drawer front ->
    # Set Pull...). Stored as the pull's filename + category folder on
    # the persistent opening cage so it survives recalcs; empty = the
    # scene-wide selection for the front's kind, 'NONE' = no pull on
    # this front.
    pull_override: StringProperty(
        name="Pull Override", default="",
        update=_update_cabinet_dim,
    )  # type: ignore
    pull_override_category: StringProperty(
        name="Pull Override Category", default="",
    )  # type: ignore
    # A false front carries no pull by default (a sink front reads as
    # dead). Set when the user picks a pull for a FALSE_FRONT opening
    # (right-click the front -> Set Pull...), so a dead front in a bank
    # of drawers can still read as a drawer. Cleared by No Pull.
    false_front_pull: BoolProperty(
        name="Pull on False Front",
        description="Give this false front a pull so it reads as a drawer",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    # Per-opening vertical pull placement for swing doors (right-click a
    # door -> Set Pull Location...). AUTO = the cabinet-type rule (base:
    # top of door, upper: bottom, tall: by door position / length);
    # the rest pin the pull regardless of that rule -- e.g. a tall
    # opening's double doors with the pulls at the top, middle, or
    # bottom of the doors. Drawer fronts ignore it.
    pull_location_override: EnumProperty(
        name="Pull Location",
        items=[
            ('AUTO', "Automatic", "Cabinet-type rule (base: top, upper: bottom, tall: by door height)"),
            ('TOP', "Top of Door", "Base-style: measured down from the top of the door"),
            ('MIDDLE', "Middle of Door", "Centered on the door height"),
            ('BOTTOM', "Bottom of Door", "Upper-style: measured up from the bottom of the door"),
            ('TALL', "Tall Reach Height", "Tall-style: the tall vertical offset up from the door bottom"),
        ],
        default='AUTO',
        update=_update_cabinet_dim,
    )  # type: ignore

    # ---- Drawer box size overrides ----
    # Per-axis overrides for the drawer box behind this opening's drawer
    # / pullout front (right-click the box -> Drawer Box Size...). The
    # box itself is wiped and rebuilt every recalc, so the user's size
    # lives here on the persistent opening cage. An un-overridden axis
    # keeps the auto fit (opening hole minus the scene clearances).
    # A rollout riding above the drawer box, behind the same front:
    # one front, a drawer below and a rollout over it. The drawer box
    # gives up the height (see _create_drawer_box_for_front), so the
    # bottom gap no longer has to be set by hand.
    rollout_above_drawer: BoolProperty(
        name="Rollout Above Drawer",
        description="Add a rollout above this drawer's box, behind the "
                    "same front. The drawer box shortens to make room",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    rollout_above_height: FloatProperty(
        name="Rollout Height",
        description="Height of the rollout box above the drawer",
        default=units.inch(4.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    rollout_above_gap: FloatProperty(
        name="Gap Above Drawer",
        description="Clear space between the top of the drawer box and "
                    "the underside of the rollout",
        default=units.inch(1.0), min=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    drawer_box_override_width: BoolProperty(
        name="Override Width",
        description="Use the entered drawer box width instead of the auto fit (opening minus side clearances)",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    drawer_box_width: FloatProperty(
        name="Drawer Box Width",
        description="Drawer box width; centered in the opening",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    drawer_box_override_height: BoolProperty(
        name="Override Height",
        description="Use the entered drawer box height instead of the auto fit (opening minus top/bottom clearances)",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    drawer_box_height: FloatProperty(
        name="Drawer Box Height",
        description="Drawer box height; the bottom clearance anchor is kept",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    drawer_box_override_depth: BoolProperty(
        name="Override Depth",
        description="Use the entered drawer box depth instead of the auto fit (cavity depth minus rear clearance)",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    drawer_box_depth: FloatProperty(
        name="Drawer Box Depth",
        description="Drawer box depth from the back of the front rearward",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore

    # ---- Sink duo (U-shaped) drawer ----
    # A drawer under a sink whose box wraps the basin / drain: a
    # centered notch cut into the box from the back. Durable on the
    # opening (boxes are wiped every recalc); the box builds full size
    # and the U-notch is cut on top, published for drawings / reports.
    sink_duo: BoolProperty(
        name="Sink Duo Drawer",
        description="U-shaped drawer box: a centered notch from the "
                    "back wraps the sink basin / plumbing",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    sink_duo_notch_width: FloatProperty(
        name="Notch Width",
        description="Width of the U-notch, centered across the box",
        default=units.inch(9.0), unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore
    sink_duo_notch_depth: FloatProperty(
        name="Notch Depth",
        description="How far the U-notch reaches into the box from the "
                    "back; 0 uses two-thirds of the box depth",
        default=0.0, unit='LENGTH', precision=4, min=0.0,
        update=_update_cabinet_dim,
    )  # type: ignore

    # ---- Drawer box construction ----
    # Which box system this opening's boxes are built from. HB5 ships no
    # list: the host application supplies the options through the
    # accessory registry (host 'drawer_box_construction'), so one job can
    # mix systems. Blank = the project style's default construction.
    # Covers the box behind a drawer / pullout front AND any rollout
    # boxes in the opening. The display label is cached next to the code
    # so a file opened without the host add-on still reads and prints.
    drawer_box_construction: StringProperty(
        name="Drawer Box Construction",
        description="Construction for this opening's drawer boxes; blank uses the project default",
        default="", update=_update_cabinet_dim,
    )  # type: ignore
    drawer_box_construction_label: StringProperty(
        name="Drawer Box Construction Label",
        description="Display name of the selected drawer box construction",
        default="",
    )  # type: ignore
    # ---- Drawer slides ----
    # Same registry-driven shape as the box construction (host
    # 'drawer_slides'): a per-opening slide override for the odd heavy
    # duty drawer, blank = the project style's slide selection. Pure
    # spec metadata - no geometry - stamped onto the built boxes for
    # downstream drawings / reports.
    drawer_slides: StringProperty(
        name="Drawer Slides",
        description="Slide hardware for this opening's drawers; blank uses the project default",
        default="", update=_update_cabinet_dim,
    )  # type: ignore
    drawer_slides_label: StringProperty(
        name="Drawer Slides Label",
        description="Display name of the selected drawer slides",
        default="",
    )  # type: ignore

    # Drawer-look door: a single working DOOR leaf whose face carries N
    # applied drawer-front panels (reveal gaps between them read as mid
    # rails) so it looks like a stack of drawers but opens as one door.
    # NONE = a plain door. The applied fronts + their pulls are built in
    # _update_fronts_in_opening, parented to the door so they swing as one;
    # they carry no product tags (the leaf reads as a single door). Lives
    # on the persistent opening cage so it survives recalcs.
    drawer_look_divisions: EnumProperty(
        name="Drawer-Look Divisions",
        description="Show this door as a stack of N applied drawer fronts (still opens as one door)",
        items=[
            ('NONE', "None", "Plain door (no drawer-look fronts)"),
            ('2', "2 Drawers", "Two applied drawer fronts"),
            ('3', "3 Drawers", "Three applied drawer fronts"),
            ('4', "4 Drawers", "Four applied drawer fronts"),
        ],
        default='NONE',
        update=_update_drawer_look_divisions,
    )  # type: ignore
    # Per-drawer OPENING heights, edited like a standard drawer stack
    # (unlock to set a height; locked rows share the remainder). Synced to
    # the division count by _update_drawer_look_divisions; consumed by
    # _build_drawer_look_fronts (front height = opening height + overlays).
    drawer_look_openings: CollectionProperty(type=Face_Frame_Drawer_Look_Opening)  # type: ignore

    HINGE_SIDE_ITEMS = [
        ('LEFT', "Left", "Single door, hinged on the left edge"),
        ('RIGHT', "Right", "Single door, hinged on the right edge"),
        ('DOUBLE', "Double", "Pair of doors meeting in the middle, hinged on outer edges"),
        ('TOP', "Top", "Flip-up door, hinged on the top edge"),
        ('BOTTOM', "Bottom", "Flip-down door, hinged on the bottom edge"),
    ]
    hinge_side: EnumProperty(
        name="Hinge Side", items=HINGE_SIDE_ITEMS, default='RIGHT',
        update=_update_cabinet_dim,
    )  # type: ignore

    # How the opening's doors operate. Retracting mechanisms pocket the
    # door back into the cabinet after opening; the closed-door look is
    # unchanged, but per the product spec they cost interior clearance,
    # which the solver applies to shelf stacks (see
    # solver_face_frame._retracting_clearances). Downstream 2D consumers
    # read this for labels / legend entries.
    DOOR_MECHANISM_ITEMS = [
        ('NONE', "Standard Swing", "Doors swing open on hinges"),
        ('RETRACTING', "Retracting",
         "Doors open, then slide back into the cabinet on rails"),
        ('RETRACTING_BIFOLD', "Bi-fold Retracting",
         "Hinged door pairs fold, then slide back into the cabinet"),
        ('RETRACTING_TOP', "Top-Mount Retracting",
         "Full-width door that retracts up into the cabinet"),
        # Lift-up family (top-hinged uppers). A plain TOP hinge is the
        # tilt-up door; these pick the stay-open lift hardware instead.
        ('LIFT_UP', "Lift-Up",
         "Top-hinged door on lift stays; opens effortlessly and holds "
         "any position"),
        ('LIFT_UP_DELUXE', "Deluxe Lift-Up",
         "Parallel-arm lift-up hardware; holds any position, deeper "
         "cabinet required"),
        ('LIFT_UP_BIFOLD', "Deluxe Bi-fold Lift-Up",
         "Two-panel door that folds as it lifts; for taller openings"),
    ]
    door_mechanism: EnumProperty(
        name="Door Mechanism", items=DOOR_MECHANISM_ITEMS, default='NONE',
        update=_update_cabinet_dim,
    )  # type: ignore
    # Powered opener option for the deluxe lift-up mechanisms.
    lift_up_servo: BoolProperty(
        name="Servo Drive",
        description="Electric-assist opener on the lift-up door",
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Pipe chase fit for the drawer box behind this opening. Consulted
    # only when the cabinet carries a pipe chase AND the box overlaps it
    # in X (see _create_drawer_box_for_front). SHORTEN (default) clamps
    # the box depth so the box and its slide clear the chase covers;
    # NOTCH keeps full depth and boolean-notches the box around the
    # chase (a custom shop operation - the box's cutlist dims stay full
    # size); FULL leaves the box untouched.
    chase_fit: EnumProperty(
        name="Chase Fit",
        items=[
            ('SHORTEN', "Shorten Box",
             "Shorten the drawer box to clear the pipe chase"),
            ('NOTCH', "Notch Box",
             "Keep full depth and notch the drawer box around the chase"),
            ('FULL', "Full Depth",
             "Leave the drawer box full depth (may collide with the chase)"),
        ],
        default='SHORTEN',
        update=_update_cabinet_dim,
    )  # type: ignore

    # Visual open state. 0 = closed, 1 = fully open. For DOOR / PULLOUT
    # with a vertical hinge it drives a swing rotation; for DRAWER_FRONT
    # and PULLOUT slide-out it drives a forward translation. The "fully
    # open" reference (max swing angle, max slide distance) lives in the
    # solver, not in props - they're construction constants for now and
    # become cabinet props later if customization is wanted.
    swing_percent: FloatProperty(
        name="Swing Percent",
        description="How far the door / drawer front is opened (0 = closed, 1 = fully open)",
        default=0.0, min=0.0, max=1.0,
        subtype='FACTOR', precision=2,
        update=_update_cabinet_dim,
    )  # type: ignore

    # Per-side overlay overrides. Used only when the matching unlock flag
    # is True; otherwise the cabinet-level default is applied.
    top_overlay: FloatProperty(
        name="Top Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    bottom_overlay: FloatProperty(
        name="Bottom Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    left_overlay: FloatProperty(
        name="Left Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    right_overlay: FloatProperty(
        name="Right Overlay", default=units.inch(0.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    unlock_top_overlay: BoolProperty(
        name="Unlock Top Overlay",
        description="Use this opening's own top overlay value instead of the cabinet default",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    unlock_bottom_overlay: BoolProperty(
        name="Unlock Bottom Overlay",
        description="Use this opening's own bottom overlay value instead of the cabinet default",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    unlock_left_overlay: BoolProperty(
        name="Unlock Left Overlay",
        description="Use this opening's own left overlay value instead of the cabinet default",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore
    unlock_right_overlay: BoolProperty(
        name="Unlock Right Overlay",
        description="Use this opening's own right overlay value instead of the cabinet default",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    # Per-opening finish: the bay-level finish_bay behavior scoped to a
    # single opening (e.g. one sub-opening of a split bay). The exterior
    # finish reads inside this opening via liner panels on its inner
    # faces; finish_opening_flush + finish_opening_flush_depth mirror the
    # bay flush controls (0 depth = full cavity depth). A bay-level finish
    # supersedes per-opening finish within that bay.
    finish_opening: BoolProperty(
        name="Finish Opening", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    finish_opening_flush: BoolProperty(
        name="Finish Flush", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    finish_opening_flush_depth: FloatProperty(
        name="Flush Depth", default=0.0, unit='LENGTH', precision=4,
        description="How far the flush finish runs back into the opening; "
                    "0 runs the full cavity depth",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Which of the cabinet style's two materials the finished opening
    # shows on its liner panels and shelves (see finish_bay_material).
    finish_opening_material: EnumProperty(
        name="Finish Color",
        items=[('FINISH', "Exterior Finish",
                "Liner panels and shelves take the cabinet's exterior finish"),
               ('INTERIOR', "Interior Material",
                "Liner panels and shelves take the style's interior material")],
        default='FINISH',
        update=_update_cabinet_dim,
    )  # type: ignore
    # Texture carved into this opening's liner panels (see
    # finish_bay_texture).
    finish_opening_texture: EnumProperty(
        name="Interior Texture",
        description="Texture carved into the finished interior's panels",
        items=INTERIOR_TEXTURE_ITEMS, default='NONE',
        update=_update_cabinet_dim,
    )  # type: ignore

    # Sink apron: a fixed face-frame-depth panel across the top of a door
    # opening (for an apron / farmhouse sink). The door(s) stay full
    # height; the apron sits behind them at the frame plane. Only built
    # for door front types.
    add_apron: BoolProperty(
        name="Add Apron", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    apron_height: FloatProperty(
        name="Apron Height", default=units.inch(7.0), unit='LENGTH',
        precision=4, min=0.0, update=_update_cabinet_dim,
    )  # type: ignore

    # Interior items: shelves, accessory labels, and (future) glass
    # shelves, half shelves, pullouts, tray dividers, rollouts. Order
    # in this collection is the visual order from bottom to top inside
    # the opening for items that stack (shelves); accessory labels
    # ignore order.
    interior_items: CollectionProperty(type=Face_Frame_Interior_Item)  # type: ignore
    interior_items_index: IntProperty(
        name="Active Interior Item Index", default=0, min=0,
    )  # type: ignore


class Face_Frame_Splitter_Width(PropertyGroup):
    """Per-splitter width override inside one split node.

    A split node with N children emits N-1 splitter members (mid rails
    for an H-split, mid stiles for a V-split). The node's scalar
    splitter_width is the default applied to every member; this
    collection lets an individual member hold its own width so the user
    can size one mid rail in a bay without dragging its siblings along.

    Index N maps to the splitter at gap N (the solver's splitter_index,
    also stamped on the part as hb_splitter_index). An entry is honored
    only when `active` is True; otherwise the member follows the node's
    scalar splitter_width. The collection grows lazily on first edit, so
    a split with no per-member overrides carries an empty collection and
    behaves exactly as before.
    """
    width: FloatProperty(
        name="Width",
        default=units.inch(1.5),
        unit='LENGTH',
        precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    active: BoolProperty(
        name="Active",
        description="Use this per-splitter width instead of the split's default",
        default=False,
    )  # type: ignore

    remove_member: BoolProperty(
        name="Remove Member",
        description=(
            "Drop this splitter's face-frame member (and its carcass backing). "
            "The opening stays split; the solver collapses the gap so the two "
            "fronts sit 3/32\" apart. Used between drawers"
        ),
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore

    remove_backing: BoolProperty(
        name="Remove Backing",
        description=(
            "Drop only this splitter's carcass backing (the shelf behind a "
            "mid rail, the division behind a mid stile). The face-frame "
            "member stays"
        ),
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore

    finished_bottom: BoolProperty(
        name="Finished Bottom",
        description=(
            "Hang the cabinet's finished bottom condition under the shelf "
            "behind this mid rail. For an opening whose exposed underside "
            "is not the cabinet's own bottom - the shelf over a "
            "refrigerator opening, say. Per shelf, so the cabinet's other "
            "shelves are untouched"
        ),
        default=False,
        update=_update_cabinet_dim,
    )  # type: ignore


class Face_Frame_Split_Props(PropertyGroup):
    """Per-split-node state. Attached to each split node Empty as
    bpy.types.Object.face_frame_split.

    Split nodes are internal nodes of the bay's opening tree; their
    children are either openings (leaves) or other split nodes. The
    split's axis dictates how the children are arranged: H = stacked
    vertically (children differ in Z), V = side by side (children
    differ in X). The split node is also a tree node itself, so it has
    its own size / unlock_size for the redistribution logic when it's
    a child of a parent split.
    """

    SPLIT_AXIS_ITEMS = [
        ('H', "Horizontal", "Children stacked vertically; mid rail between them"),
        ('V', "Vertical",   "Children side by side; mid stile between them"),
    ]
    axis: EnumProperty(
        name="Axis", items=SPLIT_AXIS_ITEMS, default='H',
        update=_update_cabinet_dim,
    )  # type: ignore

    size: FloatProperty(
        name="Size", default=units.inch(12.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_size: BoolProperty(
        name="Unlock Size",
        description="Hold this split's size during gang-construction redistribution",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    # Width of THIS split's mid rail / mid stile members. Initialized
    # from the cabinet's bay_mid_rail_width / bay_mid_stile_width when
    # the split is created; per-split override afterwards.
    splitter_width: FloatProperty(
        name="Splitter Width",
        description="Width of mid rails (H-split) or mid stiles (V-split) inside this split node",
        default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore
    unlock_splitter_width: BoolProperty(
        name="Unlock Splitter Width",
        description="Hold this split's mid rail / mid stile width when a cabinet style is applied",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    # Per-splitter width overrides, indexed by splitter_index. Empty =
    # every member follows the scalar splitter_width above; an entry with
    # active=True holds that one member's width independently (set via the
    # right-click Set Width on a single mid rail / mid stile).
    splitter_widths: CollectionProperty(type=Face_Frame_Splitter_Width)  # type: ignore

    # Carcass part rendered BEHIND each splitter member. The KIND of
    # backing is implied by the split's axis: H-splits (mid rails)
    # always get a shelf; V-splits (mid stiles) always get a division.
    # The user just toggles whether one is present at all.
    add_backing: BoolProperty(
        name="Add Backing",
        description="Add a carcass shelf (H-split) or division (V-split) behind each splitter",
        default=True,
        update=_update_cabinet_dim,
    )  # type: ignore


def _update_interior_add_face_frame(self, context):
    """Toggle callback for the optional interior face frame part.
    The first time the toggle is enabled, seed face_frame_width from
    the cabinet mid rail (H-split) or mid stile (V-split) width so
    the width field opens on the cabinet default; 0.0 marks it
    unseeded. Writing face_frame_width fires its own recalc, so the
    seed path returns without a second _update_cabinet_dim call.
    """
    if self.add_face_frame and self.face_frame_width <= 0.0:
        from . import types_face_frame
        cab = types_face_frame.find_cabinet_root(self.id_data)
        if cab is not None:
            cp = cab.face_frame_cabinet
            self.face_frame_width = (cp.bay_mid_rail_width
                                     if self.axis == 'H'
                                     else cp.bay_mid_stile_width)
            return
    _update_cabinet_dim(self, context)


class Face_Frame_Interior_Split_Props(PropertyGroup):
    """Per-interior-split-node state. Attached to each interior split
    node Empty as bpy.types.Object.face_frame_interior_split.

    Interior splits subdivide an opening into regions. H-splits are
    fixed shelves (children stacked in Z; horizontal divider between);
    V-splits are divisions (children side by side in X; vertical
    divider between). Children are sorted by hb_interior_child_index
    (0 = lower / left, 1 = upper / right) and each carries its own
    size (Face_Frame_Interior_Region_Props.size for leaves, or this
    same Face_Frame_Interior_Split_Props.size for nested splits).
    """

    SPLIT_AXIS_ITEMS = [
        ('H', "Fixed Shelf", "Horizontal divider; children stacked vertically"),
        ('V', "Division",    "Vertical divider; children side by side"),
    ]
    axis: EnumProperty(
        name="Axis", items=SPLIT_AXIS_ITEMS, default='H',
        update=_update_cabinet_dim,
    )  # type: ignore

    size: FloatProperty(
        name="Size", default=units.inch(12.0), unit='LENGTH', precision=4,
        update=_update_interior_size,
    )  # type: ignore
    unlock_size: BoolProperty(
        name="Unlock Size",
        description="Hold this split's size during sibling redistribution",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    divider_thickness: FloatProperty(
        name="Divider Thickness",
        description="Thickness of the fixed shelf or division at this split",
        default=units.inch(0.75), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore

    add_face_frame: BoolProperty(
        name="Add Face Frame",
        description="Add a face frame rail (fixed shelf) or stile "
                    "(division) inline with the cabinet face frame at "
                    "this split. Sits behind the doors and does not "
                    "split the door fronts",
        default=False, update=_update_interior_add_face_frame,
    )  # type: ignore
    face_frame_width: FloatProperty(
        name="Face Frame Width",
        description="Width of the optional face frame part at this "
                    "split. Seeded from the cabinet mid rail / mid "
                    "stile width when first enabled",
        default=0.0, unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
    )  # type: ignore


class Face_Frame_Interior_Region_Props(PropertyGroup):
    """Per-leaf-region state. Attached to each leaf cage as
    bpy.types.Object.face_frame_interior_region.

    A leaf region is a sub-rect of an opening, isolated by zero or
    more splits in the interior tree. It carries its own
    interior_items collection (same item type as the opening's flat
    collection) plus the size/unlock used by sibling redistribution.
    """

    interior_items: CollectionProperty(type=Face_Frame_Interior_Item)  # type: ignore
    interior_items_index: IntProperty(default=0)  # type: ignore

    size: FloatProperty(
        name="Size", default=units.inch(12.0), unit='LENGTH', precision=4,
        update=_update_interior_size,
    )  # type: ignore
    unlock_size: BoolProperty(
        name="Unlock Size",
        description="Hold this region's size during sibling redistribution",
        default=False, update=_update_cabinet_dim,
    )  # type: ignore

    # UI-only: collapsed by default in the inline tree view to keep
    # the opening prompts popup short. Toggled by the triangle button
    # next to each region's header.
    expanded: BoolProperty(
        name="Expanded",
        description="Show this region's size, divider, and items",
        default=False,
    )  # type: ignore


# ---------------------------------------------------------------------------
# Main scene props
# ---------------------------------------------------------------------------
# Reentrance guard for the cross-room top-drawer-height sync: writing
# the other scenes' props fires this same callback on each of them.
_SYNCING_TOP_DRAWER_HEIGHT = False


def _sync_top_drawer_opening_height(self, context):
    """Keep the Top Drawer Opening Height uniform across every ROOM
    scene in the file. Rooms are separate scenes, so without this a
    value set in room 1 left fresh rooms (and any untouched room)
    silently on the 4.5" default. The value seeds per-drawer opening
    heights at build time, so already-built cabinets in other rooms do
    NOT re-flow (use Refresh Top Drawer Openings for that), and
    per-drawer unlocked heights still override per cabinet. Layout /
    detail scenes are skipped; room creation seeds the new scene from
    the creating scene (operators/rooms.py)."""
    global _SYNCING_TOP_DRAWER_HEIGHT
    if _SYNCING_TOP_DRAWER_HEIGHT:
        return
    _SYNCING_TOP_DRAWER_HEIGHT = True
    try:
        val = self.top_drawer_opening_height
        own = self.id_data
        for scene in bpy.data.scenes:
            if scene is own:
                continue
            if scene.get('IS_LAYOUT_VIEW') or scene.get('IS_SPACES_DETAIL'):
                continue
            ff = getattr(scene, 'hb_face_frame', None)
            if ff is None:
                continue
            if abs(ff.top_drawer_opening_height - val) > 1e-9:
                ff.top_drawer_opening_height = val
    finally:
        _SYNCING_TOP_DRAWER_HEIGHT = False


# Same cross-room mirror for the project toe kick defaults (one guard
# for both props; each callback re-enters the other scenes' callbacks).
_SYNCING_TOE_KICK_DEFAULTS = False


def _sync_toe_kick_defaults(self, context):
    """Keep the default toe kick height / setback uniform across every
    ROOM scene, like _sync_top_drawer_opening_height. Seeds new cabinets
    only; use Update Toe Kicks to push onto built cabinets."""
    global _SYNCING_TOE_KICK_DEFAULTS
    if _SYNCING_TOE_KICK_DEFAULTS:
        return
    _SYNCING_TOE_KICK_DEFAULTS = True
    try:
        own = self.id_data
        for scene in bpy.data.scenes:
            if scene is own:
                continue
            if scene.get('IS_LAYOUT_VIEW') or scene.get('IS_SPACES_DETAIL'):
                continue
            ff = getattr(scene, 'hb_face_frame', None)
            if ff is None:
                continue
            for attr in ('default_toe_kick_height', 'default_toe_kick_setback'):
                val = getattr(self, attr)
                if abs(getattr(ff, attr) - val) > 1e-9:
                    setattr(ff, attr, val)
    finally:
        _SYNCING_TOE_KICK_DEFAULTS = False


def _pull_category_enum_items(self, context):
    # Deferred import to avoid a circular dependency: pulls.py imports
    # this module for the thumbnail preview collection.
    from . import pulls
    return pulls.get_pull_categories()


def _pull_finish_enum_items(self, context):
    # Same deferred-import reasoning as the category items.
    from . import pulls
    return pulls.PULL_FINISHES


def _pull_enum_items(self, context):
    """Items for door/drawer pull selection. Filtered to the currently
    chosen category. Real pulls come first (so the EnumProperty defaults
    to the first one) with 'NONE' appended at the end as an opt-out.
    """
    from . import pulls
    items = []
    cat = self.door_pull_category
    if cat != 'NONE':
        # Category id is uppercased; resolve back to on-disk folder name.
        real_cat = None
        for entry in pulls.get_pull_categories():
            if entry[0] == cat:
                real_cat = entry[1]
                break
        if real_cat is not None:
            items.extend(pulls.get_pulls_in_category(real_cat))
    items.append(('NONE', "None", "No pull"))
    return items


def _update_pulls_on_selection_change(self, context):
    """Selection change -> trigger recalc on every face frame cabinet
    so the new pull (or NONE) shows up. Cached pull objects are NOT
    invalidated here; the front-builder reloads from the new selection
    on its next pass.
    """
    from . import types_face_frame
    # Snapshot + suspend: without the suspend each recalc runs
    # immediately, deleting / recreating parts (scene objects) while
    # scene.objects was being iterated live -- hard crash. The suspend
    # also coalesces to one recalc per cabinet.
    with types_face_frame.suspend_recalc():
        cages = [obj for obj in context.scene.objects
                 if obj.get(types_face_frame.TAG_CABINET_CAGE)]
        for obj in cages:
            types_face_frame.recalculate_face_frame_cabinet(obj)


class Face_Frame_Scene_Props(PropertyGroup):
    """Scene-level face frame settings: defaults, library state, cabinet
    styles, and the library/options UI.
    """

    # ---- Selection mode (mirrors frameless) ----
    face_frame_selection_mode: EnumProperty(
        name="Face Frame Selection Mode",
        items=[
            ('Cabinets', "Cabinets", "Select cabinet roots"),
            ('Bays', "Bays", "Select bay cages"),
            ('Face Frame', "Face Frame", "Select face frame members (rails and stiles)"),
            ('Openings', "Openings", "Select opening cages"),
            ('Interiors', "Interiors", "Select interior parts"),
            ('Parts', "Parts", "Select all individual cuttable parts"),
            # 'Applied Panels' is reachable via the Show Applied Panels
            # operator in the Finished Ends and Backs panel; intentionally
            # absent from the main mode picker (see ui/view3d_sidebar.py).
            ('Applied Panels', "Applied Panels",
             "Select applied finished-end panels"),
        ],
        default='Cabinets',
        update=update_face_frame_selection_mode,
    )  # type: ignore
    face_frame_selection_mode_enabled: BoolProperty(
        name="Selection Mode Shading",
        description="When off, selection-mode highlighting is disabled: cages stay hidden and every part renders plain regardless of which mode is picked",
        default=True,
        update=update_face_frame_selection_mode,
    )  # type: ignore
    # Editable size labels drawn by dim_edit_overlay in Cabinets / Bays /
    # Openings / Face Frame modes. Per scene so a room can hide them without
    # a preference trip; cycled from the overlay's own Sizes pill in the
    # viewport (All -> Selected -> Off). SELECTED keeps only the labels
    # whose cage belongs to the current selection. No update callback --
    # the overlay's click handler tags the redraw. (Replaces the old
    # selection_mode_show_sizes bool.)
    selection_mode_sizes_scope: EnumProperty(
        name="Size Labels",
        items=[
            ('ALL', "All", "Show size labels on every cabinet"),
            ('SELECTED', "Selected",
             "Show size labels only for the selected objects"),
            ('OFF', "Off", "Hide size labels"),
        ],
        default='ALL',
    )  # type: ignore

    # ---- Top-level tabs ----
    face_frame_tabs: EnumProperty(
        name="Face Frame Tabs",
        items=[
            ('LIBRARY', "Library", "Library"),
            ('OPTIONS', "Options", "Options"),
        ],
        default='LIBRARY',
    )  # type: ignore

    library_view_mode: EnumProperty(
        name="Library View",
        description="Show library items as thumbnail tiles or a compact list",
        items=[
            ('THUMBNAIL', "Thumbnail", "Thumbnail tiles with previews", 'IMGDISPLAY', 0),
            ('LIST', "List", "Compact list of names", 'LONGDISPLAY', 1),
        ],
        default='THUMBNAIL',
    )  # type: ignore

    # ---- Library section toggles ----
    show_cabinet_sizes: BoolProperty(name="Show Cabinet Sizes", default=True)  # type: ignore
    show_corner_sizes: BoolProperty(name="Show Corner Sizes", default=False)  # type: ignore
    show_appliance_sizes: BoolProperty(name="Show Appliance Sizes", default=False)  # type: ignore
    show_opening_heights: BoolProperty(name="Show Opening Heights", default=False)  # type: ignore
    show_cabinet_library: BoolProperty(name="Show Standard Cabinets", default=True)  # type: ignore
    show_corner_cabinet_library: BoolProperty(name="Show Corner Cabinets", default=False)  # type: ignore
    show_appliance_library: BoolProperty(name="Show Appliance Products", default=False)  # type: ignore
    show_galley_library: BoolProperty(name="Show Galley Workstations", default=False)  # type: ignore
    show_vanity_library: BoolProperty(name="Show Vanities", default=False)  # type: ignore
    show_part_library: BoolProperty(name="Show Parts", default=False)  # type: ignore
    show_specialty_bath_library: BoolProperty(name="Show Specialty Bath", default=False)  # type: ignore
    show_bedroom_bookcase_library: BoolProperty(name="Show Specialty Bedroom & Bookcases", default=False)  # type: ignore
    show_angled_library: BoolProperty(name="Show Angled", default=False)  # type: ignore
    show_misc_library: BoolProperty(name="Show Misc", default=False)  # type: ignore
    show_user_library: BoolProperty(name="Show User Library", default=False)  # type: ignore

    # User library category filter. Items are dynamic so newly-created
    # subfolders show up without a restart.
    cabinet_group_category: EnumProperty(
        name="Category",
        description="Filter cabinet groups by category subfolder",
        items=get_cabinet_group_category_items,
    )  # type: ignore

    # ---- Options section toggles ----
    show_cabinet_styles: BoolProperty(name="Show Cabinet Styles", default=False)  # type: ignore
    show_door_styles: BoolProperty(name="Show Door Styles", default=False)  # type: ignore
    door_style_tab: EnumProperty(
        name="Style Tab",
        description="Switch between the door style and drawer front style lists",
        items=[('DOOR', "Door Styles", "Edit door styles"),
               ('DRAWER', "Drawer Front Styles", "Edit drawer front styles")],
        default='DOOR',
    )  # type: ignore
    show_finished_ends_options: BoolProperty(name="Show Finished Ends and Backs", default=False)  # type: ignore
    show_general_options: BoolProperty(name="Show General Options", default=False)  # type: ignore
    show_face_frame_options: BoolProperty(name="Show Face Frame Options", default=False)  # type: ignore
    show_handle_options: BoolProperty(name="Show Handle Options", default=False)  # type: ignore
    show_countertop_options: BoolProperty(name="Show Countertop Options", default=False)  # type: ignore
    show_drawer_box_options: BoolProperty(name="Show Drawer Box Options", default=False)  # type: ignore

    # ---- Drawer box defaults ----
    # include_drawer_boxes gates spawning of drawer boxes behind drawer
    # and pullout fronts; clearances are subtracted from the opening hole
    # to size each box. v1 keeps these scene-wide; per-front overrides
    # land when front parts grow editable per-part props.
    # Style colours in the solid viewport: the same fill the 2D
    # drawings use, on the cabinets themselves, so a drafter can see
    # which style section a cabinet is in without generating a drawing.
    show_style_colors: BoolProperty(
        name="Style Colors In Viewport",
        description="Colour cabinets in the viewport by their style "
                    "section, matching the 2D drawing fills",
        default=True,
        update=update_show_style_colors,
    )  # type: ignore

    include_drawer_boxes: BoolProperty(
        name="Include Drawer Boxes",
        description="Spawn a drawer box behind every drawer and pullout front",
        default=True,
        update=update_include_drawer_boxes,
    )  # type: ignore
    drawer_box_side_clearance: FloatProperty(
        name="Drawer Box Side Clearance",
        description="Gap between each side of the drawer box and the opening",
        default=units.inch(0.5), unit='LENGTH', precision=4,
    )  # type: ignore
    drawer_box_top_clearance: FloatProperty(
        name="Drawer Box Top Clearance",
        description="Gap between the top of the drawer box and the opening top",
        default=units.inch(0.75), unit='LENGTH', precision=4,
    )  # type: ignore
    drawer_box_rear_clearance: FloatProperty(
        name="Drawer Box Rear Clearance",
        description="Gap between the back of the drawer box and the cabinet back",
        default=units.inch(1.0), unit='LENGTH', precision=4,
    )  # type: ignore
    drawer_box_bottom_clearance: FloatProperty(
        name="Drawer Box Bottom Clearance",
        description="Gap between the bottom of the drawer box and the opening bottom",
        default=units.inch(0.5), unit='LENGTH', precision=4,
    )  # type: ignore
    # Boxes come in a fixed range of heights (types_face_frame.
    # STOCK_DRAWER_BOX_HEIGHTS) rather than being cut to the opening.
    # Off, the clearances alone size the box - which draws a pullout
    # behind a tall door as a drawer nearly the height of the door.
    use_stock_drawer_box_heights: BoolProperty(
        name="Stock Box Heights",
        description="Size each drawer box to the nearest stock box "
                    "height for its opening instead of cutting it to "
                    "the opening",
        default=True,
        update=update_include_drawer_boxes,
    )  # type: ignore

    # ---- Finished Ends and Backs defaults ----
    # Drives the "Apply to All Exposed" bulk operator and seeds new
    # cabinets at create_cabinet_root time. Cabinet-level overrides
    # live on Face_Frame_Cabinet_Props.
    default_finished_end_type: EnumProperty(
        name="Default Finished End Type",
        items=FIN_END_ITEMS, default='FINISHED',
    )  # type: ignore
    # Backs get their own default (a shop often runs a different
    # treatment on an exposed island back than on exposed ends).
    # Defaults to FINISHED so existing scenes behave as before until
    # the user picks something else. Read by exposure._resolve_finish_
    # type for side == 'back'; L/R keep default_finished_end_type.
    default_finished_back_type: EnumProperty(
        name="Default Finished Back Type",
        description="Finished-end type auto-applied to exposed cabinet backs",
        items=FIN_END_ITEMS, default='FINISHED',
    )  # type: ignore
    # What exposure auto-pick writes to a side that abuts a dishwasher
    # (or other panel-ready appliance). Default UNFINISHED: the side
    # comes in unfinished with the standard 0.25" neighbor scribe, and
    # a flush fin is added manually per side when wanted. Pick FLUSH_X
    # here to restore the automatic flush fin (amount from Default
    # Flush X Amount). Read by exposure._resolve_finish_type.
    dishwasher_finished_end_type: EnumProperty(
        name="Dishwasher Side Finished End Type",
        description="Finished end auto-applied to cabinet sides abutting a dishwasher",
        items=FIN_END_ITEMS, default='UNFINISHED',
    )  # type: ignore
    default_scribe: FloatProperty(
        name="Default Scribe", default=units.inch(0.5),
        unit='LENGTH', precision=4,
    )  # type: ignore
    default_flush_x_amount: FloatProperty(
        name="Default Flush X Amount", default=units.inch(4),
        unit='LENGTH', precision=4,
    )  # type: ignore
    default_panel_frame_auto: BoolProperty(
        name="Default Auto Panel Frame Widths", default=True,
    )  # type: ignore
    default_panel_top_rail_width: FloatProperty(
        name="Default Panel Top Rail Width", default=units.inch(1.5),
        unit='LENGTH', precision=4,
    )  # type: ignore
    default_panel_bottom_rail_width: FloatProperty(
        name="Default Panel Bottom Rail Width", default=units.inch(1.5),
        unit='LENGTH', precision=4,
    )  # type: ignore
    default_panel_stile_width: FloatProperty(
        name="Default Panel Stile Width", default=units.inch(1.5),
        unit='LENGTH', precision=4,
    )  # type: ignore
    show_front_options: BoolProperty(name="Show Front Options", default=False)  # type: ignore
    show_drawer_options: BoolProperty(name="Show Drawer Options", default=False)  # type: ignore
    show_countertop_options: BoolProperty(name="Show Countertop Options", default=False)  # type: ignore
    show_molding_options: BoolProperty(name="Show Molding Options", default=False)  # type: ignore

    # ---- Cabinet styles collection ----
    cabinet_styles: CollectionProperty(type=Face_Frame_Cabinet_Style)  # type: ignore
    active_cabinet_style_index: IntProperty(name="Active Cabinet Style Index", default=0)  # type: ignore

    # Shared door-style pool. Cabinet styles reference one entry as the door
    # style and another as the drawer-front style via integer indices.
    door_styles: CollectionProperty(type=Face_Frame_Door_Style)  # type: ignore
    active_door_style_index: IntProperty(name="Active Door Style Index", default=0)  # type: ignore
    drawer_front_styles: CollectionProperty(type=Face_Frame_Door_Style)  # type: ignore
    active_drawer_front_style_index: IntProperty(name="Active Drawer Front Style Index", default=0)  # type: ignore

    # ---- Default placement behaviour ----
    fill_cabinets: BoolProperty(
        name="Fill Cabinets",
        description="When dropping a cabinet, fill the available space",
        default=True,
    )  # type: ignore

    auto_join_cabinets: BoolProperty(
        name="Auto Join",
        description=(
            "Join a newly placed cabinet into the abutting cabinet "
            "beside it when the two match. Turn off to keep every "
            "cabinet a separate unit - a cabinet placed at a different "
            "depth to its neighbour, for instance"
        ),
        default=True,
    )  # type: ignore

    cabinet_placement_holdoff: FloatProperty(
        name="Cabinet Placement Hold-off",
        description=(
            "Hold cabinets back from entry doors, windows, open wall "
            "ends, and outside corners by this amount during placement. "
            "Inside corners run flush. Arrow-key offsets override this "
            "per side."
        ),
        default=units.inch(5.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # ---- Cabinet sizes ----
    default_top_cabinet_clearance: FloatProperty(
        name="Default Top Cabinet Clearance",
        description="Clearance to hold top cabinets from ceiling",
        default=units.inch(12.0),
        unit='LENGTH',
        precision=4,
        update=update_top_cabinet_clearance,
    )  # type: ignore

    default_wall_cabinet_location: FloatProperty(
        name="Default Wall Cabinet Location",
        description="Distance from floor to bottom of wall cabinet",
        default=units.inch(54.0),
        unit='LENGTH',
        precision=4,
        update=update_top_cabinet_clearance,
    )  # type: ignore

    default_cabinet_width: FloatProperty(
        name="Default Cabinet Width",
        description="Default width for cabinets when not filling",
        default=units.inch(36.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    countertop_thickness: FloatProperty(
        name="Countertop Thickness",
        description="Thickness of the countertop slab",
        default=units.inch(1.5),
        unit='LENGTH',
    )  # type: ignore

    countertop_overhang_front: FloatProperty(
        name="Countertop Front Overhang",
        description="Overhang past the front of cabinets",
        default=units.inch(1.0),
        unit='LENGTH',
    )  # type: ignore

    countertop_overhang_sides: FloatProperty(
        name="Countertop Side Overhang",
        description="Overhang past exposed ends of cabinets",
        default=units.inch(1.0),
        unit='LENGTH',
    )  # type: ignore

    countertop_overhang_back: FloatProperty(
        name="Countertop Back Overhang",
        description="Overhang past the back of cabinets toward wall",
        default=units.inch(0.0),
        unit='LENGTH',
    )  # type: ignore

    base_cabinet_depth: FloatProperty(
        name="Base Cabinet Depth",
        description="Default depth for base cabinets",
        default=units.inch(24.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # ---- Toe kick defaults ----
    # Project-wide toe kick: seeds toe_kick_height / toe_kick_setback on
    # every new cabinet (create_cabinet_root) and drives Update Toe
    # Kicks, which pushes the values onto the cabinets already built.
    # Mirrored across room scenes. Per-cabinet values stay editable.
    default_toe_kick_height: FloatProperty(
        name="Toe Kick Height",
        description="Toe kick height for new cabinets in this project",
        default=units.inch(4.0),
        unit='LENGTH',
        precision=4,
        update=_sync_toe_kick_defaults,
    )  # type: ignore

    default_toe_kick_setback: FloatProperty(
        name="Toe Kick Setback",
        description="Toe kick depth (setback from the cabinet front) for new cabinets in this project",
        default=units.inch(3.0),
        unit='LENGTH',
        precision=4,
        update=_sync_toe_kick_defaults,
    )  # type: ignore

    base_cabinet_height: FloatProperty(
        name="Base Cabinet Height",
        description="Default height for base cabinets",
        default=units.inch(34.5),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    tall_cabinet_depth: FloatProperty(
        name="Tall Cabinet Depth",
        description="Default depth for tall cabinets",
        default=units.inch(25.5),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    tall_cabinet_height: FloatProperty(
        name="Tall Cabinet Height",
        description="Default height for tall cabinets",
        default=units.inch(84.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    tall_cabinet_split_height: FloatProperty(
        name="Tall Cabinet Split Height",
        description="Height at which a tall cabinet is split into upper and lower sections",
        default=units.inch(54.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    top_drawer_opening_height: FloatProperty(
        name="Top Drawer Opening Height",
        description="Height of the top drawer opening in base cabinet "
                    "drawer presets (1 Drawer x Door, 3 Drawers, 4 "
                    "Drawers, etc.). Kept uniform across every room in "
                    "the project; per-drawer unlocked heights still "
                    "override on individual cabinets",
        default=units.inch(4.5),
        unit='LENGTH',
        precision=4,
        update=_sync_top_drawer_opening_height,
    )  # type: ignore

    upper_cabinet_depth: FloatProperty(
        name="Upper Cabinet Depth",
        description="Default depth for upper cabinets",
        default=units.inch(12.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    upper_cabinet_height: FloatProperty(
        name="Upper Cabinet Height",
        description="Default height for upper cabinets",
        default=units.inch(30.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # ---- Pulls: scene-level selection ----
    door_pull_category: EnumProperty(
        name="Pull Category",
        items=_pull_category_enum_items,
    )  # type: ignore
    door_pull_selection: EnumProperty(
        name="Door Pull",
        items=_pull_enum_items,
        update=_update_pulls_on_selection_change,
    )  # type: ignore
    drawer_pull_selection: EnumProperty(
        name="Drawer Pull",
        items=_pull_enum_items,
        update=_update_pulls_on_selection_change,
    )  # type: ignore

    # Pull library browser: an inert selection (no update callback) the
    # Assign buttons read. Assignment state lives in the pull_assign_*
    # strings below - browsing never changes placed pulls.
    pull_browser_selection: EnumProperty(
        name="Pull",
        description="Pull to assign (pick a zone button below to apply)",
        items=_pull_enum_items,
    )  # type: ignore

    # Per-zone pull assignments (filename + category folder), written
    # by hb_face_frame.assign_pull. Empty = unassigned, which falls
    # back to the legacy scene-wide selections (door_pull_selection /
    # drawer_pull_selection) so pre-assignment scenes keep their pulls;
    # 'NONE' = no pull for that zone.
    pull_assign_base: StringProperty(default="")  # type: ignore
    pull_assign_base_category: StringProperty(default="")  # type: ignore
    pull_assign_tall: StringProperty(default="")  # type: ignore
    pull_assign_tall_category: StringProperty(default="")  # type: ignore
    pull_assign_upper: StringProperty(default="")  # type: ignore
    pull_assign_upper_category: StringProperty(default="")  # type: ignore
    pull_assign_drawers: StringProperty(default="")  # type: ignore
    pull_assign_drawers_category: StringProperty(default="")  # type: ignore

    # Finish material swapped onto every pull mesh (scene-wide,
    # including per-opening overridden pulls). Dynamic items so the
    # list lives in pulls.py; AS_MODELED is first, making it the
    # default - the asset's own materials, the pre-finish behavior.
    pull_finish: EnumProperty(
        name="Pull Finish",
        description="Finish material applied to every cabinet pull",
        items=_pull_finish_enum_items,
        update=_update_pulls_on_selection_change,
    )  # type: ignore

    # Cached pull objects. Once the user picks a pull we load the .blend
    # once and link the same Object to every cabinet's pull instances.
    # Cleared / repopulated by the front-builder when selection or
    # category changes.
    current_door_pull_object: PointerProperty(type=bpy.types.Object)  # type: ignore
    current_drawer_pull_object: PointerProperty(type=bpy.types.Object)  # type: ignore

    # ---- Pulls: positioning controls ----
    # Door pulls measure horizontally from the unhinged edge of the door
    # (the side opposite the hinge). Drawer pulls use this offset as a
    # margin from one end when not centered.
    pull_horizontal_offset: FloatProperty(
        name="Pull Horizontal Offset",
        description="Distance from the door's unhinged edge to the pull's nearest edge",
        default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_pulls_on_selection_change,
    )  # type: ignore
    # Vertical placement is per cabinet zone:
    #   Base: distance from TOP of door down to pull (reach from above)
    #   Tall: distance from BOTTOM of door up to pull
    #   Upper: distance from BOTTOM of door up to pull (reach from below)
    pull_vertical_location_base: FloatProperty(
        name="Base Pull Vertical Location",
        default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_pulls_on_selection_change,
    )  # type: ignore
    pull_vertical_location_tall: FloatProperty(
        name="Tall Pull Vertical Location",
        default=units.inch(36.0), unit='LENGTH', precision=4,
        update=_update_pulls_on_selection_change,
    )  # type: ignore
    pull_vertical_location_upper: FloatProperty(
        name="Upper Pull Vertical Location",
        default=units.inch(1.5), unit='LENGTH', precision=4,
        update=_update_pulls_on_selection_change,
    )  # type: ignore
    center_pulls_on_drawer_front: BoolProperty(
        name="Center Pulls on Drawer Front",
        default=True,
        update=_update_pulls_on_selection_change,
    )  # type: ignore

    upper_top_stacked_cabinet_height: FloatProperty(
        name="Upper Top Stacked Cabinet Height",
        description="Height of the top section of a stacked upper cabinet",
        default=units.inch(12.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # ---- Corner cabinet sizes ----
    base_inside_corner_size: FloatProperty(
        name="Base Inside Corner Size",
        description="Width and depth for inside base corner cabinets",
        default=units.inch(36.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    tall_inside_corner_size: FloatProperty(
        name="Tall Inside Corner Size",
        description="Width and depth for inside tall corner cabinets",
        default=units.inch(36.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    upper_inside_corner_size: FloatProperty(
        name="Upper Inside Corner Size",
        description="Width and depth for inside upper corner cabinets",
        default=units.inch(24.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    base_width_blind: FloatProperty(
        name="Base Width Blind",
        description="Default width for base blind corner cabinets",
        default=units.inch(48.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    tall_width_blind: FloatProperty(
        name="Tall Width Blind",
        description="Default width for tall blind corner cabinets",
        default=units.inch(48.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    upper_width_blind: FloatProperty(
        name="Upper Width Blind",
        description="Default width for upper blind corner cabinets",
        default=units.inch(36.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # ---- Appliance sizes ----
    refrigerator_height: FloatProperty(
        name="Refrigerator Height",
        description="Default refrigerator height",
        default=units.inch(69.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    refrigerator_cabinet_width: FloatProperty(
        name="Refrigerator Cabinet Width",
        description="Default refrigerator cabinet width",
        default=units.inch(40.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    range_width: FloatProperty(
        name="Range Width",
        description="Default range width",
        default=units.inch(36.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    dishwasher_width: FloatProperty(
        name="Dishwasher Width",
        description="Default dishwasher width",
        default=units.inch(24.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    sink_cabinet_width: FloatProperty(
        name="Sink Cabinet Width",
        description="Default sink cabinet width",
        default=units.inch(36.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    oven_cabinet_width: FloatProperty(
        name="Oven Cabinet Width",
        description="Default oven cabinet width",
        default=units.inch(33.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # ---- Face frame defaults (used by Phase 3 cabinet construction) ----
    ff_end_stile_width: FloatProperty(
        name="End Stile Width",
        description="Default end stile width",
        default=units.inch(2.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # Exposed (visible) portion of a blind-corner end stile. When the
    # adjacent cabinet butts into the blind side (blind_left/right True),
    # the stile widens by another 0.75" to accept the adjacent face -
    # so a 3.0" default yields a 3.75" stile with 3.0" visible.
    ff_blind_stile_width: FloatProperty(
        name="Blind Stile Width",
        description="Visible (exposed) portion of a blind-corner end stile",
        default=units.inch(3.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    ff_top_rail_width: FloatProperty(
        name="Top Rail Width",
        description="Default top rail width",
        default=units.inch(1.5),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    ff_bottom_rail_width: FloatProperty(
        name="Bottom Rail Width",
        description="Default bottom rail width",
        default=units.inch(1.5),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    ff_mid_stile_width: FloatProperty(
        name="Mid Stile Width",
        description="Default mid stile width",
        default=units.inch(2.0),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    ff_face_frame_thickness: FloatProperty(
        name="Face Frame Thickness",
        description="Thickness of face frame members",
        default=units.inch(0.75),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    ff_door_overlay: FloatProperty(
        name="Default Door Overlay",
        description="Default amount the door overlays the face frame",
        default=units.inch(0.5),
        unit='LENGTH',
        precision=4,
    )  # type: ignore

    # =====================================================================
    # UI: cabinet sizes section
    # =====================================================================
    def _refrigerator_opening_width(self, context=None):
        """Width of the opening the refrigerator actually gets: the
        cabinet width less both end stiles. A refrigerator cabinet is a
        tall cabinet and both of its sides use the standard end-stile
        row, so the widths come from the active style's tall end stile.
        Returns None when there is no style to read widths from."""
        ff = get_style_props(context)
        idx = ff.active_cabinet_style_index
        if not (0 <= idx < len(ff.cabinet_styles)):
            return None
        style = ff.cabinet_styles[idx]
        opening = (self.refrigerator_cabinet_width
                   - style.ff_end_stile_width_tall * 2)
        return opening if opening > 0.0 else 0.0

    def draw_cabinet_sizes_ui(self, layout, context):
        unit_settings = context.scene.unit_settings

        row = layout.row()
        row.label(text="Top Cabinet Clearance:")
        row.prop(self, 'default_top_cabinet_clearance', text="")
        row.operator('hb_face_frame.update_cabinet_sizes', text="", icon='FILE_REFRESH')

        row = layout.row()
        row.label(text="Upper Cabinet Dim to Floor:")
        row.prop(self, 'default_wall_cabinet_location', text="")
        row.label(text="", icon='BLANK1')

        row = layout.row()
        row.label(text="Hold Off From Ends & Windows:")
        row.prop(self, 'cabinet_placement_holdoff', text="")
        row.label(text="", icon='BLANK1')

        row = layout.row()
        row.label(text="Sizes")
        row.label(text="Base")
        row.label(text="Tall")
        row.label(text="Upper")

        row = layout.row()
        row.label(text="Depth:")
        row.prop(self, 'base_cabinet_depth', text="")
        row.prop(self, 'tall_cabinet_depth', text="")
        row.prop(self, 'upper_cabinet_depth', text="")

        # Tall and upper heights are derived from ceiling, top clearance,
        # and wall cabinet location - disable their fields so the user
        # edits the source values instead. Base height stays editable.
        row = layout.row()
        row.label(text="Height:")
        row.prop(self, 'base_cabinet_height', text="")
        sub = row.row()
        sub.enabled = False
        sub.prop(self, 'tall_cabinet_height', text="")
        sub = row.row()
        sub.enabled = False
        sub.prop(self, 'upper_cabinet_height', text="")

        # Project toe kick: seeds new cabinets; the refresh pushes the
        # values onto every cabinet already in the room.
        row = layout.row()
        row.label(text="Toe Kick H / D:")
        row.prop(self, 'default_toe_kick_height', text="")
        row.prop(self, 'default_toe_kick_setback', text="")
        row.operator('hb_face_frame.update_toe_kicks', text="", icon='FILE_REFRESH')

        layout.separator()
        ohbox = layout.box()
        ohbox.prop(self, 'show_opening_heights', text="Opening Heights",
                   icon='TRIA_DOWN' if self.show_opening_heights else 'TRIA_RIGHT',
                   emboss=False)
        if self.show_opening_heights:
            row = ohbox.row()
            row.label(text="Tall Split Height:")
            row.prop(self, 'tall_cabinet_split_height', text="")
            row = ohbox.row()
            row.label(text="Top Drawer Opening Height:")
            row.prop(self, 'top_drawer_opening_height', text="")
            # Re-sync existing drawer-preset cabinets to the value above
            # (changing it does not re-flow cabinets already built).
            row.operator('hb_face_frame.refresh_top_drawer_openings',
                         text="", icon='FILE_REFRESH')
            row = ohbox.row()
            row.label(text="Upper Stacked Top Height:")
            row.prop(self, 'upper_top_stacked_cabinet_height', text="")

        # Corner + appliance sizes live here (moved out of their library
        # sections) so those sections list only products and this whole
        # block collapses with Cabinet Sizes.
        cbox = layout.box()
        cbox.prop(self, 'show_corner_sizes', text="Corner Sizes",
                  icon='TRIA_DOWN' if self.show_corner_sizes else 'TRIA_RIGHT',
                  emboss=False)
        if self.show_corner_sizes:
            row = cbox.row()
            row.label(text="")
            row.label(text="Base")
            row.label(text="Tall")
            row.label(text="Upper")
            row = cbox.row()
            row.label(text="Inside Corner:")
            row.prop(self, 'base_inside_corner_size', text="")
            row.prop(self, 'tall_inside_corner_size', text="")
            row.prop(self, 'upper_inside_corner_size', text="")
            row = cbox.row()
            row.label(text="Blind Width:")
            row.prop(self, 'base_width_blind', text="")
            row.prop(self, 'tall_width_blind', text="")
            row.prop(self, 'upper_width_blind', text="")

        abox = layout.box()
        abox.prop(self, 'show_appliance_sizes', text="Appliance Sizes",
                  icon='TRIA_DOWN' if self.show_appliance_sizes else 'TRIA_RIGHT',
                  emboss=False)
        if self.show_appliance_sizes:
            row = abox.row()
            row.label(text="Refrigerator Height:")
            row.prop(self, 'refrigerator_height', text="")
            row = abox.row()
            row.label(text="Refrigerator Cabinet Width:")
            row.prop(self, 'refrigerator_cabinet_width', text="")
            opening = self._refrigerator_opening_width(context)
            if opening is not None:
                row = abox.row()
                row.label(text="Refrigerator Opening Width:")
                row.label(text=units.unit_to_string(unit_settings, opening))
            row = abox.row()
            row.label(text="Dishwasher / Range:")
            row.prop(self, 'dishwasher_width', text="")
            row.prop(self, 'range_width', text="")
            row = abox.row()
            row.label(text="Sink / Oven:")
            row.prop(self, 'sink_cabinet_width', text="")
            row.prop(self, 'oven_cabinet_width', text="")

    # =====================================================================
    # UI: shared helper - draw a grid of catalog buttons
    # =====================================================================
    def _draw_catalog_grid(self, layout, products, columns=3):
        """Render a grid_flow of catalog buttons. `products` is an
        iterable of names; each name is used identically as the display
        label, the cabinet_name passed to draw_cabinet, and the
        thumbnail filename in face_frame_thumbnails/. Folding all three
        into one string keeps placeholder lists short - real renders
        and per-product dispatch routing can deviate later by switching
        to (display, cabinet_name, thumb_name) triples.
        """
        # List view: a tight column of full-width name buttons -- no
        # thumbnails, so many more products fit without scrolling. The
        # operator + payload match the thumbnail tiles exactly.
        if self.library_view_mode == 'LIST':
            # Two-column grid of plain name buttons -- denser than one
            # full-width row each, no thumbnails. Long names truncate.
            flow = layout.grid_flow(row_major=True, columns=2,
                                    even_columns=True, even_rows=False,
                                    align=True)
            for name in products:
                op = flow.operator('hb_face_frame.draw_cabinet', text=name)
                op.cabinet_name = name
            return

        flow = layout.grid_flow(row_major=True, columns=columns,
                                even_columns=True, even_rows=True, align=True)
        for name in products:
            box = flow.box()
            box.scale_y = 0.9
            icon_id = load_cabinet_thumbnail(name)
            if icon_id:
                box.template_icon(icon_value=icon_id, scale=4.0)
            op = box.operator('hb_face_frame.draw_cabinet', text=name)
            op.cabinet_name = name

    def _draw_catalog_labeled_row(self, layout, label, items):
        """One row: an optional left LABEL (omitted when blank) then
        product buttons to its right. `items` is a list of
        (display, cabinet_name) so the button
        can show a short name (e.g. "Base") while firing the full product
        ("Pie Cut Base"). Honors the thumbnail/list toggle: thumbnails get
        a tile each, list gets compact text buttons.
        """
        from . import library_catalog
        row = layout.row(align=True)
        if label:
            row.label(text=label)
        if self.library_view_mode == 'LIST':
            for display, cab in items:
                op = row.operator('hb_face_frame.draw_cabinet', text=display)
                op.cabinet_name = cab
                self._draw_path_button(row, cab, library_catalog)
        else:
            for display, cab in items:
                cell = row.column(align=True)
                icon_id = load_cabinet_thumbnail(cab)
                if icon_id:
                    cell.template_icon(icon_value=icon_id, scale=4.0)
                sub = cell.row(align=True)
                op = sub.operator('hb_face_frame.draw_cabinet', text=display)
                op.cabinet_name = cab
                self._draw_path_button(sub, cab, library_catalog)

    @staticmethod
    def _draw_path_button(layout, cabinet_name, library_catalog):
        """The second way in for a product that can be drawn through
        points: an icon beside its place button, the same affordance
        the viewport browser puts on the tile."""
        if not library_catalog.can_draw_path(cabinet_name):
            return
        op = layout.operator('hb_face_frame.draw_product_path', text="",
                             icon='IPO_LINEAR')
        op.cabinet_name = cabinet_name

    # =====================================================================
    # UI: product sections
    # =====================================================================
    # The products themselves live in library_catalog. They used to be
    # written out inline here, which meant the library could only be
    # read by drawing it -- no search, no category filter, no second
    # view of it anywhere. These render the shared data; the viewport
    # library panel reads the very same rows.

    def _draw_library_section(self, layout, section_key):
        """Draw one catalog section from the shared product data."""
        from . import library_catalog
        section = library_catalog.section_by_key(section_key)
        if section is None:
            return
        for row_label, items in section['rows']:
            self._draw_catalog_labeled_row(layout, row_label, items)

    def draw_cabinet_library_ui(self, layout, context):
        self._draw_library_section(layout, 'standard')
        layout.prop(self, 'auto_join_cabinets')

    def draw_corner_cabinet_library_ui(self, layout, context):
        self._draw_library_section(layout, 'corner')

    def draw_appliance_library_ui(self, layout, context):
        self._draw_library_section(layout, 'appliance')

    def draw_galley_library_ui(self, layout, context):
        self._draw_library_section(layout, 'galley')

    def draw_vanity_library_ui(self, layout, context):
        self._draw_library_section(layout, 'vanity')

    def draw_part_library_ui(self, layout, context):
        self._draw_library_section(layout, 'parts')

    def draw_specialty_bath_library_ui(self, layout, context):
        self._draw_library_section(layout, 'bath')

    def draw_bedroom_bookcase_library_ui(self, layout, context):
        self._draw_library_section(layout, 'bedroom')

    def draw_misc_library_ui(self, layout, context):
        self._draw_library_section(layout, 'misc')

    # =====================================================================
    # UI: angled library
    # =====================================================================
    def draw_angled_library_ui(self, layout, context):
        self._draw_catalog_grid(layout, [
            "Angled Ends with Doors", "Double Angled Ends",
            "Angled Finished Ends",
        ], columns=2)

    # =====================================================================
    # UI: user library
    # =====================================================================
    def draw_user_library_ui(self, layout, context):
        from .operators import ops_library

        # Header row: refresh + open-folder. Keeps these one tap away when
        # the user is iterating on a saved group.
        row = layout.row()
        row.label(text="User Library")
        row.operator('hb_face_frame.refresh_user_library', text="", icon='FILE_REFRESH')
        row.operator('hb_face_frame.open_user_library_folder', text="", icon='FILE_FOLDER')

        # Create + save sit at the top so the workflow reads top-down:
        # build a group, save it, browse what's already saved.
        col = layout.column(align=True)
        col.operator('hb_face_frame.create_cabinet_group', text="Create Cabinet Group", icon='ADD')
        col.operator('hb_face_frame.save_cabinet_group_to_user_library',
                     text="Save to Library", icon='FILE_TICK')

        layout.separator()

        row = layout.row(align=True)
        row.label(text="Category:")
        row.prop(self, 'cabinet_group_category', text="")

        category = self.cabinet_group_category if hasattr(self, 'cabinet_group_category') else 'ALL'
        library_items = ops_library.get_user_library_items(
            None if category == 'ALL' else category
        )

        if not library_items:
            box = layout.box()
            box.label(text="No saved cabinet groups", icon='INFO')
            box.label(text="Save a cabinet group to see it here")
            return

        box = layout.box()
        box.label(text=f"Saved Groups ({len(library_items)})", icon='ASSET_MANAGER')

        # Two-column grid of saved items. Each cell shows name + delete +
        # thumbnail (if rendered) + an Add-to-Scene button that fires the
        # modal load operator.
        flow = box.column_flow(columns=2, align=True)

        for item in library_items:
            item_box = flow.box()

            row = item_box.row()
            row.label(text=item['name'])
            del_op = row.operator('hb_face_frame.delete_library_item',
                                  text="", icon='X', emboss=False)
            del_op.filepath = item['filepath']
            del_op.item_name = item['name']

            if item['thumbnail']:
                icon_id = load_library_thumbnail(item['thumbnail'], item['name'])
                if icon_id:
                    item_box.template_icon(icon_value=icon_id, scale=5.0)

            op = item_box.operator('hb_face_frame.load_cabinet_group_from_library',
                                   text="Add to Scene", icon='IMPORT')
            op.filepath = item['filepath']

    # =====================================================================
    # UI: pulls (Options tab)
    # =====================================================================
    def draw_finished_ends_ui(self, layout, context):
        # default_scribe and default_panel_frame_auto (with its top/bottom
        # rail and stile width children) are intentionally hidden from
        # this UI. The underlying properties still drive the solver - the
        # user just doesn't access them here.
        col = layout.column(align=True)
        col.prop(self, 'default_finished_end_type', text="Type")
        col.prop(self, 'default_finished_back_type', text="Back Type")
        col.prop(self, 'dishwasher_finished_end_type', text="Dishwasher Side")
        # The amount field serves whichever default resolves to FLUSH_X;
        # exposure auto-pick seeds the per-cabinet amount from it.
        if (self.default_finished_end_type == 'FLUSH_X'
                or self.default_finished_back_type == 'FLUSH_X'
                or self.dishwasher_finished_end_type == 'FLUSH_X'):
            col.prop(self, 'default_flush_x_amount', text="Flush X Amount")
        col.separator()
        # The bulk operator walks every cabinet in the scene and writes
        # default_finished_end_type to any side flagged exposed. Type
        # only - scribe / flush_x / panel-frame defaults are read by the
        # solver per cabinet, so changing them here propagates without a
        # sweep.
        col.operator(
            "hb_face_frame.apply_finished_ends_to_exposed",
            text="Apply to All Exposed", icon='CHECKMARK',
        )
        col.operator(
            "hb_face_frame.recalculate_side_exposure",
            text="Recalculate Side Exposure", icon='FILE_REFRESH',
        )
        # When the scene default is anything other than plain FINISHED,
        # applied panels can exist in the scene. Surface the Show Applied
        # Panels operator here so it's reachable from the same panel that
        # configures the finish type.
        if (self.default_finished_end_type != 'FINISHED'
                or self.default_finished_back_type != 'FINISHED'):
            col.separator()
            col.operator(
                "hb_face_frame.show_applied_panels",
                text="Show Applied Panels", icon='HIDE_OFF',
            )

    def draw_pulls_ui(self, layout, context):
        from . import pulls

        # Library browser (inert - the Assign buttons apply it).
        col = layout.column(align=True)
        col.label(text="Pull Library:")
        col.prop(self, 'door_pull_category', text="Category")
        col.prop(self, 'pull_browser_selection', text="")
        if self.pull_browser_selection not in ('NONE', ''):
            icon_id = pulls.load_pull_thumbnail_icon(
                self.pull_browser_selection,
                pulls._resolve_real_category(self.door_pull_category),
            )
            if icon_id:
                col.template_icon(icon_value=icon_id, scale=4.0)
        col.prop(self, 'pull_finish', text="Finish")

        col.separator()
        col.label(text="Assign to:")
        row = col.row(align=True)
        for target, label in (('BASE', "Base"), ('TALL', "Tall"),
                              ('UPPER', "Upper"), ('DRAWERS', "Drawers")):
            row.operator('hb_face_frame.assign_pull',
                         text=label).target = target
        col.operator('hb_face_frame.assign_pull',
                     text="Assign to Selected Fronts",
                     icon='RESTRICT_SELECT_OFF').target = 'SELECTED'

        # Current assignments. Unassigned zones ride the legacy
        # scene-wide selections, so show the effective pull.
        box = col.box()
        bcol = box.column(align=True)
        for zone_prop, label, legacy in (
                ('pull_assign_base', "Base", self.door_pull_selection),
                ('pull_assign_tall', "Tall", self.door_pull_selection),
                ('pull_assign_upper', "Upper", self.door_pull_selection),
                ('pull_assign_drawers', "Drawers",
                 self.drawer_pull_selection)):
            sel = getattr(self, zone_prop) or legacy
            stem = ("None" if sel in ('NONE', '')
                    else os.path.splitext(sel)[0])
            bcol.label(text=f"{label}: {stem}")

        col.separator()
        col.label(text="Position:")
        col.prop(self, 'pull_horizontal_offset', text="Horizontal Offset")
        col.prop(self, 'pull_vertical_location_base', text="Base Vertical")
        col.prop(self, 'pull_vertical_location_tall', text="Tall Vertical")
        col.prop(self, 'pull_vertical_location_upper', text="Upper Vertical")
        col.prop(self, 'center_pulls_on_drawer_front', text="Center Drawer Pulls")

        # Installed pull packs merge into the dropdowns above; the
        # folder button is the manual route (drop category folders of
        # .blend pulls straight in).
        col.separator()
        row = col.row(align=True)
        row.operator('hb_face_frame.install_pull_library',
                     text="Install Pull Library...", icon='IMPORT')
        row.operator('hb_face_frame.open_pull_library_folder',
                     text="", icon='FILE_FOLDER')

    # =====================================================================
    # UI: cabinet styles (Options tab, placeholder for Phase 4)
    # =====================================================================
    def draw_cabinet_styles_ui(self, layout, context):
        # Pool is project-global (main scene); draw it regardless of which
        # room scene is active.
        sp = get_style_props(context)
        row = layout.row()
        row.template_list(
            "HB_UL_face_frame_cabinet_styles", "",
            sp, "cabinet_styles",
            sp, "active_cabinet_style_index",
            rows=3,
        )
        side = row.column(align=True)
        side.operator("hb_face_frame.add_cabinet_style", text="", icon='ADD')
        side.operator("hb_face_frame.remove_cabinet_style", text="", icon='REMOVE')
        # Reorder: 2D fill colours follow list order (first style = white), so
        # moving a style up/down changes which one is left white.
        side.separator()
        side.operator("hb_face_frame.move_cabinet_style", text="", icon='TRIA_UP').direction = 'UP'
        side.operator("hb_face_frame.move_cabinet_style", text="", icon='TRIA_DOWN').direction = 'DOWN'

        # Show the drawing fills on the cabinets themselves, so which
        # style a cabinet is in reads in the viewport rather than only
        # after the 2D pages are generated.
        layout.prop(sp, 'show_style_colors', text="Style Colors In Viewport")

        if sp.cabinet_styles and sp.active_cabinet_style_index < len(sp.cabinet_styles):
            style = sp.cabinet_styles[sp.active_cabinet_style_index]
            # Assign to Selected hits the current selection; Assign by
            # Painting is a modal click-to-assign; Update walks every
            # cabinet already tagged with this style name.
            btn = layout.row(align=True)
            btn.scale_y = 1.3
            btn.operator("hb_face_frame.assign_style_to_selected_cabinets",
                         text="Assign to Selected", icon='RESTRICT_SELECT_OFF')
            btn.operator("hb_face_frame.paint_assign_cabinet_style",
                         text="Assign by Painting", icon='BRUSH_DATA')
            btn.operator("hb_face_frame.update_cabinets_from_style",
                         text="", icon='FILE_REFRESH')
            # Part paint: stamp the style's finish / interior material onto
            # individual parts (or any object). Cabinet parts store it as a
            # per-part override that survives recalc; Reset returns a part
            # to its by-role material.
            paint = layout.row(align=True)
            paint.label(text="Paint Part:")
            op = paint.operator("hb_face_frame.paint_part_material",
                                text="Finish", icon='BRUSH_DATA')
            op.brush = 'FINISH'
            op = paint.operator("hb_face_frame.paint_part_material",
                                text="Interior", icon='BRUSH_DATA')
            op.brush = 'INTERIOR'
            op = paint.operator("hb_face_frame.paint_part_material",
                                text="Reset", icon='X')
            op.brush = 'RESET'
            style.draw_cabinet_style_ui(layout, context)
        else:
            box = layout.box()
            box.label(text="No cabinet styles defined", icon='INFO')

    def draw_door_styles_ui(self, layout, context):
        # Door styles and drawer front styles are SEPARATE project-global
        # pools (independent lists). A tab switches between them so only one
        # list + editor draws at a time; the catalog the editor reads is
        # implied by the pool (see _front_is_drawer), so neither shows a Kind
        # field.
        sp = get_style_props(context)
        tab_row = layout.row()
        tab_row.prop(sp, "door_style_tab", expand=True)

        if sp.door_style_tab == 'DRAWER':
            coll, idx_attr = "drawer_front_styles", "active_drawer_front_style_index"
            add_op = "hb_face_frame.add_drawer_front_style"
            rem_op = "hb_face_frame.remove_drawer_front_style"
            empty = "No drawer front styles defined"
        else:
            coll, idx_attr = "door_styles", "active_door_style_index"
            add_op = "hb_face_frame.add_door_style"
            rem_op = "hb_face_frame.remove_door_style"
            empty = "No door styles defined"

        row = layout.row()
        row.template_list(
            "HB_UL_face_frame_door_styles", "",
            sp, coll,
            sp, idx_attr,
            rows=3,
        )
        side = row.column(align=True)
        side.operator(add_op, text="", icon='ADD')
        side.operator(rem_op, text="", icon='REMOVE')

        pool = getattr(sp, coll)
        idx = getattr(sp, idx_attr)
        if pool and idx < len(pool):
            pool[idx].draw_door_style_ui(layout, context)
        else:
            layout.box().label(text=empty, icon='INFO')

    # =====================================================================
    # UI: master draw entry point (called by view3d_sidebar)
    # =====================================================================
    def draw_library_ui(self, layout, context):
        col = layout.column(align=True)

        # Tab selector. On the LIBRARY tab an icon-only Thumbnail/List
        # toggle is pinned to the right end of this same row.
        row = col.row(align=True)
        row.scale_y = 1.3
        row.prop_enum(self, 'face_frame_tabs', 'LIBRARY', icon='ASSET_MANAGER')
        row.prop_enum(self, 'face_frame_tabs', 'OPTIONS', icon='PREFERENCES')

        if self.face_frame_tabs == 'LIBRARY':
            view = row.row(align=True)
            view.alignment = 'RIGHT'
            view.prop(self, 'library_view_mode', expand=True, icon_only=True)

            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_cabinet_sizes', text="Cabinet Sizes",
                     icon='TRIA_DOWN' if self.show_cabinet_sizes else 'TRIA_RIGHT', emboss=False)
            if self.show_cabinet_sizes:
                self.draw_cabinet_sizes_ui(box, context)

            # Each section is one collapsible box; default state matches
            # the "Standard Cabinets open, rest closed" hierarchy of the
            # catalog. Order mirrors the canonical product-list order so
            # users can scan top-down.
            sections = [
                ('show_cabinet_library',          "Standard Cabinets",            self.draw_cabinet_library_ui),
                ('show_appliance_library',        "Appliance Products",           self.draw_appliance_library_ui),
                ('show_galley_library',           "Galley Workstations",          self.draw_galley_library_ui),
                ('show_corner_cabinet_library',   "Corner Cabinets",              self.draw_corner_cabinet_library_ui),
                ('show_vanity_library',           "Vanities",                     self.draw_vanity_library_ui),
                ('show_part_library',             "Parts",                        self.draw_part_library_ui),
                ('show_specialty_bath_library',   "Specialty Bath",               self.draw_specialty_bath_library_ui),
                ('show_bedroom_bookcase_library', "Specialty Bedroom & Bookcases", self.draw_bedroom_bookcase_library_ui),
                # Angled hidden for now -- re-add when Angled products exist:
                # ('show_angled_library', "Angled", self.draw_angled_library_ui),
                ('show_misc_library',             "Misc",                         self.draw_misc_library_ui),
                ('show_user_library',             "User",                         self.draw_user_library_ui),
            ]
            for prop_name, label, draw_fn in sections:
                expanded = getattr(self, prop_name)
                box = col.box()
                row = box.row()
                row.alignment = 'LEFT'
                row.prop(self, prop_name, text=label,
                         icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT',
                         emboss=False)
                if expanded:
                    draw_fn(box, context)

        else:  # OPTIONS tab
            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_cabinet_styles', text="Cabinet Styles",
                     icon='TRIA_DOWN' if self.show_cabinet_styles else 'TRIA_RIGHT', emboss=False)
            if self.show_cabinet_styles:
                self.draw_cabinet_styles_ui(box, context)

            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_door_styles', text="Door & Drawer Front Styles",
                     icon='TRIA_DOWN' if self.show_door_styles else 'TRIA_RIGHT', emboss=False)
            if self.show_door_styles:
                self.draw_door_styles_ui(box, context)

            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_finished_ends_options', text="Finished Ends and Backs",
                     icon='TRIA_DOWN' if self.show_finished_ends_options else 'TRIA_RIGHT', emboss=False)
            if self.show_finished_ends_options:
                self.draw_finished_ends_ui(box, context)

            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_handle_options', text="Pulls",
                     icon='TRIA_DOWN' if self.show_handle_options else 'TRIA_RIGHT', emboss=False)
            if self.show_handle_options:
                self.draw_pulls_ui(box, context)

            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_drawer_box_options', text="Drawer Boxes",
                     icon='TRIA_DOWN' if self.show_drawer_box_options else 'TRIA_RIGHT', emboss=False)
            if self.show_drawer_box_options:
                self.draw_drawer_box_ui(box, context)

            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_countertop_options', text="Countertops",
                     icon='TRIA_DOWN' if self.show_countertop_options else 'TRIA_RIGHT', emboss=False)
            if self.show_countertop_options:
                self.draw_countertop_ui(box, context)

            box = col.box()
            row = box.row()
            row.alignment = 'LEFT'
            row.prop(self, 'show_molding_options', text="Molding",
                     icon='TRIA_DOWN' if self.show_molding_options else 'TRIA_RIGHT', emboss=False)
            if self.show_molding_options:
                self.draw_molding_ui(box, context)

    # =====================================================================
    # UI: molding packages
    # =====================================================================
    def draw_molding_ui(self, layout, context):
        """Room molding packages: three per-room dropdowns (the props
        live on the room's home_builder scene group; picking a package
        applies it to the whole room immediately) plus the recessed-
        kick toggle and a refresh for after cabinet changes."""
        from ...molding import packages as molding_packages
        hb_scene = context.scene.home_builder
        crown_pkg = hb_scene.molding_crown_package
        # Profile-override dropdowns only make sense when a molding
        # asset pack is installed; without one the packages fall back
        # to their placeholder profiles and there is nothing to pick.
        has_pack = bool(molding_packages.profile_paths())

        # --- Crown (package + furniture cap) ---
        box = layout.box()
        box.label(text="Crown", icon='NLA_PUSHDOWN')
        col = box.column(align=True)
        col.prop(hb_scene, "molding_crown_package", text="Package")
        sub = col.row()
        sub.enabled = crown_pkg != 'NONE'
        sub.prop(hb_scene, "molding_crown_reveal", text="Reveal")
        sub = col.row()
        sub.enabled = crown_pkg != 'NONE'
        sub.prop(hb_scene, "molding_crown_to_ceiling")
        sub = col.row()
        sub.enabled = (molding_packages.stack_uses_category(
                           'CROWN', crown_pkg, 'Spacer')
                       and not hb_scene.molding_crown_to_ceiling)
        sub.prop(hb_scene, "molding_spacer_height", text="Spacer Height")
        if has_pack:
            sub = col.row()
            sub.enabled = molding_packages.stack_uses_category(
                'CROWN', crown_pkg, 'Crown Molding')
            sub.prop(hb_scene, "molding_crown_profile", text="Profile")
            sub = col.row()
            sub.enabled = molding_packages.stack_uses_category(
                'CROWN', crown_pkg, 'Spacer')
            sub.prop(hb_scene, "molding_spacer_profile", text="Spacer")
        col.separator()
        col.prop(hb_scene, "molding_crown_furniture_cap")
        sub = col.row()
        sub.enabled = hb_scene.molding_crown_furniture_cap
        sub.prop(hb_scene, "molding_cap_offset", text="Height Offset")
        sub = col.row()
        sub.enabled = hb_scene.molding_crown_furniture_cap
        sub.prop(hb_scene, "molding_cap_overhang", text="Overhang")
        if has_pack:
            sub = col.row()
            sub.enabled = hb_scene.molding_crown_furniture_cap
            sub.prop(hb_scene, "molding_cap_profile", text="Cap Profile")

        # --- Base ---
        box = layout.box()
        box.label(text="Base", icon='NLA_PUSHDOWN')
        col = box.column(align=True)
        base_on = hb_scene.molding_base_package != 'NONE'
        col.prop(hb_scene, "molding_base_package", text="Package")
        if has_pack:
            sub = col.row()
            sub.enabled = base_on
            sub.prop(hb_scene, "molding_base_profile", text="Profile")
        # The shoe is independent of the package: alone it runs at the
        # kick face, with a package it applies to the molding's front.
        col.prop(hb_scene, "molding_base_shoe")
        sub = col.row()
        sub.enabled = base_on or hb_scene.molding_base_shoe
        sub.prop(hb_scene, "molding_base_include_recessed")

        # --- Light Rail ---
        box = layout.box()
        box.label(text="Light Rail", icon='NLA_PUSHDOWN')
        col = box.column(align=True)
        col.prop(hb_scene, "molding_light_rail_package", text="Package")
        if has_pack:
            sub = col.row()
            sub.enabled = hb_scene.molding_light_rail_package != 'NONE'
            sub.prop(hb_scene, "molding_light_rail_profile", text="Profile")

        layout.operator("home_builder.refresh_room_molding",
                        text="Refresh Molding", icon='FILE_REFRESH')

    # =====================================================================
    # UI: drawer boxes
    # =====================================================================
    def draw_drawer_box_ui(self, layout, context):
        from ... import hb_project
        main_scene = hb_project.get_main_scene()
        props = main_scene.hb_face_frame

        col = layout.column(align=True)
        col.prop(props, 'include_drawer_boxes', text="Include Drawer Boxes")

        col.prop(props, 'use_stock_drawer_box_heights',
                 text="Stock Box Heights")

        col.separator()
        col.label(text="Clearances:")
        col.prop(props, 'drawer_box_side_clearance', text="Side")
        col.prop(props, 'drawer_box_top_clearance', text="Top")
        col.prop(props, 'drawer_box_bottom_clearance', text="Bottom")
        col.prop(props, 'drawer_box_rear_clearance', text="Rear")

    # =====================================================================
    # UI: countertops
    # =====================================================================
    def draw_countertop_ui(self, layout, context):
        from ... import hb_project
        main_scene = hb_project.get_main_scene()
        props = main_scene.hb_face_frame

        col = layout.column(align=True)
        col.prop(props, 'countertop_thickness', text="Thickness")
        col.prop(props, 'countertop_overhang_front', text="Front Overhang")
        col.prop(props, 'countertop_overhang_sides', text="Side Overhang")
        col.prop(props, 'countertop_overhang_back', text="Back Overhang")

        layout.separator()

        row = layout.row(align=True)
        row.scale_y = 1.3
        op = row.operator('hb_face_frame.add_countertops',
                          text="Add Countertops", icon='MESH_PLANE')
        op.selected_only = False
        row.operator('hb_face_frame.remove_countertops', text="", icon='X')

        row = layout.row(align=True)
        row.scale_y = 1.3
        op = row.operator('hb_face_frame.add_countertops',
                          text="Add to Selected", icon='RESTRICT_SELECT_OFF')
        op.selected_only = True

        layout.separator()

        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator('hb_face_frame.countertop_boolean_cut',
                     text="Cut Hole (Select 2)", icon='MOD_BOOLEAN')

        layout.separator()
        box = layout.box()
        box.label(text="Backsplash", icon='MESH_GRID')
        row = box.row(align=True)
        row.scale_y = 1.3
        row.operator('home_builder.add_backsplash', text="Add Backsplash",
                     icon='MESH_GRID')
        row.operator('home_builder.remove_backsplash', text="", icon='X')
        row = box.row(align=True)
        row.scale_y = 1.3
        row.operator('home_builder.edit_backsplash', text="Edit Edges",
                     icon='EDITMODE_HLT')
        row.operator('home_builder.surface_material', text="Material",
                     icon='MATERIAL')

    # =====================================================================
    # Registration
    # =====================================================================
    @classmethod
    def register(cls):
        bpy.types.Scene.hb_face_frame = PointerProperty(
            name="Face Frame Props",
            description="Face Frame scene-level settings and library state",
            type=cls,
        )

    @classmethod
    def unregister(cls):
        if hasattr(bpy.types.Scene, 'hb_face_frame'):
            del bpy.types.Scene.hb_face_frame


# ---------------------------------------------------------------------------
# Module registration
# ---------------------------------------------------------------------------
class Face_Frame_Leg_Props(PropertyGroup):
    """Options for the Leg Product (a slim face-frame post / filler).

    Lives on the leg's cage object alongside face_frame_cabinet. The leg's
    recalculate() override reads these to build its parts; width / height /
    depth still come from face_frame_cabinet (the cage Dim X/Z/Y). All
    fields reuse _update_cabinet_dim so an edit re-runs the leg recalc
    through the standard cabinet recalc entry point.

    v1 covers the core post (two finished side panels + stile + toe kick).
    Back / nailers, Finish-X bands, and the column / appliance / island
    variants are deferred to a later pass.
    """
    finish_type: EnumProperty(
        name="Finish Type",
        items=[
            ('FINISH_LEFT', "Finish Left",
             "Finished panel on the left face only"),
            ('INTERMEDIATE', "Intermediate",
             "Unfinished filler post between cabinets"),
            ('FINISH_RIGHT', "Finish Right",
             "Finished panel on the right face only"),
            ('FINISH_BOTH', "Finish Both",
             "Finished panels on both faces"),
        ],
        default='FINISH_LEFT',
        update=_update_cabinet_dim,
    )  # type: ignore
    only_stile: BoolProperty(
        name="Only Include Stile", default=False,
        description="Drop the side panels and toe-kick filler; keep just "
                    "the face-frame stile",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Curved support leg: the whole leg becomes ONE finished plywood
    # panel. The straight full-height edge and narrow foot post sit at
    # the BACK (against the wall); a full-depth arm crosses the top and
    # an S-curve sweeps from the arm's front underside back onto the
    # post, leaving the knee-clearance void at the FRONT (used under
    # vanity lap drawers / seating). The cage WIDTH is the panel
    # thickness (typically 3/4" or 1-1/2").
    curved: BoolProperty(
        name="Curved Support Leg", default=False,
        description="Build the leg as a single curved support panel: "
                    "full height at the wall, arm across the top, curve "
                    "sweeping back to a narrow post -- knee clearance at "
                    "the front. The leg width is the panel thickness",
        update=_update_cabinet_dim,
    )  # type: ignore
    curved_foot_depth: FloatProperty(
        name="Foot Depth", default=units.inch(3.0), min=units.inch(1.0),
        description="Depth of the post at the floor, measured out from "
                    "the back (wall) edge",
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    curved_top_band_height: FloatProperty(
        name="Top Band Height", default=units.inch(4.0), min=units.inch(1.0),
        description="Thickness of the full-depth arm at the top of the "
                    "leg, above the start of the curve",
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    curved_sweep_height: FloatProperty(
        name="Curve Height", default=units.inch(12.0), min=units.inch(1.0),
        description="Vertical span of the S-curve between the arm's "
                    "underside and the top of the straight post",
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    is_column: BoolProperty(
        name="Column", default=False,
        description="Column variant: no toe kick (runs full height)",
        update=_update_cabinet_dim,
    )  # type: ignore
    # Collapsible-section toggles for the Leg Properties dialog. UI
    # state only (no recalc); rarely-touched sections default closed
    # to keep the popup short.
    show_panel_depth: BoolProperty(
        name="Panel Depth Overrides", default=False,
    )  # type: ignore
    show_back_nailers: BoolProperty(
        name="Back & Nailers", default=False,
    )  # type: ignore
    show_finish_x: BoolProperty(
        name="Finish-X Bands", default=False,
    )  # type: ignore
    material_thickness: FloatProperty(
        name="Material Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    face_frame_thickness: FloatProperty(
        name="Face Frame Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    toe_kick_height: FloatProperty(
        name="Toe Kick Height", default=units.inch(4.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    toe_kick_setback: FloatProperty(
        name="Toe Kick Setback", default=units.inch(3.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore

    # --- v2 fields ---
    # Per-panel depth overrides: 0 means "use depth - face frame thickness".
    override_left_panel_depth: FloatProperty(
        name="Override Left Panel Depth", default=0.0,
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    override_right_panel_depth: FloatProperty(
        name="Override Right Panel Depth", default=0.0,
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    # Back + nailers (interior). The back spans only the included
    # nailer side(s); panels shift forward by the back thickness when a
    # back is present.
    include_back_left_nailer: BoolProperty(
        name="Include Back Left Nailer", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    include_back_right_nailer: BoolProperty(
        name="Include Back Right Nailer", default=False,
        update=_update_cabinet_dim,
    )  # type: ignore
    back_width: FloatProperty(
        name="Back Width", default=units.inch(18.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    back_thickness: FloatProperty(
        name="Back Thickness", default=units.inch(0.25),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    nailer_thickness: FloatProperty(
        name="Nailer Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    nailer_width: FloatProperty(
        name="Nailer Width", default=units.inch(1.5),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    # Finished band covering the front X inches on the unfinished side(s).
    # The left value is also the right one until the right is set, so a
    # leg built before the sides could differ keeps the band it had.
    flush_x_panel_width: FloatProperty(
        name="Flush X Panel Width", default=units.inch(4.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    flush_x_panel_width_right: FloatProperty(
        name="Flush X Panel Width Right", default=units.inch(4.0),
        unit='LENGTH', precision=4,
        description="Depth of the finished band on the RIGHT side; "
                    "follows the left one until you set it",
        get=_get_flush_x_right, set=_set_flush_x_right,
    )  # type: ignore
    # Placement / labeling metadata variants (no geometry effect today;
    # parity with the reference for downstream routing).
    is_appliance_leg: BoolProperty(
        name="Appliance Leg", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    is_island_leg: BoolProperty(
        name="Island Leg", default=False, update=_update_cabinet_dim,
    )  # type: ignore


class Face_Frame_Floating_Shelf_Props(PropertyGroup):
    """Options for a Floating Shelf (a wall-mounted hollow slab).

    Lives on the shelf's cage object alongside face_frame_cabinet; the
    shelf's recalculate() reads these to build its parts. Width / height
    / depth come from face_frame_cabinet (cage Dim X/Z/Y) - note height
    (Dim Z) is the shelf's overall thickness. finish_left / finish_right
    add a closed end panel on that end (auto-set on placement from the
    neighbouring exposure, editable after). LED routes are a later pass.
    """
    finish_left: BoolProperty(
        name="Finish Left", default=True, update=_update_cabinet_dim,
        description="Close the left end with a finished panel",
    )  # type: ignore
    finish_right: BoolProperty(
        name="Finish Right", default=True, update=_update_cabinet_dim,
        description="Close the right end with a finished panel",
    )  # type: ignore
    material_thickness: FloatProperty(
        name="Material Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    shelf_type: EnumProperty(
        name="Shelf Type",
        items=[
            ('FLOATING', "Floating Shelves",
             "Cantilevered floating shelf"),
            ('NON_FLOATING', "Non-Floating Shelves",
             "Shelf with visible support"),
            ('HEAVY_DUTY', "Heavy Duty Floating Shelves",
             "Heavy duty floating shelf; supports a light groove"),
        ],
        default='FLOATING',
        update=_update_cabinet_dim,
    )  # type: ignore
    # Light groove (Heavy Duty only) - a routed LED channel on the top
    # and/or bottom face, set a distance in from the rear edge.
    include_groove_top: BoolProperty(
        name="Groove Top", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    include_groove_bottom: BoolProperty(
        name="Groove Bottom", default=False, update=_update_cabinet_dim,
    )  # type: ignore
    groove_distance_from_rear: FloatProperty(
        name="Groove Distance From Rear", default=units.inch(2.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    groove_width: FloatProperty(
        name="Groove Width", default=units.inch(0.5),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    groove_depth: FloatProperty(
        name="Groove Depth", default=units.inch(0.25),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore


_mantle_crown_items_cache = []


def _mantle_crown_profile_items(self, context):
    """Crown choices for the mantle: the mantle mouldings plus every
    crown profile from the installed molding packs, then the rest of
    the Other mouldings. DEFAULT resolves per style
    (types_face_frame.MANTLE_STYLE_CROWN)."""
    from ...molding import packages
    global _mantle_crown_items_cache
    items = [('DEFAULT', "Default (by Style)",
              "The style's standard moulding")]
    other = [i for i in packages.profile_enum_items('Other')
             if i[0] != 'DEFAULT']
    other_idents = {i[0] for i in other}
    for n in ('Mantle', 'Mini Mantle'):
        if n in other_idents:
            items.append(("Other/" + n, n + " Moulding", ""))
    for ident, label, desc in packages.profile_enum_items('Crown Molding')[1:]:
        items.append(("Crown Molding/" + ident, label, desc))
    for ident, label, desc in other:
        if ident in ('Mantle', 'Mini Mantle'):
            continue
        items.append(("Other/" + ident, label, desc))
    _mantle_crown_items_cache = items
    return _mantle_crown_items_cache


_mantle_base_items_cache = []


def _mantle_base_profile_items(self, context):
    """Base moulding choices for the surround's leg feet. DEFAULT
    resolves per style (types_face_frame.MANTLE_SURROUND_BASE)."""
    from ...molding import packages
    global _mantle_base_items_cache
    items = [('DEFAULT', "Default (by Style)",
              "The style's standard base moulding")]
    for ident, label, desc in packages.profile_enum_items('Base Molding'):
        if ident == 'DEFAULT':
            continue
        items.append(("Base Molding/" + ident, label, desc))
    _mantle_base_items_cache = items
    return _mantle_base_items_cache


def _update_mantle_style(self, context):
    """Mantle style change: re-seed the overall height to the style's
    standard build (the styles differ in height and under-crown), then
    rebuild through the normal dim update."""
    from . import types_face_frame
    types_face_frame.apply_mantle_style(self.id_data)


def _update_mantle_surround(self, context):
    """Legs & Header toggle: keep the shelf top where it is - ON drops
    the product to the floor, OFF restores the wall-mounted shelf."""
    from . import types_face_frame
    types_face_frame.apply_mantle_surround(self.id_data)


class Face_Frame_Mantle_Props(PropertyGroup):
    """Options for a Mantle (fireplace mantle shelf).

    Lives on the mantle's cage object alongside face_frame_cabinet.
    Width / depth come from the cage; height (Dim Z) is the overall
    assembly height, seeded from the style's standard build on style
    change and editable after. finish_left / finish_right wrap the
    front build (box end panel + crown return) around that end.
    """
    mantle_style: EnumProperty(
        name="Mantle Style",
        items=[
            ('CONTEMPORARY', "Contemporary",
             "Plain 5\" band with eased edges, no under-crown"),
            ('TRADITIONAL', "Traditional",
             "3-3/4\" build with a crown moulding below"),
            ('SHAKER', "Shaker",
             "4-1/4\" build with a cove moulding below"),
            ('VICTORIAN', "Victorian",
             "5-3/4\" build with a crown moulding below"),
            ('CLASSIC', "Classic",
             "5-1/2\" build with stacked mouldings below"),
            ('COLONIAL', "Colonial",
             "7-1/2\" build with a crown moulding below"),
        ],
        default='CONTEMPORARY',
        update=_update_mantle_style,
    )  # type: ignore
    crown_profile: EnumProperty(
        name="Crown Profile",
        description="Moulding profile extruded around the mantle front"
                    " and finished ends (Default follows the style)",
        items=_mantle_crown_profile_items,
        update=_update_cabinet_dim,
    )  # type: ignore
    finish_left: BoolProperty(
        name="Finish Left", default=True, update=_update_cabinet_dim,
        description="Return the front build around the left end",
    )  # type: ignore
    finish_right: BoolProperty(
        name="Finish Right", default=True, update=_update_cabinet_dim,
        description="Return the front build around the right end",
    )  # type: ignore
    top_overhang: FloatProperty(
        name="Top Overhang", default=units.inch(0.75), min=0.0,
        soft_max=units.inch(3.0), unit='LENGTH', precision=4,
        update=_update_cabinet_dim,
        description="How far the top slab extends past the front and"
                    " each finished end (crown styles)",
    )  # type: ignore
    material_thickness: FloatProperty(
        name="Material Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    include_surround: BoolProperty(
        name="Legs & Header", default=False,
        update=_update_mantle_surround,
        description="Build a full floor-standing mantle surround: legs"
                    " and a header below the shelf",
    )  # type: ignore
    surround_build: EnumProperty(
        name="Surround Build",
        items=[
            ('DEFAULT', "Default (by Style)",
             "Plain for Contemporary, paneled for the other styles"),
            ('PLAIN', "Plain",
             "Plain board legs and header"),
            ('PANELED', "Paneled",
             "Applied panel legs and header (raised or flat panels"
             " per the cabinet style)"),
        ],
        default='DEFAULT', update=_update_cabinet_dim,
    )  # type: ignore
    leg_width: FloatProperty(
        name="Leg Width", default=units.inch(8.0),
        min=units.inch(3.0), soft_max=units.inch(16.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
    )  # type: ignore
    leg_depth: FloatProperty(
        name="Leg Depth", default=units.inch(8.0),
        min=units.inch(2.0), soft_max=units.inch(16.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="How far the legs project from the wall (the shelf"
                    " depth is independent)",
    )  # type: ignore
    header_height: FloatProperty(
        name="Header Height", default=units.inch(10.0),
        min=units.inch(3.0), soft_max=units.inch(24.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Height of the header band directly under the"
                    " shelf, spanning between the legs",
    )  # type: ignore
    header_depth: FloatProperty(
        name="Header Depth", default=units.inch(6.0),
        min=units.inch(1.0), soft_max=units.inch(12.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="How far the header projects from the wall -"
                    " shallower than the legs (6\" standard)",
    )  # type: ignore
    include_base_moulding: BoolProperty(
        name="Base Moulding", default=True, update=_update_cabinet_dim,
        description="Wrap a base moulding around each leg's foot",
    )  # type: ignore
    base_profile: EnumProperty(
        name="Base Profile",
        description="Base moulding profile at the leg feet (Default"
                    " follows the style)",
        items=_mantle_base_profile_items,
        update=_update_cabinet_dim,
    )  # type: ignore


def _update_wood_top(self, context):
    """Rebuild the wood top board from its propgroup. self.id_data is
    the board object itself (a lone part, like Misc Part)."""
    from . import types_face_frame
    obj = self.id_data
    if obj is None or not obj.get(types_face_frame.WOOD_TOP_TAG):
        return
    top = types_face_frame.WoodTopPart()
    top.obj = obj
    top.rebuild()


# Set while a nosing height is being seeded automatically, so the height
# callback can tell that write apart from a user edit.
_SEEDING_NOSING_HEIGHT = False


def _update_wood_top_nosing_style(self, context):
    """Turning on an extra-height nosing seeds its height from the board
    thickness -- a nosing a different thickness than the top it edges is
    the exception, not the norm, so the property default (2") was the
    wrong starting point. A height the user dialed in is left alone.
    """
    global _SEEDING_NOSING_HEIGHT
    if (self.nosing_style in shelf_nosing.EXTRA_HEIGHT_STYLES
            and not self.get('nosing_height_set')
            and abs(self.nosing_height - self.thickness) > 0.0001):
        _SEEDING_NOSING_HEIGHT = True
        try:
            # Writing the height runs its own update, which rebuilds.
            self.nosing_height = self.thickness
        finally:
            _SEEDING_NOSING_HEIGHT = False
        return
    _update_wood_top(self, context)


def _update_wood_top_nosing_height(self, context):
    """A hand-set nosing height sticks: mark it so a later style switch
    doesn't re-seed it from the board thickness."""
    if not _SEEDING_NOSING_HEIGHT:
        self['nosing_height_set'] = True
    _update_wood_top(self, context)


class Face_Frame_Wood_Top_Props(PropertyGroup):
    """Options for a Wood Top (countertop part): ONE lone finished
    board (no cage, no sub-parts -- like Misc Part).

    Lives on the board object itself; every edit rebuilds through
    WoodTopPart.rebuild(). A top parented to a cabinet (placement
    snapped it there) sizes from that cabinet plus the overhangs; a
    free-standing top uses width / depth directly. The nosing mills the
    board's front edge with a profile from the shelf-nosing set.
    """
    top_type: EnumProperty(
        name="Construction",
        items=[
            ('VENEER', "Veneer Top",
             "Veneer core with applied wood edge"),
            ('SOLID', "Solid Wood Top",
             "Staved solid lumber top"),
        ],
        default='VENEER',
        update=_update_wood_top,
    )  # type: ignore
    width: FloatProperty(
        name="Width", default=units.inch(36.0), min=units.inch(1.0),
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    depth: FloatProperty(
        name="Depth", default=units.inch(25.5), min=units.inch(1.0),
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    thickness: FloatProperty(
        name="Thickness", default=units.inch(1.5), min=units.inch(0.25),
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    overhang_front: FloatProperty(
        name="Front Overhang", default=units.inch(1.5),
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    overhang_back: FloatProperty(
        name="Back Overhang", default=0.0,
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    overhang_left: FloatProperty(
        name="Left Overhang", default=units.inch(1.0),
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    overhang_right: FloatProperty(
        name="Right Overhang", default=units.inch(1.0),
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    # Nosing profile (the shelf-nosing set). Clover / Kelli match the
    # board thickness; the extra-height styles use nosing_height and
    # drop below the board bottom. The per-side toggles pick which
    # edges are milled -- typically the exposed sides (not against a
    # wall); sides meeting at a corner miter into each other.
    nosing_style: EnumProperty(
        name="Edge Profile",
        description="Profile milled on the top's edge, whether cut into "
                    "the slab or into an applied hardwood band",
        items=wood_top_edge.EDGE_STYLE_ITEMS, default='NONE',
        update=_update_wood_top_nosing_style,
    )  # type: ignore
    nosing_height: FloatProperty(
        name="Nosing Height", default=units.inch(2.0),
        min=units.inch(0.5), soft_max=units.inch(3.0),
        unit='LENGTH', precision=4,
        update=_update_wood_top_nosing_height,
    )  # type: ignore
    nosing_front: BoolProperty(
        name="Nosing Front", default=True,
        description="Mill the nosing on the front edge",
        update=_update_wood_top,
    )  # type: ignore
    nosing_back: BoolProperty(
        name="Nosing Back", default=False,
        description="Mill the nosing on the back edge",
        update=_update_wood_top,
    )  # type: ignore
    nosing_left: BoolProperty(
        name="Nosing Left", default=False,
        description="Mill the nosing on the left edge",
        update=_update_wood_top,
    )  # type: ignore
    nosing_right: BoolProperty(
        name="Nosing Right", default=False,
        description="Mill the nosing on the right edge",
        update=_update_wood_top,
    )  # type: ignore
    # Applied edge. A veneer-core top is built as a core board plus a
    # separate edge band (typically 3/4"); the band is its own part so
    # the shop gets the edge type and can size it on its own. The
    # overhangs still measure to the outside of the band, so turning
    # an edge on shrinks the core rather than growing the top. Mutually
    # exclusive with the milled nosing, which owns the same edges.
    edge_type: EnumProperty(
        name="Edge",
        items=[
            ('NONE', "None", "No applied edge - the top is one board"),
            ('SQUARE', "Square", "Square applied edge band"),
            ('EASED', "Eased",
             "Applied edge band with the exposed corners eased"),
        ],
        default='NONE',
        update=_update_wood_top,
    )  # type: ignore
    edge_thickness: FloatProperty(
        name="Edge Thickness", default=units.inch(0.75),
        min=units.inch(0.125), soft_max=units.inch(2.0),
        unit='LENGTH', precision=4, update=_update_wood_top,
    )  # type: ignore
    edge_front: BoolProperty(
        name="Edge Front", default=True,
        description="Apply the edge band to the front",
        update=_update_wood_top,
    )  # type: ignore
    edge_back: BoolProperty(
        name="Edge Back", default=False,
        description="Apply the edge band to the back",
        update=_update_wood_top,
    )  # type: ignore
    edge_left: BoolProperty(
        name="Edge Left", default=False,
        description="Apply the edge band to the left end",
        update=_update_wood_top,
    )  # type: ignore
    edge_right: BoolProperty(
        name="Edge Right", default=False,
        description="Apply the edge band to the right end",
        update=_update_wood_top,
    )  # type: ignore


class Face_Frame_Column_Beam_Props(PropertyGroup):
    """Options for a column or beam wrap.

    Lives on the wrap's cage object alongside face_frame_cabinet, which
    carries the dims: a COLUMN runs up Dim Z with a Dim X x Dim Y
    section, a BEAM runs along Dim X with a Dim Y x Dim Z section.
    FRONT / BACK are the Y-extreme faces on both; the pair closing the
    section is LEFT / RIGHT on a column and BOTTOM / TOP on a beam, so
    only four of the six side flags apply at a time.
    """
    orientation: EnumProperty(
        name="Orientation",
        description="Which way the wrap runs",
        items=[('COLUMN', "Column", "Runs vertically, floor to ceiling"),
               ('BEAM', "Beam", "Runs horizontally under the ceiling")],
        default='COLUMN', update=_update_cabinet_dim,
    )  # type: ignore
    material_thickness: FloatProperty(
        name="Material Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Stock thickness of the wrap boards",
    )  # type: ignore

    # Which faces get built. All four is a closed box; drop the one
    # against the wall or ceiling for a 3-sided, two for an L around an
    # outside corner.
    side_front: BoolProperty(
        name="Front", default=True, update=_update_cabinet_dim,
        description="Build the front board",
    )  # type: ignore
    side_back: BoolProperty(
        name="Back", default=True, update=_update_cabinet_dim,
        description="Build the back board",
    )  # type: ignore
    side_left: BoolProperty(
        name="Left", default=True, update=_update_cabinet_dim,
        description="Build the left board (column)",
    )  # type: ignore
    side_right: BoolProperty(
        name="Right", default=True, update=_update_cabinet_dim,
        description="Build the right board (column)",
    )  # type: ignore
    side_bottom: BoolProperty(
        name="Bottom", default=True, update=_update_cabinet_dim,
        description="Build the bottom board (beam)",
    )  # type: ignore
    side_top: BoolProperty(
        name="Top", default=False, update=_update_cabinet_dim,
        description="Build the top board (beam). Usually left off where "
                    "the beam meets the ceiling",
    )  # type: ignore

    # Framed sides: stiles and rails standing on the board, which then
    # reads as the panel behind them.
    framed_front: BoolProperty(
        name="Framed Front", default=False, update=_update_cabinet_dim,
        description="Frame this side with stiles and rails",
    )  # type: ignore
    framed_back: BoolProperty(
        name="Framed Back", default=False, update=_update_cabinet_dim,
        description="Frame this side with stiles and rails",
    )  # type: ignore
    framed_left: BoolProperty(
        name="Framed Left", default=False, update=_update_cabinet_dim,
        description="Frame this side with stiles and rails",
    )  # type: ignore
    framed_right: BoolProperty(
        name="Framed Right", default=False, update=_update_cabinet_dim,
        description="Frame this side with stiles and rails",
    )  # type: ignore
    framed_bottom: BoolProperty(
        name="Framed Bottom", default=False, update=_update_cabinet_dim,
        description="Frame this side with stiles and rails",
    )  # type: ignore
    framed_top: BoolProperty(
        name="Framed Top", default=False, update=_update_cabinet_dim,
        description="Frame this side with stiles and rails",
    )  # type: ignore
    panel_count: IntProperty(
        name="Panels", default=1, min=1, max=24,
        update=_update_cabinet_dim,
        description="How many panels a framed side is divided into along "
                    "the length of the wrap",
    )  # type: ignore
    frame_stile_width: FloatProperty(
        name="Stile Width", default=units.inch(2.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Width of the frame members crossing the wrap",
    )  # type: ignore
    frame_rail_width: FloatProperty(
        name="Rail Width", default=units.inch(2.0),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Width of the frame members running the length of "
                    "the wrap",
    )  # type: ignore
    frame_member_thickness: FloatProperty(
        name="Frame Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="How far the frame members stand proud of the panel",
    )  # type: ignore

    # False ceiling: a panel set up inside a beam, leaving a recess for
    # indirect lighting.
    include_false_ceiling: BoolProperty(
        name="False Ceiling", default=False, update=_update_cabinet_dim,
        description="Set a panel up inside the beam, leaving a recess "
                    "for indirect lighting",
    )  # type: ignore
    false_ceiling_recess: FloatProperty(
        name="Recess Depth", default=units.inch(3.0), min=0.0,
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="How far up inside the beam the false ceiling sits",
    )  # type: ignore
    false_ceiling_thickness: FloatProperty(
        name="False Ceiling Thickness", default=units.inch(0.25),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Stock thickness of the false ceiling panel",
    )  # type: ignore

    # Order options. These do not change the geometry: they ride here
    # and are published on the object so a schedule or an order can read
    # them.
    butt_seam_sides: IntProperty(
        name="Butt Seams", default=0, min=0, max=4,
        description="Number of sides carrying a butt seam. Note the "
                    "location of each seam on the drawing",
    )  # type: ignore
    random_staggered_sides: IntProperty(
        name="Staggered Seam Sides", default=0, min=0, max=4,
        description="Number of sides built with random staggered seams",
    )  # type: ignore
    angled_end_start: BoolProperty(
        name="Angled Start", default=False,
        description="This end is cut at an angle. Supply a template and "
                    "dimension to the longest point",
    )  # type: ignore
    angled_end_end: BoolProperty(
        name="Angled End", default=False,
        description="This end is cut at an angle. Supply a template and "
                    "dimension to the longest point",
    )  # type: ignore


class Face_Frame_Valance_Props(PropertyGroup):
    """Options for a Valance product (a decorative board spanning the
    gap between two upper cabinets).

    Lives on the valance's cage object alongside face_frame_cabinet;
    recalculate() reads these to build its parts. Width / height / depth
    come from face_frame_cabinet (cage Dim X/Z/Y) - height (Dim Z) is
    the valance board's vertical drop. finish_left / finish_right add a
    return panel back to the wall on that end (auto-set on placement
    from the neighbouring exposure, editable after).
    """
    finish_left: BoolProperty(
        name="Finish Left", default=True, update=_update_cabinet_dim,
        description="Close the left end with a finished return panel",
    )  # type: ignore
    finish_right: BoolProperty(
        name="Finish Right", default=True, update=_update_cabinet_dim,
        description="Close the right end with a finished return panel",
    )  # type: ignore
    frame_thickness: FloatProperty(
        name="Frame Thickness", default=units.inch(0.75),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Stock thickness of the valance board and return panels",
    )  # type: ignore
    include_cover: BoolProperty(
        name="Include Cover", default=True, update=_update_cabinet_dim,
        description="Add a cover board behind the valance board",
    )  # type: ignore
    cover_thickness: FloatProperty(
        name="Cover Thickness", default=units.inch(0.5),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Stock thickness of the cover board",
    )  # type: ignore
    flush_bottom: BoolProperty(
        name="Flush Bottom", default=False, update=_update_cabinet_dim,
        description="Rest the cover at the bottom of the valance instead of below the top edge",
    )  # type: ignore
    top_scribe: FloatProperty(
        name="Top Scribe Amount", default=units.inch(0.25),
        unit='LENGTH', precision=4, update=_update_cabinet_dim,
        description="Drop the cover down from the top edge by this amount",
    )  # type: ignore


classes = (
    Face_Frame_Leg_Props,
    Face_Frame_Floating_Shelf_Props,
    Face_Frame_Mantle_Props,
    Face_Frame_Wood_Top_Props,
    Face_Frame_Valance_Props,
    Face_Frame_Column_Beam_Props,
    Face_Frame_Millwork_Item,
    Face_Frame_Special_Effect,
    Face_Frame_Cabinet_Extra_Front_Style,
    Face_Frame_Style_Note,
    Face_Frame_Cabinet_Style,
    HB_UL_face_frame_cabinet_styles,
    Face_Frame_Door_Style,
    HB_UL_face_frame_door_styles,
    Face_Frame_Panel_Row_Height,
    Face_Frame_Panel_Col_Width,
    Face_Frame_Mid_Stile_Width,
    Face_Frame_Cabinet_Column,
    Face_Frame_Corner_Section,
    Face_Frame_Cabinet_Props,
    Face_Frame_Bay_Props,
    Face_Frame_Rollout_Box,
    Face_Frame_Interior_Item,
    Face_Frame_Interior_Region_Props,
    Face_Frame_Drawer_Look_Opening,
    Face_Frame_Opening_Props,
    Face_Frame_Splitter_Width,
    Face_Frame_Split_Props,
    Face_Frame_Interior_Split_Props,
    Face_Frame_Scene_Props,
)


_register_classes, _unregister_classes = bpy.utils.register_classes_factory(classes)


@bpy.app.handlers.persistent
def _seed_style_rename_anchors(_dummy):
    """On file load, seed each style's rename_anchor from its current name
    (cabinet styles and both front-style pools). Files saved before
    rename-propagation existed have empty anchors; without this seed their
    first rename could not re-tag assigned cabinets / fronts."""
    for scene in bpy.data.scenes:
        ff = getattr(scene, 'hb_face_frame', None)
        if ff is None:
            continue
        for pool in ('cabinet_styles', 'door_styles', 'drawer_front_styles'):
            for style in getattr(ff, pool, ()):
                if not style.rename_anchor:
                    style.rename_anchor = style.name


def register():
    _register_classes()

    if _seed_style_rename_anchors not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_seed_style_rename_anchors)

    # Object-level pointer properties: face frame cabinets and bays carry
    # their state on the cage object directly. Only objects that get tagged
    # by the construction code populate these.
    bpy.types.Object.face_frame_cabinet = PointerProperty(type=Face_Frame_Cabinet_Props)
    bpy.types.Object.leg_product = PointerProperty(type=Face_Frame_Leg_Props)
    bpy.types.Object.floating_shelf = PointerProperty(type=Face_Frame_Floating_Shelf_Props)
    bpy.types.Object.mantle_product = PointerProperty(type=Face_Frame_Mantle_Props)
    bpy.types.Object.wood_top = PointerProperty(type=Face_Frame_Wood_Top_Props)
    bpy.types.Object.valance_product = PointerProperty(type=Face_Frame_Valance_Props)
    bpy.types.Object.column_beam_product = PointerProperty(type=Face_Frame_Column_Beam_Props)
    bpy.types.Object.face_frame_bay = PointerProperty(type=Face_Frame_Bay_Props)
    bpy.types.Object.face_frame_opening = PointerProperty(type=Face_Frame_Opening_Props)
    bpy.types.Object.face_frame_split = PointerProperty(type=Face_Frame_Split_Props)
    bpy.types.Object.face_frame_interior_split = PointerProperty(type=Face_Frame_Interior_Split_Props)
    bpy.types.Object.face_frame_interior_region = PointerProperty(type=Face_Frame_Interior_Region_Props)

    # Initialize preview collections so thumbnails load on first sidebar draw
    get_library_previews()
    get_cabinet_previews()


def unregister():
    if hasattr(bpy.types.Object, 'face_frame_interior_region'):
        del bpy.types.Object.face_frame_interior_region
    if hasattr(bpy.types.Object, 'face_frame_interior_split'):
        del bpy.types.Object.face_frame_interior_split
    if hasattr(bpy.types.Object, 'face_frame_split'):
        del bpy.types.Object.face_frame_split
    if hasattr(bpy.types.Object, 'face_frame_opening'):
        del bpy.types.Object.face_frame_opening
    if hasattr(bpy.types.Object, 'face_frame_bay'):
        del bpy.types.Object.face_frame_bay
    if hasattr(bpy.types.Object, 'floating_shelf'):
        del bpy.types.Object.floating_shelf
    if hasattr(bpy.types.Object, 'mantle_product'):
        del bpy.types.Object.mantle_product
    if hasattr(bpy.types.Object, 'column_beam_product'):
        del bpy.types.Object.column_beam_product
    if hasattr(bpy.types.Object, 'valance_product'):
        del bpy.types.Object.valance_product
    if hasattr(bpy.types.Object, 'wood_top'):
        del bpy.types.Object.wood_top
    if hasattr(bpy.types.Object, 'leg_product'):
        del bpy.types.Object.leg_product
    if hasattr(bpy.types.Object, 'face_frame_cabinet'):
        del bpy.types.Object.face_frame_cabinet

    if _seed_style_rename_anchors in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_seed_style_rename_anchors)

    _unregister_classes()
    for pcoll in preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    preview_collections.clear()

"""Right-click context menus for face frame cabinets, bays, and mid stiles.

The right-click handler in ui/menu_apend.py reads obj['MENU_ID'] from the
active object and shows the named Menu class. Each face-frame-tagged cage
or part sets its MENU_ID to one of the menu classes defined here.

Pass 1 keeps the menus minimal - only items that have working operators
(Recalculate + the three scoped Properties popups). Action operators
(Add Bay, Split Bay, Delete Bay, Insert Mid Stile, etc.) will land in a
later pass once those operators are implemented.
"""
import bpy

from . import bay_presets
from . import cabinet_column
from . import types_face_frame
from . import types_face_frame_corner
from . import types_column_beam
from .operators import ops_part_commands
from ... import accessory_registry, units


def _has_drawer_box_construction_options():
    """Whether the host application offers drawer box constructions. HB5
    ships none, so the submenu simply doesn't appear on its own."""
    from ... import accessory_registry
    from .operators import ops_cabinet
    return bool(accessory_registry.get_items(
        ops_cabinet.DRAWER_BOX_CONSTRUCTION_HOST))


def _draw_drawer_box_construction_menu(layout):
    layout.menu("HOME_BUILDER_MT_face_frame_drawer_box_construction",
                text="Drawer Box Construction", icon='SNAP_VOLUME')


def _draw_visibility_items(layout, scope, noun):
    """Hide / Isolate / Show All Hidden for the clicked thing.

    Blender's own hide only takes what is selected, so on a product built
    from many parented objects it hides the cage and leaves the rest
    standing. These commands hide the whole product, or one part on its
    own, and bring everything back.
    """
    layout.separator()
    op = layout.operator("hb_general.hide", text=f"Hide {noun}",
                         icon='HIDE_ON')
    op.scope = scope
    op.isolate = False
    op = layout.operator("hb_general.hide", text=f"Isolate {noun}",
                         icon='ZOOM_SELECTED')
    op.scope = scope
    op.isolate = True
    layout.operator("hb_general.show_all_hidden", text="Show All Hidden",
                    icon='HIDE_OFF')


def _draw_cutout_items(layout, obj):
    """Add / Edit / Remove entries for machining cutouts (hole or route) on a
    parametric cutpart - sides, backs, panels, doors, hood parts. Editing
    reopens the Add dialog on an existing cut, so a wrong size or position is
    corrected in place instead of removed and re-added. A single cutout gets
    flat entries; several move into a submenu so the parent menu stays short."""
    if not ops_part_commands._is_cutpart(obj):
        return
    layout.separator()
    layout.operator("hb_face_frame.add_part_cutout",
                    text="Add Cutout...", icon='MOD_BOOLEAN')
    mods = ops_part_commands._user_cutout_mods(obj)
    if len(mods) == 1:
        props = layout.operator("hb_face_frame.add_part_cutout",
                                text="Edit Cutout...", icon='WINDOW')
        props.mod_name = mods[0].name
        props = layout.operator("hb_face_frame.remove_part_cutout",
                                text="Remove Cutout", icon='X')
        props.mod_name = mods[0].name
    elif len(mods) > 1:
        layout.menu("HOME_BUILDER_MT_face_frame_cutouts",
                    text="Cutouts", icon='MOD_BOOLEAN')


def _draw_make_editable_items(layout, obj):
    """Make Editable / Revert to Parametric for one part.

    Applying a part's GeoNode(s) turns it into real, hand-editable mesh
    that the recalc then leaves alone; Revert restores parametric
    control. Works on structural cutparts AND door / drawer fronts (each
    has its own apply / revert path - see the operators), and draws
    nothing for a part that is neither.

    Both gates are self-checking, so any menu can offer this and the
    rows appear only where they mean something.
    """
    if obj is None:
        return
    is_manual = bool(obj.get('IS_MANUAL_PART'))
    can_make_editable = (
        ops_part_commands._can_make_editable(obj)
        or ops_part_commands._can_make_front_editable(obj))
    # Hood parts have no cabinet recalc to re-drive them, so they revert
    # via their own snapshot path (home_builder.revert_hood_part) which
    # restores just the clicked part. A hood part made editable before
    # the snapshot feature has no snapshot - rebuild the hood to restore
    # it.
    if is_manual and obj.get('IS_WOOD_HOOD_PART'):
        if obj.get('HOOD_PARAMETRIC_SNAPSHOT'):
            layout.separator()
            layout.operator("home_builder.revert_hood_part",
                            text="Revert to Parametric", icon='FILE_REFRESH')
    elif is_manual:
        layout.separator()
        layout.operator("hb_face_frame.revert_part_to_parametric",
                        text="Revert to Parametric", icon='FILE_REFRESH')
    elif can_make_editable:
        layout.separator()
        layout.operator("hb_face_frame.make_part_editable",
                        text="Make Editable", icon='EDITMODE_HLT')


def _has_drawer_slides_options():
    """Whether the host application offers drawer slide hardware. HB5
    ships none, so the submenu simply doesn't appear on its own."""
    from ... import accessory_registry
    from .operators import ops_cabinet
    return bool(accessory_registry.get_items(
        ops_cabinet.DRAWER_SLIDES_HOST))


def _draw_drawer_slides_menu(layout):
    layout.menu("HOME_BUILDER_MT_face_frame_drawer_slides",
                text="Drawer Slides", icon='MOD_ARRAY')


def _is_drawer_opening(obj):
    """True when obj is (or sits under) an opening whose front is a
    drawer-style front - the ones with a drawer box to lay out."""
    cur = obj
    while cur is not None:
        if cur.get(types_face_frame.TAG_OPENING_CAGE):
            return cur.face_frame_opening.front_type in (
                'DRAWER_FRONT', 'PULLOUT', 'TILT_OUT')
        cur = cur.parent
    return False


class HOME_BUILDER_MT_face_frame_cabinet_commands(bpy.types.Menu):
    """Right-click menu for a face frame cabinet root."""
    bl_label = "Face Frame Cabinet Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.cabinet_prompts",
                        text="Cabinet Properties...", icon='WINDOW')
        # Blind corner: shown when this cabinet participates in a
        # configured square blind corner (pair stamp, void-owner marker,
        # or a legacy BLIND-typed stile). The operator re-resolves and
        # seeds from the corner's current state.
        _bc_root = types_face_frame.find_cabinet_root(context.active_object)
        if _bc_root is not None:
            _bc_props = _bc_root.face_frame_cabinet
            if ('HB_BLIND_VOID_LEFT' in _bc_root
                    or 'HB_BLIND_VOID_RIGHT' in _bc_root
                    or 'HB_BLIND_PAIR' in _bc_root
                    or _bc_props.left_stile_type == 'BLIND'
                    or _bc_props.right_stile_type == 'BLIND'):
                layout.operator("hb_face_frame.edit_blind_corner",
                                text="Blind/Corner Properties...",
                                icon='SNAP_EDGE')
                layout.operator("hb_face_frame.swap_blind_corner",
                                text="Swap Blind Cabinet",
                                icon='ARROW_LEFTRIGHT')
        # Duplicate: copy-and-place. Seeds the placement modal from
        # this cabinet; the drop deep-copies the whole hierarchy so
        # bay configs, fronts, and the style come along. F in the
        # modal toggles fill-the-gap. Corner cabinets place through
        # a different modal - no duplicate for them yet.
        _dup_root = types_face_frame.find_cabinet_root(context.active_object)
        if (_dup_root is not None
                and getattr(_dup_root.face_frame_cabinet,
                            'corner_type', 'NONE') == 'NONE'):
            op = layout.operator("hb_face_frame.place_cabinet",
                                 text="Duplicate", icon='DUPLICATE')
            op.source_cabinet_name = _dup_root.name
            op = layout.operator("hb_face_frame.place_cabinet",
                                 text="Duplicate Mirror", icon='MOD_MIRROR')
            op.source_cabinet_name = _dup_root.name
            op.mirror = True
            # Place: the same modal on the cabinet itself. Nothing is
            # copied - it is picked up and dropped again, which is how
            # you move one onto another wall, into a gap, or let it
            # fill the run it now belongs to.
            op = layout.operator("hb_face_frame.place_cabinet",
                                 text="Place Cabinet", icon='SNAP_ON')
            op.source_cabinet_name = _dup_root.name
            op.move_source = True
        layout.separator()
        layout.operator("hb_face_frame.join_cabinets",
                        text="Join Cabinets", icon='AUTOMERGE_ON')
        layout.operator("hb_face_frame.equalize_bays",
                        text="Equalize Bays", icon='ALIGN_JUSTIFY')

        # Show "Create Cabinet Group" whenever at least one cabinet is in
        # the selection. A single-cabinet group is allowed on purpose: the
        # 2D sheet set generates a 9-view (IslandNineView) per cabinet group
        # (generate_room_views loops get_cabinet_groups), so grouping one
        # cabinet is how a user opts that cabinet into its own 9-view.
        # find_cabinet_root walks any selected part up to its root, so the
        # menu surfaces correctly whether the user picked roots, bays, or
        # individual face frame parts.
        selected_roots = set()
        from .operators import ops_cabinet
        for obj in context.selected_objects:
            root = ops_cabinet._find_group_member_root(obj)
            if root is not None:
                selected_roots.add(root.name)
        if len(selected_roots) >= 1:
            layout.operator("hb_face_frame.create_cabinet_group",
                            text="Create Cabinet Group", icon='ADD')

        # "Select Cabinet Group" - re-collapse the group (hide the member
        # cabinet cages, show the group cage). The group cage is hidden
        # whenever a selection mode is active, so this is how the user gets
        # it back. Shown only when the right-clicked cabinet is in a group:
        # walk its root's parents to an IS_CAGE_GROUP cage.
        active_root = types_face_frame.find_cabinet_root(context.active_object)
        cur = active_root.parent if active_root is not None else None
        while cur is not None and not cur.get('IS_CAGE_GROUP'):
            cur = cur.parent
        if cur is not None:
            layout.operator("hb_face_frame.select_cabinet_group",
                            text="Select Cabinet Group", icon='OBJECT_ORIGIN')
            layout.operator("hb_face_frame.ungroup_cabinet",
                            text="Ungroup Cabinet", icon='GROUP')

        # Show Applied Panels - only when the right-clicked cabinet has
        # applied finished-end panels (children tagged
        # TAG_APPLIED_PANEL_SIDE). Runs the existing selection-mode flip
        # (Finished Ends panel has the same button): every applied
        # panel's cage becomes clickable for right-click editing and the
        # host cabinet cages drop out of the way. Any standard mode in
        # the picker (Cabinets, Bays, ...) returns to normal.
        if active_root is not None and any(
                child.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
                for child in active_root.children):
            layout.separator()
            layout.operator("hb_face_frame.show_applied_panels",
                            text="Show Applied Panels", icon='HIDE_OFF')

        # Tip-up wedge calculator - refrigerator and tall cabinets (a
        # walk-through pantry is built from the tall products and tips up
        # into place the same way). The root carries this menu's MENU_ID,
        # so the right-clicked active object is the cabinet root;
        # find_cabinet_root is used anyway for safety.
        from .operators import ops_wedge
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is not None and ops_wedge.is_wedge_cabinet(root):
            layout.separator()
            layout.operator("hb_face_frame.add_refrigerator_wedge",
                            text="Wedge Calculator...", icon='MOD_BEVEL')
            if root.face_frame_cabinet.wedge_enabled:
                layout.operator("hb_face_frame.remove_refrigerator_wedge",
                                text="Remove Wedge", icon='X')

        # Pipe chase - any carcass cabinet. The operator's poll hides it
        # on panel-only roots (no carcass to notch).
        from .operators import ops_pipe_chase
        if ops_pipe_chase.chase_cabinet_root(context.active_object) is not None:
            layout.separator()
            has_chase = root.face_frame_cabinet.chase_enabled
            layout.operator(
                "hb_face_frame.add_pipe_chase",
                text="Edit Pipe Chase..." if has_chase else "Add Pipe Chase...",
                icon='MOD_BOOLEAN')
            if has_chase:
                layout.operator("hb_face_frame.remove_pipe_chase",
                                text="Remove Pipe Chase", icon='X')

        _draw_visibility_items(layout, 'PRODUCT', "Cabinet")

        layout.separator()
        layout.operator("hb_face_frame.delete_cabinet",
                        text="Delete Cabinet", icon='X')


class HOME_BUILDER_MT_face_frame_cabinet_group_commands(bpy.types.Menu):
    """Right-click menu for a cabinet group cage (IS_CAGE_GROUP)."""
    bl_label = "Cabinet Group Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.grab_cabinet_group",
                        text="Grab Cabinet Group", icon='OBJECT_ORIGIN')
        layout.separator()
        layout.operator("hb_face_frame.ungroup_cabinet",
                        text="Ungroup Cabinet", icon='GROUP')


class HOME_BUILDER_MT_face_frame_bay_back_type(bpy.types.Menu):
    """Back type for the picked bay. Cabinet Default follows the
    cabinet's back; the rest are built on this bay's own back plane."""
    bl_label = "Back Type"

    def draw(self, context):
        layout = self.layout
        bay_obj = context.active_object
        bp = getattr(bay_obj, 'face_frame_bay', None) if bay_obj else None
        if bp is None:
            layout.label(text="No bay selected", icon='INFO')
            return
        for item in bp.bl_rna.properties['back_condition'].enum_items:
            op = layout.operator("hb_face_frame.set_bay_back_type",
                                 text=item.name,
                                 icon=('CHECKMARK' if bp.back_condition
                                       == item.identifier else 'NONE'))
            op.back_condition = item.identifier


class HOME_BUILDER_MT_face_frame_bay_commands(bpy.types.Menu):
    """Right-click menu for a face frame bay cage."""
    bl_label = "Face Frame Bay Commands"

    def draw(self, context):
        layout = self.layout
        bay_obj = context.active_object
        cab_root = (types_face_frame.find_cabinet_root(bay_obj)
                    if bay_obj is not None else None)
        cabinet_type = (cab_root.face_frame_cabinet.cabinet_type
                        if cab_root is not None else None)

        layout.operator("hb_face_frame.bay_prompts",
                        text="Bay Properties...", icon='WINDOW')

        # What the bay carries - its finish, anything hung in or under
        # it, and the kick treatment. Each entry is gated on the
        # cabinet type that can hold it, so the group shrinks rather
        # than showing options that do nothing here.
        layout.separator()
        layout.operator("hb_face_frame.finish_bay_prompts",
                        text="Finish Bay...", icon='SHADING_RENDERED')
        # What closes this bay at the back, over the cabinet's own back.
        layout.menu("HOME_BUILDER_MT_face_frame_bay_back_type",
                    text="Back Type", icon='MOD_SOLIDIFY')
        # Under-cabinet appliance (uppers only): a microwave or a
        # short vent hood hanging below the bay.
        if cabinet_type == 'UPPER':
            layout.operator(
                "hb_face_frame.set_under_cabinet_appliance",
                text="Under Cabinet Appliance...", icon='MOD_FLUIDSIM')
        # Appliance configs (sink / cooktop) are base-bay only.
        if cabinet_type == 'BASE':
            layout.menu("HOME_BUILDER_MT_face_frame_add_appliance",
                        text="Add Appliance to Bay", icon='MOD_FLUIDSIM')
        # Flush toe kick toggle - base / tall only (uppers have no
        # kick to flush).
        if cabinet_type in ('BASE', 'TALL'):
            layout.operator("hb_face_frame.toggle_flush_toe_kick",
                            text="Toggle Flush Toe Kick",
                            icon='SNAP_PERPENDICULAR')

        # Change Bay (preset swaps) gets a group of its own: it
        # replaces the whole front layout, which is a heavier edit than
        # the options above and lighter than the structural ones below.
        # Hidden for cabinet types with no presets (currently
        # LAP_DRAWER).
        if cabinet_type in bay_presets.MENU_ENTRIES:
            layout.separator()
            layout.menu("HOME_BUILDER_MT_face_frame_change_bay",
                        text="Change Bay")

        # Structural edits live below in their own group. Anchored on
        # the right-clicked bay's index since the bay cage is the active
        # object when this menu opens.
        bay_index = (bay_obj.face_frame_bay.bay_index
                     if bay_obj is not None
                     and bay_obj.get(types_face_frame.TAG_BAY_CAGE)
                     else 0)
        layout.separator()
        op = layout.operator("hb_face_frame.insert_bay",
                             text="Insert Bay Before", icon='TRIA_LEFT')
        op.bay_index = bay_index
        op.direction = 'BEFORE'
        op = layout.operator("hb_face_frame.insert_bay",
                             text="Insert Bay After", icon='TRIA_RIGHT')
        op.bay_index = bay_index
        op.direction = 'AFTER'
        # Honest labeling: on a single-bay cabinet the operator
        # degrades to deleting the whole cabinet, so say so up front.
        _n_bays = (sum(1 for c in cab_root.children
                       if c.get(types_face_frame.TAG_BAY_CAGE))
                   if cab_root is not None else 0)
        op = layout.operator(
            "hb_face_frame.delete_bay",
            text=("Delete Cabinet" if _n_bays <= 1 else "Delete Bay"),
            icon='X')
        op.bay_index = bay_index

        layout.separator()
        layout.operator("hb_face_frame.break_cabinet_left",
                        text="Break Left", icon='TRIA_LEFT_BAR')
        layout.operator("hb_face_frame.break_cabinet_right",
                        text="Break Right", icon='TRIA_RIGHT_BAR')
        layout.operator("hb_face_frame.break_cabinet_both",
                        text="Break Both", icon='UNLINKED')

        # The two equalize commands close the menu. Both are bay-scope
        # by selection but cabinet-scope in their effect (every bay in
        # the picked cabinets is recalculated), so they sit apart from
        # the structural edits above.
        layout.separator()
        layout.operator("hb_face_frame.equalize_bays",
                        text="Equalize Bays", icon='ALIGN_JUSTIFY')
        layout.operator("hb_face_frame.set_equal_door_width",
                        text="Set Equal Door Width",
                        icon='ALIGN_JUSTIFY')


class HOME_BUILDER_MT_face_frame_part_commands(bpy.types.Menu):
    """Right-click menu shared by all face frame parts - end stiles,
    mid stiles, top / bottom rails, and bay-internal splitters. Items
    shown depend on the active part's role:

      end stile  -> Set Width, Set Scribe, Toggle Stile to Floor
      top rail   -> Set Width, Set Scribe (top_scribe)
      mid stile  -> Set Width, Mid Stile Properties... (deeper popup)
      others     -> Set Width
    """
    bl_label = "Face Frame Part Commands"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        role = obj.get('hb_part_role') if obj is not None else None

        # Parts of an applied finished-end panel (the "panel back")
        # surface that panel's own properties dialog. find_cabinet_root
        # stops at the applied-panel root, so cabinet_prompts edits the
        # panel itself, not the host cabinet.
        panel_root = types_face_frame.find_cabinet_root(obj)
        if panel_root is not None and (
                panel_root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
                or types_face_frame._is_standalone_panel(panel_root)):
            # Only a BACK panel is a "panel back" - the side panels are
            # just panels, and calling them backs reads as the wrong
            # object entirely.
            ptext = ("Panel Back Properties..."
                     if panel_root.get(
                         types_face_frame.TAG_APPLIED_PANEL_SIDE) == 'BACK'
                     else "Panel Properties...")
            layout.operator("hb_face_frame.cabinet_prompts",
                            text=ptext, icon='WINDOW')
            # Focused openings editor: columns / rows / row heights.
            layout.operator("hb_face_frame.panel_layout_prompts",
                            text="Panel Layout...", icon='MESH_GRID')
            # One-click merge on the stile the user is looking at.
            if role in ('MID_STILE', 'BAY_MID_STILE'):
                layout.operator("hb_face_frame.panel_remove_stile",
                                icon='X')
            layout.separator()

        # 5-piece door / drawer front: stile / rail / mid rail editor.
        if ops_part_commands.has_door_style_modifier(obj):
            layout.operator("hb_face_frame.set_door_frame",
                            text="Set Door Frame...", icon='MOD_BEVEL')

        # Doors: quarter / half circle tops. Per DOOR, so one leaf of a
        # pair can be round and the other square. Hidden on doors the
        # curve can't be cut into (slabs, mitered and applied-moulding
        # series, doors with nowhere to remember the choice).
        if ops_part_commands.door_shape_available(obj):
            layout.operator("hb_face_frame.set_door_shape",
                            text="Change Door Shape...", icon='SPHERECURVE')

        # Doors: per-door hardware callout override (restrictor clips /
        # touch latches / finger rout on THIS door instead of every door
        # of the style).
        if role == 'DOOR':
            layout.operator("hb_face_frame.set_door_hardware",
                            text="Set Door Hardware...", icon='TOOL_SETTINGS')

        # Door / drawer / pullout / tilt-out fronts: per-opening pull
        # override (applies to every selected front).
        if role in ops_part_commands._ROLES_WITH_PULL:
            layout.operator("hb_face_frame.set_front_pull",
                            text="Set Pull...", icon='TOOL_SETTINGS')
        # Swing doors / pullouts: pin the pull's vertical position on
        # this opening (top / middle / bottom of the door).
        if role in ('DOOR', 'PULLOUT_FRONT'):
            layout.operator_menu_enum(
                "hb_face_frame.set_pull_location", "location",
                text="Set Pull Location", icon='TOOL_SETTINGS')

        # Face frame members (stiles / rails / splitters) keep their role-aware
        # Set Width. Every other cabinet part adjusts its size via Make
        # Editable (below) - there is no direct Set Size command.
        if role in ops_part_commands._ROLES_WITH_WIDTH:
            current_w = ops_part_commands.get_current_width(obj)
            if current_w is None:
                width_text = "Set Width"
            else:
                width_text = f"Set Width: {units.unit_to_string(context.scene.unit_settings, current_w)}"
            layout.operator("hb_face_frame.set_part_width",
                            text=width_text, icon='ARROW_LEFTRIGHT')

        # Scribe only makes sense at the cabinet's outer edges: end
        # stiles (left / right) and the top rail (top_scribe).
        if role in (types_face_frame.PART_ROLE_LEFT_STILE,
                    types_face_frame.PART_ROLE_RIGHT_STILE,
                    types_face_frame.PART_ROLE_TOP_RAIL):
            layout.operator("hb_face_frame.set_part_scribe",
                            text="Set Scribe...", icon='SNAP_EDGE')

        # Stile-to-floor: end stiles and between-bay mid stiles. On an
        # applied panel only the stile facing the cabinet front has a
        # kick recess to drop into, so the other one doesn't offer it.
        if role in (types_face_frame.PART_ROLE_LEFT_STILE,
                    types_face_frame.PART_ROLE_RIGHT_STILE,
                    types_face_frame.PART_ROLE_MID_STILE):
            from . import applied_panel_sizing
            panel_side = (panel_root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
                          if panel_root is not None else None)
            if panel_side is None or role == (
                    applied_panel_sizing.panel_facing_stile_role(panel_side)):
                layout.operator("hb_face_frame.toggle_stile_to_floor",
                                text="Toggle Stile to Floor",
                                icon='TRIA_DOWN_BAR')

        # Cabinet column: split turning applied over the stile. Also
        # offered on a built column component (the stile key rides on
        # it), so an existing column re-opens its own dialog.
        if role in (types_face_frame.PART_ROLE_LEFT_STILE,
                    types_face_frame.PART_ROLE_RIGHT_STILE,
                    types_face_frame.PART_ROLE_MID_STILE,
                    cabinet_column.PART_ROLE):
            layout.operator("hb_face_frame.set_cabinet_column",
                            text="Cabinet Column...",
                            icon='MESH_CYLINDER')

        # Finished bottom - on the carcass bottom (or the finished
        # bottom panel itself) of a standard upper, and on any shelf
        # behind a mid rail. That shelf is the bottom of everything
        # above it, so where the opening below holds an appliance it is
        # the underside on show - a refrigerator surround, whose own
        # carcass bottom is nowhere near the eye. Shelves are not
        # upper-only for that reason. The dialog binds the cabinet's
        # condition and offers a room-wide apply.
        _fb_root = types_face_frame.find_cabinet_root(obj)
        # The finish panel itself re-opens the dialog whatever it hangs
        # from, so a shelf's panel stays reachable on a tall cabinet.
        _fb_on_shelf = role in (types_face_frame.PART_ROLE_BAY_SHELF,
                                types_face_frame.PART_ROLE_FINISHED_BOTTOM)
        _fb_on_bottom = (
            role == types_face_frame.PART_ROLE_BOTTOM
            and _fb_root is not None
            and _fb_root.get('CABINET_TYPE') == 'UPPER')
        if ((_fb_on_bottom or _fb_on_shelf)
                and _fb_root is not None
                and _fb_root.face_frame_cabinet.corner_type == 'NONE'):
            layout.operator("hb_face_frame.set_finished_bottom",
                            text="Set Finished Bottom...",
                            icon='MOD_SOLIDIFY')

        # Finished-end condition is per-side: shown on the left / right
        # carcass side panels and on the back (plain or finished). The
        # operator derives the side from the clicked part's role and
        # shows only that side's props.
        if role in (types_face_frame.PART_ROLE_LEFT_SIDE,
                    types_face_frame.PART_ROLE_RIGHT_SIDE,
                    types_face_frame_corner.PART_ROLE_CORNER_LEFT_SIDE,
                    types_face_frame_corner.PART_ROLE_CORNER_RIGHT_SIDE,
                    types_face_frame.PART_ROLE_BACK,
                    types_face_frame.PART_ROLE_FINISHED_BACK):
            layout.operator("hb_face_frame.set_finished_end_condition",
                            text="Set Finished End Condition...",
                            icon='MOD_SOLIDIFY')

        # Two sides picked at one end of a back-to-back island: finish
        # that end as ONE panel across the whole island depth instead of
        # two half-depth panels meeting in a seam. The side that was
        # right-clicked is the one the panel is built on, so picking the
        # other side and running it again is how the panel moves runs.
        if ops_part_commands.combinable_end_parts(context) is not None:
            layout.operator("hb_face_frame.set_combined_finished_end",
                            text="Set Finished End for 2 Parts...",
                            icon='CON_SAMEVOL')
        _ce_side = ops_part_commands.combined_end_side(obj)
        if _ce_side is not None:
            layout.operator("hb_face_frame.separate_combined_end",
                            text="Separate Combined End",
                            icon='MOD_EDGESPLIT').side = _ce_side

        # Panel seam: a finished end taller than the board it is cut
        # from is made in two pieces joined at a height the user picks.
        # Offered on either piece of an already-seamed panel, so the
        # joint can be moved or taken out from whichever board is
        # clicked. Only on FINISHED ends - see ops_part_commands.
        if ops_part_commands.seam_available(obj):
            root = types_face_frame.find_cabinet_root(obj)
            side = ops_part_commands.seam_side_for(obj)
            cab = root.face_frame_cabinet
            seam = getattr(cab, 'left_side_seam_height' if side == 'LEFT'
                           else 'right_side_seam_height', 0.0)
            no_seam = getattr(cab, 'left_side_no_seam' if side == 'LEFT'
                              else 'right_side_no_seam', False)
            if no_seam:
                seam = 0.0
                seam_text = "Set Panel Seam: None"
            elif seam > 0:
                seam_text = "Set Panel Seam: %s" % units.unit_to_string(
                    context.scene.unit_settings, seam)
            else:
                seam_text = "Set Panel Seam..."
            layout.operator("hb_face_frame.set_panel_seam",
                            text=seam_text, icon='MOD_BEVEL')
            if seam > 0:
                layout.operator("hb_face_frame.remove_panel_seam",
                                text="Remove Panel Seam", icon='X')

        # Bottom rail can be removed. The rail spans the bays in its
        # segment; the operator sets Remove Bottom across that whole span
        # so the rail the user clicked goes away as one piece.
        if role == types_face_frame.PART_ROLE_BOTTOM_RAIL:
            layout.operator("hb_face_frame.remove_bottom_rail",
                            text="Remove Bottom Rail", icon='X')
            # Flush wide-bottom-rail toggle - base / tall cabinets only
            # (uppers have no kick; corners carry their own kick frame).
            _fr_root = ops_part_commands._flush_rail_root(obj)
            if _fr_root is not None:
                is_flush = (_fr_root.face_frame_cabinet.toe_kick_type
                            == 'FLUSH')
                layout.operator(
                    "hb_face_frame.toggle_flush_bottom_rail",
                    text=("Remove Flush Bottom Rail" if is_flush
                          else "Make Flush Bottom Rail"),
                    icon='TRIA_DOWN_BAR')
            layout.menu("HOME_BUILDER_MT_face_frame_bottom_rail_profile",
                        text="Bottom Rail Profile", icon='MOD_BEVEL')

        # The valance front board carries the same decorative profile
        # option as a cabinet bottom rail (arch etc.).
        if role == types_face_frame.PART_ROLE_VALANCE_BOARD:
            layout.menu("HOME_BUILDER_MT_face_frame_bottom_rail_profile",
                        text="Bottom Profile", icon='MOD_BEVEL')

        # A mid rail can be removed (mainly between drawers). The split
        # stays; the FF member + its backing drop and the solver closes
        # the two fronts to a 3/32" reveal. No restore here - rebuild the
        # bay via Change Bay if needed.
        if role == types_face_frame.PART_ROLE_BAY_MID_RAIL:
            layout.operator("hb_face_frame.remove_mid_rail",
                            text="Remove Mid Rail", icon='X')

        # The carcass backing behind a splitter comes and goes on its own:
        # a drawer bank is rails with no floors between the boxes, while a
        # stacked-door cabinet wants the shelf. Offered on the member and
        # on the backing part itself, so a shelf already in the way can be
        # clicked and dropped.
        if role in ops_part_commands._BACKING_HOST_ROLES:
            is_stile_side = role in (types_face_frame.PART_ROLE_BAY_MID_STILE,
                                     types_face_frame.PART_ROLE_BAY_DIVISION)
            noun = "Division" if is_stile_side else "Shelf"
            behind = ("Behind Mid Stile" if is_stile_side
                      else "Behind Mid Rail")
            removed = ops_part_commands.backing_removed(obj)
            op = layout.operator(
                "hb_face_frame.toggle_splitter_backing",
                text=f"{'Add' if removed else 'Remove'} {noun} {behind}",
                icon=('ADD' if removed else 'X'))
            op.remove = not removed

        # Mid stiles keep their deeper properties popup (extend up /
        # down) as an additional item.
        if role == types_face_frame.PART_ROLE_MID_STILE:
            layout.separator()
            layout.operator("hb_face_frame.mid_stile_prompts",
                            text="Mid Stile Properties...", icon='WINDOW')

        # Machining cutouts (hole / route). Shows in 3D and in the 2D copy, so
        # no detail view is needed. Operators live in ops_part_commands.
        # Finish Opening - the clicked part's own opening, reachable
        # without going by way of the opening properties dialog. Only
        # where there is an opening to finish: a carcass panel hangs off
        # the cabinet, not an opening, and has none.
        from .operators import ops_cabinet
        if (obj is not None
                and ops_cabinet._find_owning_opening(obj) is not None):
            layout.operator("hb_face_frame.finish_opening_prompts",
                            text="Finish Opening...",
                            icon='SHADING_RENDERED')

        _draw_cutout_items(layout, obj)

        _draw_make_editable_items(layout, obj)

        _draw_visibility_items(layout, 'OBJECT', "Part")


class HOME_BUILDER_MT_face_frame_interior_part_commands(bpy.types.Menu):
    """Right-click menu for an interior part (shelf, pullout, mesh part,
    rollout box, etc.). Surfaces the owning opening's properties so the
    user can edit the opening's interior_items list without having to
    select the opening cage directly. The opening_prompts operator
    handles the walk-up from the clicked interior part.
    """
    bl_label = "Face Frame Interior Part Commands"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if _is_drawer_opening(obj):
            layout.operator("hb_face_frame.drawer_interior",
                            text="Drawer Interior...", icon='MESH_GRID')
        # Rollout boxes are drawer boxes on slides, so they carry the
        # same construction / slide picks as the box behind a drawer
        # front.
        if (obj is not None
                and obj.get('hb_part_role')
                == types_face_frame.PART_ROLE_ROLLOUT_BOX):
            # Per-box U-notch, the rollout's version of the sink duo
            # drawer. Self-polling: hidden when the box predates the
            # per-box options and its indices don't resolve.
            layout.operator("hb_face_frame.sink_duo_rollout_prompts",
                            text="U-Shaped Rollout...",
                            icon='SELECT_SUBTRACT')
            if _has_drawer_box_construction_options():
                _draw_drawer_box_construction_menu(layout)
            if _has_drawer_slides_options():
                _draw_drawer_slides_menu(layout)
        # The owning opening's three dialogs, in the order the opening
        # cage's own menu offers them - clicking a shelf and clicking
        # the opening it sits in should reach the same places the same
        # way. Interior Options is where the shelf itself is edited, so
        # it has to be here above all.
        layout.separator()
        layout.operator("hb_face_frame.opening_prompts",
                        text="Opening Properties...", icon='WINDOW')
        layout.operator("hb_face_frame.finish_opening_prompts",
                        text="Finish Opening...", icon='SHADING_RENDERED')
        layout.operator("hb_face_frame.interior_options",
                        text="Interior Options...", icon='MESH_GRID')
        # A shelf is as worth hand-editing as any other cutpart, and
        # this is the only menu it has.
        _draw_make_editable_items(layout, obj)

        _draw_visibility_items(layout, 'OBJECT', "Part")


class HOME_BUILDER_MT_face_frame_drawer_box_construction(bpy.types.Menu):
    """Which construction the clicked drawer's / rollout's boxes are
    built to. The entries come from the host application's option list;
    the pick is stored on the owning opening, so one job can mix
    constructions cabinet by cabinet."""
    bl_label = "Drawer Box Construction"

    def draw(self, context):
        from .operators import ops_cabinet
        layout = self.layout
        opening = ops_cabinet._find_owning_opening(context.active_object)
        current = (opening.face_frame_opening.drawer_box_construction
                   if opening is not None else '')
        entries = [(ops_cabinet.DRAWER_BOX_CONSTRUCTION_DEFAULT,
                    "Project Default", '')]
        entries += [(code, name, code)
                    for code, name in ops_cabinet.drawer_box_construction_options()]
        for code, name, stored in entries:
            op = layout.operator(
                "hb_face_frame.set_drawer_box_construction", text=name,
                icon=('RADIOBUT_ON' if stored == current else 'RADIOBUT_OFF'))
            op.code = code
            if opening is not None:
                op.opening_name = opening.name


class HOME_BUILDER_MT_face_frame_drawer_slides(bpy.types.Menu):
    """Which slide hardware the clicked drawer's / rollout's boxes run
    on. Same shape as the construction submenu: options come from the
    host application, the pick stores on the owning opening, so the odd
    heavy duty drawer can differ from the project's slides."""
    bl_label = "Drawer Slides"

    def draw(self, context):
        from .operators import ops_cabinet
        layout = self.layout
        opening = ops_cabinet._find_owning_opening(context.active_object)
        current = (opening.face_frame_opening.drawer_slides
                   if opening is not None else '')
        entries = [(ops_cabinet.DRAWER_BOX_CONSTRUCTION_DEFAULT,
                    "Project Default", '')]
        entries += [(code, name, code)
                    for code, name in ops_cabinet.drawer_slides_options()]
        for code, name, stored in entries:
            op = layout.operator(
                "hb_face_frame.set_drawer_slides", text=name,
                icon=('RADIOBUT_ON' if stored == current else 'RADIOBUT_OFF'))
            op.code = code
            if opening is not None:
                op.opening_name = opening.name


class HOME_BUILDER_MT_face_frame_drawer_box_commands(bpy.types.Menu):
    """Right-click menu for a drawer box (reachable in Interiors
    selection mode). Size edits store on the owning opening - the box
    itself is rebuilt every recalc - and Opening Properties walks up
    from the box the same way interior parts do.
    """
    bl_label = "Drawer Box Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.drawer_interior",
                        text="Drawer Interior...", icon='MESH_GRID')
        layout.operator("hb_face_frame.toggle_front_open",
                        text="Open / Close Drawer", icon='FULLSCREEN_ENTER')
        layout.separator()
        layout.operator("hb_face_frame.drawer_box_prompts",
                        text="Drawer Box Size...", icon='ARROW_LEFTRIGHT')
        layout.operator("hb_face_frame.rollout_above_drawer_prompts",
                        text="Rollout Above Drawer...", icon='TRIA_UP_BAR')
        layout.operator("hb_face_frame.sink_duo_drawer_prompts",
                        text="Sink Duo Drawer...", icon='SELECT_SUBTRACT')
        if _has_drawer_box_construction_options():
            _draw_drawer_box_construction_menu(layout)
        if _has_drawer_slides_options():
            _draw_drawer_slides_menu(layout)
        # Same trailing group as every other interior surface. Drawer
        # Interior keeps its row at the top: this menu is about the box,
        # and that is the dialog it is opened for.
        layout.separator()
        layout.operator("hb_face_frame.opening_prompts",
                        text="Opening Properties...", icon='WINDOW')
        layout.operator("hb_face_frame.finish_opening_prompts",
                        text="Finish Opening...", icon='SHADING_RENDERED')
        layout.operator("hb_face_frame.interior_options",
                        text="Interior Options...", icon='MESH_GRID')
        _draw_make_editable_items(layout, context.active_object)


class HOME_BUILDER_MT_face_frame_opening_commands(bpy.types.Menu):
    """Right-click menu for a face frame opening cage."""
    bl_label = "Face Frame Opening Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.opening_prompts",
                        text="Opening Properties...", icon='WINDOW')

        # What the opening holds: how its inside is finished, what
        # lives in it, and the catalog items called out on it. Opening
        # a front is left to Open Door mode in the viewport.
        layout.separator()
        layout.operator("hb_face_frame.finish_opening_prompts",
                        text="Finish Opening...", icon='SHADING_RENDERED')
        layout.operator("hb_face_frame.interior_options",
                        text="Interior Options...", icon='MESH_GRID')
        # Accessories are the host application's catalog; with none
        # registered there is nothing to add, so the entry stays out.
        if accessory_registry.available():
            layout.operator("hb_face_frame.accessory_menu",
                            text="Add Accessory...", icon='ADD')

        layout.separator()
        layout.menu("HOME_BUILDER_MT_face_frame_change_opening",
                    text="Change Opening")

        layout.separator()
        layout.operator("hb_face_frame.equalize_opening_heights",
                        text="Equalize Opening Heights",
                        icon='ALIGN_JUSTIFY')

        layout.separator()
        op = layout.operator("hb_face_frame.split_opening",
                             text="Split Horizontal", icon='SNAP_EDGE')
        op.axis = 'H'
        op = layout.operator("hb_face_frame.split_opening",
                             text="Split Vertical", icon='PAUSE')
        op.axis = 'V'


class HOME_BUILDER_MT_face_frame_change_opening(bpy.types.Menu):
    """Submenu of opening configuration presets. Each entry calls
    hb_face_frame.change_opening with the appropriate config; the
    operator drives front_type, hinge_side, and the ADJUSTABLE_SHELF
    interior item to match.
    """
    bl_label = "Change Opening"

    # (config_value, display_text); ('SEP',) inserts a separator.
    ENTRIES = [
        ('OPEN',              "Open"),
        ('OPEN_WITH_SHELVES', "Open with Shelves"),
        ('SEP',),
        ('LEFT_DOOR',         "Left Door"),
        ('RIGHT_DOOR',        "Right Door"),
        ('DOUBLE_DOOR',       "Double Door"),
        ('SEP',),
        ('FLIP_UP_DOOR',      "Flip Up Door"),
        ('FLIP_DOWN_DOOR',    "Flip Down Door"),
        ('SEP',),
        ('RETRACTING_DOOR',        "Retracting Door"),
        ('RETRACTING_DOOR_PAIR',   "Retracting Doors (Pair)"),
        ('BIFOLD_RETRACTING_DOOR', "Bi-fold Retracting Doors"),
        ('TOP_RETRACTING_DOOR',    "Top-Mount Retracting Door"),
        ('SEP',),
        ('DRAWER',            "Drawer"),
        ('FALSE_FRONT',       "False Front"),
        ('TILT_OUT',          "Tilt-Out"),
        ('PULLOUT',           "Pullout"),
        ('SEP',),
        ('INSET_PANEL',       "Inset Panel"),
        ('APPLIANCE',         "Appliance"),
    ]

    def draw(self, context):
        layout = self.layout
        for entry in self.ENTRIES:
            if entry[0] == 'SEP':
                layout.separator()
                continue
            config, label = entry
            op = layout.operator("hb_face_frame.change_opening", text=label)
            op.config = config


class HOME_BUILDER_MT_face_frame_change_bay(bpy.types.Menu):
    """Submenu of bay configuration presets. Reads the active bay's
    cabinet type to pick which entry list to render. Each entry calls
    hb_face_frame.change_bay with the right config string; the
    operator looks the recipe up in bay_presets.PRESETS.
    """
    bl_label = "Change Bay"

    def draw(self, context):
        layout = self.layout
        bay_obj = context.active_object
        cab_root = (types_face_frame.find_cabinet_root(bay_obj)
                    if bay_obj is not None else None)
        if cab_root is None:
            layout.label(text="No cabinet selected")
            return
        cabinet_type = cab_root.face_frame_cabinet.cabinet_type
        entries = bay_presets.MENU_ENTRIES.get(cabinet_type)
        if not entries:
            layout.label(text=f"No presets for {cabinet_type}")
            return
        for entry in entries:
            if entry[0] == 'SEP':
                layout.separator()
                continue
            config, label, *rest = entry
            icon = rest[0] if rest else 'NONE'
            op = layout.operator("hb_face_frame.change_bay",
                                 text=label, icon=icon)
            op.config = config


class HOME_BUILDER_MT_face_frame_add_appliance(bpy.types.Menu):
    """Submenu: configure the active base bay for a sink or cooktop. Each
    entry invokes hb_face_frame.add_appliance_to_bay with the appliance
    kind preset; the operator opens a dialog for width / drop / config /
    interior.
    """
    bl_label = "Add Appliance to Bay"

    def draw(self, context):
        layout = self.layout
        for kind, label, icon in (
            ('KITCHEN_SINK', "Add Kitchen Sink", 'MOD_FLUIDSIM'),
            ('VANITY_SINK',  "Add Vanity Sink",  'MOD_FLUIDSIM'),
            ('COOKTOP',      "Add Cooktop",      'VOLUME_DATA'),
        ):
            op = layout.operator("hb_face_frame.add_appliance_to_bay",
                                 text=label, icon=icon)
            op.appliance_kind = kind

        # Remove entry only when the bay currently carries an appliance:
        # a SINK / COOKTOP stamp, or (dedicated sink cabinet) the
        # auto-detected annotation child.
        bay = context.active_object
        kind = bay.get('APPLIANCE_BAY') if bay is not None else None
        if kind not in ('SINK', 'COOKTOP') and bay is not None:
            kind = None
            for child in bay.children:
                if child.get('APPLIANCE_ANNOTATION'):
                    kind = ('SINK' if child.get('IS_SINK_ANNOTATION')
                            else 'COOKTOP')
                    break
        if kind in ('SINK', 'COOKTOP'):
            layout.separator()
            layout.operator("hb_face_frame.remove_appliance_from_bay",
                            text=f"Remove {kind.title()}", icon='X')


class HOME_BUILDER_MT_face_frame_leg_product_commands(bpy.types.Menu):
    """Right-click menu for a leg product root."""
    bl_label = "Leg Product Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.leg_product_prompts",
                        text="Leg Properties...", icon='WINDOW')
        layout.separator()
        layout.operator("hb_face_frame.delete_cabinet",
                        text="Delete Leg", icon='X')


class HOME_BUILDER_MT_face_frame_floating_shelf_commands(bpy.types.Menu):
    """Right-click menu for a floating shelf root."""
    bl_label = "Floating Shelf Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.floating_shelf_prompts",
                        text="Floating Shelf Properties...", icon='WINDOW')
        layout.operator("hb_face_frame.duplicate_floating_shelf",
                        text="Set Quantity & Spacing...", icon='LINENUMBERS_ON')
        # Multi-shelf editor - only when 2+ distinct floating shelves are
        # selected (align their floor height, spacing, and thickness).
        roots = set()
        for o in context.selected_objects:
            r = types_face_frame.find_cabinet_root(o)
            if r is not None and r.get('IS_FLOATING_SHELF'):
                roots.add(r.name)
        if len(roots) > 1:
            layout.operator("hb_face_frame.adjust_floating_shelves",
                            text="Adjust Spacing & Heights...", icon='LINENUMBERS_ON')
        layout.separator()
        layout.operator("hb_face_frame.delete_cabinet",
                        text="Delete Shelf", icon='X')


class HOME_BUILDER_MT_face_frame_door_part_commands(bpy.types.Menu):
    """Right-click menu for a Door Part - a bare door front (cutpart +
    door style + pull, no cabinet cage). Set Dimensions resizes the door
    (and re-tracks its pull); Assign Active Style re-applies the project's
    active cabinet style's door style; Delete routes through the HB5-aware
    delete (falls back to object.delete for a cage-less part).
    """
    bl_label = "Door Part Commands"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        show_pull = obj.get('DOOR_PART_SHOW_PULL', True) if obj else True
        is_drawer = (obj.get('DOOR_PART_FRONT_KIND', 'DOOR') == 'DRAWER') if obj else False
        layout.operator("hb_face_frame.set_door_part_dimensions",
                        text="Set Dimensions...", icon='ARROW_LEFTRIGHT')
        if ops_part_commands.has_door_style_modifier(obj):
            layout.operator("hb_face_frame.set_door_frame",
                            text="Set Door Frame...", icon='MOD_BEVEL')
        layout.operator("hb_face_frame.assign_active_door_style",
                        text="Assign Active Style", icon='MOD_BEVEL')
        layout.separator()
        # Front kind: door vs drawer front (only the pull placement /
        # asset differs). Label offers the OTHER kind.
        layout.operator("hb_face_frame.toggle_door_part_front_kind",
                        text="Switch to Door Front" if is_drawer else "Switch to Drawer Front",
                        icon='FILE_REFRESH')
        layout.separator()
        # Pull controls. Toggle label tracks current state; switch-side is
        # only meaningful for a shown DOOR-front pull (drawer pulls are
        # centered, so side does nothing there).
        layout.operator("hb_face_frame.toggle_door_part_pull",
                        text="Hide Pull" if show_pull else "Show Pull",
                        icon='CHECKBOX_HLT' if show_pull else 'CHECKBOX_DEHLT')
        row = layout.row()
        row.enabled = show_pull and not is_drawer
        row.operator("hb_face_frame.switch_door_part_pull_side",
                     text="Switch Pull Side", icon='ARROW_LEFTRIGHT')
        layout.separator()
        layout.operator("hb_general.delete", text="Delete Part", icon='X')


class HOME_BUILDER_MT_face_frame_valance_commands(bpy.types.Menu):
    """Right-click menu for a valance root."""
    bl_label = "Valance Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.valance_prompts",
                        text="Valance Properties...", icon='WINDOW')
        layout.menu("HOME_BUILDER_MT_face_frame_bottom_rail_profile",
                    text="Bottom Profile", icon='MOD_BEVEL')
        layout.separator()
        layout.operator("hb_face_frame.delete_cabinet",
                        text="Delete Valance", icon='X')


class HOME_BUILDER_MT_face_frame_column_beam_commands(bpy.types.Menu):
    """Right-click menu for a column or beam wrap root."""
    bl_label = "Column / Beam Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.column_beam_properties",
                        text="Column / Beam Properties...", icon='WINDOW')
        layout.separator()
        layout.operator("hb_face_frame.delete_cabinet",
                        text="Delete Column / Beam", icon='X')


class HOME_BUILDER_MT_face_frame_mantle_commands(bpy.types.Menu):
    """Right-click menu for a mantle root."""
    bl_label = "Mantle Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.mantle_prompts",
                        text="Mantle Properties...", icon='WINDOW')
        layout.separator()
        layout.operator("hb_face_frame.delete_cabinet",
                        text="Delete Mantle", icon='X')


class HOME_BUILDER_MT_face_frame_cutouts(bpy.types.Menu):
    """Edit / Remove picker for a part carrying more than one machining
    cutout. Numbered in the order they were added, which is the order they
    sit in the modifier stack."""
    bl_label = "Cutouts"

    def draw(self, context):
        layout = self.layout
        mods = ops_part_commands._user_cutout_mods(context.active_object)
        for i, mod in enumerate(mods):
            props = layout.operator("hb_face_frame.add_part_cutout",
                                    text=f"Edit Cutout {i + 1}...",
                                    icon='WINDOW')
            props.mod_name = mod.name
        layout.separator()
        for i, mod in enumerate(mods):
            props = layout.operator("hb_face_frame.remove_part_cutout",
                                    text=f"Remove Cutout {i + 1}", icon='X')
            props.mod_name = mod.name


class HOME_BUILDER_MT_face_frame_misc_part_commands(bpy.types.Menu):
    """Right-click menu for a Misc Part - a bare GeoNodeCutpart with no
    cabinet cage. The cabinet / part-role menus don't apply, so this is
    properties (size + panel type), machining cutouts, Make Editable /
    Revert, and delete. Part Properties and the cutout items edit the
    cutpart's GeoNode inputs, so they hide once the part is made editable
    (GN applied); Delete routes through the HB5-aware delete (which falls
    back to object.delete for a cage-less part).
    """
    bl_label = "Misc Part Commands"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        if ops_part_commands._is_cutpart(obj):
            layout.operator("hb_face_frame.set_misc_part_dimensions",
                            text="Part Properties...", icon='WINDOW')
            # Machining cutouts - same entries as the cabinet-part menu; a
            # Misc Part is itself a parametric cutpart so they apply unchanged.
            _draw_cutout_items(layout, obj)

        # Make Editable / Revert. A Misc Part has no cabinet recalc, so
        # Revert restores its stashed Length / Width / Thickness directly
        # (see ops_part_commands._revert_one).
        if obj is not None and obj.get('IS_MANUAL_PART'):
            layout.separator()
            layout.operator("hb_face_frame.revert_part_to_parametric",
                            text="Revert to Parametric", icon='FILE_REFRESH')
        elif ops_part_commands._can_make_editable(obj):
            layout.separator()
            layout.operator("hb_face_frame.make_part_editable",
                            text="Make Editable", icon='EDITMODE_HLT')

        layout.separator()
        layout.operator("hb_general.delete", text="Delete Part", icon='X')


class HOME_BUILDER_MT_face_frame_wood_top_commands(bpy.types.Menu):
    """Right-click menu for a Wood Top (countertop part)."""
    bl_label = "Wood Top Commands"

    def draw(self, context):
        layout = self.layout
        layout.operator("hb_face_frame.wood_top_prompts",
                        text="Wood Top Options...", icon='WINDOW')
        layout.separator()
        layout.operator("hb_general.delete", text="Delete Wood Top",
                        icon='X')


class HOME_BUILDER_MT_face_frame_bottom_rail_profile(bpy.types.Menu):
    """Pick the decorative bottom-rail profile. Lists None + every
    '* Cutter' curve in face_frame_assets/profiles; the current choice is
    marked. On a bottom RAIL the pick (and the mark) is that rail's bay
    override; elsewhere (valance board / cabinet menus) it is the
    cabinet-level enum."""
    bl_label = "Bottom Rail Profile"

    def draw(self, context):
        import os
        layout = self.layout
        active = context.active_object
        root = types_face_frame.find_cabinet_root(active)
        current = ''
        if root is not None:
            current = getattr(root.face_frame_cabinet, 'bottom_rail_profile', 'NONE')
        if (active is not None and active.get('hb_part_role')
                == types_face_frame.PART_ROLE_BOTTOM_RAIL):
            bay = types_face_frame.bay_cage_for_bottom_rail(active)
            if bay is not None:
                ov = getattr(bay.face_frame_bay, 'bottom_rail_profile', 'CABINET')
                if ov and ov != 'CABINET':
                    current = ov
        items = [('NONE', 'None'), ('ARCH', 'Arched'),
                 ('TRADITIONAL', 'Traditional')]
        d = types_face_frame.bottom_rail_profile_dir()
        if os.path.isdir(d):
            for fn in sorted(os.listdir(d)):
                if fn.endswith(' Cutter.blend'):
                    stem = fn[:-len('.blend')]
                    items.append((stem, stem[:-len(' Cutter')]))
        for pid, label in items:
            icon = 'RADIOBUT_ON' if pid == current else 'RADIOBUT_OFF'
            op = layout.operator('hb_face_frame.set_bottom_rail_profile',
                                  text=label, icon=icon)
            op.profile_id = pid


classes = (
    HOME_BUILDER_MT_face_frame_cabinet_commands,
    HOME_BUILDER_MT_face_frame_floating_shelf_commands,
    HOME_BUILDER_MT_face_frame_valance_commands,
    HOME_BUILDER_MT_face_frame_mantle_commands,
    HOME_BUILDER_MT_face_frame_column_beam_commands,
    HOME_BUILDER_MT_face_frame_misc_part_commands,
    HOME_BUILDER_MT_face_frame_door_part_commands,
    HOME_BUILDER_MT_face_frame_leg_product_commands,
    HOME_BUILDER_MT_face_frame_cabinet_group_commands,
    HOME_BUILDER_MT_face_frame_bay_commands,
    HOME_BUILDER_MT_face_frame_bay_back_type,
    HOME_BUILDER_MT_face_frame_part_commands,
    HOME_BUILDER_MT_face_frame_interior_part_commands,
    HOME_BUILDER_MT_face_frame_drawer_box_construction,
    HOME_BUILDER_MT_face_frame_drawer_slides,
    HOME_BUILDER_MT_face_frame_drawer_box_commands,
    HOME_BUILDER_MT_face_frame_opening_commands,
    HOME_BUILDER_MT_face_frame_change_opening,
    HOME_BUILDER_MT_face_frame_change_bay,
    HOME_BUILDER_MT_face_frame_add_appliance,
    HOME_BUILDER_MT_face_frame_wood_top_commands,
    HOME_BUILDER_MT_face_frame_bottom_rail_profile,
    HOME_BUILDER_MT_face_frame_cutouts,
)


register, unregister = bpy.utils.register_classes_factory(classes)

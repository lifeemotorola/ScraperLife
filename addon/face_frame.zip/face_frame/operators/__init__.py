from . import ops_cabinet
from . import ops_countertop
from . import ops_defaults
from . import ops_finished_ends
from . import ops_library
from . import ops_placement
from . import ops_styles
from . import op_modify_cabinet
from . import op_open_mode
from . import ops_part_commands
from . import ops_appliance_panels
from . import ops_thumbnails
from . import ops_wedge
from . import ops_pipe_chase
from . import ops_pull_library
from . import ops_draw_path


def register():
    ops_cabinet.register()
    ops_countertop.register()
    ops_defaults.register()
    ops_finished_ends.register()
    ops_library.register()
    ops_placement.register()
    ops_styles.register()
    op_modify_cabinet.register()
    op_open_mode.register()
    ops_part_commands.register()
    ops_appliance_panels.register()
    ops_thumbnails.register()
    ops_wedge.register()
    ops_pipe_chase.register()
    ops_pull_library.register()
    ops_draw_path.register()


def unregister():
    ops_draw_path.unregister()
    ops_pull_library.unregister()
    ops_pipe_chase.unregister()
    ops_wedge.unregister()
    ops_thumbnails.unregister()
    ops_appliance_panels.unregister()
    ops_part_commands.unregister()
    op_open_mode.unregister()
    op_modify_cabinet.unregister()
    ops_styles.unregister()
    ops_placement.unregister()
    ops_library.unregister()
    ops_finished_ends.unregister()
    ops_defaults.unregister()
    ops_countertop.unregister()
    ops_cabinet.unregister()

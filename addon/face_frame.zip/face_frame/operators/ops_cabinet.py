import bpy
from mathutils import Vector, Matrix, Euler

from .... import hb_utils

from .. import types_face_frame
from .. import types_face_frame_corner
from .. import bay_presets
from .. import props_hb_face_frame
from .. import split_preview
from .. import quiet_cages
from ....units import inch, meter_to_inch
from .... import hb_types, hb_utils
from .... import accessory_registry
from ...frameless.operators.ops_placement import toggle_cabinet_color


# ---------------------------------------------------------------------------
# Operator: drop a cabinet from the library
# ---------------------------------------------------------------------------
class hb_face_frame_OT_draw_cabinet(bpy.types.Operator):
    """Drop a face frame cabinet at the 3D cursor."""
    bl_idname = "hb_face_frame.draw_cabinet"
    bl_label = "Draw Face Frame Cabinet"
    bl_options = {'REGISTER', 'UNDO'}

    cabinet_name: bpy.props.StringProperty(
        name="Cabinet Name",
        description="The face frame cabinet type to draw",
        default="",
    )  # type: ignore

    bay_qty: bpy.props.IntProperty(
        name="Bay Quantity",
        description="Number of bays to create on the cabinet (1-10)",
        default=1, min=1, max=10,
    )  # type: ignore

    def execute(self, context):
        # Thin wrapper over the modal placement operator. Lets the
        # catalog browser keep calling hb_face_frame.draw_cabinet while
        # the actual placement (cursor follow, wall snap, click-to-
        # commit) lives in hb_face_frame.place_cabinet. Same pattern
        # frameless uses (see ops_placement.py in that library).
        if not self.cabinet_name:
            self.report({'WARNING'}, "No cabinet name supplied")
            return {'CANCELLED'}
        # Appliance products: invoke the appliance placement modal
        # (cursor follow + wall snap, fixed width, single instance).
        if self.cabinet_name in types_face_frame.APPLIANCE_NAME_DISPATCH:
            bpy.ops.hb_face_frame.place_appliance(
                'INVOKE_DEFAULT',
                appliance_name=self.cabinet_name,
            )
            return {'FINISHED'}
        # Corner cabinets get a dedicated placement modal - same
        # cursor-follow / GPU-dim feedback as regular cabinets, but
        # snaps to wall corners instead of gap edges and skips the
        # fill / bay-qty / typed-width affordances that don't apply
        # to a corner build.
        cls = types_face_frame.get_cabinet_class(self.cabinet_name)
        if cls is not None and issubclass(
                cls, types_face_frame_corner.CornerFaceFrameCabinet):
            bpy.ops.hb_face_frame.place_corner_cabinet(
                'INVOKE_DEFAULT',
                cabinet_name=self.cabinet_name,
            )
            return {'FINISHED'}
        bpy.ops.hb_face_frame.place_cabinet(
            'INVOKE_DEFAULT',
            cabinet_name=self.cabinet_name,
            bay_qty=self.bay_qty,
        )
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operator: delete the active face frame cabinet (and any others selected)
# ---------------------------------------------------------------------------
class hb_face_frame_OT_delete_cabinet(bpy.types.Operator):
    """Delete every face frame cabinet currently selected."""
    bl_idname = "hb_face_frame.delete_cabinet"
    bl_label = "Delete Face Frame Cabinet"
    bl_description = "Delete the selected cabinet(s) and all their parts"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return types_face_frame.find_cabinet_root(context.active_object) is not None

    def execute(self, context):
        # Collect distinct cabinet roots from the selection so that
        # selecting any descendant (bay, opening, mid stile, part)
        # still resolves to the cabinet, and selecting multiple parts
        # of the same cabinet only triggers one delete.
        roots = []
        seen = set()
        for obj in context.selected_objects:
            root = types_face_frame.find_cabinet_root(obj)
            if root is None or root.name in seen:
                continue
            seen.add(root.name)
            roots.append(root)

        if not roots:
            self.report({'WARNING'}, "No face frame cabinet selected")
            return {'CANCELLED'}

        for root in roots:
            hb_utils.delete_obj_and_children(root)

        self.report({'INFO'}, f"Deleted {len(roots)} cabinet(s)")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operator: join multiple selected cabinets into one
# ---------------------------------------------------------------------------
class hb_face_frame_OT_join_cabinets(bpy.types.Operator):
    """Merge selected face frame cabinets into the active cabinet,
    sharing a continuous face frame. Each absorbed cabinet's bays
    (and per-opening configuration) carry over; the active cabinet
    is the survivor.
    """
    bl_idname = "hb_face_frame.join_cabinets"
    bl_label = "Join Cabinets"
    bl_description = (
        "Merge selected face frame cabinets into the active cabinet, "
        "sharing one continuous face frame"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        # Need at least two distinct face frame cabinets in the
        # selection, with the active object resolving to one of them.
        active_root = types_face_frame.find_cabinet_root(context.active_object)
        if active_root is None:
            return False
        seen = {active_root.name}
        for obj in context.selected_objects:
            root = types_face_frame.find_cabinet_root(obj)
            if root is not None:
                seen.add(root.name)
                if len(seen) >= 2:
                    return True
        return False

    def execute(self, context):
        active_root = types_face_frame.find_cabinet_root(context.active_object)
        if active_root is None:
            self.report({'ERROR'}, "No active face frame cabinet")
            return {'CANCELLED'}

        roots = []
        seen = set()
        for obj in context.selected_objects:
            root = types_face_frame.find_cabinet_root(obj)
            if root is None or root.name in seen:
                continue
            seen.add(root.name)
            roots.append(root)

        if len(roots) < 2:
            self.report({'WARNING'}, "Select two or more face frame cabinets")
            return {'CANCELLED'}

        # All selected cabinets must share a parent (same wall, or all
        # unparented). The merge primitive checks per-pair, but bailing
        # here gives a clearer error than "merge failed".
        if len({r.parent for r in roots}) > 1:
            self.report({'ERROR'}, "Cabinets must share the same parent")
            return {'CANCELLED'}

        # Sort left-to-right and pre-flight every adjacent pair before
        # any merge runs - half-merged state on a partial failure is
        # confusing for the user even with undo.
        roots.sort(key=lambda r: r.location.x)
        eps = 1e-4
        tol = inch(1.0)
        for a, b in zip(roots, roots[1:]):
            ap = a.face_frame_cabinet
            bp = b.face_frame_cabinet
            if abs(ap.height - bp.height) > eps:
                self.report({'ERROR'}, "Cabinets must match in height")
                return {'CANCELLED'}
            if abs(ap.depth - bp.depth) > eps:
                self.report({'ERROR'}, "Cabinets must match in depth")
                return {'CANCELLED'}
            if abs(a.matrix_world.translation.z - b.matrix_world.translation.z) > eps:
                self.report({'ERROR'}, "Cabinets must sit at the same Z")
                return {'CANCELLED'}
            if ap.corner_type != 'NONE' or bp.corner_type != 'NONE':
                self.report({'ERROR'}, "Corner cabinets cannot be joined")
                return {'CANCELLED'}
            if abs(b.location.x - (a.location.x + ap.width)) > tol:
                self.report({'ERROR'},
                            "Cabinets must abut along the wall (no gaps)")
                return {'CANCELLED'}

        # Active becomes anchor. Merge cabinets on each side of active
        # closest-first so the running anchor's geometry stays sane.
        active_idx = roots.index(active_root)
        for i in range(active_idx - 1, -1, -1):
            if not types_face_frame.merge_cabinets(active_root, roots[i], 'LEFT'):
                self.report({'ERROR'}, "Merge failed during pairwise join")
                return {'CANCELLED'}
        for i in range(active_idx + 1, len(roots)):
            if not types_face_frame.merge_cabinets(active_root, roots[i], 'RIGHT'):
                self.report({'ERROR'}, "Merge failed during pairwise join")
                return {'CANCELLED'}

        for o in context.selected_objects:
            o.select_set(False)
        active_root.select_set(True)
        context.view_layer.objects.active = active_root

        self.report({'INFO'}, f"Joined {len(roots)} cabinets")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Helper: resolve active object to (bay, cabinet_root)
# ---------------------------------------------------------------------------
def _find_active_bay_and_root(context):
    """Walk up from the active object to find the enclosing bay cage
    and cabinet root. Returns (bay, root) or (None, None)."""
    obj = context.active_object
    if obj is None:
        return None, None
    bay = None
    cur = obj
    while cur is not None:
        if bay is None and cur.get(types_face_frame.TAG_BAY_CAGE):
            bay = cur
        if cur.get(types_face_frame.TAG_CABINET_CAGE):
            return bay, cur
        cur = cur.parent
    return None, None


def _bay_count(root):
    return sum(1 for c in root.children
               if c.get(types_face_frame.TAG_BAY_CAGE))


# ---------------------------------------------------------------------------
# Operators: break a cabinet at gaps adjacent to the active bay
# ---------------------------------------------------------------------------
class hb_face_frame_OT_break_cabinet_left(bpy.types.Operator):
    """Break the cabinet at the gap to the left of the active bay.
    The active bay becomes the leftmost bay of the new right-side
    cabinet; its width is locked so it holds through the recalc.
    """
    bl_idname = "hb_face_frame.break_cabinet_left"
    bl_label = "Break Left"
    bl_description = "Split the cabinet at the gap left of the active bay"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        bay, root = _find_active_bay_and_root(context)
        if bay is None or root is None:
            return False
        return bay.face_frame_bay.bay_index > 0

    def execute(self, context):
        bay, root = _find_active_bay_and_root(context)
        if bay is None or root is None:
            self.report({'ERROR'}, "No active bay")
            return {'CANCELLED'}
        bay_index = bay.face_frame_bay.bay_index
        if bay_index <= 0:
            self.report({'WARNING'}, "Active bay is the first bay")
            return {'CANCELLED'}
        bay.face_frame_bay.unlock_width = True
        new_root = types_face_frame.break_cabinet_at_gap(root, bay_index - 1)
        if new_root is None:
            self.report({'ERROR'}, "Break failed")
            return {'CANCELLED'}
        return {'FINISHED'}


class hb_face_frame_OT_break_cabinet_right(bpy.types.Operator):
    """Break the cabinet at the gap to the right of the active bay.
    The active bay stays as the rightmost bay of the (modified)
    original cabinet; its width is locked so it holds through the
    recalc.
    """
    bl_idname = "hb_face_frame.break_cabinet_right"
    bl_label = "Break Right"
    bl_description = "Split the cabinet at the gap right of the active bay"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        bay, root = _find_active_bay_and_root(context)
        if bay is None or root is None:
            return False
        return bay.face_frame_bay.bay_index < _bay_count(root) - 1

    def execute(self, context):
        bay, root = _find_active_bay_and_root(context)
        if bay is None or root is None:
            self.report({'ERROR'}, "No active bay")
            return {'CANCELLED'}
        bay_index = bay.face_frame_bay.bay_index
        if bay_index >= _bay_count(root) - 1:
            self.report({'WARNING'}, "Active bay is the last bay")
            return {'CANCELLED'}
        bay.face_frame_bay.unlock_width = True
        new_root = types_face_frame.break_cabinet_at_gap(root, bay_index)
        if new_root is None:
            self.report({'ERROR'}, "Break failed")
            return {'CANCELLED'}
        return {'FINISHED'}


class hb_face_frame_OT_break_cabinet_both(bpy.types.Operator):
    """Break the cabinet on both sides of the active bay so the
    active bay becomes its own single-bay cabinet. On a first or
    last bay, only the applicable side breaks. The active bay's
    width is locked so it holds through the recalcs.
    """
    bl_idname = "hb_face_frame.break_cabinet_both"
    bl_label = "Break Both"
    bl_description = (
        "Split the cabinet on both sides of the active bay so it "
        "becomes its own single-bay cabinet"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        bay, root = _find_active_bay_and_root(context)
        if bay is None or root is None:
            return False
        return _bay_count(root) > 1

    def execute(self, context):
        bay, root = _find_active_bay_and_root(context)
        if bay is None or root is None:
            self.report({'ERROR'}, "No active bay")
            return {'CANCELLED'}
        count = _bay_count(root)
        if count <= 1:
            self.report({'WARNING'}, "Cabinet has only one bay")
            return {'CANCELLED'}
        bay_index = bay.face_frame_bay.bay_index
        bay.face_frame_bay.unlock_width = True
        # Break right first so the original keeps the active bay; the
        # subsequent break-left then operates on the modified original.
        # Each break sends its extra width AWAY from the active bay so
        # both outer cabinets absorb exactly one boundary's worth and
        # come out the same size (a balanced split would double up on
        # the left: the right break's left-half share can't land on
        # the locked active bay, and the left break's right half IS
        # the locked bay, pushing its whole share left).
        if bay_index < count - 1:
            if types_face_frame.break_cabinet_at_gap(
                    root, bay_index, shrink_side='RIGHT') is None:
                self.report({'ERROR'}, "Break (right) failed")
                return {'CANCELLED'}
        if bay_index > 0:
            if types_face_frame.break_cabinet_at_gap(
                    root, bay_index - 1, shrink_side='LEFT') is None:
                self.report({'ERROR'}, "Break (left) failed")
                return {'CANCELLED'}
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operator: equalize bay widths across selected cabinets
# ---------------------------------------------------------------------------
class hb_face_frame_OT_equalize_bays(bpy.types.Operator):
    """Make every bay the same width across the selected cabinets.

    One shared bay width is computed from the combined span minus all
    frame wood (end stiles + mid stiles); each cabinet is resized to
    frame + bays and the run re-abutted left to right. Works on a
    single cabinet too (its bays equalize within its current width).
    Intended cleanup after breaking a run apart: any bay widths the
    break sequence locked or skewed come back out equal.

    Picking two or more bays of one cabinet narrows the scope to those
    bays: they split the width they already occupy between them and
    nothing else in the cabinet moves.
    """
    bl_idname = "hb_face_frame.equalize_bays"
    bl_label = "Equalize Bays"
    bl_description = (
        "Resize the selected cabinets so every bay across them is the "
        "same width (cabinets stay abutted; the total run is unchanged). "
        "Select two or more bays of one cabinet to equalize just those"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return types_face_frame.find_cabinet_root(context.active_object) is not None

    def _equalize_picked_bays(self, bays):
        """Split the width the picked bays already occupy evenly between
        them. The cabinet's own width, its stiles and every bay outside
        the selection stay put - the pool is conserved, so unlocked bays
        elsewhere in the cabinet keep their share too.
        """
        total = sum(b.face_frame_bay.width for b in bays)
        share = total / len(bays)
        if share <= 0:
            self.report({'ERROR'}, "Not enough width for the bays")
            return {'CANCELLED'}
        with types_face_frame.suspend_recalc():
            for b in bays:
                bp = b.face_frame_bay
                bp.unlock_width = True
                bp.width = share
        self.report(
            {'INFO'},
            f"Equalized {len(bays)} selected bay(s) at "
            f"{meter_to_inch(share):.2f}\"")
        return {'FINISHED'}

    def execute(self, context):
        # A multi-bay pick out of one cabinet means "make these equal",
        # not "make the whole cabinet equal" - honor the selection.
        picked = []
        picked_names = set()
        for obj in context.selected_objects:
            if (obj.get(types_face_frame.TAG_BAY_CAGE)
                    and obj.name not in picked_names):
                picked_names.add(obj.name)
                picked.append(obj)
        if len(picked) > 1:
            owners = {types_face_frame.find_cabinet_root(b) for b in picked}
            owners.discard(None)
            if len(owners) == 1 and len(picked) < _bay_count(owners.pop()):
                return self._equalize_picked_bays(picked)

        roots = []
        seen = set()
        for obj in context.selected_objects:
            root = types_face_frame.find_cabinet_root(obj)
            if root is None or root.name in seen:
                continue
            seen.add(root.name)
            roots.append(root)
        if not roots:
            self.report({'WARNING'}, "No face frame cabinet selected")
            return {'CANCELLED'}

        # Same run guards as Join: one parent, same Z row, no corner
        # units, abutting along the wall.
        if len({r.parent for r in roots}) > 1:
            self.report({'ERROR'}, "Cabinets must share the same parent")
            return {'CANCELLED'}
        for r in roots:
            if r.face_frame_cabinet.corner_type != 'NONE':
                self.report({'ERROR'}, "Corner cabinets cannot be equalized")
                return {'CANCELLED'}
        roots.sort(key=lambda r: r.location.x)
        eps = 1e-4
        tol = inch(1.0)
        for a, b in zip(roots, roots[1:]):
            if abs(a.matrix_world.translation.z - b.matrix_world.translation.z) > eps:
                self.report({'ERROR'}, "Cabinets must sit at the same Z")
                return {'CANCELLED'}
            if abs(b.location.x - (a.location.x + a.face_frame_cabinet.width)) > tol:
                self.report({'ERROR'},
                            "Cabinets must abut along the wall (no gaps)")
                return {'CANCELLED'}

        total_span = sum(r.face_frame_cabinet.width for r in roots)
        frames = []
        bay_counts = []
        for r in roots:
            p = r.face_frame_cabinet
            n = _bay_count(r)
            if n == 0:
                self.report({'ERROR'}, f"{r.name} has no bays")
                return {'CANCELLED'}
            frames.append(p.left_stile_width + p.right_stile_width
                          + sum(e.width for e in p.mid_stile_widths))
            bay_counts.append(n)
        total_bays = sum(bay_counts)
        bay_width = (total_span - sum(frames)) / total_bays
        if bay_width <= 0:
            self.report({'ERROR'}, "Not enough width for the bays")
            return {'CANCELLED'}

        with types_face_frame.suspend_recalc():
            x = roots[0].location.x
            for r, frame, n in zip(roots, frames, bay_counts):
                # unlock_width=False returns a bay to the recalc
                # redistributor, which hands unlocked bays equal shares
                # of the cabinet width - exactly the shared bay width
                # once the cabinet width is set below.
                for c in r.children:
                    if c.get(types_face_frame.TAG_BAY_CAGE):
                        c.face_frame_bay.unlock_width = False
                r.face_frame_cabinet.width = frame + n * bay_width
                r.location.x = x
                x += r.face_frame_cabinet.width

        self.report(
            {'INFO'},
            f"Equalized {total_bays} bay(s) at "
            f"{meter_to_inch(bay_width):.2f}\" across {len(roots)} cabinet(s)")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operator: equalize opening heights across selected openings
# ---------------------------------------------------------------------------
class hb_face_frame_OT_equalize_opening_heights(bpy.types.Operator):
    """Lock every selected opening's height to the ACTIVE opening's
    height. Works across bays and cabinets -- the right-click companion
    to hand-locking each opening's height in the Openings menu (e.g.
    matching drawer stacks beside a bay whose flush bottom rail eats
    into its openings). Only H-split children carry a height of their
    own: a bay's single root opening follows the bay, and V-split
    children size by width, so both are skipped with a note."""
    bl_idname = "hb_face_frame.equalize_opening_heights"
    bl_label = "Equalize Opening Heights"
    bl_description = (
        "Lock every selected opening's height to the active opening's "
        "height (openings stacked in a horizontal split)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    @staticmethod
    def _is_h_split_child(cage):
        parent = cage.parent
        return (parent is not None
                and hasattr(parent, 'face_frame_split')
                and parent.get('IS_FACE_FRAME_SPLIT_NODE')
                and parent.face_frame_split.axis == 'H')

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get('IS_FACE_FRAME_OPENING_CAGE'))

    def execute(self, context):
        cages = [o for o in context.selected_objects
                 if o.get('IS_FACE_FRAME_OPENING_CAGE')]
        active = context.active_object
        if active is None or not active.get('IS_FACE_FRAME_OPENING_CAGE'):
            self.report({'WARNING'}, "Active object is not an opening")
            return {'CANCELLED'}
        if active not in cages:
            cages.append(active)
        if len(cages) < 2:
            self.report({'WARNING'}, "Select two or more openings")
            return {'CANCELLED'}
        if not self._is_h_split_child(active):
            self.report(
                {'WARNING'},
                "The active opening has no height of its own (only "
                "openings stacked in a horizontal split do)")
            return {'CANCELLED'}
        target = active.face_frame_opening.size
        roots = []
        skipped = 0
        changed = 0
        with types_face_frame.suspend_recalc():
            for cage in cages:
                if not self._is_h_split_child(cage):
                    skipped += 1
                    continue
                fo = cage.face_frame_opening
                fo.unlock_size = True
                fo.size = target
                changed += 1
                root = types_face_frame.find_cabinet_root(cage)
                if root is not None and root not in roots:
                    roots.append(root)
        for root in roots:
            types_face_frame.recalculate_face_frame_cabinet(root)
        msg = (f"Locked {changed} opening(s) at "
               f"{meter_to_inch(target):.2f}\"")
        if skipped:
            msg += f" ({skipped} skipped: no height of their own)"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Selection mode application (highlights matching objects, dims others)
# ---------------------------------------------------------------------------
# Module-level so non-operator callers (the live-preview appliance dialog)
# can re-apply the mode DIRECTLY. Calling the toggle_mode OPERATOR from
# inside another operator's execute registers it (default bl_options is
# REGISTER) and steals the "last redo" slot -- which breaks
# invoke_props_popup live dialogs: their on-edit repeat only fires while
# the popup's own operator is the last redo op, so the popup stops
# re-executing and its property UI falls back to defaults.

# Object-marker tags for cage-level modes
SELECTION_MODE_TAGS = {
    'Cabinets':       types_face_frame.TAG_CABINET_CAGE,
    'Bays':           types_face_frame.TAG_BAY_CAGE,
    'Openings':       'IS_FACE_FRAME_OPENING_CAGE',     # Phase 3c
    'Interiors':      'IS_FACE_FRAME_INTERIOR_PART',    # Phase 3d
    # Applied panel roots also carry TAG_CABINET_CAGE (every cabinet
    # root does); they're discriminated from regular cabinets by the
    # per-side marker that _reconcile_applied_panels stamps on them.
    'Applied Panels': types_face_frame.TAG_APPLIED_PANEL_SIDE,
}


def apply_face_frame_selection_mode(context, root_obj=None):
    """Re-apply the current face-frame selection mode: to ``root_obj``'s
    subtree when given, else every object in the scene. Function form of
    the toggle_mode operator's execute (which delegates here) so recalc-
    style callers can refresh the mode without an operator round-trip."""
    ff_scene = context.scene.hb_face_frame
    mode = ff_scene.face_frame_selection_mode
    # When the master toggle is off, route every object through the
    # "not highlighted" branch by passing a sentinel mode that no
    # _matches_mode case recognizes - keeps all face frame parts in
    # their default render state and hides the cages.
    # Parts mode also takes the off-path so individual parts render
    # at default color rather than the cabinet-color highlight; the
    # mode value is still readable elsewhere for selection scoping.
    if not ff_scene.face_frame_selection_mode_enabled or mode == 'Parts':
        mode = '__off__'
    if root_obj is not None:
        with hb_utils.children_index():
            for obj in [root_obj, *root_obj.children_recursive]:
                _selection_mode_toggle_one(obj, mode)
    else:
        for obj in context.scene.objects:
            _selection_mode_toggle_one(obj, mode)
    quiet_cages.after_mode_applied()


class hb_face_frame_OT_toggle_mode(bpy.types.Operator):
    """Apply visibility/highlighting for the current face frame selection mode.

    Mirrors the frameless toggle_mode operator but scoped to face-frame-tagged
    objects. Iterates scene objects (or the children of search_obj_name), and
    for each object decides whether it matches the active mode. Matching
    objects become solid + selectable; non-matching objects get hidden/dimmed.
    """
    bl_idname = "hb_face_frame.toggle_mode"
    bl_label = "Toggle Face Frame Selection Mode"
    bl_description = "Highlight objects matching the current face frame selection mode"

    search_obj_name: bpy.props.StringProperty(name="Search Object Name", default="")  # type: ignore

    # Kept as a class alias -- external readers reference the mapping here.
    MODE_TAGS = SELECTION_MODE_TAGS

    def execute(self, context):
        root_obj = None
        if self.search_obj_name and self.search_obj_name in bpy.data.objects:
            root_obj = bpy.data.objects[self.search_obj_name]
        apply_face_frame_selection_mode(context, root_obj)
        bpy.ops.object.select_all(action='DESELECT')
        return {'FINISHED'}


def _selection_mode_matches(obj, mode):
    """Return True if obj should be highlighted in the given mode."""
    if mode == 'Face Frame':
        return obj.get('hb_part_role') in types_face_frame.FACE_FRAME_PART_ROLES
    # Drawer boxes join Interiors mode BY ROLE, not by carrying
    # IS_FACE_FRAME_INTERIOR_PART: that tag also routes objects into
    # the dashed hidden-line pass on 2D layout views, where drawer
    # boxes must not draw.
    if (mode == 'Interiors'
            and obj.get('hb_part_role')
            == types_face_frame.PART_ROLE_DRAWER_BOX):
        return True
    if mode == 'Parts':
        if not obj.get('CABINET_PART'):
            return False
        # Conditional parts (corner finish kicks, kick returns,
        # slot-1 mid-divs / partition skins, etc.) are persistent
        # children that the recalc layer marks hide_render=True when
        # currently inactive. Skip those so Parts mode doesn't
        # surface them as zero-geometry phantom selections.
        if obj.hide_render:
            return False
        return True
    if mode == 'Cabinets':
        if obj.get('IS_APPLIANCE'):
            # Appliances live alongside cabinets in the catalog and
            # should highlight together in Cabinets mode.
            return True
        if obj.get(types_face_frame.TAG_PRODUCT_CAGE):
            # Non-cabinet products (e.g. Half Wall) show their cage and
            # are the selection target in Cabinets mode, like appliances.
            return True
        # Applied panels are nested cabinet roots that share
        # TAG_CABINET_CAGE with their host. They get their own
        # Applied Panels mode (reached via the Show Applied Panels
        # operator in the Finished Ends and Backs panel) and are
        # excluded from regular Cabinets mode so the host cabinet
        # cage stays the single selection target there.
        if obj.get(types_face_frame.TAG_APPLIED_PANEL_SIDE):
            return False
    tag = SELECTION_MODE_TAGS.get(mode)
    if tag is None:
        return False
    return tag in obj


def _selection_mode_toggle_one(obj, mode):
    """Apply highlight/dim to a single object."""
    # Skip walls, doors, windows, cutting objects - they are not part of
    # the face frame hierarchy and shouldn't be touched by mode toggling.
    # 2D annotations (dimension text, numbered callouts) parented onto a
    # cabinet are skipped too: they author their own colour and must keep
    # it, otherwise the not-highlighted branch resets them to white and
    # they disappear on layout-view output.
    if any(t in obj for t in ('IS_WALL_BP', 'IS_ENTRY_DOOR_BP',
                              'IS_WINDOW_BP', 'IS_CUTTING_OBJ',
                              'IS_2D_ANNOTATION')):
        return
    # A cabinet group cage is a container the user reaches INTO via a
    # selection mode (Cabinets shows its member cabinet cages, etc.),
    # so whenever a mode is being applied the group cage gets out of
    # the way - hide it. It never matches any MODE_TAGS, and without
    # this it would fall through the cabinet-root guard below
    # (find_cabinet_root is None, not an appliance, not a product
    # cage) and stay visible on top of the member cages. "Select
    # Cabinet Group" re-shows it (hb_face_frame.select_cabinet_group).
    if obj.get('IS_CAGE_GROUP'):
        toggle_cabinet_color(obj, False)
        return
    # Only touch objects that are part of a face frame cabinet,
    # an appliance product, or are generic cabinet parts/cages we
    # know about. Avoids dimming arbitrary scene geometry.
    if (types_face_frame.find_cabinet_root(obj) is None
            and not obj.get('IS_APPLIANCE')
            and not obj.get(types_face_frame.TAG_PRODUCT_CAGE)):
        return

    # dont_show_parent=False: the frameless toggle_cabinet_color
    # suppresses a parent whenever any descendant shares the same
    # type tag. Applied panel roots always carry TAG_CABINET_CAGE,
    # which would re-hide the host cabinet cage in Cabinets mode
    # even after _matches_mode correctly excludes the panel itself.
    # _matches_mode already does the conceptual filtering here.
    if _selection_mode_matches(obj, mode):
        # Material Preview / Rendered: a cage the mode offers stays
        # hidden unless it is selected (see quiet_cages).
        if quiet_cages.keep_hidden(obj, mode):
            toggle_cabinet_color(obj, False,
                                 type_name=SELECTION_MODE_TAGS.get(mode, ''))
            return
        toggle_cabinet_color(obj, True, type_name=SELECTION_MODE_TAGS.get(mode, ''),
                             dont_show_parent=False)
        # In Face Frame mode, recolour parts the user has unlocked so
        # changed-from-default parts stand out from the light-blue highlight.
        if (mode == 'Face Frame'
                and types_face_frame.part_width_is_unlocked(obj)):
            obj.color = types_face_frame.FACE_FRAME_UNLOCKED_COLOR
    else:
        toggle_cabinet_color(obj, False, type_name=SELECTION_MODE_TAGS.get(mode, ''))


# ---------------------------------------------------------------------------
# Operator: wood top options popup (right-click -> Wood Top Options)
# ---------------------------------------------------------------------------
class hb_face_frame_OT_wood_top_prompts(bpy.types.Operator):
    """Options dialog for a Wood Top (countertop part).

    Construction label, slab thickness, and the four overhangs. The
    overhangs refit the top from the cabinet it is parented to (the one
    placement seated it on); a free-standing top edits its width and
    depth directly instead. All rows are live-bound props, so edits
    apply as they're made and OK just closes the dialog.
    """
    bl_idname = "hb_face_frame.wood_top_prompts"
    bl_label = "Wood Top Options"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get(types_face_frame.WOOD_TOP_TAG))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        if obj is None or not obj.get(types_face_frame.WOOD_TOP_TAG):
            layout.label(text="No wood top selected", icon='INFO')
            return
        wt = obj.wood_top
        col = layout.column(align=True)
        col.use_property_split = True
        col.use_property_decorate = False
        col.prop(wt, 'top_type')
        col.prop(wt, 'thickness')
        col.separator()
        # Applied edge: the top splits into a core board plus a separate
        # edge band. Off while a milled nosing is set - both work the
        # same edges.
        edge_col = col.column(align=True)
        edge_col.use_property_split = True
        edge_col.enabled = wt.nosing_style == 'NONE'
        edge_col.prop(wt, 'edge_type')
        if wt.edge_type != 'NONE':
            edge_col.prop(wt, 'edge_thickness')
            row = edge_col.row(align=True)
            row.label(text="Edge Sides:")
            row = edge_col.row(align=True)
            row.prop(wt, 'edge_front', text="Front", toggle=True)
            row.prop(wt, 'edge_back', text="Back", toggle=True)
            row.prop(wt, 'edge_left', text="Left", toggle=True)
            row.prop(wt, 'edge_right', text="Right", toggle=True)
        col.separator()
        # Nosing: edge profile from the shelf-nosing set; the
        # extra-height styles take a height of their own. Side toggles
        # pick which edges are milled (exposed sides, not walls).
        nose_col = col.column(align=True)
        nose_col.use_property_split = True
        nose_col.enabled = wt.edge_type == 'NONE'
        nose_col.prop(wt, 'nosing_style')
        if wt.nosing_style != 'NONE':
            if wt.nosing_style in types_face_frame.shelf_nosing.EXTRA_HEIGHT_STYLES:
                nose_col.prop(wt, 'nosing_height')
            row = nose_col.row(align=True)
            row.label(text="Nosing Sides:")
            row = nose_col.row(align=True)
            row.prop(wt, 'nosing_front', text="Front", toggle=True)
            row.prop(wt, 'nosing_back', text="Back", toggle=True)
            row.prop(wt, 'nosing_left', text="Left", toggle=True)
            row.prop(wt, 'nosing_right', text="Right", toggle=True)
        col.separator()
        anchor = obj.parent
        anchored = (anchor is not None
                    and bool(anchor.get(types_face_frame.TAG_CABINET_CAGE)))
        if anchored:
            col.label(text=f"Overhangs from {anchor.name}:")
            col.prop(wt, 'overhang_front')
            col.prop(wt, 'overhang_back')
            col.prop(wt, 'overhang_left')
            col.prop(wt, 'overhang_right')
        else:
            col.prop(wt, 'width')
            col.prop(wt, 'depth')


# ---------------------------------------------------------------------------
# Operator: cabinet prompts popup (right-click -> Cabinet Prompts)
# ---------------------------------------------------------------------------
class hb_face_frame_OT_cabinet_prompts(bpy.types.Operator):
    """Open the cabinet-wide properties dialog.

    Tabbed: General (dimensions), Construction (material / toe kick /
    stretchers), Face Frame (stile / rail / overlay defaults). Only
    cabinet-wide settings here - per-bay editing goes through
    hb_face_frame.bay_prompts; per-mid-stile editing through
    hb_face_frame.mid_stile_prompts.
    """
    bl_idname = "hb_face_frame.cabinet_prompts"
    bl_label = "Cabinet Properties"
    bl_description = "Edit cabinet-wide properties (dimensions, construction, face frame defaults)"
    bl_options = {'UNDO'}

    # Tab state lives on the operator instance so it persists across
    # the dialog's draw calls. Default lands on General each open.
    active_tab: bpy.props.EnumProperty(
        name="Tab",
        items=[
            ('GENERAL',      "General",      "Dimensions"),
            ('CONSTRUCTION', "Construction", "Material, toe kick, stretchers"),
            ('FACE_FRAME',   "Face Frame",   "Frame thickness, stiles, rails, default overlays"),
        ],
        default='GENERAL',
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        return types_face_frame.find_cabinet_root(context.active_object) is not None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.layout.label(text="No face frame cabinet selected", icon='INFO')
            return
        layout = self.layout
        cab_props = root.face_frame_cabinet

        ui_face_frame.draw_identity(layout, root)
        layout.separator()

        # Tab strip - expand=True renders the enum as a row of toggle
        # buttons rather than a dropdown.
        row = layout.row()
        row.prop(self, 'active_tab', expand=True)
        layout.separator()

        if self.active_tab == 'GENERAL':
            ui_face_frame.draw_dimensions(layout, root)
            # Bay section sits under cabinet dimensions on the same tab.
            # Single-bay collapses to a one-line size readout (cabinet
            # dims above are the editor); multi-bay gets a compact box
            # per bay with editable size + an expand toggle for more.
            ui_face_frame.draw_bays_in_prompts(layout, root)
            # Applied panels: the shared layout block (auto-openings
            # toggle, column + row overrides, per-row heights, X frame).
            # The overrides only apply while Auto Openings is on -- a
            # pinned panel keeps whatever tree the user built by hand.
            if (root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
                    or types_face_frame._is_standalone_panel(root)):
                ui_face_frame.draw_panel_layout(layout, root)
        elif self.active_tab == 'CONSTRUCTION':
            ui_face_frame.draw_construction(layout, cab_props)
            # Refrigerator opening height + per-side raise (self-gated
            # to refrigerator cabinets); root carries the CLASS_NAME.
            ui_face_frame.draw_refrigerator_options(layout, root)
            # Accessible sink apron (self-gated to that product).
            ui_face_frame.draw_ada_sink_options(layout, root)
        elif self.active_tab == 'FACE_FRAME':
            ui_face_frame.draw_face_frame_defaults(layout, cab_props)


def _owning_panel_root(obj):
    """The applied / standalone panel root that owns ``obj`` (which may
    be the root itself or any of its parts), or None."""
    root = types_face_frame.find_cabinet_root(obj)
    if root is None:
        return None
    if (root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
            or types_face_frame._is_standalone_panel(root)):
        return root
    return None


class hb_face_frame_OT_panel_layout_prompts(bpy.types.Operator):
    """Edit an applied panel's layout: columns, rows and row heights.
    Reachable from the right-click menu of any of the panel's parts."""
    bl_idname = "hb_face_frame.panel_layout_prompts"
    bl_label = "Panel Layout"
    bl_description = ("Edit this panel's openings: columns, rows and "
                      "row heights")
    bl_options = {'UNDO'}

    # The panel root is resolved ONCE at invoke and held by name: the
    # clicked part (e.g. a mid rail the edit removes) can die in a
    # rebuild mid-dialog, and the active object with it - the root
    # itself survives every rebuild.
    panel_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore

    @classmethod
    def poll(cls, context):
        return _owning_panel_root(context.active_object) is not None

    def invoke(self, context, event):
        root = _owning_panel_root(context.active_object)
        if root is None:
            self.report({'WARNING'}, "Select a panel part first")
            return {'CANCELLED'}
        self.panel_name = root.name
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        root = bpy.data.objects.get(self.panel_name)
        if root is None:
            root = _owning_panel_root(context.active_object)
        if root is None:
            self.layout.label(text="No panel selected", icon='INFO')
            return
        ui_face_frame.draw_identity(self.layout, root)
        self.layout.separator()
        ui_face_frame.draw_panel_layout(self.layout, root)


# ---------------------------------------------------------------------------
# Drawer Interior editor: one dialog to lay out everything inside a drawer.
# A list box of the drawer's accessories with add / delete, and the selected
# item's settings (quantity, orientation, position) below it, so multiple
# accessories can be positioned without leaving the dialog. HB5 ships no
# catalog - the add dropdown is filled from the accessory_registry providers
# (drawer host), like every other accessory surface.
# ---------------------------------------------------------------------------
class AccessorySearchRow(bpy.types.PropertyGroup):
    """One result row in an accessory search list."""
    code: bpy.props.StringProperty()  # type: ignore
    label: bpy.props.StringProperty()  # type: ignore
    name: bpy.props.StringProperty()  # type: ignore
    section: bpy.props.StringProperty()  # type: ignore
    group: bpy.props.StringProperty()  # type: ignore
    # Non-empty when the accessory builds geometry, so a search row can
    # say up front whether picking it will show anything in the drawer.
    render_kind: bpy.props.StringProperty()  # type: ignore


def _populate_drawer_accessory_search(operator, context):
    """Fill ``operator.matches`` with the host application's drawer
    accessories, ordered by group then name and narrowed by
    ``operator.filter_text``. The filter is split into space-separated
    tokens; every token must appear (case-insensitively) in the item's
    name, group or code, so "knife dbl" or "kbwd" both land on the
    double tier block."""
    operator.matches.clear()
    tokens = operator.filter_text.lower().split()
    found = []
    for it in accessory_registry.all_items():
        if it.get('host') != 'drawer_accessory':
            continue
        code = it.get('code')
        if not code:
            continue
        name = it.get('name', code)
        group = it.get('group', '')
        if tokens:
            hay = (" ".join((name, group, code))).lower()
            if not all(tok in hay for tok in tokens):
                continue
        found.append((group.lower(), name.lower(), code, name, group,
                      it.get('render') or ''))
    for _g, _n, code, name, group, render in sorted(found):
        row = operator.matches.add()
        row.code = code
        row.name = name
        row.label = name
        row.group = group
        row.render_kind = types_face_frame.render_hint_kind(render.upper())
    operator.match_index = min(operator.match_index,
                               max(0, len(operator.matches) - 1))


class HB_UL_face_frame_drawer_catalog(bpy.types.UIList):
    """Search results for the drawer's Add list: the accessory, its
    product code, and the group it belongs to. The code earns its
    column - two different products can carry the same name, and it is
    what gets quoted. Items that build real geometry are flagged so it
    is obvious which ones will show up inside the drawer."""

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname):
        split = layout.split(factor=0.52)
        split.label(text=item.label,
                    icon='MESH_GRID' if item.render_kind else 'DOT')
        sub = split.split(factor=0.28)
        sub.label(text=item.code)
        sub.label(text=item.group)


class HB_UL_face_frame_drawer_items(bpy.types.UIList):
    """The drawer's accessories: label on the left, quantity on the
    right. Non-accessory interior kinds are filtered out - this list is
    about what goes INSIDE the drawer box."""

    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname):
        split = layout.split(factor=0.75)
        split.label(text=item.accessory_label or item.accessory_code,
                    icon='SNAP_VERTEX')
        qty = getattr(item, 'accessory_qty', 1)
        split.label(text=("x%d" % qty) if qty > 1 else "")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        flt = [self.bitflag_filter_item if it.kind == 'ACCESSORY' else 0
               for it in items]
        return flt, []


# ---------------------------------------------------------------------------
# Drawer box construction: which box system a drawer / rollout is built
# from. HB5 ships no list - the host application supplies the options
# through the accessory registry, same as every other catalog-backed
# surface. The pick lives on the owning opening (boxes are wiped and
# rebuilt every recalc); blank = the project default.
# ---------------------------------------------------------------------------
DRAWER_BOX_CONSTRUCTION_HOST = 'drawer_box_construction'
DRAWER_BOX_CONSTRUCTION_DEFAULT = 'DEFAULT'
# Slides ride the same registry shape: the host supplies the options
# (host 'drawer_slides'), the pick lives on the owning opening as pure
# spec metadata for the odd heavy duty drawer.
DRAWER_SLIDES_HOST = 'drawer_slides'

_drawer_box_construction_items = []
_drawer_slides_items = []


def _opening_overlay_bucket(opening):
    """The door-overlay bucket of the cabinet style governing an opening
    (walk up to the cage, resolve STYLE_NAME), or None when unresolvable."""
    if opening is None:
        return None
    cur = opening
    while cur is not None:
        if cur.get('IS_FACE_FRAME_CABINET_CAGE'):
            style_name = cur.get('STYLE_NAME')
            if style_name:
                ff = props_hb_face_frame.get_style_props()
                for cs in ff.cabinet_styles:
                    if cs.name == style_name:
                        return cs.door_overlay_type
            return None
        cur = cur.parent
    return None


def drawer_box_construction_options(overlay=None):
    """(code, name) for every box construction the host provides. Items may
    declare overlays they are not offered for (excluded_overlays); those are
    dropped when the caller passes the governing overlay bucket."""
    out = []
    for it in accessory_registry.get_items(DRAWER_BOX_CONSTRUCTION_HOST):
        if overlay and overlay in (it.get('excluded_overlays') or ()):
            continue
        code = it.get('code')
        if code:
            out.append((code, it.get('name', code)))
    return out


def drawer_box_construction_label(code):
    """Display name for a construction code, falling back to the code."""
    entry = accessory_registry.lookup(
        DRAWER_BOX_CONSTRUCTION_HOST, code) or {}
    return entry.get('name', code)


def _drawer_box_construction_enum(self, context):
    """Project Default plus every construction the host provides for the
    opening's overlay."""
    overlay = _opening_overlay_bucket(
        bpy.data.objects.get(getattr(self, 'opening_name', '') or ''))
    _drawer_box_construction_items.clear()
    _drawer_box_construction_items.append(
        (DRAWER_BOX_CONSTRUCTION_DEFAULT, "Project Default",
         "Build these boxes to the project's default construction"))
    for code, name in drawer_box_construction_options(overlay):
        _drawer_box_construction_items.append((code, name, ""))
    return _drawer_box_construction_items


def _set_opening_construction(opening, code):
    """Write a construction pick (code, '' = default) plus its cached
    label onto an opening. The code prop's update runs the rebuild."""
    props = opening.face_frame_opening
    if code == DRAWER_BOX_CONSTRUCTION_DEFAULT:
        code = ''
    if (props.drawer_box_construction or '') == code:
        return False
    props.drawer_box_construction_label = (
        drawer_box_construction_label(code) if code else '')
    props.drawer_box_construction = code
    return True


def drawer_slides_options():
    """(code, name) for every slide option the host provides."""
    out = []
    for it in accessory_registry.get_items(DRAWER_SLIDES_HOST):
        code = it.get('code')
        if code:
            out.append((code, it.get('name', code)))
    return out


def drawer_slides_label(code):
    """Display name for a slide code, falling back to the code."""
    entry = accessory_registry.lookup(DRAWER_SLIDES_HOST, code) or {}
    return entry.get('name', code)


def _drawer_slides_enum(self, context):
    """Project Default plus every slide option the host provides."""
    _drawer_slides_items.clear()
    _drawer_slides_items.append(
        (DRAWER_BOX_CONSTRUCTION_DEFAULT, "Project Default",
         "Use the project's slide selection for these drawers"))
    for code, name in drawer_slides_options():
        _drawer_slides_items.append((code, name, ""))
    return _drawer_slides_items


def _set_opening_slides(opening, code):
    """Write a slide pick (code, '' = default) plus its cached label
    onto an opening."""
    props = opening.face_frame_opening
    if code == DRAWER_BOX_CONSTRUCTION_DEFAULT:
        code = ''
    if (props.drawer_slides or '') == code:
        return False
    props.drawer_slides_label = (
        drawer_slides_label(code) if code else '')
    props.drawer_slides = code
    return True


class hb_face_frame_OT_set_drawer_box_construction(bpy.types.Operator):
    """Build the clicked drawer's / rollout's boxes to the chosen
    construction. Stored on the owning opening, so it survives the
    rebuild that wipes the boxes themselves."""
    bl_idname = "hb_face_frame.set_drawer_box_construction"
    bl_label = "Set Drawer Box Construction"
    bl_description = ("Build this opening's drawer boxes with the chosen "
                      "construction")
    bl_options = {'UNDO', 'INTERNAL'}

    code: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    opening_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore

    def execute(self, context):
        opening = (bpy.data.objects.get(self.opening_name)
                   if self.opening_name
                   else _find_owning_opening(context.active_object))
        if opening is None:
            self.report({'WARNING'}, "No opening selected")
            return {'CANCELLED'}
        _set_opening_construction(opening, self.code)
        return {'FINISHED'}


class hb_face_frame_OT_set_drawer_slides(bpy.types.Operator):
    """Run the clicked drawer's / rollout's boxes on the chosen slide
    hardware. Stored on the owning opening, so it survives the rebuild
    that wipes the boxes themselves."""
    bl_idname = "hb_face_frame.set_drawer_slides"
    bl_label = "Set Drawer Slides"
    bl_description = "Run this opening's drawers on the chosen slides"
    bl_options = {'UNDO', 'INTERNAL'}

    code: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    opening_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore

    def execute(self, context):
        opening = (bpy.data.objects.get(self.opening_name)
                   if self.opening_name
                   else _find_owning_opening(context.active_object))
        if opening is None:
            self.report({'WARNING'}, "No opening selected")
            return {'CANCELLED'}
        _set_opening_slides(opening, self.code)
        return {'FINISHED'}


def _drawer_opening_for(obj):
    """The opening cage owning ``obj`` when it carries a drawer-style
    front (drawer box, front, divider, or the cage itself)."""
    opening = _find_owning_opening(obj)
    if opening is None:
        return None
    front = opening.face_frame_opening.front_type
    if front in ('DRAWER_FRONT', 'PULLOUT', 'TILT_OUT'):
        return opening
    return None


class hb_face_frame_OT_drawer_add_accessory(bpy.types.Operator):
    """Append the chosen accessory to this drawer's item list."""
    bl_idname = "hb_face_frame.drawer_add_accessory"
    bl_label = "Add"
    bl_description = "Add this accessory to the drawer"
    bl_options = {'UNDO', 'INTERNAL'}

    opening_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    code: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore

    def execute(self, context):
        opening = bpy.data.objects.get(self.opening_name)
        if opening is None or not self.code or self.code == 'NONE':
            return {'CANCELLED'}
        entry = accessory_registry.find(self.code) or {}
        props = opening.face_frame_opening
        item = props.interior_items.add()
        item.kind = 'ACCESSORY'
        item.accessory_label = entry.get('name', self.code)
        item.accessory_code = self.code
        item.accessory_render = (entry.get('render') or '').upper()
        props.interior_items_index = len(props.interior_items) - 1
        root = types_face_frame.find_cabinet_root(opening)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


class hb_face_frame_OT_drawer_remove_accessory(bpy.types.Operator):
    """Remove the selected accessory from this drawer."""
    bl_idname = "hb_face_frame.drawer_remove_accessory"
    bl_label = "Remove"
    bl_description = "Remove the selected accessory from the drawer"
    bl_options = {'UNDO', 'INTERNAL'}

    opening_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore

    def execute(self, context):
        opening = bpy.data.objects.get(self.opening_name)
        if opening is None:
            return {'CANCELLED'}
        props = opening.face_frame_opening
        idx = props.interior_items_index
        if not (0 <= idx < len(props.interior_items)):
            return {'CANCELLED'}
        props.interior_items.remove(idx)
        props.interior_items_index = min(idx,
                                         len(props.interior_items) - 1)
        root = types_face_frame.find_cabinet_root(opening)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


def _update_drawer_interior_construction(self, context):
    """Live-bind the dialog's construction dropdown to the opening. The
    no-op guard in _set_opening_construction keeps seeding the enum on
    invoke from triggering a pointless rebuild."""
    opening = bpy.data.objects.get(self.opening_name)
    if opening is not None:
        _set_opening_construction(opening, self.construction)


def _update_drawer_interior_slides(self, context):
    """Live-bind the dialog's slides dropdown to the opening; same
    no-op-guard seeding contract as the construction dropdown."""
    opening = bpy.data.objects.get(self.opening_name)
    if opening is not None:
        _set_opening_slides(opening, self.slides)


class hb_face_frame_OT_drawer_interior(bpy.types.Operator):
    """Lay out the inside of a drawer: add, remove and position the
    accessories that live in the drawer box."""
    bl_idname = "hb_face_frame.drawer_interior"
    bl_label = "Drawer Interior"
    bl_description = ("Design the inside of this drawer: add accessories "
                      "and position them")
    bl_options = {'UNDO'}

    # Held by name so rebuilds (every accessory edit wipes and respawns
    # the drawer box and its contents) can't blank the dialog.
    opening_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    filter_text: bpy.props.StringProperty(
        name="Search",
        description="Filter the accessory list by name, group or code",
        options={'TEXTEDIT_UPDATE'},
        update=lambda self, ctx: _populate_drawer_accessory_search(self, ctx),
    )  # type: ignore
    matches: bpy.props.CollectionProperty(type=AccessorySearchRow)  # type: ignore
    match_index: bpy.props.IntProperty(default=0)  # type: ignore
    construction: bpy.props.EnumProperty(
        name="Box Construction", items=_drawer_box_construction_enum,
        description="Construction this drawer's box is built to",
        update=_update_drawer_interior_construction,
    )  # type: ignore
    slides: bpy.props.EnumProperty(
        name="Slides", items=_drawer_slides_enum,
        description="Slide hardware this drawer runs on",
        update=_update_drawer_interior_slides,
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        return _drawer_opening_for(context.active_object) is not None

    def invoke(self, context, event):
        opening = _drawer_opening_for(context.active_object)
        if opening is None:
            self.report({'WARNING'}, "Select a drawer first")
            return {'CANCELLED'}
        self.opening_name = opening.name
        # Open the drawer so the user can see what they're laying out.
        op_props = opening.face_frame_opening
        if op_props.swing_percent < 0.5:
            op_props.swing_percent = 1.0
        # Seed the construction dropdown from the opening. A code the
        # host no longer offers isn't in the enum - leave the dropdown
        # on Project Default rather than raising; the stored pick is
        # untouched unless the user picks something.
        code = op_props.drawer_box_construction or ''
        try:
            self.construction = code or DRAWER_BOX_CONSTRUCTION_DEFAULT
        except TypeError:
            pass
        slide_code = op_props.drawer_slides or ''
        try:
            self.slides = slide_code or DRAWER_BOX_CONSTRUCTION_DEFAULT
        except TypeError:
            pass
        self.filter_text = ""
        self.match_index = 0
        _populate_drawer_accessory_search(self, context)
        return context.window_manager.invoke_props_dialog(self, width=520)

    def check(self, context):
        # Any edit in the dialog re-runs the filter and forces a redraw,
        # so the list follows the search box keystroke by keystroke.
        _populate_drawer_accessory_search(self, context)
        return True

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        opening = bpy.data.objects.get(self.opening_name)
        if opening is None:
            layout.label(text="No drawer selected", icon='INFO')
            return
        props = opening.face_frame_opening

        # Box construction / slides sit above the accessory list:
        # they're properties of the box itself, not of what goes in
        # it. Each hidden when the host application offers no options.
        has_construction = bool(drawer_box_construction_options())
        has_slides = bool(drawer_slides_options())
        if has_construction:
            layout.prop(self, 'construction')
        if has_slides:
            layout.prop(self, 'slides')
        if has_construction or has_slides:
            layout.separator()

        # Pick from the catalog: type to narrow, highlight, Add. The
        # list is grouped the way the product data groups it, so
        # browsing works as well as searching.
        pick = layout.box()
        pick.label(text="Add an accessory", icon='ADD')
        pick.prop(self, 'filter_text', text="", icon='VIEWZOOM')
        if len(self.matches) == 0:
            pick.label(text="Nothing matches that search", icon='INFO')
        else:
            row = pick.row()
            row.template_list(
                "HB_UL_face_frame_drawer_catalog", "",
                self, "matches",
                self, "match_index",
                rows=6,
            )
            side = row.column(align=True)
            add = side.operator("hb_face_frame.drawer_add_accessory",
                                text="", icon='ADD')
            add.opening_name = self.opening_name
            idx = max(0, min(self.match_index, len(self.matches) - 1))
            add.code = self.matches[idx].code
            note = pick.row()
            note.enabled = False
            note.label(text="Marked accessories are drawn in the drawer; "
                            "the rest are listed only", icon='MESH_GRID')

        layout.separator()
        layout.label(text="In this drawer")
        row = layout.row()
        row.template_list(
            "HB_UL_face_frame_drawer_items", "",
            props, "interior_items",
            props, "interior_items_index",
            rows=4,
        )
        side = row.column(align=True)
        rem = side.operator("hb_face_frame.drawer_remove_accessory",
                            text="", icon='REMOVE')
        rem.opening_name = self.opening_name

        idx = props.interior_items_index
        if not (0 <= idx < len(props.interior_items)):
            layout.label(text="Add an accessory to get started", icon='INFO')
            return
        item = props.interior_items[idx]
        if item.kind != 'ACCESSORY':
            return
        from .. import ui_face_frame
        box = layout.box()
        box.label(text=item.accessory_label or item.accessory_code)
        box.prop(item, 'accessory_qty', text="Quantity")
        ui_face_frame.draw_drawer_insert_settings(box, item)


class hb_face_frame_OT_toggle_front_open(bpy.types.Operator):
    """Open or close the door / drawer the clicked part belongs to.
    Right-click companion to Open Door Mode - resolves the owning
    opening from any descendant (front, drawer box, divider, pull) and
    flips its swing."""
    bl_idname = "hb_face_frame.toggle_front_open"
    bl_label = "Open / Close"
    bl_description = "Open or close this door / drawer"
    bl_options = {'UNDO'}

    @classmethod
    def _owning_opening(cls, obj):
        cur = obj
        while cur is not None:
            if cur.get(types_face_frame.TAG_OPENING_CAGE):
                return cur
            cur = cur.parent
        return None

    @classmethod
    def poll(cls, context):
        opening = cls._owning_opening(context.active_object)
        if opening is None:
            return False
        return opening.face_frame_opening.front_type in (
            'DOOR', 'DRAWER_FRONT', 'PULLOUT', 'TILT_OUT')

    def execute(self, context):
        opening = self._owning_opening(context.active_object)
        if opening is None:
            return {'CANCELLED'}
        op_props = opening.face_frame_opening
        # The prop's update runs the recalc that moves the front.
        op_props.swing_percent = (
            0.0 if op_props.swing_percent > 0.5 else 1.0)
        return {'FINISHED'}


class hb_face_frame_OT_panel_remove_stile(bpy.types.Operator):
    """Merge a panel's columns into one opening (remove the mid
    stile). Shortcut for Columns = 1 with Auto Openings on."""
    bl_idname = "hb_face_frame.panel_remove_stile"
    bl_label = "Remove Stile (Merge Openings)"
    bl_description = ("Merge this panel's side-by-side openings into "
                      "one full-width opening per row")
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return _owning_panel_root(context.active_object) is not None

    def execute(self, context):
        root = _owning_panel_root(context.active_object)
        if root is None:
            return {'CANCELLED'}
        cab = root.face_frame_cabinet
        # Order matters: the auto flag's update re-runs the split, so
        # set the count first and let the toggle's rebuild see it. If
        # auto is already on, the count write rebuilds by itself.
        cab.panel_vertical_bays = 1
        if not cab.panel_split_auto:
            cab.panel_split_auto = True
        return {'FINISHED'}


# Maximum count of openings the split dialog can produce in one shot.
# Bounded by the FloatVectorProperty / BoolVectorProperty fixed sizes
# below; raise both if more is needed.
MAX_SPLIT_OPENINGS = 8


class hb_face_frame_OT_split_opening(bpy.types.Operator):
    """Subdivide an opening with N-1 horizontal or vertical splitters,
    producing `count` total openings inside one new split node.

    Inserts a new split-node Empty between the active opening and its
    current parent (bay or another split node). The active opening is
    moved under the split node as the LAST child; (count - 1) fresh
    openings are inserted before it.

    Convention: original is at the highest child index (bottom for
    H-split, right for V-split); new openings fill the lower indices
    (top for H-split, left for V-split). Drawer-on-top-of-door is the
    canonical use case with count = 2.

    Per-opening size + unlock can be set in the dialog: unlocked
    openings hold their typed size during recalc, locked (the default)
    share evenly. The mid rail / mid stile width for THIS split is
    also configurable; it overrides the cabinet-level default for
    this split only.
    """
    bl_idname = "hb_face_frame.split_opening"
    bl_label = "Split Opening"
    bl_description = (
        "Divide the selected opening into stacked or side-by-side "
        "openings (for example, a drawer above a door). A dialog lets "
        "you set how many openings to create and the size of each one"
    )
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(
        name="Axis",
        items=[
            ('H', "Horizontal", "Add mid rails; new openings above, original below"),
            ('V', "Vertical",   "Add mid stiles; new openings on the left, original on the right"),
        ],
        default='H',
        update=split_preview.tag_redraw,
    )  # type: ignore
    count: bpy.props.IntProperty(
        name="Openings",
        description="Total number of openings the split should produce (including the original)",
        default=2, min=2, max=MAX_SPLIT_OPENINGS,
        update=split_preview.tag_redraw,
    )  # type: ignore
    mid_rail_width: bpy.props.FloatProperty(
        name="Mid Rail Width",
        description="Width of mid rails for this split (H-axis only)",
        default=inch(1.5), unit='LENGTH', precision=4,
        update=split_preview.tag_redraw,
    )  # type: ignore
    mid_stile_width: bpy.props.FloatProperty(
        name="Mid Stile Width",
        description="Width of mid stiles for this split (V-axis only)",
        default=inch(2.0), unit='LENGTH', precision=4,
        update=split_preview.tag_redraw,
    )  # type: ignore
    add_backing: bpy.props.BoolProperty(
        name="Add Backing",
        description="Add a carcass shelf (H-split) or division (V-split) behind each splitter",
        default=True,
    )  # type: ignore
    sizes: bpy.props.FloatVectorProperty(
        name="Sizes",
        description="Per-opening size (used only when the matching unlock flag is on)",
        size=MAX_SPLIT_OPENINGS,
        default=(0.0,) * MAX_SPLIT_OPENINGS,
        unit='LENGTH', precision=4,
        update=split_preview.tag_redraw,
    )  # type: ignore
    unlocks: bpy.props.BoolVectorProperty(
        name="Unlocks",
        description="When on, the opening's size is held at the typed value during redistribution",
        size=MAX_SPLIT_OPENINGS,
        default=(False,) * MAX_SPLIT_OPENINGS,
        update=split_preview.tag_redraw,
    )  # type: ignore
    # Per-opening contents (front type). No EnumVectorProperty exists, so
    # one enum per slot; slot i maps to opening i, the original takes the
    # last slot (count - 1), mirroring `sizes` / `unlocks`.
    front_type_0: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore
    front_type_1: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore
    front_type_2: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore
    front_type_3: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore
    front_type_4: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore
    front_type_5: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore
    front_type_6: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore
    front_type_7: bpy.props.EnumProperty(
        name="Contents", items=props_hb_face_frame.FRONT_TYPE_ITEMS,
        default='NONE',
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # view_layer.objects.active, not context.active_object: in
        # Bay selection mode the opening cages are hidden, and a
        # hidden active object resolves to None through
        # context.active_object in the 3D-view context (notably
        # when this operator's dialog is confirmed).
        # view_layer.objects.active holds the cage in either mode.
        obj = context.view_layer.objects.active
        return (obj is not None
                and obj.get(types_face_frame.TAG_OPENING_CAGE))

    def invoke(self, context, event):
        # Initialize axis-specific defaults from the cabinet so the
        # dialog opens with sensible starting values rather than the
        # operator's hard-coded class defaults.
        root = types_face_frame.find_cabinet_root(
            context.view_layer.objects.active)
        if root is not None:
            cab_props = root.face_frame_cabinet
            self.mid_rail_width = cab_props.bay_mid_rail_width
            self.mid_stile_width = cab_props.bay_mid_stile_width
        # Reset per-opening fields so previous invocations don't leak in
        zeros = (0.0,) * MAX_SPLIT_OPENINGS
        falses = (False,) * MAX_SPLIT_OPENINGS
        self.sizes = zeros
        self.unlocks = falses
        opening = context.view_layer.objects.active
        # Default per-opening contents to the existing behavior: new
        # openings get the root's default front, the original (last slot)
        # keeps its current front_type -- so an untouched dialog produces
        # an identical result to before this field existed.
        default_front = types_face_frame.default_front_type_for_root(root)
        orig_front = (opening.face_frame_opening.front_type
                      if opening is not None else 'NONE')
        for i in range(MAX_SPLIT_OPENINGS):
            setattr(self, f'front_type_{i}', default_front)
        setattr(self, f'front_type_{self.count - 1}', orig_front)
        split_preview.add_preview(self, opening.name if opening else "")
        return context.window_manager.invoke_props_dialog(self, width=420)

    def cancel(self, context):
        # Drop the preview overlay when the dialog is dismissed
        # without confirming (Esc / click-away).
        split_preview.remove_preview()

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'axis', expand=True)
        layout.prop(self, 'count')
        if self.axis == 'H':
            layout.prop(self, 'mid_rail_width')
            layout.prop(self, 'add_backing', text="Add Shelf Behind Mid Rail")
            first_label, last_label = 'Top', 'Bottom'
        else:
            layout.prop(self, 'mid_stile_width')
            layout.prop(self, 'add_backing', text="Add Division Behind Mid Stile")
            first_label, last_label = 'Left', 'Right'

        layout.separator()
        layout.label(text="Opening Sizes & Contents")
        for i in range(self.count):
            if i == 0:
                label = first_label
            elif i == self.count - 1:
                label = last_label
            else:
                label = f"#{i + 1}"
            row = layout.row(align=True)
            field = row.row(align=True)
            field.enabled = self.unlocks[i]
            field.prop(self, 'sizes', index=i, text=label)
            lock_icon = 'UNLOCKED' if self.unlocks[i] else 'LOCKED'
            row.prop(self, 'unlocks', index=i, text="", icon=lock_icon)
            row.prop(self, f'front_type_{i}', text="")

    def execute(self, context):
        split_preview.remove_preview()
        original = context.view_layer.objects.active
        root = types_face_frame.find_cabinet_root(original)
        if root is None:
            self.report({'WARNING'}, "Active opening is not in a face frame cabinet")
            return {'CANCELLED'}

        with types_face_frame.suspend_recalc():
            old_parent = original.parent
            old_index = original.get('hb_split_child_index', 0)

            # Snapshot original's current size + unlock for handing to the
            # split node (which will now occupy original's slot in the
            # parent tree).
            op_props = original.face_frame_opening
            inherited_size = op_props.size
            inherited_unlock = op_props.unlock_size
            # SIZE_ROLE describes the SLOT, not the opening: it says how
            # this position in the parent tree is sized. The split node
            # takes the slot over, so the stamp moves with it. Left on
            # the original, a later re-sync would push a height onto a
            # node whose size now means something else entirely (a width,
            # under a V-split) and unbalance its new siblings.
            inherited_role = original.get('SIZE_ROLE')

            # Create split node empty
            split_obj = hb_utils.new_object('Split Node', None)
            bpy.context.scene.collection.objects.link(split_obj)
            split_obj.empty_display_type = 'PLAIN_AXES'
            split_obj.empty_display_size = 0.001
            split_obj[types_face_frame.TAG_SPLIT_NODE] = True
            split_obj.parent = old_parent
            split_obj['hb_split_child_index'] = old_index
            sp = split_obj.face_frame_split
            sp.axis = self.axis
            sp.size = inherited_size
            sp.unlock_size = inherited_unlock
            sp.splitter_width = (self.mid_rail_width if self.axis == 'H'
                                 else self.mid_stile_width)
            sp.add_backing = self.add_backing
            if 'SIZE_ROLE' in original:
                split_obj['SIZE_ROLE'] = inherited_role
                del original['SIZE_ROLE']

            # Find the bay (for opening_index counter) before re-parenting.
            bay = original
            while bay is not None and not bay.get(types_face_frame.TAG_BAY_CAGE):
                bay = bay.parent
            if bay is not None:
                existing = [c for c in bay.children_recursive
                            if c.get(types_face_frame.TAG_OPENING_CAGE)]
                next_idx = 1 + max(
                    (c.face_frame_opening.opening_index for c in existing),
                    default=-1,
                )
            else:
                next_idx = 1

            # Create (count - 1) new sibling openings at indices 0 .. count-2.
            # The dialog's per-opening size + unlock arrays cover all `count`
            # children; the original takes the last slot (index count - 1).
            new_count = max(0, self.count - 1)
            new_openings = []
            for i in range(new_count):
                new_op = types_face_frame.FaceFrameOpening()
                new_op.create('Opening')
                new_op.obj.parent = split_obj
                new_op.obj['hb_split_child_index'] = i
                new_op.obj.face_frame_opening.opening_index = next_idx + i
                new_op.obj.face_frame_opening.size = self.sizes[i]
                new_op.obj.face_frame_opening.unlock_size = self.unlocks[i]
                # Per-opening contents chosen in the dialog (defaults match
                # the previous behavior -- new openings get the root default).
                new_op.obj.face_frame_opening.front_type = getattr(
                    self, f'front_type_{i}')
                new_openings.append(new_op.obj)

            # Re-parent original under split as the last child.
            original.parent = split_obj
            hb_utils.note_parent_change()
            original['hb_split_child_index'] = new_count
            op_props.size = self.sizes[new_count]
            op_props.unlock_size = self.unlocks[new_count]
            # Original opening's chosen contents (last slot). Assign only on
            # change so an untouched dialog leaves its front_type exactly as-is.
            orig_front = getattr(self, f'front_type_{new_count}')
            if op_props.front_type != orig_front:
                op_props.front_type = orig_front

            # A custom split inside an applied panel pins it to manual
            # mode so the host recalc stops wiping / rebuilding the
            # opening tree (mirrors insert / delete bay). Without this the
            # next recalc would revert the user's split.
            if (root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
                    or types_face_frame._is_standalone_panel(root)):
                root.face_frame_cabinet.panel_split_auto = False

            types_face_frame.recalculate_face_frame_cabinet(root)

        # Apply current selection mode's visual treatment to the new
        # cages and the split node so they appear correctly highlighted
        # / dimmed instead of stuck on default colors. Scoped to this
        # cabinet via search_obj_name to avoid touching unrelated scene
        # geometry.
        try:
            bpy.ops.hb_face_frame.toggle_mode(search_obj_name=root.name)
        except RuntimeError:
            # toggle_mode poll might fail in unusual contexts; not
            # fatal, the new cages are still functionally valid.
            pass

        self.report({'INFO'},
                    f"Split {original.name} into {self.count} along {self.axis}-axis")
        return {'FINISHED'}


def _find_owning_opening(obj):
    """Walk obj's parent chain up to the first opening cage. Returns
    None if no opening ancestor exists. Used by opening_prompts so a
    right-click on an interior part (shelf, pullout, mesh part, rollout
    box) lands on the same dialog as right-clicking the opening cage
    itself - flat case the interior part is a direct child of the
    opening; tree case it's under one or more interior region / split-
    node empties.
    """
    cur = obj
    while cur is not None:
        if cur.get(types_face_frame.TAG_OPENING_CAGE):
            return cur
        cur = cur.parent
    return None


class hb_face_frame_OT_opening_prompts(bpy.types.Operator):
    """Open a focused properties dialog for a single opening.

    Active object can be the opening cage itself OR any descendant
    (interior part, interior region, interior split node) - the
    operator walks up to find the owning opening so users in Interior
    selection mode can right-click a shelf and reach the same dialog.

    The owning opening's name is captured at invoke and held on the
    operator. Necessary because interior_items rebuilds wipe and
    recreate the parts on every kind change; without the cached name,
    the popup loses its active object mid-edit and renders empty.
    The opening cage itself is stable across these rebuilds.
    """
    bl_idname = "hb_face_frame.opening_prompts"
    bl_label = "Opening Properties"
    bl_description = "Edit a single opening's properties"
    bl_options = {'UNDO'}

    opening_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        return _find_owning_opening(context.active_object) is not None

    def _resolve_opening(self, context):
        """Prefer the cached opening_name; fall back to the active-object
        walk-up if it's empty or stale (e.g. cabinet was deleted)."""
        if self.opening_name:
            obj = bpy.data.objects.get(self.opening_name)
            if obj is not None and obj.get(types_face_frame.TAG_OPENING_CAGE):
                return obj
        return _find_owning_opening(context.active_object)

    def invoke(self, context, event):
        opening_obj = _find_owning_opening(context.active_object)
        if opening_obj is None:
            self.report({'WARNING'}, "No opening selected")
            return {'CANCELLED'}
        self.opening_name = opening_obj.name
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        opening_obj = self._resolve_opening(context)
        if opening_obj is None:
            self.layout.label(text="No opening selected", icon='INFO')
            return
        ui_face_frame.draw_opening_properties(self.layout, opening_obj)


class hb_face_frame_OT_interior_options(bpy.types.Operator):
    """Edit the inside of one opening on its own: the shelves,
    roll-outs, dividers and accessories it holds.

    Resolved the same way as opening_prompts - the click target can be
    any descendant of the opening - and held by name, because a kind
    change wipes and rebuilds every interior part while the dialog is
    still open.
    """
    bl_idname = "hb_face_frame.interior_options"
    bl_label = "Interior Options"
    bl_description = ("Add and edit the shelves, roll-outs, dividers and "
                      "accessories inside this opening")
    bl_options = {'UNDO'}

    opening_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        opening = _find_owning_opening(context.active_object)
        if opening is None:
            return False
        # Panels carry no carcass, so there is no interior to edit.
        root = types_face_frame.find_cabinet_root(opening)
        if root is not None and                 root.face_frame_cabinet.cabinet_type == 'PANEL':
            return False
        return True

    def _resolve_opening(self, context):
        """Prefer the cached opening_name; fall back to the active-object
        walk-up if it's empty or stale (e.g. cabinet was deleted)."""
        if self.opening_name:
            obj = bpy.data.objects.get(self.opening_name)
            if obj is not None and obj.get(types_face_frame.TAG_OPENING_CAGE):
                return obj
        return _find_owning_opening(context.active_object)

    def invoke(self, context, event):
        opening_obj = _find_owning_opening(context.active_object)
        if opening_obj is None:
            self.report({'WARNING'}, "No opening selected")
            return {'CANCELLED'}
        self.opening_name = opening_obj.name
        return context.window_manager.invoke_props_dialog(self, width=340)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        opening_obj = self._resolve_opening(context)
        if opening_obj is None:
            self.layout.label(text="No opening selected", icon='INFO')
            return
        ui_face_frame.draw_opening_interior_options(self.layout, opening_obj)


class hb_face_frame_OT_finish_bay_prompts(bpy.types.Operator):
    """Finish the inside of one bay, straight from the right-click menu:
    the same controls the bay properties dialog carries, without opening
    the whole thing.

    The bay is resolved by cached name, because switching the finish on
    rebuilds the bay's parts - and on a bay cage the click target itself
    survives, but the liners it grows do not.
    """
    bl_idname = "hb_face_frame.finish_bay_prompts"
    bl_label = "Finish Bay"
    bl_description = ("Finish the inside of this bay so the exterior "
                      "finish reads within it")
    bl_options = {'UNDO'}

    bay_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get(types_face_frame.TAG_BAY_CAGE))

    def _resolve_bay(self, context):
        if self.bay_name:
            obj = bpy.data.objects.get(self.bay_name)
            if obj is not None and obj.get(types_face_frame.TAG_BAY_CAGE):
                return obj
        obj = context.active_object
        if obj is not None and obj.get(types_face_frame.TAG_BAY_CAGE):
            return obj
        return None

    def invoke(self, context, event):
        bay_obj = self._resolve_bay(context)
        if bay_obj is None:
            self.report({'WARNING'}, "No bay selected")
            return {'CANCELLED'}
        self.bay_name = bay_obj.name
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        bay_obj = self._resolve_bay(context)
        if bay_obj is None:
            self.layout.label(text="No bay selected", icon='INFO')
            return
        self.layout.label(
            text=f"Bay {bay_obj.face_frame_bay.bay_index + 1}",
            icon='MESH_CUBE')
        ui_face_frame.draw_bay_finish_options(self.layout, bay_obj)


class hb_face_frame_OT_finish_opening_prompts(bpy.types.Operator):
    """Finish the inside of one opening, straight from the right-click
    menu: the same controls the sidebar's Finish Options box carries,
    without going through the whole opening properties dialog.

    Same walk-up as opening_prompts, so it opens from the opening cage,
    a front, or an interior part. The props live-bind, and the opening
    is resolved by cached name because switching the finish on rebuilds
    the parts the click came from - including, often, the clicked part.
    """
    bl_idname = "hb_face_frame.finish_opening_prompts"
    bl_label = "Finish Opening"
    bl_description = ("Finish the inside of this opening so the exterior "
                      "finish reads within it")
    bl_options = {'UNDO'}

    opening_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        return _find_owning_opening(context.active_object) is not None

    def _resolve_opening(self, context):
        if self.opening_name:
            obj = bpy.data.objects.get(self.opening_name)
            if obj is not None and obj.get(types_face_frame.TAG_OPENING_CAGE):
                return obj
        return _find_owning_opening(context.active_object)

    def invoke(self, context, event):
        opening_obj = _find_owning_opening(context.active_object)
        if opening_obj is None:
            self.report({'WARNING'}, "No opening selected")
            return {'CANCELLED'}
        self.opening_name = opening_obj.name
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        opening_obj = self._resolve_opening(context)
        if opening_obj is None:
            self.layout.label(text="No opening selected", icon='INFO')
            return
        ui_face_frame.draw_opening_finish_options(self.layout, opening_obj)


class hb_face_frame_OT_drawer_box_prompts(bpy.types.Operator):
    """Edit the size of the drawer box behind a drawer / pullout front.

    Right-click entry on a drawer box (Interiors selection mode). The
    size lives on the owning opening's props - drawer boxes are wiped
    and rebuilt every recalc, so nothing durable can sit on the box
    object itself. One row per axis: an override toggle plus the size;
    un-overridden axes keep the auto fit (opening hole minus the scene
    clearances). The props live-bind, so edits rebuild the box as the
    user types; the dialog resolves the opening by cached name because
    the clicked box object dies on the first rebuild.
    """
    bl_idname = "hb_face_frame.drawer_box_prompts"
    bl_label = "Drawer Box Size"
    bl_description = "Edit this drawer box's size (stored on the owning opening)"
    bl_options = {'UNDO'}

    opening_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    _AXES = (
        ("Width",  'drawer_box_override_width',  'drawer_box_width'),
        ("Height", 'drawer_box_override_height', 'drawer_box_height'),
        ("Depth",  'drawer_box_override_depth',  'drawer_box_depth'),
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or not obj.get('IS_DRAWER_BOX'):
            return False
        return _find_owning_opening(obj) is not None

    def invoke(self, context, event):
        box_obj = context.active_object
        opening_obj = _find_owning_opening(box_obj)
        if opening_obj is None:
            self.report({'WARNING'}, "No owning opening found")
            return {'CANCELLED'}
        self.opening_name = opening_obj.name
        op_props = opening_obj.face_frame_opening
        # Seed un-overridden axes from the box's current (auto) size so
        # switching an override on starts from what's already there
        # instead of jumping to a stale value. ID-property writes on
        # purpose: they skip the update callbacks, so seeding triggers
        # no rebuild.
        try:
            geo = hb_types.GeoNodeObject(box_obj)
            dim_x = geo.get_input('Dim X')
            dim_y = geo.get_input('Dim Y')
            dim_z = geo.get_input('Dim Z')
        except Exception:
            dim_x = dim_y = dim_z = None
        if dim_x is not None:
            if not op_props.drawer_box_override_width:
                op_props['drawer_box_width'] = dim_x
            if not op_props.drawer_box_override_depth:
                op_props['drawer_box_depth'] = dim_y
            if not op_props.drawer_box_override_height:
                op_props['drawer_box_height'] = dim_z
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        layout = self.layout
        opening_obj = bpy.data.objects.get(self.opening_name)
        if opening_obj is None:
            layout.label(text="Opening not found", icon='INFO')
            return
        op_props = opening_obj.face_frame_opening
        col = layout.column(align=True)
        for label, ov_prop, val_prop in self._AXES:
            row = col.row(align=True)
            row.prop(op_props, ov_prop, text="")
            sub = row.row(align=True)
            sub.enabled = getattr(op_props, ov_prop)
            sub.prop(op_props, val_prop, text=label)
        col.separator()
        col.label(text="Unchecked sizes stay automatic", icon='INFO')

    def execute(self, context):
        # Live-bound via the opening props' update callbacks; OK needs
        # no extra work.
        return {'FINISHED'}


class hb_face_frame_OT_rollout_above_drawer_prompts(bpy.types.Operator):
    """Add a rollout above this drawer, behind the same front.

    Right-click entry on a drawer box, alongside the other box options.
    Like them the settings live on the owning opening (boxes are wiped
    and rebuilt every recalc) and live-bind, so the drawer box shortens
    and the rollout appears as the user types.
    """
    bl_idname = "hb_face_frame.rollout_above_drawer_prompts"
    bl_label = "Rollout Above Drawer"
    bl_description = ("Add a rollout above this drawer's box, behind the "
                      "same front. The drawer box shortens to make room")
    bl_options = {'UNDO'}

    opening_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or not obj.get('IS_DRAWER_BOX'):
            return False
        return _find_owning_opening(obj) is not None

    def invoke(self, context, event):
        opening_obj = _find_owning_opening(context.active_object)
        if opening_obj is None:
            self.report({'WARNING'}, "No owning opening found")
            return {'CANCELLED'}
        self.opening_name = opening_obj.name
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        opening_obj = bpy.data.objects.get(self.opening_name)
        if opening_obj is None:
            layout.label(text="Opening not found", icon='INFO')
            return
        op_props = opening_obj.face_frame_opening
        col = layout.column(align=True)
        col.prop(op_props, 'rollout_above_drawer', text="Rollout Above Drawer")
        sub = col.column(align=True)
        sub.enabled = op_props.rollout_above_drawer
        sub.prop(op_props, 'rollout_above_height', text="Rollout Height")
        sub.prop(op_props, 'rollout_above_gap', text="Gap Above Drawer")
        col.separator()
        col.label(text="The drawer box shortens to fit underneath",
                  icon='INFO')

    def execute(self, context):
        # Live-bound via the opening props' update callbacks.
        return {'FINISHED'}


class hb_face_frame_OT_sink_duo_drawer_prompts(bpy.types.Operator):
    """Toggle / size the sink duo (U-shaped) option on a drawer box.

    Right-click entry on a drawer box. The option lives on the owning
    opening's props (boxes are wiped and rebuilt every recalc); the
    props live-bind, so edits rebuild the box as the user types.
    """
    bl_idname = "hb_face_frame.sink_duo_drawer_prompts"
    bl_label = "Sink Duo Drawer"
    bl_description = ("Make this a U-shaped sink drawer: a centered "
                      "notch from the back wraps the sink basin")
    bl_options = {'UNDO'}

    opening_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or not obj.get('IS_DRAWER_BOX'):
            return False
        return _find_owning_opening(obj) is not None

    def invoke(self, context, event):
        opening_obj = _find_owning_opening(context.active_object)
        if opening_obj is None:
            self.report({'WARNING'}, "No owning opening found")
            return {'CANCELLED'}
        self.opening_name = opening_obj.name
        return context.window_manager.invoke_props_dialog(self, width=280)

    def draw(self, context):
        layout = self.layout
        opening_obj = bpy.data.objects.get(self.opening_name)
        if opening_obj is None:
            layout.label(text="Opening not found", icon='INFO')
            return
        op_props = opening_obj.face_frame_opening
        col = layout.column(align=True)
        col.prop(op_props, 'sink_duo')
        sub = col.column(align=True)
        sub.enabled = op_props.sink_duo
        sub.prop(op_props, 'sink_duo_notch_width')
        sub.prop(op_props, 'sink_duo_notch_depth')
        col.separator()
        col.label(text="Notch Depth 0 uses 2/3 of the box depth",
                  icon='INFO')

    def execute(self, context):
        # Live-bound via the opening props' update callbacks.
        return {'FINISHED'}


class hb_face_frame_OT_sink_duo_rollout_prompts(bpy.types.Operator):
    """Toggle / size the U-notch on ONE rollout box.

    The rollout equivalent of the sink duo drawer, but per box rather
    than per opening: a stack under a sink usually wants the box that
    passes the trap notched and the others left whole. The options live
    on the opening's rollout_boxes entry (the boxes themselves are wiped
    and rebuilt every recalc); the props live-bind, so edits rebuild the
    box as the user types.
    """
    bl_idname = "hb_face_frame.sink_duo_rollout_prompts"
    bl_label = "U-Shaped Rollout"
    bl_description = ("Notch this rollout box from the back so it wraps "
                      "the sink basin / plumbing")
    bl_options = {'UNDO'}

    opening_name: bpy.props.StringProperty(
        default='', options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore
    item_index: bpy.props.IntProperty(
        default=-1, options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore
    box_index: bpy.props.IntProperty(
        default=-1, options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        _opening, box_props = types_face_frame.rollout_box_props_for_object(
            context.active_object)
        return box_props is not None

    def invoke(self, context, event):
        obj = context.active_object
        opening, box_props = types_face_frame.rollout_box_props_for_object(obj)
        if box_props is None:
            self.report({'WARNING'}, "No rollout box options found")
            return {'CANCELLED'}
        self.opening_name = opening.name
        self.item_index = obj.get(
            types_face_frame.TAG_ROLLOUT_ITEM_INDEX, -1)
        self.box_index = obj.get(
            types_face_frame.TAG_ROLLOUT_BOX_INDEX, -1)
        return context.window_manager.invoke_props_dialog(self, width=280)

    def _box_props(self):
        return types_face_frame.rollout_box_props(
            bpy.data.objects.get(self.opening_name),
            self.item_index, self.box_index)

    def draw(self, context):
        layout = self.layout
        box_props = self._box_props()
        if box_props is None:
            layout.label(text="Rollout box not found", icon='INFO')
            return
        col = layout.column(align=True)
        col.prop(box_props, 'galley_top')
        col.prop(box_props, 'sink_duo')
        sub = col.column(align=True)
        sub.enabled = box_props.sink_duo
        sub.prop(box_props, 'sink_duo_notch_width')
        sub.prop(box_props, 'sink_duo_notch_depth')
        col.separator()
        col.label(text="Notch Depth 0 uses 2/3 of the box depth",
                  icon='INFO')

    def execute(self, context):
        # Live-bound via the rollout box props' update callbacks.
        return {'FINISHED'}


class hb_face_frame_OT_bay_prompts(bpy.types.Operator):
    """Open a focused properties dialog for a single bay.

    Targets the bay named by bay_name; when that is empty (the normal
    right-click / selection entry point) it resolves from the active
    object. The dialog's Previous / Next buttons re-invoke this same
    operator with bay_name set to a sibling, so Blender closes the
    current popup and opens a fresh one on that bay - no manual
    re-invoke needed. invoke() also makes the resolved bay the active
    selection so the viewport tracks the dialog as the user pages
    through bays.
    """
    bl_idname = "hb_face_frame.bay_prompts"
    bl_label = "Bay Properties"
    bl_description = "Edit a single bay's properties"
    bl_options = {'UNDO'}

    # SKIP_SAVE so a fresh right-click invocation starts with an empty
    # bay_name and falls back to the active object, rather than reusing
    # whatever bay the previous dialog navigated to.
    bay_name: bpy.props.StringProperty(
        name="Bay Name",
        description=("Object name of the bay cage to edit; empty "
                     "resolves from the active object"),
        default="",
        options={'SKIP_SAVE'},
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None:
            return False
        return bool(obj.get(types_face_frame.TAG_BAY_CAGE))

    def _resolve_bay(self, context):
        """Return the bay cage this invocation targets, or None.

        bay_name wins when set (Previous / Next path); otherwise fall
        back to the active object (right-click / selection path).
        """
        if self.bay_name:
            obj = bpy.data.objects.get(self.bay_name)
            if obj is not None and obj.get(types_face_frame.TAG_BAY_CAGE):
                return obj
        obj = context.active_object
        if obj is not None and obj.get(types_face_frame.TAG_BAY_CAGE):
            return obj
        return None

    def invoke(self, context, event):
        bay_obj = self._resolve_bay(context)
        if bay_obj is None:
            self.report({'WARNING'}, "No bay selected")
            return {'CANCELLED'}
        # Pin bay_name so draw() and any Previous / Next re-invoke are
        # anchored to a concrete bay, not whatever stays active.
        self.bay_name = bay_obj.name
        # Track the dialog in the viewport: select only the target bay
        # so paging between bays moves the selection with the dialog.
        for o in context.selected_objects:
            o.select_set(False)
        bay_obj.select_set(True)
        context.view_layer.objects.active = bay_obj
        return context.window_manager.invoke_props_dialog(self, width=300)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        bay_obj = self._resolve_bay(context)
        if bay_obj is None:
            self.layout.label(text="No bay selected", icon='INFO')
            return

        # Sibling bays in index order, for the Previous / Next nav row.
        cabinet = bay_obj.parent
        siblings = sorted(
            [c for c in cabinet.children
             if c.get(types_face_frame.TAG_BAY_CAGE)],
            key=lambda c: c.get('hb_bay_index', 0),
        ) if cabinet else [bay_obj]
        try:
            pos = siblings.index(bay_obj)
        except ValueError:
            pos = 0

        # Each nav button is another bay_prompts invocation with
        # bay_name pre-set: clicking it closes this popup and Blender
        # opens a fresh dialog on the sibling. Clamped at the ends.
        nav = self.layout.row(align=True)
        prev_btn = nav.row(align=True)
        prev_btn.enabled = pos > 0
        op = prev_btn.operator(
            'hb_face_frame.bay_prompts', text="Previous", icon='TRIA_LEFT',
        )
        op.bay_name = siblings[pos - 1].name if pos > 0 else ""
        nav.label(text=f"Bay {pos + 1} of {len(siblings)}")
        next_btn = nav.row(align=True)
        next_btn.enabled = pos < len(siblings) - 1
        op = next_btn.operator(
            'hb_face_frame.bay_prompts', text="Next", icon='TRIA_RIGHT',
        )
        op.bay_name = (siblings[pos + 1].name
                       if pos < len(siblings) - 1 else "")
        self.layout.separator()

        ui_face_frame.draw_bay_properties(self.layout, bay_obj)


class hb_face_frame_OT_mid_stile_prompts(bpy.types.Operator):
    """Open a focused properties dialog for a single mid stile.

    Operates on the active object - which must be a mid stile face frame
    part (hb_part_role == PART_ROLE_MID_STILE). Shows just that mid
    stile's width, extend up, and extend down.
    """
    bl_idname = "hb_face_frame.mid_stile_prompts"
    bl_label = "Mid Stile Properties"
    bl_description = "Edit a single mid stile's properties"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None:
            return False
        return obj.get('hb_part_role') == types_face_frame.PART_ROLE_MID_STILE

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=260)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        obj = context.active_object
        if obj is None or obj.get('hb_part_role') != types_face_frame.PART_ROLE_MID_STILE:
            self.layout.label(text="No mid stile selected", icon='INFO')
            return
        root = types_face_frame.find_cabinet_root(obj)
        if root is None:
            self.layout.label(text="No cabinet root found", icon='ERROR')
            return
        msi = obj.get('hb_mid_stile_index', 0)
        ui_face_frame.draw_mid_stile_properties(self.layout, root, msi)


def _resolve_interior_target(operator, context):
    """Return the active interior target object for an operator,
    honoring an explicit `target_name` set by the inline opening
    popup when present, else falling back to context.active_object.
    Used so buttons rendered inside the opening's modal popup can
    address a specific leaf without changing the active object.
    """
    name = getattr(operator, 'target_name', '') or ''
    if name:
        obj = bpy.data.objects.get(name)
        if obj is not None:
            return obj
    return context.active_object


def _interior_items_target(obj):
    """Return the props object whose `interior_items` collection should
    be edited by add/remove operators when `obj` is active. Returns
    None for objects that don't carry items (cabinet, bay, parts).

    - Opening cage with no tree: opening's flat interior_items.
    - Opening cage with a tree: None (the user must drill into a leaf).
    - Interior region (leaf): the leaf's interior_items.
    - Any other descendant of an opening (drawer box, front, shelf,
      divider, pull): the owning opening's collection, so right-
      clicking the geometry works like right-clicking the cage.
    """
    if obj is None:
        return None
    if not (obj.get(types_face_frame.TAG_OPENING_CAGE)
            or obj.get(types_face_frame.TAG_INTERIOR_REGION)):
        owner = _find_owning_opening(obj)
        if owner is not None:
            obj = owner
    if obj.get(types_face_frame.TAG_OPENING_CAGE):
        # When the opening has a tree, items live on leaves and the
        # opening's flat collection is dead. Block direct edits to
        # avoid silent writes the walker would never read.
        has_tree = any(
            c.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE)
            or c.get(types_face_frame.TAG_INTERIOR_REGION)
            for c in obj.children
        )
        if has_tree:
            return None
        return obj.face_frame_opening
    if obj.get(types_face_frame.TAG_INTERIOR_REGION):
        return obj.face_frame_interior_region
    return None


class hb_face_frame_OT_add_interior_item(bpy.types.Operator):
    """Append a new interior item to the active opening's collection.
    Auto-seeds qty fields where applicable; field defaults on
    Face_Frame_Interior_Item supply the rest, and the user edits in
    the panel afterward.

    The half_depth flag is a shortcut: when on, the new item lands on
    the HALF_DEPTH_SHELF kind regardless of the kind the operator was
    called with (kept for callers predating the dedicated kind).
    """
    bl_idname = "hb_face_frame.add_interior_item"
    bl_label = "Add Interior Item"
    bl_description = (
        "Add an interior item (shelf, drawer, rollout, etc.) to the "
        "selected opening or region. Item details can be edited in "
        "the properties panel afterwards"
    )
    bl_options = {'UNDO'}

    kind: bpy.props.EnumProperty(
        name="Kind",
        items=props_hb_face_frame.Face_Frame_Interior_Item.INTERIOR_KIND_ITEMS,
        default='ADJUSTABLE_SHELF',
    )  # type: ignore

    half_depth: bpy.props.BoolProperty(
        name="Half Depth",
        description="Create a half-depth shelf item (kind = HALF_DEPTH_SHELF)",
        default=False,
    )  # type: ignore

    target_name: bpy.props.StringProperty(
        name="Target Name",
        description="Object name to target instead of active_object "
                    "(used when the panel renders inside a modal popup)",
        default="",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # Always allow - target_name carries the indirection these
        # operators need when called from inside a popup whose active
        # object can go stale mid-edit. execute() validates via
        # _resolve_interior_target and reports a clean warning if the
        # target can't be resolved.
        return True

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            self.report({'WARNING'}, "Could not resolve target")
            return {'CANCELLED'}
        target_props = _interior_items_target(target)
        if target_props is None:
            self.report({'WARNING'},
                        "Select an opening or interior region first")
            return {'CANCELLED'}

        item = target_props.interior_items.add()
        if self.half_depth:
            # The half-depth preset is a kind override: regardless of
            # what kind the operator was called with, we land on the
            # half-depth shelf kind (the solver computes the setback
            # from the cavity depth).
            item.kind = 'HALF_DEPTH_SHELF'
        else:
            item.kind = self.kind
            # Seed a couple of default boxes for a new rollout; the box
            # count is the list length and each box defaults to the
            # standard 3 5/8" height.
            if self.kind == 'ROLLOUT':
                for _ in range(2):
                    item.rollout_boxes.add()

        # Field defaults on the prop class (shelf_qty=1, qty=2, tray_qty=3,
        # vanity_z=11", ...) cover the initial values; the recalc owns
        # any auto-recompute (shelf_qty when unlock_shelf_qty is False).

        target_props.interior_items_index = len(target_props.interior_items) - 1
        # Property writes above already trigger update_cabinet_dim,
        # but call recalc explicitly so the new parts appear even if
        # the update path was suppressed by a re-entrance guard.
        root = types_face_frame.find_cabinet_root(target)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


class hb_face_frame_OT_remove_interior_item(bpy.types.Operator):
    """Remove an interior item from the active opening. Targets the
    item at `index` when set explicitly (per-row remove buttons), or
    falls back to interior_items_index when called without args.
    """
    bl_idname = "hb_face_frame.remove_interior_item"
    bl_label = "Remove Interior Item"
    bl_description = "Remove the selected interior item from this opening"
    bl_options = {'UNDO'}

    index: bpy.props.IntProperty(
        name="Index",
        description="Item index to remove (-1 uses the active index)",
        default=-1,
    )  # type: ignore

    target_name: bpy.props.StringProperty(
        name="Target Name",
        description="Object name to target instead of active_object",
        default="",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # Always allow - the button is only rendered next to an item
        # that actually exists, so the empty-collection guard the old
        # check enforced is redundant. execute() validates via
        # _resolve_interior_target if anything has gone stale.
        return True

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            return {'CANCELLED'}
        target_props = _interior_items_target(target)
        if target_props is None:
            return {'CANCELLED'}
        idx = (self.index if self.index >= 0
               else target_props.interior_items_index)
        if 0 <= idx < len(target_props.interior_items):
            target_props.interior_items.remove(idx)
            if target_props.interior_items_index >= len(target_props.interior_items):
                target_props.interior_items_index = max(
                    0, len(target_props.interior_items) - 1
                )
        root = types_face_frame.find_cabinet_root(target)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


class hb_face_frame_OT_apply_shelf_nosing_to_room(bpy.types.Operator):
    """Push the nosing profile on one shelf item onto every adjustable /
    half-depth shelf in the room. Shelf nosing is otherwise set item by
    item, which is a lot of clicks on a job that runs one profile
    throughout."""
    bl_idname = "hb_face_frame.apply_shelf_nosing_to_room"
    bl_label = "Apply to Room"
    bl_description = ("Apply this nosing profile and height to every "
                      "adjustable and half-depth shelf in the room")
    bl_options = {'REGISTER', 'UNDO'}

    index: bpy.props.IntProperty(
        name="Index",
        description="Source item index (-1 uses the active index)",
        default=-1,
    )  # type: ignore

    target_name: bpy.props.StringProperty(
        name="Target Name",
        description="Object name to target instead of active_object",
        default="",
    )  # type: ignore

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            return {'CANCELLED'}
        target_props = _interior_items_target(target)
        if target_props is None:
            return {'CANCELLED'}
        idx = (self.index if self.index >= 0
               else target_props.interior_items_index)
        if not (0 <= idx < len(target_props.interior_items)):
            return {'CANCELLED'}
        source = target_props.interior_items[idx]
        style = source.shelf_nosing_style
        height = source.shelf_nosing_height

        # Snapshot first: each write recalcs the cabinet, and recalcs
        # can add / remove scene objects under a live iteration.
        objects = list(context.scene.objects)
        roots = []
        with types_face_frame.suspend_recalc():
            for obj in objects:
                if not (obj.get(types_face_frame.TAG_OPENING_CAGE)
                        or obj.get(types_face_frame.TAG_INTERIOR_REGION)):
                    continue
                # Skips opening cages whose items moved onto a tree -
                # their flat collection is dead and never read.
                item_props = _interior_items_target(obj)
                if item_props is None:
                    continue
                changed = False
                for item in item_props.interior_items:
                    if item.kind not in {'ADJUSTABLE_SHELF',
                                         'HALF_DEPTH_SHELF',
                                         'QUARTER_DEPTH_SHELF'}:
                        continue
                    if (item.shelf_nosing_style == style
                            and abs(item.shelf_nosing_height - height) < 1e-9):
                        continue
                    item.shelf_nosing_style = style
                    item.shelf_nosing_height = height
                    changed = True
                if not changed:
                    continue
                root = types_face_frame.find_cabinet_root(obj)
                if root is not None and root not in roots:
                    roots.append(root)

        for root in roots:
            types_face_frame.recalculate_face_frame_cabinet(root)
        self.report({'INFO'},
                    f"Shelf nosing applied to {len(roots)} cabinet(s)")
        return {'FINISHED'}


class hb_face_frame_OT_add_rollout_box(bpy.types.Operator):
    """Append a drawer box to a rollout stack. Targets the interior item
    at item_index on the resolved opening / region. New boxes default to
    the standard 3 5/8" height."""
    bl_idname = "hb_face_frame.add_rollout_box"
    bl_label = "Add Rollout Box"
    bl_description = "Add another drawer box to this rollout stack"
    bl_options = {'UNDO'}

    item_index: bpy.props.IntProperty(default=-1)  # type: ignore
    target_name: bpy.props.StringProperty(default="")  # type: ignore

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            return {'CANCELLED'}
        target_props = _interior_items_target(target)
        if target_props is None:
            return {'CANCELLED'}
        if not (0 <= self.item_index < len(target_props.interior_items)):
            return {'CANCELLED'}
        item = target_props.interior_items[self.item_index]
        item.rollout_boxes.add()
        root = types_face_frame.find_cabinet_root(target)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


class hb_face_frame_OT_remove_rollout_box(bpy.types.Operator):
    """Remove the drawer box at box_index from the rollout stack on the
    interior item at item_index."""
    bl_idname = "hb_face_frame.remove_rollout_box"
    bl_label = "Remove Rollout Box"
    bl_description = "Remove this drawer box from the rollout stack"
    bl_options = {'UNDO'}

    item_index: bpy.props.IntProperty(default=-1)  # type: ignore
    box_index: bpy.props.IntProperty(default=-1)  # type: ignore
    target_name: bpy.props.StringProperty(default="")  # type: ignore

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            return {'CANCELLED'}
        target_props = _interior_items_target(target)
        if target_props is None:
            return {'CANCELLED'}
        if not (0 <= self.item_index < len(target_props.interior_items)):
            return {'CANCELLED'}
        item = target_props.interior_items[self.item_index]
        if 0 <= self.box_index < len(item.rollout_boxes):
            item.rollout_boxes.remove(self.box_index)
        root = types_face_frame.find_cabinet_root(target)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Interior split operators
# ---------------------------------------------------------------------------
# Two operators (Add Division, Add Fixed Shelf) plus a shared splitter that
# handles both "first split of a flat opening" (the opening's items migrate
# onto the lower/left child) and "subdivide an existing leaf" (the leaf
# becomes the lower/left child, a fresh empty leaf is the upper/right).
def _read_cage_dims(obj):
    """Return cage_dim_x/y/z dict by reading 'Dim X/Y/Z' inputs off the
    object's geometry node modifier. Used by the split operator to seed
    the new children's sizes from the active target's current rect.

    Reads via hb_utils: a modifier isn't an ID property container on 5.2.
    """
    rect = {'cage_dim_x': 0.0, 'cage_dim_y': 0.0, 'cage_dim_z': 0.0}
    nm = next((m for m in obj.modifiers if m.type == 'NODES'), None)
    if not (nm and nm.node_group):
        return rect
    for sk in nm.node_group.interface.items_tree:
        if sk.in_out != 'INPUT':
            continue
        if sk.name == 'Dim X':
            rect['cage_dim_x'] = hb_utils.try_get_gn_input(nm, sk.identifier, 0.0) or 0.0
        elif sk.name == 'Dim Y':
            rect['cage_dim_y'] = hb_utils.try_get_gn_input(nm, sk.identifier, 0.0) or 0.0
        elif sk.name == 'Dim Z':
            rect['cage_dim_z'] = hb_utils.try_get_gn_input(nm, sk.identifier, 0.0) or 0.0
    return rect


def _copy_interior_items(src, dst):
    """Append every item in src CollectionProperty into dst, copying all
    user-facing fields. Used by the flat -> tree migration on first split
    and (later) by tree collapse.
    """
    for s in src:
        d = dst.add()
        for prop in s.bl_rna.properties:
            if prop.identifier == 'rna_type' or prop.is_readonly:
                continue
            try:
                setattr(d, prop.identifier, getattr(s, prop.identifier))
            except (AttributeError, TypeError):
                # Skip props we can't copy (pointer types, etc.); the
                # generic loop also can't assign the rollout_boxes
                # collection, which is deep-copied just below.
                pass
        # rollout_boxes is a nested collection setattr can't assign; copy
        # each box explicitly so per-box rollout heights survive the
        # flat -> tree migration on split.
        if hasattr(s, 'rollout_boxes'):
            d.rollout_boxes.clear()
            for sb in s.rollout_boxes:
                db = d.rollout_boxes.add()
                db.height_preset = sb.height_preset
                db.height = sb.height


def _split_active_region(target, axis):
    """Insert a new split node + two child leaves at the position of
    `target`. axis = 'V' (vertical divider) or 'H' (horizontal divider).
    Handles both target=opening (flat -> tree) and target=existing leaf
    (subdivide). All initial size writes are bracketed by the
    _DISTRIBUTING_WIDTHS guard so the auto-lock-on-edit callback
    treats them as system writes (the user just clicked "Add" - they
    didn't type a custom size).
    """
    is_flat_opening = bool(target.get(types_face_frame.TAG_OPENING_CAGE))
    is_leaf = bool(target.get(types_face_frame.TAG_INTERIOR_REGION))
    if not (is_flat_opening or is_leaf):
        return None

    rect = _read_cage_dims(target)
    parent_dim = (rect['cage_dim_x'] if axis == 'V'
                  else rect['cage_dim_z'])
    div_t = inch(0.75)
    half = max(0.0, (parent_dim - div_t) / 2.0)

    root = types_face_frame.find_cabinet_root(target)
    guard_id = id(root) if root is not None else None

    def _seed_size(props, value, unlock):
        """Write size + unlock_size as a system-style seed: bracketed
        by the redistribution guard so the size update callback skips
        the auto-lock (user didn't type this value)."""
        if guard_id is not None:
            types_face_frame._DISTRIBUTING_WIDTHS.add(guard_id)
        try:
            props.size = value
            props.unlock_size = unlock
        finally:
            if guard_id is not None:
                types_face_frame._DISTRIBUTING_WIDTHS.discard(guard_id)

    # Create the split node empty
    split = hb_utils.new_object('Interior Split', None)
    bpy.context.scene.collection.objects.link(split)
    split.empty_display_type = 'PLAIN_AXES'
    split.empty_display_size = 0.001
    split[types_face_frame.TAG_INTERIOR_SPLIT_NODE] = True
    sp = split.face_frame_interior_split
    sp.axis = axis
    sp.divider_thickness = div_t

    if is_flat_opening:
        opening = target
        split.parent = opening
        split.location = (0.0, 0.0, 0.0)

        # Lower/left child: existing items migrate here. Per the locked
        # design, items move to lower/left on first split.
        leaf_a = types_face_frame.FaceFrameInteriorRegion()
        leaf_a.create('Region 1')
        leaf_a.obj.parent = split
        leaf_a.obj['hb_interior_child_index'] = 0
        _seed_size(leaf_a.obj.face_frame_interior_region, half, False)
        _copy_interior_items(
            opening.face_frame_opening.interior_items,
            leaf_a.obj.face_frame_interior_region.interior_items,
        )
        opening.face_frame_opening.interior_items.clear()

        # Upper/right child: empty leaf
        leaf_b = types_face_frame.FaceFrameInteriorRegion()
        leaf_b.create('Region 2')
        leaf_b.obj.parent = split
        leaf_b.obj['hb_interior_child_index'] = 1
        _seed_size(leaf_b.obj.face_frame_interior_region, half, False)
        return split

    # Subdivide existing leaf: split node takes leaf's slot in parent;
    # leaf becomes child 0; a new empty leaf becomes child 1.
    leaf = target
    leaf_parent = leaf.parent
    leaf_index = leaf.get('hb_interior_child_index', 0)
    rp_existing = leaf.face_frame_interior_region

    # Hand the leaf's current size + unlock to the new split (which now
    # occupies the leaf's slot).
    _seed_size(sp, rp_existing.size, rp_existing.unlock_size)

    split.parent = leaf_parent
    split['hb_interior_child_index'] = leaf_index
    leaf.parent = split
    hb_utils.note_parent_change()
    leaf['hb_interior_child_index'] = 0
    _seed_size(rp_existing, half, False)

    leaf_b = types_face_frame.FaceFrameInteriorRegion()
    leaf_b.create('Region')
    leaf_b.obj.parent = split
    leaf_b.obj['hb_interior_child_index'] = 1
    _seed_size(leaf_b.obj.face_frame_interior_region, half, False)
    return split


class hb_face_frame_OT_add_interior_division(bpy.types.Operator):
    """Add a vertical division to the active opening or interior leaf,
    splitting it into a left and a right region.
    """
    bl_idname = "hb_face_frame.add_interior_division"
    bl_label = "Add Interior Division"
    bl_description = (
        "Split the selected opening or region into a left and right "
        "side with a vertical division"
    )
    bl_options = {'UNDO'}

    target_name: bpy.props.StringProperty(
        name="Target Name", default="",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # Always allow - target_name carries the indirection these
        # operators need when called from inside a popup whose active
        # object can go stale mid-edit. execute() validates via
        # _resolve_interior_target and reports a clean warning if the
        # target can't be resolved.
        return True

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            return {'CANCELLED'}
        # When the opening already has a tree, the user must pick a leaf
        # to subdivide further. Block here so the operator is unambiguous.
        if (target.get(types_face_frame.TAG_OPENING_CAGE)
                and any(c.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE)
                        or c.get(types_face_frame.TAG_INTERIOR_REGION)
                        for c in target.children)):
            self.report({'WARNING'},
                        "Opening already has interior splits - "
                        "select a region to subdivide")
            return {'CANCELLED'}

        if _split_active_region(target, axis='V') is None:
            self.report({'WARNING'},
                        "Select an opening or interior region first")
            return {'CANCELLED'}

        root = types_face_frame.find_cabinet_root(target)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


class hb_face_frame_OT_add_interior_fixed_shelf(bpy.types.Operator):
    """Add a horizontal fixed shelf to the active opening or interior
    leaf, splitting it into a bottom and a top region.
    """
    bl_idname = "hb_face_frame.add_interior_fixed_shelf"
    bl_label = "Add Interior Fixed Shelf"
    bl_description = (
        "Split the selected opening or region into a bottom and top "
        "section with a fixed shelf"
    )
    bl_options = {'UNDO'}

    target_name: bpy.props.StringProperty(
        name="Target Name", default="",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # Always allow - target_name carries the indirection these
        # operators need when called from inside a popup whose active
        # object can go stale mid-edit. execute() validates via
        # _resolve_interior_target and reports a clean warning if the
        # target can't be resolved.
        return True

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            return {'CANCELLED'}
        if (target.get(types_face_frame.TAG_OPENING_CAGE)
                and any(c.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE)
                        or c.get(types_face_frame.TAG_INTERIOR_REGION)
                        for c in target.children)):
            self.report({'WARNING'},
                        "Opening already has interior splits - "
                        "select a region to subdivide")
            return {'CANCELLED'}

        if _split_active_region(target, axis='H') is None:
            self.report({'WARNING'},
                        "Select an opening or interior region first")
            return {'CANCELLED'}

        root = types_face_frame.find_cabinet_root(target)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


def _collect_subtree_items_into(node, dest_collection):
    """Recursively walk the interior subtree rooted at `node` and copy
    every leaf's interior_items into `dest_collection`. Doesn't modify
    or delete the source tree - the caller handles teardown.
    """
    if node.get(types_face_frame.TAG_INTERIOR_REGION):
        _copy_interior_items(
            node.face_frame_interior_region.interior_items,
            dest_collection,
        )
        return
    if not node.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE):
        return
    children = sorted(
        [c for c in node.children
         if c.get(types_face_frame.TAG_INTERIOR_REGION)
         or c.get(types_face_frame.TAG_INTERIOR_SPLIT_NODE)],
        key=lambda c: c.get('hb_interior_child_index', 0),
    )
    for c in children:
        _collect_subtree_items_into(c, dest_collection)


class hb_face_frame_OT_remove_interior_split(bpy.types.Operator):
    """Remove an interior region's parent split, merging both sides
    of the split (and any nested regions under them) into a single
    flat list of items.

    If the removed split was the opening's tree root, the merged
    items fold back to the opening's flat interior_items collection
    and the opening returns to the no-tree state. Otherwise a new
    merged leaf takes the split's slot in the grandparent.

    target_name selects which leaf identifies the split to remove
    (its parent split). When two children share a parent, removing
    the split via either child gives the same result, so any leaf
    in the affected pair is a valid target.
    """
    bl_idname = "hb_face_frame.remove_interior_split"
    bl_label = "Remove Interior Split"
    bl_description = (
        "Remove the division or fixed shelf next to this region and "
        "combine the two sides back into one"
    )
    bl_options = {'UNDO'}

    target_name: bpy.props.StringProperty(
        name="Target Name",
        description="Region object whose parent split should be removed",
        default="",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # Always allow - target_name carries the indirection this
        # operator needs from popups whose active_object can go stale
        # mid-edit (e.g., shelf right-click flow). execute() validates
        # via _resolve_interior_target and reports a clean warning if
        # the region can't be resolved.
        return True

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None or not target.get(
                types_face_frame.TAG_INTERIOR_REGION):
            self.report({'WARNING'},
                        "Select an interior region first")
            return {'CANCELLED'}

        parent_split = target.parent
        if (parent_split is None
                or not parent_split.get(
                    types_face_frame.TAG_INTERIOR_SPLIT_NODE)):
            self.report({'WARNING'},
                        "Region has no parent split to remove")
            return {'CANCELLED'}

        grandparent = parent_split.parent
        is_root_split = (
            grandparent is not None
            and grandparent.get(types_face_frame.TAG_OPENING_CAGE)
        )
        root = types_face_frame.find_cabinet_root(target)
        guard_id = id(root) if root is not None else None

        if is_root_split:
            # Fold back to flat opening: merged items go on the
            # opening's flat collection, entire subtree torn down.
            opening = grandparent
            dest = opening.face_frame_opening.interior_items
            dest.clear()  # flat collection should already be empty
            for c in list(parent_split.children):
                _collect_subtree_items_into(c, dest)
            hb_utils.delete_obj_and_children(parent_split)
        else:
            # Replace split with a merged leaf in the grandparent's
            # slot. The new leaf inherits the split's size + unlock
            # state so sibling redistribution stays balanced.
            split_index = parent_split.get('hb_interior_child_index', 0)
            split_props = parent_split.face_frame_interior_split
            split_size = split_props.size
            split_unlock = split_props.unlock_size

            new_leaf = types_face_frame.FaceFrameInteriorRegion()
            new_leaf.create('Region')
            new_leaf.obj.parent = grandparent
            new_leaf.obj['hb_interior_child_index'] = split_index

            # Seed size + unlock as a system write so the user-edit
            # auto-lock callback skips them.
            if guard_id is not None:
                types_face_frame._DISTRIBUTING_WIDTHS.add(guard_id)
            try:
                rp = new_leaf.obj.face_frame_interior_region
                rp.size = split_size
                rp.unlock_size = split_unlock
            finally:
                if guard_id is not None:
                    types_face_frame._DISTRIBUTING_WIDTHS.discard(guard_id)

            # Gather subtree items into the new leaf, then tear down
            # the old subtree (children get hauled in by the recursive
            # delete helper).
            dest = new_leaf.obj.face_frame_interior_region.interior_items
            for c in list(parent_split.children):
                _collect_subtree_items_into(c, dest)
            hb_utils.delete_obj_and_children(parent_split)

        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


class hb_face_frame_OT_show_interior_add_menu(bpy.types.Operator):
    """Pop a menu of every interior add option (subdivisions and item
    kinds) for one target. Replaces the older multi-row button grid.

    The target_name property is captured into a closure-based draw
    function so each menu item stamps the right target on its
    operator regardless of which leaf was clicked. Lets one Add
    button serve every leaf in the inline tree view without each
    leaf needing its own row of buttons.
    """
    bl_idname = "hb_face_frame.show_interior_add_menu"
    bl_label = "Add Interior..."
    bl_description = (
        "Show a menu of items that can be added to this opening or "
        "region (divisions, shelves, drawers, rollouts, and more)"
    )
    bl_options = {'UNDO'}

    target_name: bpy.props.StringProperty(
        name="Target Name", default="",
    )  # type: ignore

    def execute(self, context):
        target_name = self.target_name

        def draw_fn(menu_self, _ctx):
            layout = menu_self.layout

            # Subdivisions
            op = layout.operator(
                "hb_face_frame.add_interior_division",
                text="Division", icon='MOD_ARRAY',
            )
            op.target_name = target_name
            op = layout.operator(
                "hb_face_frame.add_interior_fixed_shelf",
                text="Fixed Shelf", icon='SNAP_FACE',
            )
            op.target_name = target_name

            layout.separator()

            # Shelves
            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Adjustable Shelf",
            )
            op.kind = 'ADJUSTABLE_SHELF'
            op.half_depth = False
            op.target_name = target_name

            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Glass Shelf",
            )
            op.kind = 'GLASS_SHELF'
            op.half_depth = False
            op.target_name = target_name

            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Half-Depth Shelf",
            )
            op.kind = 'HALF_DEPTH_SHELF'
            op.half_depth = False
            op.target_name = target_name

            op = layout.operator(
                "hb_face_frame.add_interior_item",
                text="Quarter-Depth Shelf",
            )
            op.kind = 'QUARTER_DEPTH_SHELF'
            op.half_depth = False
            op.target_name = target_name

            layout.separator()

            # Pullouts / rollouts / tray dividers. Named the way the
            # trade names them on a spec sheet: a roll-out shelf is a
            # flat shelf on slides, a roll-out is a drawer box on
            # slides. Same wording as the Kind dropdown and the legend.
            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Roll-out Shelf",
            )
            op.kind = 'PULLOUT_SHELF'
            op.half_depth = False
            op.target_name = target_name

            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Roll-out",
            )
            op.kind = 'ROLLOUT'
            op.half_depth = False
            op.target_name = target_name

            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Tray Dividers",
            )
            op.kind = 'TRAY_DIVIDERS'
            op.half_depth = False
            op.target_name = target_name

            layout.separator()

            # Vanity / accessory
            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Vanity Shelves",
            )
            op.kind = 'VANITY_SHELVES'
            op.half_depth = False
            op.target_name = target_name

            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Text",
                icon='FONT_DATA',
            )
            op.kind = 'ACCESSORY'
            op.half_depth = False
            op.target_name = target_name

            op = layout.operator(
                "hb_face_frame.add_interior_item", text="Closet Rod",
            )
            op.kind = 'CLOSET_ROD'
            op.half_depth = False
            op.target_name = target_name

            layout.separator()

            # Tableware & Bar Storage Solutions - auto-sized from
            # the opening; every kind is a single derived-mesh insert.
            layout.label(text="Bar Storage")
            for bar_kind, bar_label in (
                ('WINE_CUBBY',       "Wine Storage Cubby"),
                ('WINE_CELLAR',      "Wine Cellar Rack"),
                ('WINE_LATTICE',     "Lattice Wine Rack"),
                ('WINE_X',           "X-Style Wine Rack"),
                ('WINE_DIAGONAL',    "Diagonal Wine Dividers"),
                ('WINE_HALF_CIRCLE', "Half Circle Wine Rack"),
                ('STEMWARE_RACK',    "Stemware Rack"),
                ('PLATE_RACK',       "Plate Rack"),
            ):
                op = layout.operator(
                    "hb_face_frame.add_interior_item", text=bar_label,
                )
                op.kind = bar_kind
                op.half_depth = False
                op.target_name = target_name

            # Operator buttons in a popup_menu default to EXEC context,
            # which would skip invoke() and add the default item without
            # showing the picker. Force INVOKE so the props dialog opens.
            layout.operator_context = 'INVOKE_DEFAULT'
            # One catalog browser for every accessory host (the per-host
            # pickers were consolidated here). The dialog groups by the
            # catalog's own category and routes by host on apply. Left
            # out when no host has registered a catalog.
            if accessory_registry.available(*_ALL_ACCESSORY_HOSTS):
                op = layout.operator(
                    "hb_face_frame.accessory_menu",
                    text="Add Accessory...",
                )
                op.target_name = target_name

        context.window_manager.popup_menu(
            draw_fn, title="Add Interior", icon='ADD',
        )
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Bay rebuild helpers (used by change_bay)
# ---------------------------------------------------------------------------
def _wipe_bay_children(bay_obj):
    """Delete every descendant of bay_obj. The bay cage itself and its
    parent (the cabinet root) are untouched. Cabinet-level face frame
    parts (left/right stiles, top/bottom rails) are children of the
    cabinet root, not the bay, so they're safe.
    """
    import bpy
    descendants = list(bay_obj.children_recursive)
    # Reverse so deeper objects unparent before their ancestors.
    for child in reversed(descendants):
        if child.name in bpy.data.objects:
            bpy.data.objects.remove(child, do_unlink=True)


# Opening presets whose front is a drawer box or a fixed panel in front
# of one - the fronts that need no carcass shelf behind their mid rail.
_DRAWER_STACK_CONFIGS = frozenset({'DRAWER', 'FALSE_FRONT', 'PULLOUT'})


def _recipe_is_drawer_stack(recipe):
    """True when every front under this recipe node is drawer-like, so
    the stack is a drawer bank rather than a mixed door / appliance
    cabinet. Recurses through nested splits (a row of two drawers side
    by side still counts)."""
    kind = recipe[0]
    if kind == 'leaf':
        return recipe[1] in _DRAWER_STACK_CONFIGS
    if kind == 'split':
        children = recipe[2]
        return bool(children) and all(
            _recipe_is_drawer_stack(c) for c in children)
    return False


def _build_recipe_into(recipe, parent_obj, child_index,
                       opening_idx_counter, cab_props):
    """Materialize a bay_presets recipe tree as objects under parent_obj.

    Leaf -> creates one Opening cage and applies its opening preset.
    Split -> creates a Split Node empty with the right axis and splitter
             width, then recurses into each child.

    opening_idx_counter is a single-element mutable list used as a
    shared counter across recursive calls so opening_index values are
    unique within the bay.
    """
    import bpy
    kind = recipe[0]
    # size_role lives in slot 3 for both leaf and split tuples (added
    # for top-drawer pinning in BASE drawer presets). Older 3-tuples
    # default to None so callers that haven't been updated still work.
    size_role = recipe[3] if len(recipe) > 3 else None

    def apply_size_role(props):
        """Pin a node's size + unlock_size based on its size_role.
        New roles get added here; the value they map to is a scene-level
        preference or, where no meaningful preference exists, a fixed
        constant.

        Order matters: unlock_size MUST be written before size. Each
        prop write fires a recalc, and a recalc with this node still
        marked unlocked will redistribute and overwrite size with the
        node's share of the available space. Writing unlock_size first
        means the recalc triggered by the size write sees a locked
        node and leaves the value alone.
        """
        # Persist the role on the node object so a later re-sync (the Top
        # Drawer Opening Height refresh) can find these nodes; size_role
        # itself is only a transient recipe slot, not stored anywhere.
        if size_role:
            props.id_data['SIZE_ROLE'] = size_role
        if size_role == 'TOP_DRAWER':
            # Scene-level preference, not per-cabinet.
            props.unlock_size = True
            props.size = bpy.context.scene.hb_face_frame.top_drawer_opening_height
        elif size_role == 'TALL_SPLIT_BOTTOM':
            # Scene-level preference, not per-cabinet.
            props.unlock_size = True
            props.size = bpy.context.scene.hb_face_frame.tall_cabinet_split_height
        elif size_role == 'UPPER_STACKED_TOP':
            # Scene-level preference, not per-cabinet.
            props.unlock_size = True
            props.size = bpy.context.scene.hb_face_frame.upper_top_stacked_cabinet_height
        elif size_role == 'REFRIGERATOR':
            # Pins the bottom appliance opening of a refrigerator
            # cabinet to the scene's refrigerator_height so the
            # door zone above flexes with the cabinet height.
            props.unlock_size = True
            props.size = bpy.context.scene.hb_face_frame.refrigerator_height
        elif size_role == 'GARAGE_BOTTOM':
            # Pins a garage opening to the cabinet's stored counter
            # extension (written by the Appliance Garage toggle) minus
            # the mid rail, so the doors above keep their opening.
            root = types_face_frame.find_cabinet_root(props.id_data)
            ext = float(root.get('hb_garage_extension', 0.0)) if root else 0.0
            if ext > 0.0:
                props.unlock_size = True
                props.size = max(
                    ext - root.face_frame_cabinet.bay_mid_rail_width,
                    inch(4.0))
        elif size_role == 'VANITY_SINK_WIDTH':
            # Pins a vanity sink false front to a fixed 20" width so the
            # flanking drawers absorb the bay's width changes. A constant
            # rather than a preference - the false front stays adjustable
            # per-cabinet after placement.
            props.unlock_size = True
            props.size = 0.508  # 20"
        elif size_role == 'BOOKCASE_STORAGE_BOTTOM':
            # Pins the Bookcase Storage Unit's bottom door zone to a fixed
            # 30" so the open-shelf zone above flexes with cabinet height.
            # A constant, not a scene preference; stays editable per-cabinet
            # after placement.
            props.unlock_size = True
            props.size = 0.762  # 30"

    if kind == 'leaf':
        config = recipe[1]
        overrides = recipe[2] if len(recipe) > 2 else {}
        opening = types_face_frame.FaceFrameOpening()
        opening.create('Opening')
        opening.obj.parent = parent_obj
        opening.obj['hb_split_child_index'] = child_index
        opening.obj.face_frame_opening.opening_index = opening_idx_counter[0]
        opening_idx_counter[0] += 1
        apply_opening_preset(opening.obj, config, **overrides)
        apply_size_role(opening.obj.face_frame_opening)
        return

    if kind == 'split':
        axis = recipe[1]
        children = recipe[2]
        split_obj = hb_utils.new_object('Split Node', None)
        bpy.context.scene.collection.objects.link(split_obj)
        split_obj.empty_display_type = 'PLAIN_AXES'
        split_obj.empty_display_size = 0.001
        split_obj[types_face_frame.TAG_SPLIT_NODE] = True
        split_obj.parent = parent_obj
        split_obj['hb_split_child_index'] = child_index
        sp = split_obj.face_frame_split
        sp.axis = axis
        sp.splitter_width = (cab_props.bay_mid_rail_width if axis == 'H'
                             else cab_props.bay_mid_stile_width)
        # A drawer bank is mid rails only - the boxes ride on the sides,
        # so there is no floor behind each rail. Anything else (doors or
        # an appliance in the stack) keeps the shelf; the right-click
        # Add / Remove Shelf Behind Mid Rail covers the rest per member.
        if axis == 'H' and _recipe_is_drawer_stack(('split', axis, children)):
            sp.add_backing = False
        apply_size_role(sp)
        for i, child_recipe in enumerate(children):
            _build_recipe_into(child_recipe, split_obj, i,
                               opening_idx_counter, cab_props)
        return

    raise ValueError(f"Unknown recipe node kind: {kind!r}")


# ---------------------------------------------------------------------------
# Operator: change opening configuration (right-click quick presets)
# ---------------------------------------------------------------------------
# Each preset is a dict of actions the operator runs on the active
# opening. Recognized keys:
#   'front_type'      - required, written to op_props.front_type
#   'hinge_side'      - optional, written when present
#   'shelves'         - 'CLEAR' to remove ADJUSTABLE_SHELF items, or
#                       'ENSURE' to add one if missing. Omitted means
#                       leave shelves alone (the front_type callback
#                       still auto-adds for DOOR).
#   'appliance_label' - True to ensure an ACCESSORY item with label
#                       'Appliance' is present
_OPENING_PRESETS = {
    'OPEN':              {'front_type': 'NONE',         'shelves': 'CLEAR'},
    'OPEN_WITH_SHELVES': {'front_type': 'NONE',         'shelves': 'ENSURE'},
    'LEFT_DOOR':         {'front_type': 'DOOR',         'hinge_side': 'LEFT'},
    'RIGHT_DOOR':        {'front_type': 'DOOR',         'hinge_side': 'RIGHT'},
    'DOUBLE_DOOR':       {'front_type': 'DOOR',         'hinge_side': 'DOUBLE'},
    'DOOR_LOOKS_2_DRAWER': {'front_type': 'DOOR', 'hinge_side': 'LEFT', 'drawer_look': '2'},
    'DOOR_LOOKS_3_DRAWER': {'front_type': 'DOOR', 'hinge_side': 'LEFT', 'drawer_look': '3'},
    'DOOR_LOOKS_4_DRAWER': {'front_type': 'DOOR', 'hinge_side': 'LEFT', 'drawer_look': '4'},
    'FLIP_UP_DOOR':      {'front_type': 'DOOR',         'hinge_side': 'TOP'},
    'FLIP_DOWN_DOOR':    {'front_type': 'DOOR',         'hinge_side': 'BOTTOM'},
    # Retracting mechanisms: regular door fronts plus the door_mechanism
    # stamp (the solver applies the interior clearances; downstream 2D
    # prints the labels). 'mechanism' is applied unconditionally in
    # apply_opening_preset so plain presets clear a previous stamp.
    'RETRACTING_DOOR':        {'front_type': 'DOOR', 'hinge_side': 'LEFT',
                               'mechanism': 'RETRACTING'},
    'RETRACTING_DOOR_PAIR':   {'front_type': 'DOOR', 'hinge_side': 'DOUBLE',
                               'mechanism': 'RETRACTING'},
    'BIFOLD_RETRACTING_DOOR': {'front_type': 'DOOR', 'hinge_side': 'DOUBLE',
                               'mechanism': 'RETRACTING_BIFOLD'},
    'TOP_RETRACTING_DOOR':    {'front_type': 'DOOR', 'hinge_side': 'TOP',
                               'mechanism': 'RETRACTING_TOP'},
    'DRAWER':            {'front_type': 'DRAWER_FRONT'},
    'PULLOUT':           {'front_type': 'PULLOUT'},
    'INSET_PANEL':       {'front_type': 'INSET_PANEL', 'shelves': 'CLEAR'},
    'FALSE_FRONT':       {'front_type': 'FALSE_FRONT'},
    # Tilt-out: a drawer-styled front hinged on the bottom (its own front_type
    # now, not a FALSE_FRONT + label flag).
    'TILT_OUT':          {'front_type': 'TILT_OUT'},
    # APPLIANCE: appliance front_type (auto left/right filler stiles fitting
    # the appliance width) with no shelves. The ACCESSORY 'Appliance' label is
    # kept so the appliance name still prints on 2D drawings / legend.
    'APPLIANCE':         {'front_type': 'APPLIANCE',
                          'shelves': 'CLEAR',
                          'appliance_label': True},
}


def apply_opening_preset(opening_obj, config, **overrides):
    """Programmatic version of hb_face_frame.change_opening - applies the
    named preset's prop changes to a specific opening object without
    going through bpy.ops. The caller is responsible for triggering a
    recalc when it's done batching changes.

    Recognized overrides:
      accessory_label  - replaces the label on the (typically just-added)
                         ACCESSORY interior item. Used by the bay
                         presets to set 'Microwave' instead of the
                         default 'Appliance' on appliance labels.
      no_shelves       - strip ADJUSTABLE_SHELF items AFTER the
                         front_type write. Must run after, not before:
                         writing front_type = DOOR fires
                         _update_front_type, which re-seeds a shelf
                         item on any door opening that lacks one. Used
                         by the sink presets so the plumbing zone under
                         the basin comes in empty.
    """
    preset = _OPENING_PRESETS[config]
    op_props = opening_obj.face_frame_opening

    # Mutate interior_items first so the recalc kicked off by the
    # front_type write below sees the final state in one pass.
    shelves = preset.get('shelves')
    if shelves == 'CLEAR':
        for i in range(len(op_props.interior_items) - 1, -1, -1):
            if op_props.interior_items[i].kind in ('ADJUSTABLE_SHELF',
                                                   'HALF_DEPTH_SHELF',
                                                   'QUARTER_DEPTH_SHELF'):
                op_props.interior_items.remove(i)
    elif shelves == 'ENSURE':
        has_shelves = any(
            item.kind in ('ADJUSTABLE_SHELF', 'HALF_DEPTH_SHELF',
                          'QUARTER_DEPTH_SHELF')
            for item in op_props.interior_items
        )
        if not has_shelves:
            op_props.interior_items.add()

    if preset.get('appliance_label'):
        has_accessory = any(
            item.kind == 'ACCESSORY' for item in op_props.interior_items
        )
        if not has_accessory:
            new_item = op_props.interior_items.add()
            new_item.kind = 'ACCESSORY'
            new_item.accessory_label = "APPLIANCE"

    op_props.front_type = preset['front_type']
    # Unconditional so re-applying any non-tilt-out preset (including
    # plain FALSE_FRONT) clears a previous tilt-out designation.
    op_props.is_tilt_out = bool(preset.get('tilt_out'))
    # Same rule for the door mechanism: plain presets drop a previous
    # retracting designation.
    op_props.door_mechanism = preset.get('mechanism', 'NONE')
    if 'hinge_side' in preset:
        op_props.hinge_side = preset['hinge_side']

    # Drawer-look door: a single DOOR leaf shown as N stacked drawer
    # fronts. Set after front_type / hinge so it lands on a valid door;
    # its update seeds the per-opening height rows. Unconditional so
    # re-applying another preset drops a previous drawer-look.
    op_props.drawer_look_divisions = preset.get('drawer_look', 'NONE')

    # Post-front_type shelf strip (see docstring: the DOOR write above
    # re-seeds a shelf, so this must come after it).
    if overrides.get('no_shelves'):
        for i in range(len(op_props.interior_items) - 1, -1, -1):
            if op_props.interior_items[i].kind in ('ADJUSTABLE_SHELF',
                                                   'HALF_DEPTH_SHELF',
                                                   'QUARTER_DEPTH_SHELF'):
                op_props.interior_items.remove(i)

    # Apply post-preset overrides. accessory_label targets the most
    # recent ACCESSORY item - for fresh openings the preset just added
    # one; for re-applied presets we deliberately retarget the existing
    # item so the user's named appliance reflects the new preset.
    accessory_label = overrides.get('accessory_label')
    if accessory_label is not None:
        for item in reversed(op_props.interior_items):
            if item.kind == 'ACCESSORY':
                item.accessory_label = accessory_label
                break


class hb_face_frame_OT_change_opening(bpy.types.Operator):
    """Apply a named opening preset to every selected opening cage.

    Drives front_type, hinge_side, and the ADJUSTABLE_SHELF interior
    item in one click. Used by the right-click 'Change Opening' submenu.
    Lets the user reach the common configurations without opening the
    full opening properties dialog.
    """
    bl_idname = "hb_face_frame.change_opening"
    bl_label = "Change Opening"
    bl_description = (
        "Change the selected opening to a preset front type (door, "
        "drawer, pullout, open shelves, etc.) in one click"
    )
    bl_options = {'UNDO'}

    config: bpy.props.EnumProperty(
        name="Configuration",
        items=[
            ('OPEN',              "Open",              "Open opening with no interior items"),
            ('OPEN_WITH_SHELVES', "Open with Shelves", "Open opening with adjustable shelves"),
            ('LEFT_DOOR',         "Left Door",         "Single door hinged on the left"),
            ('RIGHT_DOOR',        "Right Door",        "Single door hinged on the right"),
            ('DOUBLE_DOOR',       "Double Door",       "Pair of doors meeting in the middle"),
            ('FLIP_UP_DOOR',      "Flip Up Door",      "Door hinged on the top edge"),
            ('FLIP_DOWN_DOOR',    "Flip Down Door",    "Door hinged on the bottom edge"),
            ('RETRACTING_DOOR',   "Retracting Door",   "Single door that opens, then slides back into the cabinet"),
            ('RETRACTING_DOOR_PAIR', "Retracting Doors (Pair)", "Pair of doors that open, then slide back into the cabinet"),
            ('BIFOLD_RETRACTING_DOOR', "Bi-fold Retracting Doors", "Hinged pair that folds, then slides back into the cabinet"),
            ('TOP_RETRACTING_DOOR', "Top-Mount Retracting Door", "Full-width door that retracts up into the cabinet"),
            ('DRAWER',            "Drawer",            "Drawer front"),
            ('PULLOUT',           "Pullout",           "Door front on a pullout slide"),
            ('INSET_PANEL',       "Inset Panel",       "Recessed 1/4\" panel filling the opening"),
            ('FALSE_FRONT',       "False Front",       "Decorative drawer-style panel; fixed"),
            ('TILT_OUT',          "Tilt-Out",          "Drawer-style front hinged on the bottom; tilts down to open"),
            ('APPLIANCE',         "Appliance",         "Opening reserved for an appliance"),
        ],
        default='OPEN',
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get(types_face_frame.TAG_OPENING_CAGE))

    def execute(self, context):
        active = context.active_object
        if not active or not active.get(types_face_frame.TAG_OPENING_CAGE):
            self.report({'WARNING'}, "Select an opening first")
            return {'CANCELLED'}

        openings = [o for o in context.selected_objects
                    if o.get(types_face_frame.TAG_OPENING_CAGE)]
        if active not in openings:
            openings.append(active)

        # One outer suspend so every opening's preset writes coalesce
        # into a single recalc per affected cabinet. The explicit recalc
        # per opening also covers re-applying the same config: an
        # unchanged front_type fires no callback, but interior_items may
        # still have been mutated (e.g. shelves cleared), so the cabinet
        # must be recalculated regardless.
        with types_face_frame.suspend_recalc():
            for opening_obj in openings:
                apply_opening_preset(opening_obj, self.config)
                types_face_frame.recalculate_face_frame_cabinet(opening_obj)

        self.report({'INFO'}, f"Changed {len(openings)} opening(s)")

        # A PULLOUT opening prompts for its accessory model + min-width check.
        if self.config == 'PULLOUT' and active is not None \
                and active.get(types_face_frame.TAG_OPENING_CAGE):
            return bpy.ops.hb_face_frame.add_pullout_accessory(
                'INVOKE_DEFAULT', opening_name=active.name)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operator: choose a pullout accessory model for pullout opening(s).
# The product list comes from whatever catalog the host application
# registered in accessory_registry (HB5 ships none), so HB5 stays
# catalog-agnostic. Selecting a model is data only - it records a code on
# the opening and has no 3D effect.
# ---------------------------------------------------------------------------
_PULLOUT_HOST = "opening_interior_pullout"
# Enum item lists must stay alive at module scope: Blender keeps only the
# char* of each string, so a list built and dropped inside the callback can
# be garbage-collected and crash the UI.
_pullout_category_items = []
_pullout_product_items = []


def _pullout_catalog_available():
    """Whether a host application has registered pullout models. Without
    one the dialog is only about the opening width, so it shows only
    that -- a Category and Model row reading "(no catalog)" is noise."""
    return bool(accessory_registry.categories(_PULLOUT_HOST))


def _pullout_category_enum(self, context):
    _pullout_category_items.clear()
    for cat in accessory_registry.categories(_PULLOUT_HOST):
        _pullout_category_items.append((cat, cat, cat))
    if not _pullout_category_items:
        _pullout_category_items.append(
            ('NONE', "(no catalog)", "No accessory catalog is registered"))
    return _pullout_category_items


def _pullout_product_enum(self, context):
    _pullout_product_items.clear()
    for it in accessory_registry.get_items(_PULLOUT_HOST):
        if it.get('category') != self.category:
            continue
        code = it.get('code')
        if not code:
            continue
        name = it.get('name', code)
        mw = it.get('min_opening_w')
        label = name if mw is None else "%s  (min %g\")" % (name, mw)
        _pullout_product_items.append((code, label, name))
    if not _pullout_product_items:
        _pullout_product_items.append(('NONE', "(none)", "No models in this category"))
    return _pullout_product_items


def _opening_width_in(opening_obj):
    if opening_obj is None:
        return None
    return meter_to_inch(opening_obj.dimensions.x)


def _find_pullout_openings(bay_obj):
    """Descendant opening cages of bay_obj whose front_type is PULLOUT."""
    found = []
    stack = list(getattr(bay_obj, 'children', []))
    while stack:
        o = stack.pop()
        stack.extend(o.children)
        if o.get(types_face_frame.TAG_OPENING_CAGE):
            fo = getattr(o, 'face_frame_opening', None)
            if fo is not None and fo.front_type == 'PULLOUT':
                found.append(o)
    return found


def _find_bay(opening_obj):
    """The bay cage that owns this opening, walking up parents."""
    p = getattr(opening_obj, 'parent', None)
    while p is not None:
        if p.get(types_face_frame.TAG_BAY_CAGE):
            return p
        p = p.parent
    return None


class hb_face_frame_OT_add_pullout_accessory(bpy.types.Operator):
    """Choose a pullout accessory model for the selected pullout
    opening(s) and show the model's minimum opening width."""
    bl_idname = "hb_face_frame.add_pullout_accessory"
    bl_label = "Pullout Model"
    bl_description = (
        "Choose a pullout accessory model for the opening and show its "
        "minimum opening width"
    )
    bl_options = {'UNDO'}

    category: bpy.props.EnumProperty(name="Category", items=_pullout_category_enum)  # type: ignore
    product: bpy.props.EnumProperty(name="Model", items=_pullout_product_enum)  # type: ignore
    # Explicit target so the bay route (where the active object is the bay,
    # not the freshly-built pullout opening) doesn't depend on selection.
    opening_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    opening_width: bpy.props.FloatProperty(
        name="Opening Width", unit='LENGTH', precision=4, min=0.0,
        description="Clear opening width for the pullout (sets the bay width)",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # Always invoked programmatically (with an explicit opening_name, or
        # with a pullout opening active), so don't gate on context here --
        # the real target is resolved and validated in invoke / execute.
        return True

    def _resolve_opening(self, context):
        """Target opening: the cached opening_name if set, else the active
        object when it is an opening cage."""
        if self.opening_name:
            return bpy.data.objects.get(self.opening_name)
        obj = context.active_object
        if obj is not None and obj.get(types_face_frame.TAG_OPENING_CAGE):
            return obj
        return None

    def invoke(self, context, event):
        opening_obj = self._resolve_opening(context)
        if opening_obj is None:
            self.report({'WARNING'}, "Select a pullout opening first")
            return {'CANCELLED'}
        self.opening_name = opening_obj.name
        bay = _find_bay(opening_obj)
        if bay is not None and getattr(bay, 'face_frame_bay', None) is not None:
            self.opening_width = bay.face_frame_bay.width
        if not _pullout_catalog_available():
            return context.window_manager.invoke_props_dialog(
                self, width=300, title="Pullout Width")
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        if not _pullout_catalog_available():
            layout.prop(self, "opening_width")
            return
        layout.prop(self, "category")
        layout.prop(self, "product")
        layout.prop(self, "opening_width")
        box = layout.box()
        item = accessory_registry.lookup(_PULLOUT_HOST, self.product)
        if item is None:
            box.label(text="No model selected")
            return
        box.label(text="Model: %s" % item.get('name', self.product))
        mw = item.get('min_opening_w')
        if mw is None:
            box.label(text="Minimum opening width: not specified")
        else:
            box.label(text="Minimum opening width: %g\"" % mw)
            ow = meter_to_inch(self.opening_width)
            if ow + 1e-6 < mw:
                box.label(
                    text="Opening width %g\" is below the %g\" minimum" % (ow, mw),
                    icon='ERROR')

    def execute(self, context):
        if self.opening_name:
            target = bpy.data.objects.get(self.opening_name)
            openings = [target] if target is not None \
                and target.get(types_face_frame.TAG_OPENING_CAGE) else []
        else:
            active = context.active_object
            openings = [o for o in context.selected_objects
                        if o.get(types_face_frame.TAG_OPENING_CAGE)]
            if active is not None and active.get(types_face_frame.TAG_OPENING_CAGE) \
                    and active not in openings:
                openings.append(active)
        if not openings:
            self.report({'WARNING'}, "Select a pullout opening first")
            return {'CANCELLED'}

        code = "" if self.product in ('NONE', '') else self.product
        with types_face_frame.suspend_recalc():
            for opening_obj in openings:
                op_props = opening_obj.face_frame_opening
                if op_props.front_type != 'PULLOUT':
                    apply_opening_preset(opening_obj, 'PULLOUT')
                op_props.pullout_accessory_code = code
                bay = _find_bay(opening_obj)
                if bay is not None and self.opening_width > 0.0 \
                        and getattr(bay, 'face_frame_bay', None) is not None:
                    bay.face_frame_bay.width = self.opening_width
                types_face_frame.recalculate_face_frame_cabinet(opening_obj)

        if code:
            self.report({'INFO'}, "Set pullout model on %d opening(s)" % len(openings))
        else:
            self.report({'INFO'}, "Cleared pullout model on %d opening(s)" % len(openings))
        return {'FINISHED'}


_INTERIOR_HOST = "opening_interior_accessory"
_interior_product_items = []


def _interior_product_enum(self, context):
    _interior_product_items.clear()
    for it in accessory_registry.get_items(self.host):
        code = it.get('code')
        if not code:
            continue
        name = it.get('name', code)
        mw = it.get('min_opening_w')
        label = name if mw is None else "%s  (min %g\")" % (name, mw)
        _interior_product_items.append((code, label, name))
    if not _interior_product_items:
        _interior_product_items.append(('NONE', "(none)", "No accessories available"))
    return _interior_product_items


class hb_face_frame_OT_add_interior_accessory(bpy.types.Operator):
    """Add a catalog interior accessory (used behind a standard swing
    door) to the selected opening or region as an ACCESSORY interior
    item. Data only -- drives the 2D legend + reports, no 3D effect."""
    bl_idname = "hb_face_frame.add_interior_accessory"
    bl_label = "Add Accessory"
    bl_description = (
        "Add an accessory from the catalog to the selected opening and "
        "show its minimum opening width"
    )
    bl_options = {'UNDO'}

    target_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    host: bpy.props.StringProperty(default=_INTERIOR_HOST, options={'HIDDEN'})  # type: ignore
    product: bpy.props.EnumProperty(name="Accessory", items=_interior_product_enum)  # type: ignore

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        target = _resolve_interior_target(self, context)
        if target is None or _interior_items_target(target) is None:
            self.report({'WARNING'}, "Select an opening or interior region first")
            return {'CANCELLED'}
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "product")
        box = layout.box()
        item = accessory_registry.lookup(self.host, self.product)
        if item is None:
            box.label(text="No accessory selected")
            return
        box.label(text="Accessory: %s" % item.get('name', self.product))
        mw = item.get('min_opening_w')
        if mw is None:
            box.label(text="Minimum opening width: not specified")
        else:
            box.label(text="Minimum opening width: %g\"" % mw)
            target = _resolve_interior_target(self, context)
            ow = _opening_width_in(target) if target is not None else None
            if ow is not None and ow + 1e-6 < mw:
                box.label(text="Opening is %g\" wide - below the minimum" % ow,
                          icon='ERROR')

    def execute(self, context):
        target = _resolve_interior_target(self, context)
        if target is None:
            self.report({'WARNING'}, "Could not resolve target")
            return {'CANCELLED'}
        target_props = _interior_items_target(target)
        if target_props is None:
            self.report({'WARNING'}, "Select an opening or interior region first")
            return {'CANCELLED'}
        if self.product in ('NONE', ''):
            self.report({'WARNING'}, "No accessory selected")
            return {'CANCELLED'}
        entry = accessory_registry.lookup(self.host, self.product)
        name = entry.get('name', self.product) if entry else self.product
        item = target_props.interior_items.add()
        item.kind = 'ACCESSORY'
        item.accessory_label = name
        item.accessory_code = self.product
        item.accessory_render = ((entry.get('render') or '').upper()
                                 if entry else '')
        target_props.interior_items_index = len(target_props.interior_items) - 1
        root = types_face_frame.find_cabinet_root(target)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        self.report({'INFO'}, "Added %s" % name)
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operator: unified accessory browser. Lists every catalog accessory grouped
# by the catalog's own category (across all registered hosts) and adds the
# chosen item to the selected opening. Pull-out / trash items (host
# opening_interior_pullout) convert the opening front to a pullout and record
# the model on the dedicated field, mirroring add_pullout_accessory; every
# other host stores the pick as a data-only ACCESSORY interior item. HB5 ships
# no catalog, so the lists come from accessory_registry providers (the host
# application supplies the product data).
# ---------------------------------------------------------------------------
_ACCESSORY_PULLOUT_HOST = "opening_interior_pullout"
_ALL_ACCESSORY_HOSTS = {
    'opening_interior_pullout', 'opening_interior_accessory', 'tall_pantry',
    'behind_door_rollout', 'pullout_board', 'tilt_out', 'closet_rod',
    'door_mounted', 'drawer_accessory', 'blind_corner_hardware',
}
# Enum item lists must stay alive at module scope (Blender keeps only the
# char* of each string).
_accessory_section_items = []


def _valid_accessory_hosts(opening_obj):
    """Host keys whose accessories make sense for ``opening_obj`` (strict
    context filter). ``opening_obj`` may be the opening cage itself or any
    descendant (interior region, split node, part) the user clicked - the
    owning opening cage is resolved first so the front type is read off the
    real opening, not whatever leaf happened to be active. Drawer-front
    openings -> drawer inserts only; an opening in a blind-corner cabinet ->
    blind-corner hardware only; otherwise every opening host, with door-
    mounted items gated to openings that have a door. Returns an EMPTY set
    when no owning opening / front type can be resolved, so a detection miss
    shows nothing (and the menu prompts to select an opening) rather than
    dumping the whole catalog."""
    opening = _find_owning_opening(opening_obj) if opening_obj is not None else None
    if opening is None:
        return set()
    fo = getattr(opening, 'face_frame_opening', None)
    front = fo.front_type if fo is not None else None
    if front is None:
        return set()
    if front == 'DRAWER_FRONT':
        return {'drawer_accessory'}
    root = types_face_frame.find_cabinet_root(opening)
    cab = getattr(root, 'face_frame_cabinet', None) if root is not None else None
    if (cab is not None and (getattr(cab, 'blind_left', False)
                             or getattr(cab, 'blind_right', False))
            # The garage bottom opening is ordinary garage storage even
            # on a blind cabinet (the blind zone is handled by the
            # section treatment, not by corner hardware in THIS
            # opening) - it keeps the standard host set.
            and opening.get('SIZE_ROLE') != 'GARAGE_BOTTOM'):
        return {'blind_corner_hardware'}
    hosts = {'opening_interior_pullout', 'opening_interior_accessory',
             'tall_pantry', 'behind_door_rollout', 'pullout_board',
             'tilt_out', 'closet_rod'}
    if front == 'DOOR':
        hosts.add('door_mounted')
    return hosts


def _accessory_target(operator, context):
    """The object the accessory menu/dialog acts on (cached name or active)."""
    name = getattr(operator, 'target_name', '') or ''
    if name:
        obj = bpy.data.objects.get(name)
        if obj is not None:
            return obj
    return context.active_object


def _section_has_valid(section, valid):
    return any(it.get('host') in valid for it in accessory_registry.all_items()
               if it.get('section') == section)


def _accessory_section_enum(self, context):
    """The catalog sections holding something valid for this opening,
    behind an All entry. Drives the section dropdown in the Add
    Accessory dialog, so browsing by category needs no drill-down."""
    _accessory_section_items.clear()
    _accessory_section_items.append(
        ('ALL', "All Sections", "Everything that fits this opening"))
    valid = _valid_accessory_hosts(_accessory_target(self, context))
    for sec in accessory_registry.sections():
        if _section_has_valid(sec, valid):
            _accessory_section_items.append((sec, sec, sec))
    return _accessory_section_items


def _draw_accessory_notes(box, item, code, is_pullout, region_pullout, ow_in):
    """The note block under a chosen accessory: what it is, whether it
    is modelled, and how its minimum opening width compares with the
    opening it is going into.

    An accessory is an ORDER line first: it is what goes on the
    drawings, the legend and the report. Most are not modelled, and
    picking one expecting shelves to appear is an easy mistake to make
    - so say which this one is, and where to go if the 3D was the
    point.
    """
    box.label(text="Accessory: %s" % item.get('name', code))
    if not is_pullout and not types_face_frame.render_hint_kind(
            (item.get('render') or '').upper()):
        box.label(text="Called out on the drawings; not shown in 3D",
                  icon='INFO')
        box.label(text="To see it, add the matching interior item "
                       "(Roll-outs, Shelves, ...) as well")
    if region_pullout:
        box.label(text="Adds the pullout inside this divider region "
                       "(front unchanged)", icon='INFO')
    elif is_pullout:
        box.label(text="Adds a pullout front to the opening", icon='INFO')
    mw = item.get('min_opening_w')
    if mw is None:
        box.label(text="Minimum opening width: not specified")
        return
    box.label(text="Minimum opening width: %g\"" % mw)
    if ow_in is not None and ow_in + 1e-6 < mw:
        box.label(
            text="Opening width %g\" is below the %g\" minimum" % (ow_in, mw),
            icon='ERROR')


def _apply_accessory_choice(operator, context, target, code, item,
                            opening_width=0.0):
    """Put one catalog model on ``target`` and report what happened.

    Shared by the Add Accessory dialog and the group picker so both
    routes place a model identically. Pull-out / trash hosts convert
    the opening front and record the model on the dedicated field,
    mirroring hb_face_frame.add_pullout_accessory - except inside a
    divider region, where the front belongs to the whole opening and
    is left alone, the model stored as a data-only item instead. Every
    other host becomes an ACCESSORY interior item, which drives the 2D
    legend and the reports and grows geometry only when the catalog
    entry carries a render hint.
    """
    host = item.get('host')
    name = item.get('name', code)

    def _store_item(props_owner, message):
        props = _interior_items_target(props_owner)
        if props is None:
            operator.report({'WARNING'},
                            "Select an opening or interior region first")
            return {'CANCELLED'}
        new_item = props.interior_items.add()
        new_item.kind = 'ACCESSORY'
        new_item.accessory_label = name
        new_item.accessory_code = code
        new_item.accessory_render = (item.get('render') or '').upper()
        props.interior_items_index = len(props.interior_items) - 1
        root = types_face_frame.find_cabinet_root(props_owner)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        operator.report({'INFO'}, message)
        return {'FINISHED'}

    if host == _ACCESSORY_PULLOUT_HOST:
        if target.get(types_face_frame.TAG_INTERIOR_REGION):
            return _store_item(
                target,
                "Added %s to the divider region (front unchanged)" % name)
        if not target.get(types_face_frame.TAG_OPENING_CAGE):
            operator.report(
                {'WARNING'},
                "Pull-outs attach to an opening - select the opening cage")
            return {'CANCELLED'}
        with types_face_frame.suspend_recalc():
            op_props = target.face_frame_opening
            if op_props.front_type != 'PULLOUT':
                apply_opening_preset(target, 'PULLOUT')
            op_props.pullout_accessory_code = code
            bay = _find_bay(target)
            if bay is not None and opening_width > 0.0                     and getattr(bay, 'face_frame_bay', None) is not None:
                bay.face_frame_bay.width = opening_width
            types_face_frame.recalculate_face_frame_cabinet(target)
        operator.report({'INFO'}, "Set pullout model: %s" % name)
        return {'FINISHED'}

    return _store_item(target, "Added %s" % name)


def _populate_accessory_search(operator, context):
    """Fill ``operator.matches`` with the catalog accessories valid for the
    opening, narrowed by ``operator.filter_text`` and - where the operator
    offers one - its ``section_filter`` pick. The text filter is split into
    space-separated tokens; every token must appear (case-insensitively)
    somewhere in the item's name / section / group / code. Called on invoke
    and on every keystroke (via the operator's ``check``)."""
    operator.matches.clear()
    valid = _valid_accessory_hosts(_accessory_target(operator, context))
    tokens = operator.filter_text.lower().split()
    section_pick = getattr(operator, 'section_filter', 'ALL')
    for it in accessory_registry.all_items():
        if it.get('host') not in valid:
            continue
        code = it.get('code')
        if not code:
            continue
        name = it.get('name', code)
        sec = it.get('section', '')
        grp = it.get('group', '')
        if section_pick not in ('', 'ALL') and sec != section_pick:
            continue
        if tokens:
            hay = (" ".join((name, sec, grp, code))).lower()
            if not all(tok in hay for tok in tokens):
                continue
        row = operator.matches.add()
        row.code = code
        row.name = name
        row.section = sec
        row.group = grp
        row.render_kind = types_face_frame.render_hint_kind(
            (it.get('render') or '').upper())
        mw = it.get('min_opening_w')
        row.label = name if mw is None else "%s  (min %g\")" % (name, mw)
    operator.active_index = min(operator.active_index,
                                max(0, len(operator.matches) - 1))


# ---------------------------------------------------------------------------
# Operator: accessory picker. One dialog does the whole job - a search box
# and a section dropdown narrow a single list of everything that fits the
# selected opening, and the highlighted model's notes sit under the list, so
# picking an accessory never leaves the window. (It used to walk sections
# then groups through stacked popups, with a Back button to climb out.)
# Everything is filtered to the opening's valid hosts (strict context
# filter). HB5 stays catalog-agnostic: the section/group/item tree comes
# from the accessory_registry providers.
# ---------------------------------------------------------------------------
class HB_UL_face_frame_accessory_search(bpy.types.UIList):
    """Result list for the accessory picker: model name (with any
    minimum-width note) on the left, its catalog section / group on the
    right."""
    def draw_item(self, context, layout, data, item, icon, active_data,
                  active_propname):
        split = layout.split(factor=0.55)
        split.label(text=item.label,
                    icon='MESH_GRID' if item.render_kind else 'DOT')
        loc = ("%s / %s" % (item.section, item.group)
               if item.group else item.section)
        split.label(text=loc)


def _accessory_search_update(self, context):
    """Live filter as the user types (filter_text uses TEXTEDIT_UPDATE) or
    picks a different section."""
    _populate_accessory_search(self, context)


class hb_face_frame_OT_accessory_menu(bpy.types.Operator):
    """Browse and add a catalog accessory to the opening: one list of
    everything that fits, narrowed by a search box and a section
    dropdown."""
    bl_idname = "hb_face_frame.accessory_menu"
    bl_label = "Add Accessory"
    bl_description = "Browse and add a catalog accessory to the opening"
    bl_options = {'UNDO'}

    target_name: bpy.props.StringProperty(default="", options={'HIDDEN'})  # type: ignore
    filter_text: bpy.props.StringProperty(
        name="Search",
        description="Filter accessories by name, section, group or code",
        options={'TEXTEDIT_UPDATE'}, update=_accessory_search_update,
    )  # type: ignore
    section_filter: bpy.props.EnumProperty(
        name="Section", items=_accessory_section_enum,
        description="Show one catalog section, or all of them",
        update=_accessory_search_update,
    )  # type: ignore
    matches: bpy.props.CollectionProperty(type=AccessorySearchRow)  # type: ignore
    active_index: bpy.props.IntProperty(default=0)  # type: ignore
    opening_width: bpy.props.FloatProperty(
        name="Opening Width", unit='LENGTH', precision=4, min=0.0,
        description="Clear opening width for a pullout (sets the bay width)",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        # Nothing to browse without a host catalog; the menus leave the
        # entry out on the same test, this keeps a stale button honest.
        return accessory_registry.available(*_ALL_ACCESSORY_HOSTS)

    def _selected_row(self):
        """The highlighted result row, or None when the list is empty."""
        if len(self.matches) == 0:
            return None
        return self.matches[max(0, min(self.active_index,
                                       len(self.matches) - 1))]

    def _selected(self):
        """(code, catalog item) for the highlighted row, or (None, None)."""
        row = self._selected_row()
        if row is None:
            return None, None
        return row.code, accessory_registry.find(row.code)

    def invoke(self, context, event):
        # Cache the target so the dialog keeps addressing the same opening
        # even if the active object changes while it is open.
        if not self.target_name:
            tgt = _resolve_interior_target(self, context)
            if tgt is not None:
                self.target_name = tgt.name
        target = _accessory_target(self, context)
        # Seed the width field from the bay, for the pullout hosts that
        # write it back.
        bay = _find_bay(target) if target is not None else None
        if bay is not None and getattr(bay, 'face_frame_bay', None) is not None:
            self.opening_width = bay.face_frame_bay.width
        self.filter_text = ""
        self.active_index = 0
        _populate_accessory_search(self, context)
        return context.window_manager.invoke_props_dialog(self, width=620)

    def check(self, context):
        # Any edit in the dialog re-runs the filter and forces a redraw, so
        # the list follows the search box keystroke by keystroke.
        _populate_accessory_search(self, context)
        return True

    def draw(self, context):
        layout = self.layout
        head = layout.row(align=True)
        head.prop(self, "filter_text", text="", icon='VIEWZOOM')
        head.prop(self, "section_filter", text="")
        if len(self.matches) == 0:
            layout.label(
                text=("No accessories fit this opening"
                      if not self.filter_text and self.section_filter == 'ALL'
                      else "Nothing matches that search"),
                icon='INFO')
            return
        layout.template_list(
            "HB_UL_face_frame_accessory_search", "",
            self, "matches",
            self, "active_index",
            rows=10,
        )
        code, item = self._selected()
        if item is None:
            return
        tgt = _resolve_interior_target(self, context)
        is_pullout = item.get('host') == _ACCESSORY_PULLOUT_HOST
        # A pullout aimed at an interior REGION stays a data-only item
        # (no front conversion, no bay-width write) -- the width field
        # would set the BAY width, which is wrong for a divider region.
        region_pullout = (is_pullout and tgt is not None
                          and tgt.get(types_face_frame.TAG_INTERIOR_REGION))
        if is_pullout and not region_pullout:
            layout.prop(self, "opening_width")
            ow = meter_to_inch(self.opening_width)
        else:
            ow = _opening_width_in(tgt) if tgt is not None else None
        _draw_accessory_notes(layout.box(), item, code, is_pullout,
                              region_pullout, ow)

    def execute(self, context):
        code, item = self._selected()
        if item is None:
            self.report({'WARNING'}, "No accessory selected")
            return {'CANCELLED'}
        target = _resolve_interior_target(self, context)
        if target is None:
            self.report({'WARNING'},
                        "Select an opening or interior region first")
            return {'CANCELLED'}
        return _apply_accessory_choice(self, context, target, code, item,
                                       self.opening_width)


def _apply_bay_prop_overrides(bay_obj, config, reset):
    """Write a preset's bay-level construction props (bay_presets.BAY_PROPS).

    Most presets only rebuild the opening tree; a few (Lap Drawer,
    Support Frame) also change how the bay is built. With reset=True the
    managed props (bay_presets.BAY_PROP_DEFAULTS) are first returned to
    stock values, so swapping a bay away from a construction preset
    restores standard construction. Placement-time callers keep
    reset=False so cabinet classes that pre-set these flags on their
    bays (e.g. removed bottoms) are not undone.

    Values are written only when they differ so prop update callbacks
    (remove_bottom's overlay rewrite, kick_height's auto-lock) fire only
    on real changes.
    """
    def differs(current, target):
        if isinstance(target, float):
            return abs(current - target) > 1e-6
        return current != target

    overrides = bay_presets.BAY_PROPS.get(config, {})
    bp = bay_obj.face_frame_bay
    if reset:
        for prop, default in bay_presets.BAY_PROP_DEFAULTS.items():
            if prop in overrides:
                continue  # the override write below carries the final value
            if differs(getattr(bp, prop), default):
                setattr(bp, prop, default)
    for prop, value in overrides.items():
        if differs(getattr(bp, prop), value):
            setattr(bp, prop, value)


def _bay_wants_floor_stiles(bay_obj):
    """True when a bay's construction implies floor stiles: it floats
    (lap drawer) or has no bottom (support frame). Inferred from the
    bay props since bays don't persist their preset id."""
    bp = bay_obj.face_frame_bay
    return bool(bp.floating_bay or bp.remove_bottom)


def _apply_flanking_stile_floor(root, bay_obj, config, reset, was_floor=False):
    """Toggle the to-floor flag on the stiles flanking `bay_obj`.

    Selecting a bay_presets.FLOOR_STILE_CONFIGS preset (Lap Drawer /
    Support Frame) drops both flanking stiles to the floor so they
    carry through the exposed kick zone - the end stile when the bay
    is first / last, the shared mid stile otherwise. Swapping the bay
    back to a normal preset (reset=True) clears the flags again,
    except that a shared mid stile is left down when the bay on its
    OTHER side still needs floor stiles. The clear path never sets a
    flag because of a neighbor - it only declines to clear - so bays
    that float for other reasons (e.g. a floating base cabinet) can't
    drag stiles to the floor on an unrelated preset swap.
    Placement-time callers (reset=False) only ever set flags, never
    clear, mirroring _apply_bay_prop_overrides.

    `was_floor` says whether the bay needed floor stiles BEFORE the
    swap (read by the caller, since the bay props are reset first).
    Only a bay that had them is allowed to take them away again: a
    stile that was dropped to the floor deliberately has to survive
    an unrelated layout change.
    """
    want = config in bay_presets.FLOOR_STILE_CONFIGS
    if not want and not (reset and was_floor):
        return
    cab = root.face_frame_cabinet
    bay_index = bay_obj.get('hb_bay_index', 0)
    bays = {b.get('hb_bay_index', 0): b for b in root.children
            if b.get(types_face_frame.TAG_BAY_CAGE)}
    last = max(bays) if bays else 0

    def _neighbor_needs(idx):
        b = bays.get(idx)
        return b is not None and _bay_wants_floor_stiles(b)

    def _set_mid_stile(gap, neighbor_idx):
        if not (0 <= gap < len(cab.mid_stile_widths)):
            return
        ms = cab.mid_stile_widths[gap]
        if want:
            value = True
        elif ms.to_floor and _neighbor_needs(neighbor_idx):
            value = True
        else:
            value = False
        if ms.to_floor != value:
            ms.to_floor = value

    # Left flank: cabinet end stile for the first bay, else the mid
    # stile at gap bay_index - 1 (shared with the bay to the left).
    if bay_index == 0:
        if cab.extend_left_stile_to_floor != want:
            cab.extend_left_stile_to_floor = want
    else:
        _set_mid_stile(bay_index - 1, bay_index - 1)

    # Right flank: end stile for the last bay, else gap bay_index.
    if bay_index == last:
        if cab.extend_right_stile_to_floor != want:
            cab.extend_right_stile_to_floor = want
    else:
        _set_mid_stile(bay_index, bay_index + 1)


def apply_bay_recipe(bay_obj, recipe, config=None, reset_bay_props=False):
    """Wipe `bay_obj`'s contents and rebuild them from a recipe tree.

    The tree has the shape bay_presets builds - ('leaf', config,
    overrides, size_role) and ('split', axis, children, size_role) - but
    the caller supplies it, so a bay layout that is read from somewhere
    else (another program's file, for instance) can be materialized
    without first having to exist as a named preset.

    `config` is optional and only used to look up the bay-level prop
    overrides a named preset carries; pass None when the recipe did not
    come from PRESETS.

    Returns True on success, False if `bay_obj` is not a bay cage or has
    no cabinet root.
    """
    if not bay_obj.get(types_face_frame.TAG_BAY_CAGE):
        return False
    root = types_face_frame.find_cabinet_root(bay_obj)
    if root is None:
        return False
    # Read before the prop reset below wipes the evidence: the stile
    # clear path is only allowed to lift stiles a floor-stile bay put
    # down, so it needs the bay's construction as it was.
    was_floor = _bay_wants_floor_stiles(bay_obj)
    # Wipe + rebuild fires update callbacks on every front_type / overlay /
    # hinge write, and each one triggers a full cabinet recalc. Suspend so
    # the explicit final recalc below is the only one that actually runs.
    with types_face_frame.suspend_recalc():
        _wipe_bay_children(bay_obj)
        opening_idx = [0]
        _build_recipe_into(
            recipe, bay_obj, 0, opening_idx, root.face_frame_cabinet,
        )
        if config is not None:
            _apply_bay_prop_overrides(bay_obj, config, reset_bay_props)
            _apply_flanking_stile_floor(root, bay_obj, config,
                                        reset_bay_props, was_floor)
        types_face_frame.recalculate_face_frame_cabinet(root)
    return True


def apply_bay_preset(bay_obj, config, reset_bay_props=False):
    """Wipe `bay_obj`'s contents and rebuild from a bay preset.
    Programmatic equivalent of hb_face_frame.change_bay's execute body,
    minus the user-feedback bits (active object, report, selection
    mode toggle). The caller is responsible for triggering selection
    refresh if needed; the recalc itself runs here.

    reset_bay_props=True additionally resets the bay-level construction
    props managed by bay_presets.BAY_PROPS (see
    _apply_bay_prop_overrides); the change_bay operator passes True,
    placement-time callers keep the default False.

    Returns True on success, False if the bay's cabinet type has no
    presets or `config` isn't recognized for that type.
    """
    if not bay_obj.get(types_face_frame.TAG_BAY_CAGE):
        return False
    root = types_face_frame.find_cabinet_root(bay_obj)
    if root is None:
        return False
    cabinet_type = root.face_frame_cabinet.cabinet_type
    presets = bay_presets.PRESETS.get(cabinet_type)
    if not presets or config not in presets:
        return False
    return apply_bay_recipe(bay_obj, presets[config], config, reset_bay_props)


# ---------------------------------------------------------------------------
# Operator: flush toe kick toggle (per bay). The kick recess is removed
# and the face frame bottom rail widens to cover the kick zone, butting
# into full-height stiles on the selected run's outer flanks.
# ---------------------------------------------------------------------------
FLUSH_KICK_BOTTOM_RAIL = inch(5.25)
_FLUSH_KICK_EPS = 1e-6


def _bay_is_flush_kick(bay_obj):
    """A bay reads as flush-kick when its kick height is (effectively)
    zero. Only meaningful on base / tall cabinets - uppers carry
    kick_height 0 by construction and are excluded by the operator."""
    return bay_obj.face_frame_bay.kick_height <= _FLUSH_KICK_EPS


class hb_face_frame_OT_set_bay_back_type(bpy.types.Operator):
    """Set the back type on the selected bays.

    Cabinet Default hands the bay back to the cabinet's own back type;
    anything else is built on that bay's back plane, so bays at
    different depths carry their backs where they actually are. A
    working face frame also leaves the carcass back off, since the bay
    has to open from behind.
    """
    bl_idname = "hb_face_frame.set_bay_back_type"
    bl_label = "Set Bay Back Type"
    bl_description = "Set what closes the back of the selected bay(s)"
    bl_options = {'UNDO'}

    back_condition: bpy.props.StringProperty(default='DEFAULT')  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.get(types_face_frame.TAG_BAY_CAGE)

    def execute(self, context):
        bays = [o for o in context.selected_objects
                if o.get(types_face_frame.TAG_BAY_CAGE)]
        active = context.active_object
        if (active is not None and active.get(types_face_frame.TAG_BAY_CAGE)
                and active not in bays):
            bays.append(active)
        if not bays:
            self.report({'WARNING'}, "No bay selected")
            return {'CANCELLED'}
        for bay in bays:
            try:
                # The write carries its own recalc.
                bay.face_frame_bay.back_condition = self.back_condition
            except TypeError:
                self.report({'WARNING'},
                            f"Unknown back type: {self.back_condition}")
                return {'CANCELLED'}
        self.report({'INFO'}, f"Back type set on {len(bays)} bay(s)")
        return {'FINISHED'}


class hb_face_frame_OT_toggle_flush_toe_kick(bpy.types.Operator):
    """Toggle flush toe kick construction on the selected bays.

    Flush = bay kick height 0 (auto-locked so the kick distribution
    leaves it alone) + a wide bottom rail + the stiles on the OUTER
    flanks of the selected run dropped to the floor, so the wide rail
    butts into full-height stiles. Mid stiles BETWEEN selected bays are
    left alone. If any selected bay still has a kick recess the
    operator makes them all flush; when every one is already flush it
    reverts them (kick height unlocks back to the cabinet's toe kick
    height, bottom rail returns to the cabinet default, flank stiles
    lift unless the neighboring bay still needs them).
    """
    bl_idname = "hb_face_frame.toggle_flush_toe_kick"
    bl_label = "Toggle Flush Toe Kick"
    bl_description = ("Set the selected bays to flush toe kick "
                      "construction (no kick recess, wide bottom rail, "
                      "flanking stiles to the floor); run again to revert")
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.get(types_face_frame.TAG_BAY_CAGE)

    def execute(self, context):
        active = context.active_object
        bays = [o for o in context.selected_objects
                if o.get(types_face_frame.TAG_BAY_CAGE)]
        if (active is not None
                and active.get(types_face_frame.TAG_BAY_CAGE)
                and active not in bays):
            bays.append(active)
        # Group per cabinet; uppers have no toe kick to flush.
        by_root = {}
        for bay_obj in bays:
            root = types_face_frame.find_cabinet_root(bay_obj)
            if root is None:
                continue
            if root.face_frame_cabinet.cabinet_type == 'UPPER':
                continue
            by_root.setdefault(root.name, (root, []))[1].append(bay_obj)
        if not by_root:
            self.report({'WARNING'}, "No base / tall bays selected")
            return {'CANCELLED'}
        # One decision for the whole selection: enable when any targeted
        # bay still has a kick recess; revert only when all are flush.
        enable = any(not _bay_is_flush_kick(b)
                     for _root, group in by_root.values() for b in group)
        with types_face_frame.suspend_recalc():
            for root, group in by_root.values():
                self._apply(root, group, enable)
                types_face_frame.recalculate_face_frame_cabinet(root)
        self.report({'INFO'}, "Flush toe kick %s" %
                    ("set" if enable else "removed"))
        return {'FINISHED'}

    def _apply(self, root, group, enable):
        cab = root.face_frame_cabinet
        for bay_obj in group:
            bp = bay_obj.face_frame_bay
            if enable:
                # Writing kick_height auto-locks unlock_kick_height via
                # its update callback (same mechanism BAY_PROPS uses for
                # the lap drawer lift).
                bp.kick_height = 0.0
                bp.unlock_bottom_rail = True
                # The wide rail covers the kick zone plus the rail itself,
                # so it tracks the cabinet's toe kick height + bottom rail
                # width; the constant only backstops degenerate values.
                rail = cab.toe_kick_height + cab.bottom_rail_width
                bp.bottom_rail_width = (rail if rail > _FLUSH_KICK_EPS
                                        else FLUSH_KICK_BOTTOM_RAIL)
            else:
                # Unlocking re-syncs the bay to the cabinet's
                # toe_kick_height on the next recalc distribution.
                if bp.unlock_kick_height:
                    bp.unlock_kick_height = False
                bp.bottom_rail_width = cab.bottom_rail_width
                bp.unlock_bottom_rail = False
        # Flank stiles: only the OUTER flanks of the selected run in
        # this cabinet - mid stiles between selected bays stay put.
        indices = sorted(b.get('hb_bay_index', 0) for b in group)
        lo, hi = indices[0], indices[-1]
        bays_by_idx = {b.get('hb_bay_index', 0): b for b in root.children
                       if b.get(types_face_frame.TAG_BAY_CAGE)}
        last = max(bays_by_idx) if bays_by_idx else 0

        def _neighbor_needs(idx):
            # A neighboring bay outside the run keeps a shared stile on
            # the floor when it floats / lost its bottom (lap drawer,
            # support frame) or is itself flush-kick.
            b = bays_by_idx.get(idx)
            if b is None:
                return False
            return _bay_wants_floor_stiles(b) or _bay_is_flush_kick(b)

        def _set_mid(gap, neighbor_idx):
            if not (0 <= gap < len(cab.mid_stile_widths)):
                return
            ms = cab.mid_stile_widths[gap]
            if enable:
                value = True
            elif ms.to_floor and _neighbor_needs(neighbor_idx):
                value = True
            else:
                value = False
            if ms.to_floor != value:
                ms.to_floor = value

        if lo == 0:
            if cab.extend_left_stile_to_floor != enable:
                cab.extend_left_stile_to_floor = enable
        else:
            _set_mid(lo - 1, lo - 1)
        if hi == last:
            if cab.extend_right_stile_to_floor != enable:
                cab.extend_right_stile_to_floor = enable
        else:
            _set_mid(hi, hi + 1)


# ---------------------------------------------------------------------------
# Operator: change bay configuration (right-click quick presets per
# cabinet type). Wipes the bay's existing tree and rebuilds it from a
# preset recipe in bay_presets.PRESETS.
# ---------------------------------------------------------------------------
class hb_face_frame_OT_change_bay(bpy.types.Operator):
    """Apply a named bay configuration preset to every selected bay cage.

    The preset's available configurations differ by cabinet type. The
    operator looks up bay_presets.PRESETS[cabinet_type][config] and
    materializes its tree of split nodes and openings under the bay,
    replacing whatever was there.

    The two CUSTOM_* configs are special: they reset the bay to a
    single opening and route to the existing split_opening dialog so
    the user picks count and per-opening sizes. Because that dialog
    is interactive and per-opening, the CUSTOM configs act only on
    the active bay, never the wider selection.
    """
    bl_idname = "hb_face_frame.change_bay"
    bl_label = "Change Bay"
    bl_description = (
        "Replace the doors, drawers, and openings in the selected bay(s) "
        "with a preset layout. Custom options open a dialog to set the "
        "number and size of openings yourself"
    )
    bl_options = {'UNDO'}

    config: bpy.props.StringProperty(
        name="Configuration",
        description="Bay preset id from bay_presets (or CUSTOM_VERTICAL / CUSTOM_HORIZONTAL)",
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get(types_face_frame.TAG_BAY_CAGE))

    def execute(self, context):
        active = context.active_object
        if not active or not active.get(types_face_frame.TAG_BAY_CAGE):
            self.report({'WARNING'}, "Select a bay first")
            return {'CANCELLED'}

        # CUSTOM routes are interactive (per-opening split dialog), so
        # they act on the single active bay even with several selected.
        if self.config in ('CUSTOM_VERTICAL', 'CUSTOM_HORIZONTAL'):
            root = types_face_frame.find_cabinet_root(active)
            if root is None:
                self.report({'WARNING'}, "Bay is not part of a cabinet")
                return {'CANCELLED'}
            _wipe_bay_children(active)
            opening_idx = [0]
            _build_recipe_into(
                bay_presets.L('OPEN'), active, 0,
                opening_idx, root.face_frame_cabinet,
            )
            types_face_frame.recalculate_face_frame_cabinet(root)
            new_opening = next(
                (c for c in active.children
                 if c.get(types_face_frame.TAG_OPENING_CAGE)), None
            )
            if new_opening is None:
                return {'FINISHED'}
            bpy.ops.object.select_all(action='DESELECT')
            new_opening.select_set(True)
            context.view_layer.objects.active = new_opening
            axis = 'V' if self.config == 'CUSTOM_VERTICAL' else 'H'
            return bpy.ops.hb_face_frame.split_opening('INVOKE_DEFAULT', axis=axis)

        # Regular presets apply to every selected bay. Bays whose cabinet
        # type doesn't define this config are skipped (apply_bay_preset
        # returns False), so a mixed selection is handled gracefully.
        bays = [o for o in context.selected_objects
                if o.get(types_face_frame.TAG_BAY_CAGE)]
        if active not in bays:
            bays.append(active)

        changed_roots = set()
        changed = skipped = 0
        # One outer suspend so every bay's rebuild coalesces into a
        # single recalc per affected cabinet.
        with types_face_frame.suspend_recalc():
            for bay_obj in bays:
                if apply_bay_preset(bay_obj, self.config,
                                    reset_bay_props=True):
                    changed += 1
                    root = types_face_frame.find_cabinet_root(bay_obj)
                    if root is not None:
                        changed_roots.add(root.name)
                else:
                    skipped += 1

        if changed == 0:
            self.report({'WARNING'},
                        f"No selected bay accepts config {self.config!r}")
            return {'CANCELLED'}

        # Re-apply selection mode so the rebuilt cages render correctly
        # instead of staying in their default colors.
        for root_name in changed_roots:
            try:
                bpy.ops.hb_face_frame.toggle_mode(search_obj_name=root_name)
            except RuntimeError:
                pass

        if skipped:
            self.report({'INFO'},
                        f"Changed {changed} bay(s), skipped {skipped}")
        else:
            self.report({'INFO'}, f"Changed {changed} bay(s)")

        # If the active bay's new layout has exactly one pullout opening,
        # prompt for its accessory model (with the min-width check).
        pullouts = _find_pullout_openings(active)
        if len(pullouts) == 1:
            return bpy.ops.hb_face_frame.add_pullout_accessory(
                'INVOKE_DEFAULT', opening_name=pullouts[0].name)
        return {'FINISHED'}


class hb_face_frame_OT_insert_bay(bpy.types.Operator):
    """Insert a new bay before or after the bay at bay_index. The new
    bay starts width=0 + unlock_width=False so the recalc redistributor
    immediately gives it an equal share of unlocked space; height and
    depth follow the cabinet's defaults."""
    bl_idname = "hb_face_frame.insert_bay"
    bl_label = "Insert Bay"
    bl_description = "Insert a new bay before or after the chosen bay"
    bl_options = {'REGISTER', 'UNDO'}

    bay_index: bpy.props.IntProperty(
        name="Bay Index",
        description="Index of the existing bay this insert is anchored to",
        default=0, min=0,
    )  # type: ignore
    direction: bpy.props.EnumProperty(
        name="Direction",
        items=[
            ('BEFORE', "Before", "Insert to the left of the anchor bay"),
            ('AFTER',  "After",  "Insert to the right of the anchor bay"),
        ],
        default='AFTER',
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        return types_face_frame.find_cabinet_root(context.active_object) is not None

    def execute(self, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.report({'ERROR'}, "No face frame cabinet selected")
            return {'CANCELLED'}
        cab = types_face_frame._wrap_cabinet(root)
        cab.insert_bay(self.bay_index, self.direction)

        # A user-driven insert on an applied panel pins its opening count
        # so the host recalc's auto-split stops overriding it. The auto
        # path calls insert_bay as a method (not via this operator), so it
        # won't trip this. Setting the flag recalcs the host panel.
        if (root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
                or types_face_frame._is_standalone_panel(root)):
            root.face_frame_cabinet.panel_split_auto = False

        # Reapply the cabinet's current selection mode so the new bay's
        # cage / opening / parts inherit the right visual treatment
        # instead of staying on default colors. Scoped via
        # search_obj_name. Same pattern split_opening uses.
        try:
            bpy.ops.hb_face_frame.toggle_mode(search_obj_name=root.name)
        except RuntimeError:
            pass
        return {'FINISHED'}


class hb_face_frame_OT_delete_bay(bpy.types.Operator):
    """Delete the bay at bay_index. Removes the bay's full subtree
    (openings, fronts, pulls, interior items) and one mid-stile +
    mid-div pair. Deleting a cabinet's ONLY bay deletes the whole
    cabinet - an empty shell has no use, so the command degrades to
    Delete Cabinet (the bay menu relabels itself to say so)."""
    bl_idname = "hb_face_frame.delete_bay"
    bl_label = "Delete Bay"
    bl_description = ("Delete a bay and its mid stile / mid division. "
                      "Deleting the only bay deletes the cabinet")
    bl_options = {'REGISTER', 'UNDO'}

    bay_index: bpy.props.IntProperty(
        name="Bay Index",
        description="Index of the bay to remove",
        default=0, min=0,
    )  # type: ignore

    @classmethod
    def poll(cls, context):
        return types_face_frame.find_cabinet_root(context.active_object) is not None

    def execute(self, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.report({'ERROR'}, "No face frame cabinet selected")
            return {'CANCELLED'}
        cab = types_face_frame._wrap_cabinet(root)
        n_bays = sum(1 for c in root.children
                     if c.get(types_face_frame.TAG_BAY_CAGE))
        if n_bays <= 1:
            # Deleting the only bay would leave an empty shell, so the
            # command degrades to deleting the cabinet - same cleanup
            # as Delete Cabinet, scoped to THIS root so other selected
            # cabinets are untouched. Applied panels are the exception:
            # they're owned by the host cabinet's finished-end config,
            # which would be orphaned by a direct delete.
            if root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE):
                self.report({'ERROR'},
                            "Cannot delete an applied panel's only bay")
                return {'CANCELLED'}
            name = root.name
            hb_utils.delete_obj_and_children(root)
            self.report({'INFO'}, f"Deleted cabinet {name}")
            return {'FINISHED'}
        ok = cab.delete_bay(self.bay_index)
        if not ok:
            self.report({'ERROR'}, "Cannot delete the only remaining bay")
            return {'CANCELLED'}
        # A user-driven delete on an applied panel pins its opening count
        # so the host recalc's auto-split stops overriding it (the auto
        # path calls delete_bay as a method, not via this operator).
        if (root.get(types_face_frame.TAG_APPLIED_PANEL_SIDE)
                or types_face_frame._is_standalone_panel(root)):
            root.face_frame_cabinet.panel_split_auto = False
        return {'FINISHED'}


class hb_face_frame_OT_set_equal_door_width(bpy.types.Operator):
    """Equalize visible door widths across the selected bays.

    Selection sets the scope. Pick two or more bays and only those bays
    share their combined width - every other bay in the cabinet holds
    the width it has. Pick a single bay (the right-click case) and the
    whole cabinet containing it is balanced, which is the original
    behavior. Each cabinet's own width floats by the change in its bay
    total so a cross-cabinet target can still be honored.

    Bay door count rule: a bay contributes 2 doors and one
    DOUBLE_DOOR_REVEAL gap if any opening reached from the bay tree
    root via H-splits only is a DOOR with hinge_side='DOUBLE'.
    Otherwise the bay is treated as 1 door of width = bay width
    regardless of front_type. V-split nodes shrink children's
    widths so they short-circuit the descent."""
    bl_idname = "hb_face_frame.set_equal_door_width"
    bl_label = "Set Equal Door Width"
    bl_description = (
        "Make the selected bays' door widths equal. Select two or more "
        "bays to leave the rest of the cabinet alone; select one bay to "
        "balance its whole cabinet"
    )
    bl_options = {'REGISTER', 'UNDO'}

    # Reveal between the two leaves of a pair. Mirrors
    # solver_face_frame.DOUBLE_DOOR_REVEAL / INSET_DOUBLE_DOOR_REVEAL;
    # not imported to keep this operator's deps the same as its
    # neighbors. Inset leaves butt closer than overlay leaves, so the
    # gap has to be read per cabinet (_pair_gap) or a pair on an inset
    # cabinet comes out 1/32" wider per leaf than the single doors
    # beside it -- the one thing this command exists to prevent.
    _DOUBLE_DOOR_REVEAL = inch(0.125)
    _INSET_DOUBLE_DOOR_REVEAL = inch(0.0625)

    @classmethod
    def _pair_gap(cls, root):
        """Leaf-to-leaf reveal a double-door bay on this cabinet builds
        with. Same test the solver uses: a positive door inset amount
        means the fronts sit in the frame (full or partial inset)."""
        if root.face_frame_cabinet.default_door_inset_amount > 0:
            return cls._INSET_DOUBLE_DOOR_REVEAL
        return cls._DOUBLE_DOOR_REVEAL

    @classmethod
    def poll(cls, context):
        for obj in context.selected_objects:
            if obj.get(types_face_frame.TAG_BAY_CAGE):
                return True
        ao = context.active_object
        return ao is not None and bool(ao.get(types_face_frame.TAG_BAY_CAGE))

    @staticmethod
    def _bay_has_full_width_double_door(bay_obj):
        TAG_OP = types_face_frame.TAG_OPENING_CAGE
        TAG_SP = types_face_frame.TAG_SPLIT_NODE
        roots = [c for c in bay_obj.children
                 if c.get(TAG_OP) or c.get(TAG_SP)]
        if not roots:
            return False

        def walk(node):
            if node.get(TAG_OP):
                op = node.face_frame_opening
                return (op.front_type == 'DOOR'
                        and op.hinge_side == 'DOUBLE')
            if node.get(TAG_SP):
                # Only H-splits keep children at the bay's full width.
                if node.face_frame_split.axis != 'H':
                    return False
                for c in node.children:
                    if c.get(TAG_OP) or c.get(TAG_SP):
                        if walk(c):
                            return True
            return False

        return walk(roots[0])

    def execute(self, context):
        # Collect the picked bays and their cabinet roots (the active
        # object counts too - right-click usually activates without
        # selecting).
        candidates = list(context.selected_objects)
        if (context.active_object is not None
                and context.active_object not in candidates):
            candidates.append(context.active_object)
        picked_names = set()
        roots = []
        seen = set()
        for obj in candidates:
            if not obj.get(types_face_frame.TAG_BAY_CAGE):
                continue
            picked_names.add(obj.name)
            root = types_face_frame.find_cabinet_root(obj)
            if root is not None and root.name not in seen:
                roots.append(root)
                seen.add(root.name)
        if not roots:
            self.report({'WARNING'}, "Select at least one face frame bay")
            return {'CANCELLED'}

        # Two or more bays picked -> the selection IS the scope: those
        # bays pool only their own width, so the pool is conserved and
        # bays outside it neither get resized nor drift when the cabinet
        # redistributes. One bay picked keeps the cabinet-wide behavior.
        subset = len(picked_names) > 1

        # Per-bay info: (bay_obj, root, is_double_door_bay). Bay width
        # == face frame opening width on every construction, scribed
        # WALL ends included -- the wall stile EXTENDS past the cabinet
        # by the scribe (FF plane = width + scribe), it does not eat
        # into the openings. So no scribe terms belong in the door
        # math; only the width resync below needs to be construction-
        # agnostic.
        all_bays = []
        for root in roots:
            bays = sorted(
                [c for c in root.children
                 if c.get(types_face_frame.TAG_BAY_CAGE)],
                key=lambda c: c.get('hb_bay_index', 0),
            )
            for bay in bays:
                if subset and bay.name not in picked_names:
                    continue
                all_bays.append((bay, root,
                                 self._bay_has_full_width_double_door(bay)))

        # Pool budget. Each bay's overlay AND pair gap come from its
        # own cabinet so cabinets with different ff_door_overlay - or a
        # mix of overlay and inset - still balance.
        total_bay_widths = sum(b.face_frame_bay.width for b, _, _ in all_bays)
        # Each bay's overlay budget is (left + right) at the cabinet
        # default. Per-opening overlay overrides are not consulted in
        # v1 - same simplification a single-overlay model would make.
        total_overlay_pad = sum(
            (r.face_frame_cabinet.default_left_overlay
             + r.face_frame_cabinet.default_right_overlay)
            for _, r, _ in all_bays
        )
        total_pair_gap = sum(self._pair_gap(r)
                             for _, r, dd in all_bays if dd)
        num_doors = sum(2 if dd else 1 for _, _, dd in all_bays)
        if num_doors == 0:
            self.report({'WARNING'}, "No doors to equalize")
            return {'CANCELLED'}

        total_visible = (total_bay_widths
                         + total_overlay_pad
                         - total_pair_gap)
        target_door_width = total_visible / num_doors

        # Write new bay widths under one suspended recalc, then float
        # each cabinet's overall width by the CHANGE in its bay total.
        # Delta-preserving on purpose: recomputing the width as
        # stiles + bays assumes stiles + openings tile exactly dim_x,
        # which a scribed WALL end breaks -- its stile extends PAST the
        # cabinet by the scribe (FF plane = width + scribe), so that
        # resync grew a scribed cabinet by exactly its scribe (measured
        # live: 48.75" -> 49.75" with a 1" right scribe). Adding the
        # delta keeps every construction idiosyncrasy (wall-stile
        # scribes, blind offsets) intact while still letting width move
        # between cabinets so the cross-cabinet target is honored.
        bay_totals_before = {
            root.name: sum(
                c.face_frame_bay.width for c in root.children
                if c.get(types_face_frame.TAG_BAY_CAGE))
            for root in roots
        }
        with types_face_frame.suspend_recalc():
            for bay, root, is_double in all_bays:
                cp = root.face_frame_cabinet
                lr_pad = cp.default_left_overlay + cp.default_right_overlay
                if is_double:
                    new_w = (2.0 * target_door_width - lr_pad
                             + self._pair_gap(root))
                else:
                    new_w = target_door_width - lr_pad
                bp = bay.face_frame_bay
                bp.unlock_width = True
                bp.width = new_w

            for root in roots:
                cp = root.face_frame_cabinet
                bay_total = sum(
                    c.face_frame_bay.width for c in root.children
                    if c.get(types_face_frame.TAG_BAY_CAGE))
                delta = bay_total - bay_totals_before[root.name]
                if abs(delta) > 1e-9:
                    cp.width = cp.width + delta

        if subset:
            self.report(
                {'INFO'},
                f"Equalized {len(all_bays)} selected bay(s); the rest of "
                f"the cabinet was left alone")
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Operator: group selected face frame cabinets into a saveable cage group
# ---------------------------------------------------------------------------
def _find_group_member_root(obj):
    """Walk obj's parent chain to find the root that belongs in a
    cabinet group: a face-frame cabinet cage, a bare product cage
    (Support Frame, Half Wall, ...), a misc part, or an appliance.
    Returns the root Object or None.
    """
    cur = obj
    while cur is not None:
        if cur.get(types_face_frame.TAG_CABINET_CAGE):
            return cur
        if (cur.get(types_face_frame.TAG_PRODUCT_CAGE)
                or cur.get('IS_FRAMELESS_PRODUCT_CAGE')):
            return cur
        if cur.get('IS_FACE_FRAME_MISC_PART'):
            return cur
        if cur.get('IS_APPLIANCE'):
            return cur
        cur = cur.parent
    return None


class hb_face_frame_OT_create_cabinet_group(bpy.types.Operator):
    """Group selected face frame cabinets under a single cage that can be
    saved to the user library.

    The group cage is a generic GeoNodeCage with IS_CAGE_GROUP - the same
    marker frameless uses, so save/load is shared via a common library
    folder.
    """
    bl_idname = "hb_face_frame.create_cabinet_group"
    bl_label = "Create Cabinet Group"
    bl_description = "Group the selected face frame cabinets into a single cabinet group"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Walk each selected object up to its group-member root: a face-
        # frame cabinet cage OR an appliance. Appliances (dishwasher,
        # range, etc.) belong in an island group too, even though their
        # widths don't change with resize ops.
        roots = []
        seen = set()
        for obj in context.selected_objects:
            root = _find_group_member_root(obj)
            if root is not None and root.name not in seen:
                seen.add(root.name)
                roots.append(root)

        if not roots:
            self.report({'WARNING'},
                        "No face frame cabinets or appliances selected")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')
        group_obj = create_cabinet_group_from_roots(roots)
        group_obj.select_set(True)
        context.view_layer.objects.active = group_obj
        return {'FINISHED'}

    def _calculate_group_bounds(self, roots):
        """World-space AABB across all roots, returned as the back-left-bottom
        corner for a Mirror-Y cage (origin at back, +Y is back, geometry
        extends -Y into the room).
        """
        if not roots:
            return (Vector((0, 0, 0)), (0, 0, 0), 0, 0, 0)

        min_x = float('inf'); max_x = float('-inf')
        min_y = float('inf'); max_y = float('-inf')
        min_z = float('inf'); max_z = float('-inf')

        for root in roots:
            if root.get(types_face_frame.TAG_CABINET_CAGE):
                cab_props = root.face_frame_cabinet
                cw, cd, ch = cab_props.width, cab_props.depth, cab_props.height
            elif root.get('IS_FACE_FRAME_MISC_PART'):
                # Misc Part: a lone board with Length/Width/Thickness inputs
                # (no Dim X/Y/Z), same Mirror-Y frame as a cabinet.
                geo = hb_types.GeoNodeObject(root)
                cw = geo.get_input('Length')
                cd = geo.get_input('Width')
                ch = geo.get_input('Thickness')
            else:
                # Appliance: dims come off the GeoNodeObject inputs.
                geo = hb_types.GeoNodeObject(root)
                cw = geo.get_input('Dim X')
                cd = geo.get_input('Dim Y')
                ch = geo.get_input('Dim Z')

            # Cabinet local frame: origin at back, depth in -Y (Mirror Y).
            local_corners = [
                Vector((0,   0, 0)),
                Vector((cw,  0, 0)),
                Vector((0,  -cd, 0)),
                Vector((cw, -cd, 0)),
                Vector((0,   0, ch)),
                Vector((cw,  0, ch)),
                Vector((0,  -cd, ch)),
                Vector((cw, -cd, ch)),
            ]

            mw = _resolved_world_matrix(root)
            for lc in local_corners:
                wc = mw @ lc
                min_x = min(min_x, wc.x); max_x = max(max_x, wc.x)
                min_y = min(min_y, wc.y); max_y = max(max_y, wc.y)
                min_z = min(min_z, wc.z); max_z = max(max_z, wc.z)

        overall_w = max_x - min_x
        overall_d = max_y - min_y
        overall_h = max_z - min_z

        # The group cage uses Mirror Y, so its origin sits at +Y (back of
        # the world AABB) and its geometry extends -Y from there.
        location = Vector((min_x, max_y, min_z))
        rotation = (0, 0, 0)

        return (location, rotation, overall_w, overall_d, overall_h)


def _resolved_world_matrix(obj):
    """``obj.matrix_world`` that is safe to read from any scene.

    ``Object.matrix_world`` is depsgraph-evaluated runtime data: it is not
    stored in the file and is only written back for objects in a view layer
    that has actually been evaluated. An object living in a scene that has
    not been visited in this session therefore reports an identity matrix,
    which silently reads as "sits at the world origin". Anything that groups
    or measures objects in another scene has to fall back to the transform
    that IS stored on the object.

    For an unparented root the basis matrix is the world matrix by
    definition, so prefer it whenever the reported world matrix has gone
    identity on us.
    """
    mw = obj.matrix_world
    if obj.parent is None and mw == Matrix.Identity(4):
        return obj.matrix_basis.copy()
    return mw.copy()


def create_cabinet_group_from_roots(roots, name="New Cabinet Group"):
    """Programmatic core of hb_face_frame.create_cabinet_group: wrap the
    given cabinet / appliance roots in a new IS_CAGE_GROUP cage,
    preserving each root's world transform. Returns the group cage
    object (None for an empty roots list).

    No bpy.ops and no selection handling, so it is callable from any
    context -- the operator delegates here, and the host add-on's 2D generation
    calls it directly to auto-group ungrouped free-standing runs
    (peninsulas) so the island view machinery can target them.
    """
    if not roots:
        return None
    loc, rot, w, d, h = (hb_face_frame_OT_create_cabinet_group.
                         _calculate_group_bounds(None, roots))

    group = hb_types.GeoNodeCage()
    group.create(name)
    group.obj['IS_CAGE_GROUP'] = True
    group.obj.parent = None
    group.obj.location = loc
    group.obj.rotation_euler = rot
    group.set_input('Dim X', w)
    group.set_input('Dim Y', d)
    group.set_input('Dim Z', h)
    # Mirror Y so the group cage matches face frame's cabinet
    # convention: origin at back, geometry extending -Y into the room.
    group.set_input('Mirror Y', True)
    # Right-click menu dispatch: ui/menu_apend reads MENU_ID off the
    # active object and shows the named Menu class.
    group.obj['MENU_ID'] = 'HOME_BUILDER_MT_face_frame_cabinet_group_commands'

    # Reparent preserving world transforms - the user placed these
    # cabinets where they wanted them and the group shouldn't shift
    # them at creation time. The cabinet roots' own cages stay
    # in the scene but hide_viewport=True keeps their wireframes
    # from cluttering the group cage; child parts (carcass, doors,
    # drawers) remain visible because hide_viewport doesn't
    # propagate to children.
    #
    # The child basis is composed by hand rather than assigned through
    # root.matrix_world: that setter solves the basis against the cage's
    # CURRENT evaluated matrix, which is identity on a freshly created
    # object (and stays identity for as long as the cage's scene goes
    # unevaluated), so every member would land displaced by the cage's
    # location. The cage's transform is known exactly right here, so use it.
    group_matrix = (Matrix.Translation(loc)
                    @ Euler(rot, 'XYZ').to_matrix().to_4x4())
    group_matrix_inv = group_matrix.inverted_safe()
    for root in roots:
        world_matrix = _resolved_world_matrix(root)
        root.parent = group.obj
        hb_utils.note_parent_change()
        root.matrix_parent_inverse = Matrix.Identity(4)
        root.matrix_basis = group_matrix_inv @ world_matrix
        # Cabinet / product cages get hidden so only the group cage
        # shows (their part children stay visible); appliances keep
        # their visible geometry on the root, so hiding them would
        # make the dishwasher / range disappear.
        if (root.get(types_face_frame.TAG_CABINET_CAGE)
                or root.get(types_face_frame.TAG_PRODUCT_CAGE)
                or root.get('IS_FRAMELESS_PRODUCT_CAGE')):
            root.hide_viewport = True

    # Shade the group cage like a cabinet (solid, addon's cabinet
    # color, drawn in front). Same helper frameless uses on its
    # cabinet roots; dont_show_parent=False forces application
    # even though the group cage has cabinet-cage children that
    # would normally suppress the toggle.
    toggle_cabinet_color(
        group.obj, True,
        type_name=types_face_frame.TAG_CABINET_CAGE,
        dont_show_parent=False,
    )
    return group.obj


def _find_group_cage(obj):
    """Walk obj's parent chain to the cabinet group cage (IS_CAGE_GROUP)
    it belongs to, or None. Lets "Select Cabinet Group" re-collapse a group
    from any selected member - a cabinet root, a bay, or an individual part.
    """
    cur = obj
    while cur is not None:
        if cur.get('IS_CAGE_GROUP'):
            return cur
        cur = cur.parent
    return None


class hb_face_frame_OT_select_cabinet_group(bpy.types.Operator):
    """Re-collapse a cabinet group: hide the member cabinet cages and show
    the group cage as the single selection target.

    Counterpart to entering a selection mode (hb_face_frame_OT_toggle_mode),
    which hides the group cage and surfaces the individual member cabinets.
    Right-clicking a cabinet that belongs to a group offers this so the group
    cage can be recovered after a selection mode hid it.
    """
    bl_idname = "hb_face_frame.select_cabinet_group"
    bl_label = "Select Cabinet Group"
    bl_description = ("Hide the group's member cabinet cages and show the "
                      "cabinet group cage")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _find_group_cage(context.active_object) is not None

    def execute(self, context):
        group = _find_group_cage(context.active_object)
        if group is None:
            self.report({'WARNING'},
                        "Selected object isn't in a cabinet group")
            return {'CANCELLED'}

        bpy.ops.object.select_all(action='DESELECT')

        # Hide every member cabinet / product cage so only the group cage
        # shows - the create-time collapsed state. Appliances keep their
        # visible geometry (real meshes, not just a cage), exactly as
        # Create Cabinet Group leaves them.
        for child in group.children_recursive:
            if (child.get(types_face_frame.TAG_CABINET_CAGE)
                    or child.get(types_face_frame.TAG_PRODUCT_CAGE)):
                child.hide_viewport = True
                child.select_set(False)

        # Show + select the group cage. dont_show_parent=False forces the
        # toggle even though the cage has cabinet-cage children sharing the
        # type tag (which would otherwise suppress it).
        toggle_cabinet_color(
            group, True,
            type_name=types_face_frame.TAG_CABINET_CAGE,
            dont_show_parent=False,
        )
        group.select_set(True)
        context.view_layer.objects.active = group
        return {'FINISHED'}


class hb_face_frame_OT_ungroup_cabinet(bpy.types.Operator):
    """Ungroup a cabinet group: free its member cabinets / appliances and
    delete the group cage. Members keep their world position and become
    independently selectable again - the inverse of Create Cabinet Group.

    The pre-group wall parent is NOT stored at group creation, so members
    are unparented to the scene root (world-transform-preserving clear-
    parent), un-hidden, and the current selection mode is re-applied so they
    render in their correct per-mode state.
    """
    bl_idname = "hb_face_frame.ungroup_cabinet"
    bl_label = "Ungroup Cabinet"
    bl_description = "Delete the group cage and free its member cabinets"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _find_group_cage(context.active_object) is not None

    def execute(self, context):
        group = _find_group_cage(context.active_object)
        if group is None:
            self.report({'WARNING'},
                        "Selected object isn't in a cabinet group")
            return {'CANCELLED'}

        # Free each direct member (cabinet root or appliance), preserving
        # world transform. The original wall parent was dropped at group
        # creation and isn't recoverable, so members land on the scene root.
        members = list(group.children)
        for m in members:
            world_matrix = m.matrix_world.copy()
            m.parent = None
            hb_utils.note_parent_change()
            m.matrix_world = world_matrix
            # Cabinet / product cages were hidden when grouped; show them
            # again so the freed member is selectable. The selection-mode
            # re-apply below then puts them in their correct per-mode state.
            if (m.get(types_face_frame.TAG_CABINET_CAGE)
                    or m.get(types_face_frame.TAG_PRODUCT_CAGE)
                    or m.get('IS_FRAMELESS_PRODUCT_CAGE')):
                m.hide_viewport = False

        # Delete the now-childless group cage (and its cage data). Members
        # were unparented above, so delete_obj_and_children removes only the
        # cage itself.
        hb_utils.delete_obj_and_children(group)

        # Re-apply the active selection mode so the freed cabinets render per
        # the current mode (e.g. Cabinets shows their cages). toggle_mode
        # clears the selection at the end, so re-select the freed members
        # afterward.
        bpy.ops.hb_face_frame.toggle_mode(search_obj_name="")
        bpy.ops.object.select_all(action='DESELECT')
        for m in members:
            m.select_set(True)
        if members:
            context.view_layer.objects.active = members[0]

        self.report({'INFO'}, f"Ungrouped {len(members)} item(s)")
        return {'FINISHED'}


class hb_face_frame_OT_leg_product_prompts(bpy.types.Operator):
    """Popup properties dialog for a leg product (right-click entry)."""
    bl_idname = "hb_face_frame.leg_product_prompts"
    bl_label = "Leg Properties"
    bl_description = "Edit the leg product's dimensions and options"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        return root is not None and bool(root.get('IS_LEG_PRODUCT'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.layout.label(text="No leg product selected", icon='INFO')
            return
        ui_face_frame.draw_identity(self.layout, root)
        self.layout.separator()
        ui_face_frame.draw_leg_product(self.layout, root)


class hb_face_frame_OT_floating_shelf_prompts(bpy.types.Operator):
    """Popup properties dialog for a floating shelf (right-click entry)."""
    bl_idname = "hb_face_frame.floating_shelf_prompts"
    bl_label = "Floating Shelf Properties"
    bl_description = "Edit the floating shelf's dimensions and finished ends"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        return root is not None and bool(root.get('IS_FLOATING_SHELF'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.layout.label(text="No floating shelf selected", icon='INFO')
            return
        ui_face_frame.draw_identity(self.layout, root)
        self.layout.separator()
        ui_face_frame.draw_floating_shelf(self.layout, root)


class hb_face_frame_OT_mantle_prompts(bpy.types.Operator):
    """Popup properties dialog for a mantle (right-click entry)."""
    bl_idname = "hb_face_frame.mantle_prompts"
    bl_label = "Mantle Properties"
    bl_description = "Edit the mantle's style, dimensions, and finished ends"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        return root is not None and bool(root.get('IS_MANTLE_PRODUCT'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.layout.label(text="No mantle selected", icon='INFO')
            return
        ui_face_frame.draw_identity(self.layout, root)
        self.layout.separator()
        ui_face_frame.draw_mantle_product(self.layout, root)


class hb_face_frame_OT_valance_prompts(bpy.types.Operator):
    """Popup properties dialog for a valance (right-click entry)."""
    bl_idname = "hb_face_frame.valance_prompts"
    bl_label = "Valance Properties"
    bl_description = "Edit the valance's dimensions, finished ends, and cover"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        return root is not None and bool(root.get('IS_VALANCE_PRODUCT'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.layout.label(text="No valance selected", icon='INFO')
            return
        ui_face_frame.draw_identity(self.layout, root)
        self.layout.separator()
        ui_face_frame.draw_valance_product(self.layout, root)


class hb_face_frame_OT_column_beam_properties(bpy.types.Operator):
    """Edit a column or beam wrap: which sides are built, framed sides,
    the false ceiling and the order options."""
    bl_idname = "hb_face_frame.column_beam_properties"
    bl_label = "Column / Beam Properties"
    bl_description = "Edit the wrap's sides, framing and options"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        return root is not None and bool(root.get('IS_COLUMN_BEAM_PRODUCT'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=360)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        from .. import ui_face_frame
        root = types_face_frame.find_cabinet_root(context.active_object)
        if root is None:
            self.layout.label(text="No column or beam selected", icon='INFO')
            return
        ui_face_frame.draw_identity(self.layout, root)
        self.layout.separator()
        ui_face_frame.draw_column_beam_product(self.layout, root)


class hb_face_frame_OT_duplicate_floating_shelf(bpy.types.Operator):
    """Duplicate the selected floating shelf vertically by a quantity +
    spacing. Each copy is an independent, separately-editable shelf that
    inherits the source's dimensions, type, finish, and groove."""
    bl_idname = "hb_face_frame.duplicate_floating_shelf"
    bl_label = "Duplicate Floating Shelf"
    bl_description = "Add stacked copies of this floating shelf at a set spacing"
    bl_options = {'UNDO'}

    quantity: bpy.props.IntProperty(
        name="Quantity to Add", default=1, min=1, max=20)  # type: ignore
    spacing: bpy.props.FloatProperty(
        name="Spacing Between Shelves", default=inch(12.0),
        unit='LENGTH', precision=4)  # type: ignore

    _SHELF_PROPS = (
        'finish_left', 'finish_right', 'material_thickness', 'shelf_type',
        'include_groove_top', 'include_groove_bottom',
        'groove_distance_from_rear', 'groove_width', 'groove_depth',
    )

    @classmethod
    def poll(cls, context):
        root = types_face_frame.find_cabinet_root(context.active_object)
        return root is not None and bool(root.get('IS_FLOATING_SHELF'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, 'quantity')
        layout.prop(self, 'spacing')

    def execute(self, context):
        from .. import props_hb_face_frame
        src = types_face_frame.find_cabinet_root(context.active_object)
        if src is None or not src.get('IS_FLOATING_SHELF'):
            self.report({'WARNING'}, "Select a floating shelf first")
            return {'CANCELLED'}

        src_ffc = src.face_frame_cabinet
        src_shelf = src.floating_shelf
        step = src_ffc.height + self.spacing   # thickness + clear gap

        # Resolve the source's cabinet style so copies share materials.
        style = None
        style_name = src.get('STYLE_NAME')
        if style_name:
            sp = props_hb_face_frame.get_style_props(context)
            style = next((s for s in sp.cabinet_styles if s.name == style_name), None)

        new_objs = []
        for i in range(1, self.quantity + 1):
            shelf = types_face_frame.FloatingShelfFaceFrameCabinet()
            shelf.create("Floating Shelf")
            n = shelf.obj
            with types_face_frame.suspend_recalc():
                n.face_frame_cabinet.width = src_ffc.width
                n.face_frame_cabinet.depth = src_ffc.depth
                n.face_frame_cabinet.height = src_ffc.height
                ns = n.floating_shelf
                for prop in self._SHELF_PROPS:
                    setattr(ns, prop, getattr(src_shelf, prop))
            shelf.recalculate()

            n.parent = src.parent
            if src.parent is not None:
                n.matrix_parent_inverse = src.matrix_parent_inverse.copy()
            n.location = src.location.copy()
            n.location.z = src.location.z + step * i
            if style is not None:
                style.assign_style_to_cabinet(n)
            new_objs.append(n)

        for o in context.selected_objects:
            o.select_set(False)
        if new_objs:
            new_objs[-1].select_set(True)
            context.view_layer.objects.active = new_objs[-1]
        self.report({'INFO'}, f"Added {self.quantity} floating shelf(s)")
        return {'FINISHED'}


# Add Appliance to Bay dialog session counter. invoke_props_popup popups
# can LINGER: Esc doesn't dismiss them (it only cancels an in-progress
# field edit) and opening the dialog again stacks a second popup over the
# first. Every live popup keeps its own operator instance alive, and an
# edit on a STALE popup re-executes that instance with its frozen
# properties -- observed as the bay's configuration snapping back to the
# fresh-bay default (False Front with Doors) mid-edit. Each invoke bumps
# this counter and stamps the instance; execute no-ops for any instance
# that is not the newest dialog. List so the closure mutates in place.
_appliance_dialog_session = [0]


def _bay_layout_is_presetlike(bay_obj):
    """True when the bay's current fronts are the door / false-front
    layouts the sink and cooktop presets themselves produce, so the
    dialog's immediate live preview loses nothing by rebuilding them.
    Anything else (a drawer stack, pullouts, a split the user built)
    must NOT be wiped by the seeded first execute -- those bays open
    the dialog on Keep Existing instead."""
    fronts = [c.face_frame_opening.front_type
              for c in bay_obj.children_recursive
              if c.get(types_face_frame.TAG_OPENING_CAGE)]
    if len(fronts) > 2:
        return False
    return all(f in ('NONE', 'DOOR', 'FALSE_FRONT') for f in fronts)


def _set_opening_interior(op_props, interior):
    """Set a door opening's interior to OPEN / SHELF / VANITY_SHELVES by
    rewriting only its shelf-type interior items (ADJUSTABLE_SHELF /
    VANITY_SHELVES). Other interior items (e.g. ACCESSORY labels) are left
    untouched. OPEN clears the shelves entirely.
    """
    items = op_props.interior_items
    for i in range(len(items) - 1, -1, -1):
        if items[i].kind in ('ADJUSTABLE_SHELF', 'HALF_DEPTH_SHELF',
                             'QUARTER_DEPTH_SHELF',
                             'VANITY_SHELVES'):
            items.remove(i)
    if interior == 'SHELF':
        items.add()  # .add() picks up the EnumProperty default ADJUSTABLE_SHELF
    elif interior == 'VANITY_SHELVES':
        items.add().kind = 'VANITY_SHELVES'
    # OPEN -> leave cleared


# A vanity sink opening this wide or wider gets the pair of fixed side
# shelves by the product spec; narrower ones stay open for the plumbing.
# Measured on the clear face-frame opening, not the bay.
VANITY_SHELVES_MIN_OPENING = inch(30.0)


def _bay_interior(bay):
    """OPEN / SHELF / VANITY_SHELVES as the bay's door openings carry it
    now, so re-editing an appliance bay seeds the dialog from what is
    there instead of clearing the shelves on the first live preview."""
    for child in bay.children_recursive:
        if not child.get(types_face_frame.TAG_OPENING_CAGE):
            continue
        op_props = child.face_frame_opening
        if op_props.front_type != 'DOOR':
            continue
        for item in op_props.interior_items:
            if item.kind == 'VANITY_SHELVES':
                return 'VANITY_SHELVES'
            if item.kind in ('ADJUSTABLE_SHELF', 'HALF_DEPTH_SHELF',
                             'QUARTER_DEPTH_SHELF'):
                return 'SHELF'
    return 'OPEN'


def _bay_door_opening_width(bay, root):
    """Widest clear face-frame opening among the bay's door openings,
    or None when the layout cannot be measured yet."""
    from .. import solver_face_frame
    sizes = solver_face_frame.opening_ff_sizes(root)
    best = None
    for child in bay.children_recursive:
        if not child.get(types_face_frame.TAG_OPENING_CAGE):
            continue
        if child.face_frame_opening.front_type != 'DOOR':
            continue
        size = sizes.get(child.name)
        if size is None:
            continue
        if best is None or size[0] > best:
            best = size[0]
    return best


def _auto_appliance_interior(appliance_kind, opening_width):
    """The interior a fresh appliance bay takes on its own: cooktops
    keep a shelf, sinks stay open for the plumbing, and a vanity sink
    whose opening reaches VANITY_SHELVES_MIN_OPENING gets the side
    shelves. Still user-selectable in the dialog."""
    if appliance_kind == 'COOKTOP':
        return 'SHELF'
    if (appliance_kind == 'VANITY_SINK' and opening_width is not None
            and opening_width + 1e-6 >= VANITY_SHELVES_MIN_OPENING):
        return 'VANITY_SHELVES'
    return 'OPEN'


# Re-entrancy guard: the dialog writes ``interior`` itself when it is
# following the width, and that write must not read as a user pick.
_appliance_interior_seeding = [False]


def _on_appliance_interior_edited(self, context):
    if not _appliance_interior_seeding[0]:
        self.interior_auto = False


def _appliance_finish_items(self, context):
    # Module-level list so Blender keeps the item strings alive.
    from .. import pulls
    return pulls.APPLIANCE_FINISHES


class hb_face_frame_OT_set_under_cabinet_appliance(bpy.types.Operator):
    """Hang a microwave or a short vent hood under the selected upper
    bay. Writes the choice, its overall size and its finish to the bay;
    the opening resizes around the appliance (raised by its height, and
    widened / narrowed to its width) and the recalc builds a block at
    that size in the space left below, running forward from the back of
    the cabinet so a unit deeper than the cabinet stands proud of the
    front.

    Block geometry only - the detailed models live in the separate
    appliance library and are swapped in over the block.
    """
    bl_idname = "hb_face_frame.set_under_cabinet_appliance"
    bl_label = "Under Cabinet Appliance"
    bl_description = ("Show a microwave or a short vent hood hanging "
                      "under this upper bay, in 3D and on the elevations")
    bl_options = {'REGISTER', 'UNDO'}

    # Per-kind starting sizes. Microwaves are a fixed 30" box; hoods are
    # ordered to the cabinet, so their width starts at 0 (follow the bay).
    _KIND_DEFAULTS = {
        'MICROWAVE': (inch(30.0), inch(16.0), inch(15.0)),
        'HOOD': (0.0, inch(6.0), inch(17.5)),
    }

    appliance: bpy.props.EnumProperty(
        name="Appliance",
        items=[
            ('NONE',      "None",      "Remove the appliance under this bay"),
            ('MICROWAVE', "Microwave", "Over-the-range microwave"),
            ('HOOD',      "Hood",      "Short under-cabinet vent hood"),
        ],
        default='MICROWAVE',
    )  # type: ignore
    width: bpy.props.FloatProperty(
        name="Width", unit='LENGTH', precision=4, default=inch(30.0), min=0.0,
        description="Width of the appliance; the opening resizes to it. "
                    "0 leaves the widths alone",
    )  # type: ignore
    height: bpy.props.FloatProperty(
        name="Height", unit='LENGTH', precision=4, default=inch(16.0), min=0.0,
        description="How far the appliance hangs below the bay; the "
                    "opening is raised by this much to make room",
    )  # type: ignore
    finish: bpy.props.EnumProperty(
        name="Finish",
        description="Metal finish on the appliance",
        items=_appliance_finish_items,
    )  # type: ignore
    depth: bpy.props.FloatProperty(
        name="Depth", unit='LENGTH', precision=4, default=inch(15.0), min=0.0,
        description="Front-to-back depth, measured from the back of the "
                    "cabinet",
    )  # type: ignore
    bay_name: bpy.props.StringProperty(default="", options={'SKIP_SAVE'})  # type: ignore
    # The kind the size fields were last seeded from, so re-picking the
    # appliance in the open dialog resets the sizes to that kind's
    # defaults without stomping a size the user has typed since.
    last_kind: bpy.props.StringProperty(default="", options={'SKIP_SAVE'})  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or not obj.get(types_face_frame.TAG_BAY_CAGE):
            return False
        root = types_face_frame.find_cabinet_root(obj)
        return (root is not None
                and root.face_frame_cabinet.cabinet_type == 'UPPER')

    def _resolve_bay(self, context):
        if self.bay_name:
            o = bpy.data.objects.get(self.bay_name)
            if o is not None and o.get(types_face_frame.TAG_BAY_CAGE):
                return o
        o = context.active_object
        if o is not None and o.get(types_face_frame.TAG_BAY_CAGE):
            return o
        return None

    def _seed_from_kind(self, kind):
        sizes = self._KIND_DEFAULTS.get(kind)
        if sizes is None:
            return
        self.width, self.height, self.depth = sizes
        self.last_kind = kind

    def invoke(self, context, event):
        bay = self._resolve_bay(context)
        if bay is None:
            self.report({'WARNING'}, "Select a bay first")
            return {'CANCELLED'}
        self.bay_name = bay.name
        props = bay.face_frame_bay
        current = props.under_cabinet_appliance
        if current == 'NONE':
            self.appliance = 'MICROWAVE'
            self._seed_from_kind('MICROWAVE')
        else:
            # Re-editing: show what the bay already carries.
            self.appliance = current
            self.width = props.under_cabinet_appliance_width
            self.height = props.under_cabinet_appliance_height
            self.depth = props.under_cabinet_appliance_depth
            self.last_kind = current
        self.finish = props.under_cabinet_appliance_finish
        return context.window_manager.invoke_props_dialog(self, width=300)

    def draw(self, context):
        # Switching the appliance in the open dialog re-seeds the sizes
        # to that kind's defaults.
        if self.appliance != 'NONE' and self.appliance != self.last_kind:
            self._seed_from_kind(self.appliance)
        layout = self.layout
        col = layout.column(align=True)
        col.prop(self, 'appliance', text="Appliance")
        sizes = col.column(align=True)
        sizes.enabled = self.appliance != 'NONE'
        sizes.prop(self, 'width')
        sizes.prop(self, 'height')
        sizes.prop(self, 'depth')
        sizes.prop(self, 'finish')
        if self.appliance != 'NONE':
            note = layout.column(align=True)
            note.scale_y = 0.8
            note.label(text="The opening is raised to make room.")
            note.label(text="Width 0 leaves the widths alone.")

    def execute(self, context):
        bay = self._resolve_bay(context)
        if bay is None:
            self.report({'WARNING'}, "Select a bay first")
            return {'CANCELLED'}
        props = bay.face_frame_bay
        with types_face_frame.suspend_recalc():
            # One suspend for the lot: each size write resizes the
            # opening on its own, and the recalcs they queue coalesce
            # into one at the end.
            props.under_cabinet_appliance_finish = self.finish
            props.under_cabinet_appliance_width = self.width
            props.under_cabinet_appliance_height = self.height
            props.under_cabinet_appliance_depth = self.depth
            # Kind last: its update does the opening resize, so the
            # sizes are already in place when the block gets built.
            props.under_cabinet_appliance = self.appliance
        root = types_face_frame.find_cabinet_root(bay)
        if root is not None:
            types_face_frame.recalculate_face_frame_cabinet(root)
        return {'FINISHED'}


class hb_face_frame_OT_add_appliance_to_bay(bpy.types.Operator):
    """Configure the active BASE bay as a sink or cooktop bay: apply a
    sink-style front preset, set the bay width, optionally drop the bay,
    and set the door interior. Stamps APPLIANCE_BAY on the bay cage so
    the recalc annotation pass draws the square + SINK/COOKTOP word on
    top of the bay. (3D appliance models are deferred. The apron config
    builds full-height doors with a top apron on the door opening.)

    Live preview: invoked via invoke_props_popup, so execute re-runs on
    every field edit and the bay updates in the viewport as options
    change (same pattern as the Appliance Panels dialog). The heavy
    preset rebuild is guarded by last_preset so a width / drop / filler
    tweak only re-runs the cheap prop writes + recalc.
    """
    bl_idname = "hb_face_frame.add_appliance_to_bay"
    bl_label = "Add Appliance to Bay"
    bl_description = (
        "Turn the selected base bay into a sink or cooktop bay. Sets "
        "the bay width and front layout and labels the bay on 2D drawings"
    )
    bl_options = {'REGISTER', 'UNDO'}

    appliance_kind: bpy.props.EnumProperty(
        name="Appliance",
        items=[
            ('KITCHEN_SINK', "Kitchen Sink", "Kitchen sink bay"),
            ('VANITY_SINK',  "Vanity Sink",  "Vanity sink bay"),
            ('COOKTOP',      "Cooktop",      "Cooktop bay"),
        ],
        default='KITCHEN_SINK',
        options={'SKIP_SAVE'},
    )  # type: ignore
    bay_name: bpy.props.StringProperty(default="", options={'SKIP_SAVE'})  # type: ignore
    # The bay preset applied by the last execute run. invoke_props_popup
    # re-runs execute on every edit with state persisting between runs, so
    # this keeps the destructive front-layout rebuild to actual
    # configuration / door-count changes.
    last_preset: bpy.props.StringProperty(default="", options={'SKIP_SAVE'})  # type: ignore
    # Which dialog session this instance belongs to (see
    # _appliance_dialog_session). 0 = not invoked through the popup
    # (direct EXEC / scripting), which is always allowed to run.
    session_id: bpy.props.IntProperty(default=0, options={'SKIP_SAVE', 'HIDDEN'})  # type: ignore
    width: bpy.props.FloatProperty(
        name="Width", unit='LENGTH', precision=4, default=inch(36.0),
    )  # type: ignore
    drop_bay_amount: bpy.props.FloatProperty(
        name="Drop Bay Amount", unit='LENGTH', precision=4,
        default=0.0, min=0.0,
        description="Lower the bay's top rail and front stretcher for the "
                    "sink / cooktop. The back, rear stretcher, sides and "
                    "end stiles stay full height",
    )  # type: ignore
    # Drop-band fillers: fit a farm sink / cooktop to the dropped opening.
    # Mirrors the APPLIANCE opening's filler dialog; written through to the
    # bay's front_drop_* props (see Face_Frame_Bay_Props).
    include_fillers: bpy.props.BoolProperty(
        name="Include Fillers", default=False,
        description="Build filler stiles in the dropped band so the clear "
                    "width fits the farm sink / cooktop",
    )  # type: ignore
    set_appliance_width: bpy.props.BoolProperty(
        name="Set Appliance Width", default=True,
        description="Enter the appliance width and split the remainder into "
                    "equal left/right fillers; off lets you type each filler "
                    "width directly",
    )  # type: ignore
    appliance_width: bpy.props.FloatProperty(
        name="Appliance Width", unit='LENGTH', precision=4,
        default=inch(30.0), min=0.0,
        description="Width of the farm sink / cooktop the dropped band "
                    "must fit",
    )  # type: ignore
    left_filler_amount: bpy.props.FloatProperty(
        name="Left Filler", unit='LENGTH', precision=4,
        default=0.0, min=0.0,
        description="Width of the left drop filler stile (used directly "
                    "when Set Appliance Width is off)",
    )  # type: ignore
    right_filler_amount: bpy.props.FloatProperty(
        name="Right Filler", unit='LENGTH', precision=4,
        default=0.0, min=0.0,
        description="Width of the right drop filler stile (used directly "
                    "when Set Appliance Width is off)",
    )  # type: ignore
    config: bpy.props.EnumProperty(
        name="Configuration",
        items=[
            ('FALSE_FRONT_DOORS', "False Front with Doors",
             "A false-front apron over door(s)"),
            ('FULL_HEIGHT_DOORS_APRON', "Full Height Doors with Apron",
             "Full-height door(s) with a sink apron across the top"),
            ('KEEP_EXISTING', "Keep Existing",
             "Leave the bay's current front layout unchanged"),
        ],
        default='FALSE_FRONT_DOORS',
    )  # type: ignore
    interior: bpy.props.EnumProperty(
        name="Interior",
        items=[
            ('OPEN',           "Open",           "No interior shelves"),
            ('SHELF',          "Shelf",          "Adjustable shelves"),
            ('VANITY_SHELVES', "Vanity Shelves", "L/R shelves on corbels"),
        ],
        default='SHELF',
        update=_on_appliance_interior_edited,
    )  # type: ignore
    # True while ``interior`` is still the dialog's own default and may
    # follow the appliance kind and width; any user pick pins it.
    interior_auto: bpy.props.BoolProperty(
        default=False, options={'HIDDEN', 'SKIP_SAVE'},
    )  # type: ignore

    def _seed_interior(self, value):
        _appliance_interior_seeding[0] = True
        try:
            self.interior = value
        finally:
            _appliance_interior_seeding[0] = False

    def _follow_interior(self, bay, root):
        """Keep an untouched Interior in step with the kind and the
        opening width as the live preview changes them."""
        if not self.interior_auto or root is None:
            return
        width = _bay_door_opening_width(bay, root)
        want = _auto_appliance_interior(self.appliance_kind, width)
        if want != self.interior:
            self._seed_interior(want)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get(types_face_frame.TAG_BAY_CAGE))

    def _resolve_bay(self, context):
        if self.bay_name:
            o = bpy.data.objects.get(self.bay_name)
            if o is not None and o.get(types_face_frame.TAG_BAY_CAGE):
                return o
        o = context.active_object
        if o is not None and o.get(types_face_frame.TAG_BAY_CAGE):
            return o
        return None

    def invoke(self, context, event):
        bay = self._resolve_bay(context)
        if bay is None:
            self.report({'WARNING'}, "Select a bay first")
            return {'CANCELLED'}
        self.bay_name = bay.name
        self.last_preset = ""
        # Newest dialog wins: stamp this instance and invalidate every
        # older popup still lingering on screen (their execute no-ops).
        _appliance_dialog_session[0] += 1
        self.session_id = _appliance_dialog_session[0]
        bp = bay.face_frame_bay
        # Re-editing an existing sink / cooktop bay: seed everything from
        # the bay and default the configuration to Keep Existing, so the
        # immediate live-preview execute below doesn't rebuild a front
        # layout the user may have customized.
        already_appliance = bay.get('APPLIANCE_BAY') in ('SINK', 'COOKTOP')
        if already_appliance:
            self.config = 'KEEP_EXISTING'
            self.width = bp.width
        else:
            # Fresh bay: explicit defaults (REGISTER remembers last-used
            # values across invocations; the defaults should win here).
            # A vanity sink base is narrow (20"); kitchen sink / cooktop
            # default to a 36" sink base. A bay whose fronts the user
            # already customized (a drawer stack, pullouts, splits)
            # opens on Keep Existing: the seeded execute below runs
            # BEFORE the popup shows, and applying the false-front
            # preset there would wipe a layout Keep Existing can never
            # bring back.
            presetlike = _bay_layout_is_presetlike(bay)
            self.config = ('FALSE_FRONT_DOORS' if presetlike
                           else 'KEEP_EXISTING')
            # Keep Existing also keeps the bay's width; the sink-base
            # width defaults only make sense when the preset rebuilds
            # the fronts anyway.
            self.width = (bp.width if not presetlike
                          else inch(20.0) if self.appliance_kind == 'VANITY_SINK'
                          else inch(36.0))
        # Re-editing keeps whatever interior the bay already has. A fresh
        # bay follows the kind and width (see _auto_appliance_interior)
        # until the user picks one; the width-based seed happens in the
        # live preview once the bay has been resized.
        if already_appliance:
            self.interior_auto = False
            self._seed_interior(_bay_interior(bay))
        else:
            self.interior_auto = True
            self._seed_interior(
                _auto_appliance_interior(self.appliance_kind, None))
        # Seed the drop + filler fields from the bay's current state so
        # re-running the dialog edits in place instead of resetting.
        self.drop_bay_amount = bp.front_drop
        self.include_fillers = bp.front_drop_include_fillers
        self.set_appliance_width = bp.front_drop_set_appliance_width
        self.appliance_width = bp.front_drop_appliance_width
        self.left_filler_amount = bp.front_drop_left_filler
        self.right_filler_amount = bp.front_drop_right_filler
        # Snapshot everything the live preview may touch so Cancel can
        # put it back. (The front-layout preset is NOT previewed -- it
        # only applies on OK -- so the snapshot stays scalar.)
        self._revert = {
            'appliance_bay': bay.get('APPLIANCE_BAY'),
            'appliance_bay_kind': bay.get('APPLIANCE_BAY_KIND'),
            'width': bp.width,
            'unlock_width': bp.unlock_width,
            'front_drop': bp.front_drop,
            'include_fillers': bp.front_drop_include_fillers,
            'set_appliance_width': bp.front_drop_set_appliance_width,
            'appliance_width': bp.front_drop_appliance_width,
            'left_filler': bp.front_drop_left_filler,
            'right_filler': bp.front_drop_right_filler,
        }
        # A true dialog (OK / Cancel), NOT invoke_props_popup: the popup
        # re-runs execute through the operator-repeat machinery, whose
        # undo + re-execute rolled the bay back to its pre-dialog layout
        # on every later edit (the last_preset guard then skipped the
        # rebuild, so the viewport snapped back to the old fronts).
        # check() live-previews the cheap reversible writes instead;
        # the destructive front-layout preset waits for OK.
        return context.window_manager.invoke_props_dialog(self, width=380)

    def check(self, context):
        """Live preview on each dialog edit: width / drop / fillers /
        appliance stamp. Cheap prop writes + one recalc -- no front
        layout rebuild (that happens on OK) so every edit is fully
        reversible by Cancel."""
        applied = self._apply_scalars(context)
        if applied is not None:
            self._follow_interior(*applied)
        return True

    def cancel(self, context):
        """Dialog dismissed (Cancel / Esc / click-away): restore the
        state the live preview touched."""
        snap = getattr(self, '_revert', None)
        bay = self._resolve_bay(context)
        if snap is None or bay is None:
            return
        root = types_face_frame.find_cabinet_root(bay)
        with types_face_frame.suspend_recalc():
            for key, tag in (('appliance_bay', 'APPLIANCE_BAY'),
                             ('appliance_bay_kind', 'APPLIANCE_BAY_KIND')):
                if snap[key] is None:
                    if tag in bay:
                        del bay[tag]
                else:
                    bay[tag] = snap[key]
            bp = bay.face_frame_bay
            bp.width = snap['width']
            bp.unlock_width = snap['unlock_width']
            bp.front_drop = snap['front_drop']
            bp.front_drop_include_fillers = snap['include_fillers']
            bp.front_drop_set_appliance_width = snap['set_appliance_width']
            bp.front_drop_appliance_width = snap['appliance_width']
            bp.front_drop_left_filler = snap['left_filler']
            bp.front_drop_right_filler = snap['right_filler']
            if root is not None:
                types_face_frame.recalculate_face_frame_cabinet(root)

    def _apply_scalars(self, context):
        """The reversible live-preview writes shared by check() and
        execute(): appliance stamps, bay width, drop and fillers."""
        if self.session_id and self.session_id != _appliance_dialog_session[0]:
            return None
        bay = self._resolve_bay(context)
        if bay is None:
            return None
        root = types_face_frame.find_cabinet_root(bay)
        if root is None or root.face_frame_cabinet.cabinet_type != 'BASE':
            return None
        with types_face_frame.suspend_recalc():
            # Durable annotation signal: the bay cage persists across
            # recalcs, so _apply_appliance_annotations can rebuild the
            # square + word from this stamp every pass.
            bay['APPLIANCE_BAY'] = ('COOKTOP' if self.appliance_kind == 'COOKTOP'
                                    else 'SINK')
            # The annotation pass only needs SINK vs COOKTOP, but 2D
            # consumers distinguish kitchen from vanity sinks (e.g.
            # depth callout rules), so keep the specific kind too.
            bay['APPLIANCE_BAY_KIND'] = self.appliance_kind
            bp = bay.face_frame_bay
            # Width setter auto-locks unlock_width.
            bp.width = self.width
            # Drop: lower the bay's FRONT construction (top rail + front
            # stretcher) by the amount. Only the front drops - the back,
            # rear stretcher, sides and end / mid stiles stay full height
            # to carry the countertop; the basin occupies the open band
            # behind the dropped rail. Assigned (not added) so re-running
            # the dialog replaces the drop instead of compounding it.
            bp.front_drop = self.drop_bay_amount
            # Drop-band fillers: written through even when the drop is 0
            # or fillers are off - the solver gates on front_drop +
            # include, so stale filler parts reconcile away.
            bp.front_drop_include_fillers = self.include_fillers
            bp.front_drop_set_appliance_width = self.set_appliance_width
            bp.front_drop_appliance_width = self.appliance_width
            bp.front_drop_left_filler = self.left_filler_amount
            bp.front_drop_right_filler = self.right_filler_amount
            types_face_frame.recalculate_face_frame_cabinet(root)
        return bay, root

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        row = box.row(); row.label(text="Width:")
        row.prop(self, 'width', text="")
        row = box.row(); row.label(text="Drop Bay Amount:")
        row.prop(self, 'drop_bay_amount', text="")
        if self.drop_bay_amount > 0.0:
            # Drop-band fillers, mirroring the appliance opening's dialog.
            fbox = box.box()
            fbox.prop(self, 'include_fillers')
            if self.include_fillers:
                fbox.prop(self, 'set_appliance_width')
                if self.set_appliance_width:
                    row = fbox.row(); row.label(text="Appliance Width:")
                    row.prop(self, 'appliance_width', text="")
                else:
                    row = fbox.row(); row.label(text="Left Filler:")
                    row.prop(self, 'left_filler_amount', text="")
                    row = fbox.row(); row.label(text="Right Filler:")
                    row.prop(self, 'right_filler_amount', text="")
        box.label(text="Configuration:")
        box.prop(self, 'config', expand=True)
        box.label(text="Interior:")
        box.prop(self, 'interior', expand=True)
        if (self.appliance_kind == 'VANITY_SINK'
                and self.interior == 'VANITY_SHELVES' and self.interior_auto):
            box.label(text='Opening is 30" or wider: side shelves added',
                      icon='INFO')
        # Width / drop / fillers preview live; the front-layout rebuild
        # is deliberately deferred so Cancel can restore everything.
        box.label(text="Configuration and Interior apply on OK",
                  icon='INFO')

    def execute(self, context):
        # Stale-dialog guard: only the NEWEST dialog may touch the bay.
        # session_id 0 (direct EXEC / scripting, never invoked) is allowed.
        if self.session_id and self.session_id != _appliance_dialog_session[0]:
            return {'CANCELLED'}
        bay = self._resolve_bay(context)
        if bay is None:
            self.report({'WARNING'}, "Select a bay first")
            return {'CANCELLED'}
        root = types_face_frame.find_cabinet_root(bay)
        if root is None:
            self.report({'WARNING'}, "Bay is not part of a cabinet")
            return {'CANCELLED'}
        if root.face_frame_cabinet.cabinet_type != 'BASE':
            self.report({'WARNING'}, "Appliances are only supported on base bays")
            return {'CANCELLED'}

        # Friendly config -> bay preset. Single vs double doors follows the
        # same width threshold the auto presets use. The apron is added
        # per-opening below (add_apron) for the apron config.
        wide = self.width >= bay_presets.DOUBLE_DOOR_WIDTH_THRESHOLD
        # KEEP_EXISTING leaves the bay's current front layout untouched
        # (preset stays None, and the apron toggle below is skipped); only the
        # width / drop / interior / appliance label are applied.
        preset = None
        if self.config == 'FALSE_FRONT_DOORS':
            preset = 'FALSE_FRONT_DOUBLE_DOOR' if wide else 'FALSE_FRONT_DOOR'
        elif self.config == 'FULL_HEIGHT_DOORS_APRON':
            preset = 'DOUBLE_DOOR' if wide else 'LEFT_SWING_DOOR'

        with types_face_frame.suspend_recalc():
            # The destructive front-layout rebuild happens HERE (OK),
            # never in the live preview -- so Cancel always has a bay
            # layout to go back to. last_preset still guards a repeat
            # execute (OK after OK via redo) from rebuilding twice.
            if (preset is not None and preset != self.last_preset
                    and not apply_bay_preset(bay, preset)):
                self.report({'WARNING'},
                            f"Bay does not accept preset {preset!r}")
                return {'CANCELLED'}
            if preset is not None:
                self.last_preset = preset
        if self._apply_scalars(context) is None:
            return {'CANCELLED'}
        self._follow_interior(bay, root)
        with types_face_frame.suspend_recalc():
            # Interior on the door opening(s) only - skip the false-front
            # apron opening. Walk recursively since the preset nests the
            # openings under a vertical split cage.
            for child in bay.children_recursive:
                if not child.get(types_face_frame.TAG_OPENING_CAGE):
                    continue
                op_props = child.face_frame_opening
                if op_props.front_type == 'DOOR':
                    _set_opening_interior(op_props, self.interior)
                    # Full-height-doors-with-apron adds the per-opening
                    # sink apron across the top of the door opening.
                    if self.config == 'FULL_HEIGHT_DOORS_APRON':
                        op_props.add_apron = True
            types_face_frame.recalculate_face_frame_cabinet(root)

        # Re-apply selection mode so the rebuilt cages render correctly.
        # DIRECT call, not bpy.ops.hb_face_frame.toggle_mode: a nested
        # operator call would steal the "last redo" slot.
        try:
            apply_face_frame_selection_mode(context, root)
        except Exception:
            pass

        self.report({'INFO'},
                    f"Configured {self.appliance_kind.replace('_', ' ').title()} bay")
        return {'FINISHED'}


class hb_face_frame_OT_remove_appliance_from_bay(bpy.types.Operator):
    """Remove the sink / cooktop designation from the active bay: marks
    the bay non-appliance (APPLIANCE_BAY = 'NONE' -- an explicit opt-out
    so the dedicated sink cabinet's auto-detect doesn't re-add it) and
    clears the sink apron flag on the bay's door openings. The recalc
    annotation pass then wipes the square + word. The bay's front layout
    is left as-is (use Change Bay to reconfigure it).
    """
    bl_idname = "hb_face_frame.remove_appliance_from_bay"
    bl_label = "Remove Appliance from Bay"
    bl_description = (
        "Remove the sink or cooktop label from the selected bay. The "
        "bay's front layout is left as-is; use Change Bay to reconfigure it"
    )
    bl_options = {'UNDO'}

    bay_name: bpy.props.StringProperty(default="", options={'SKIP_SAVE'})  # type: ignore

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and bool(obj.get(types_face_frame.TAG_BAY_CAGE))

    def execute(self, context):
        bay = None
        if self.bay_name:
            o = bpy.data.objects.get(self.bay_name)
            if o is not None and o.get(types_face_frame.TAG_BAY_CAGE):
                bay = o
        if bay is None:
            o = context.active_object
            if o is not None and o.get(types_face_frame.TAG_BAY_CAGE):
                bay = o
        if bay is None:
            self.report({'WARNING'}, "Select a bay first")
            return {'CANCELLED'}
        root = types_face_frame.find_cabinet_root(bay)
        if root is None:
            self.report({'WARNING'}, "Bay is not part of a cabinet")
            return {'CANCELLED'}

        with types_face_frame.suspend_recalc():
            bay['APPLIANCE_BAY'] = 'NONE'
            for child in bay.children_recursive:
                if not child.get(types_face_frame.TAG_OPENING_CAGE):
                    continue
                op_props = child.face_frame_opening
                if op_props.front_type == 'DOOR' and op_props.add_apron:
                    op_props.add_apron = False
            types_face_frame.recalculate_face_frame_cabinet(root)

        self.report({'INFO'}, "Removed appliance from bay")
        return {'FINISHED'}


class hb_face_frame_OT_refresh_top_drawer_openings(bpy.types.Operator):
    """Re-apply the scene Top Drawer Opening Height to every drawer-preset
    top opening in the current scene.

    Cabinets pin their top drawer opening to the scene value when built
    (the 'TOP_DRAWER' size role, stamped as SIZE_ROLE on the opening, or
    on the split node that later took over its slot); changing the value
    afterward does not re-flow existing cabinets, so this pushes the
    current value back out to them.
    """
    bl_idname = "hb_face_frame.refresh_top_drawer_openings"
    bl_label = "Refresh Top Drawer Openings"
    bl_description = ("Re-apply the Top Drawer Opening Height to existing "
                      "drawer-preset cabinets in this scene")
    bl_options = {'UNDO'}

    @staticmethod
    def _row_node(obj):
        """Resolve a stamped node to the node that occupies the drawer ROW.

        A node's size is measured along its parent split's axis: under an
        'H' split it is a height, under a 'V' split a width. Files written
        before the stamp moved with the split node can carry the role on an
        opening that has since been split side-by-side, where writing size
        would set that opening's WIDTH and leave its siblings to absorb the
        difference. Walk up out of any V-splits so the write always lands on
        the node whose size is the row height.
        """
        node = obj
        while True:
            parent = node.parent
            if (parent is None
                    or not parent.get(types_face_frame.TAG_SPLIT_NODE)
                    or parent.face_frame_split.axis != 'V'):
                return node
            node = parent

    def execute(self, context):
        val = context.scene.hb_face_frame.top_drawer_opening_height
        count = 0
        done = set()
        for obj in context.scene.objects:
            if obj.get('SIZE_ROLE') != 'TOP_DRAWER':
                continue
            node = self._row_node(obj)
            # Side-by-side siblings can resolve to the same row; write once.
            if node.name in done:
                continue
            done.add(node.name)
            props = (node.face_frame_split
                     if node.get(types_face_frame.TAG_SPLIT_NODE)
                     else node.face_frame_opening)
            # unlock_size BEFORE size: the size write fires a recalc, and an
            # unlocked node would just redistribute over the new value.
            props.unlock_size = True
            props.size = val
            count += 1
        self.report({'INFO'}, f"Refreshed {count} top drawer opening(s)")
        return {'FINISHED'}


class FloatingShelfRow(bpy.types.PropertyGroup):
    """One row in the multi-shelf adjust dialog: a shelf's elevation + thickness."""
    obj_name: bpy.props.StringProperty()  # type: ignore
    elevation: bpy.props.FloatProperty(name="Elevation", unit='LENGTH', precision=5)  # type: ignore
    thickness: bpy.props.FloatProperty(name="Thickness", unit='LENGTH', precision=5)  # type: ignore


def _selected_floating_shelf_roots(context):
    """Unique floating-shelf cabinet roots among the current selection.

    Walks up from each selected object to its cabinet root and de-duplicates
    so two selected parts of one shelf count once.
    """
    roots = []
    for obj in context.selected_objects:
        root = types_face_frame.find_cabinet_root(obj)
        if root is not None and root.get('IS_FLOATING_SHELF') and root not in roots:
            roots.append(root)
    return roots


class hb_face_frame_OT_adjust_floating_shelves(bpy.types.Operator):
    """Set the floor height, spacing, and thickness of several selected
    floating shelves at once. Bottom Height + Spacing distribute the stack
    evenly (Spacing is the clear gap between shelves); each shelf's elevation
    and thickness can also be edited individually."""
    bl_idname = "hb_face_frame.adjust_floating_shelves"
    bl_label = "Adjust Floating Shelves"
    bl_description = "Set the floor height, spacing, and thickness of the selected floating shelves"
    bl_options = {'UNDO'}

    bottom_height: bpy.props.FloatProperty(name="Bottom Height", unit='LENGTH', precision=5)  # type: ignore
    spacing: bpy.props.FloatProperty(name="Spacing", unit='LENGTH', precision=5)  # type: ignore
    shelves: bpy.props.CollectionProperty(type=FloatingShelfRow)  # type: ignore

    # Previous summary values, used to detect which field the user edited.
    _prev_bottom = 0.0
    _prev_spacing = 0.0

    @classmethod
    def poll(cls, context):
        return len(_selected_floating_shelf_roots(context)) > 1

    @staticmethod
    def _parent_z(obj):
        return obj.parent.matrix_world.translation.z if obj.parent else 0.0

    def invoke(self, context, event):
        roots = _selected_floating_shelf_roots(context)
        # Bottom-to-top by world height so the row order matches the model.
        roots.sort(key=lambda o: o.matrix_world.translation.z)

        self.shelves.clear()
        for root in roots:
            row = self.shelves.add()
            row.obj_name = root.name
            row.elevation = root.matrix_world.translation.z
            row.thickness = root.face_frame_cabinet.height

        self.bottom_height = self.shelves[0].elevation
        if len(self.shelves) > 1:
            first = self.shelves[0]
            self.spacing = self.shelves[1].elevation - (first.elevation + first.thickness)
        self._prev_bottom = self.bottom_height
        self._prev_spacing = self.spacing

        return context.window_manager.invoke_props_dialog(self, width=380)

    def check(self, context):
        eps = 1e-6
        bottom_changed = abs(self.bottom_height - self._prev_bottom) > eps
        spacing_changed = abs(self.spacing - self._prev_spacing) > eps

        if bottom_changed or spacing_changed:
            # Redistribute from the bottom using a uniform clear gap (top face
            # of one shelf to the bottom face of the next).
            z = self.bottom_height
            for row in self.shelves:
                row.elevation = z
                z += row.thickness + self.spacing
        else:
            # A per-shelf field was edited - keep those values and refresh the
            # summary fields from the lowest shelf.
            if len(self.shelves) > 0:
                self.bottom_height = self.shelves[0].elevation
            if len(self.shelves) > 1:
                first = self.shelves[0]
                self.spacing = self.shelves[1].elevation - (first.elevation + first.thickness)

        self.apply_to_scene(context)
        self._prev_bottom = self.bottom_height
        self._prev_spacing = self.spacing
        return True

    def apply_to_scene(self, context):
        for row in self.shelves:
            obj = bpy.data.objects.get(row.obj_name)
            if obj is None:
                continue
            # Setting height runs the cabinet's dim update callback, which
            # rebuilds the shelf; only write it when it actually changed.
            if abs(obj.face_frame_cabinet.height - row.thickness) > 1e-7:
                obj.face_frame_cabinet.height = row.thickness
            # location.z is parent-relative (the wall sits on the floor at
            # z=0), so convert the desired world elevation back to local.
            obj.location.z = row.elevation - self._parent_z(obj)

    def execute(self, context):
        self.apply_to_scene(context)
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Distribution")
        col = box.column(align=True)
        row = col.row(align=True)
        row.label(text="Bottom Height:")
        row.prop(self, 'bottom_height', text="")
        row = col.row(align=True)
        row.label(text="Spacing (clear gap):")
        row.prop(self, 'spacing', text="")

        box = layout.box()
        box.label(text="Shelves (bottom to top)")
        col = box.column(align=True)
        for i, row in enumerate(self.shelves):
            r = col.row(align=True)
            r.label(text=f"{i + 1}:")
            r.prop(row, 'elevation', text="Elev")
            r.prop(row, 'thickness', text="Thick")


classes = (
    FloatingShelfRow,
    hb_face_frame_OT_draw_cabinet,
    hb_face_frame_OT_column_beam_properties,
    hb_face_frame_OT_create_cabinet_group,
    hb_face_frame_OT_select_cabinet_group,
    hb_face_frame_OT_ungroup_cabinet,
    hb_face_frame_OT_delete_cabinet,
    hb_face_frame_OT_join_cabinets,
    hb_face_frame_OT_break_cabinet_left,
    hb_face_frame_OT_break_cabinet_right,
    hb_face_frame_OT_break_cabinet_both,
    hb_face_frame_OT_equalize_bays,
    hb_face_frame_OT_equalize_opening_heights,
    hb_face_frame_OT_wood_top_prompts,
    hb_face_frame_OT_toggle_mode,
    hb_face_frame_OT_cabinet_prompts,
    hb_face_frame_OT_leg_product_prompts,
    hb_face_frame_OT_floating_shelf_prompts,
    hb_face_frame_OT_valance_prompts,
    hb_face_frame_OT_mantle_prompts,
    hb_face_frame_OT_panel_layout_prompts,
    hb_face_frame_OT_panel_remove_stile,
    hb_face_frame_OT_toggle_front_open,
    AccessorySearchRow,
    HB_UL_face_frame_drawer_items,
    HB_UL_face_frame_drawer_catalog,
    hb_face_frame_OT_drawer_add_accessory,
    hb_face_frame_OT_drawer_remove_accessory,
    hb_face_frame_OT_set_drawer_box_construction,
    hb_face_frame_OT_set_drawer_slides,
    hb_face_frame_OT_drawer_interior,
    hb_face_frame_OT_duplicate_floating_shelf,
    hb_face_frame_OT_adjust_floating_shelves,
    hb_face_frame_OT_bay_prompts,
    hb_face_frame_OT_opening_prompts,
    hb_face_frame_OT_interior_options,
    hb_face_frame_OT_finish_opening_prompts,
    hb_face_frame_OT_finish_bay_prompts,
    hb_face_frame_OT_drawer_box_prompts,
    hb_face_frame_OT_sink_duo_drawer_prompts,
    hb_face_frame_OT_rollout_above_drawer_prompts,
    hb_face_frame_OT_sink_duo_rollout_prompts,
    hb_face_frame_OT_split_opening,
    hb_face_frame_OT_mid_stile_prompts,
    hb_face_frame_OT_add_interior_item,
    hb_face_frame_OT_remove_interior_item,
    hb_face_frame_OT_apply_shelf_nosing_to_room,
    hb_face_frame_OT_add_rollout_box,
    hb_face_frame_OT_remove_rollout_box,
    hb_face_frame_OT_add_interior_division,
    hb_face_frame_OT_add_interior_fixed_shelf,
    hb_face_frame_OT_remove_interior_split,
    hb_face_frame_OT_show_interior_add_menu,
    hb_face_frame_OT_change_opening,
    hb_face_frame_OT_change_bay,
    hb_face_frame_OT_toggle_flush_toe_kick,
    hb_face_frame_OT_set_bay_back_type,
    hb_face_frame_OT_add_pullout_accessory,
    hb_face_frame_OT_add_interior_accessory,
    hb_face_frame_OT_accessory_menu,
    HB_UL_face_frame_accessory_search,
    hb_face_frame_OT_add_appliance_to_bay,
    hb_face_frame_OT_set_under_cabinet_appliance,
    hb_face_frame_OT_remove_appliance_from_bay,
    hb_face_frame_OT_insert_bay,
    hb_face_frame_OT_delete_bay,
    hb_face_frame_OT_set_equal_door_width,
    hb_face_frame_OT_refresh_top_drawer_openings,
)


register, unregister = bpy.utils.register_classes_factory(classes)
